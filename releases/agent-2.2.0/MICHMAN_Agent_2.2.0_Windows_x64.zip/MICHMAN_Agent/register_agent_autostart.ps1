param(
    [Parameter(Mandatory=$true)][string]$AgentExe,
    [Parameter(Mandatory=$true)][string]$ConfigDirectory
)
$ErrorActionPreference = 'Stop'
$taskAgentPath = (Resolve-Path -LiteralPath $AgentExe).Path
$taskConfigPath = (Resolve-Path -LiteralPath $ConfigDirectory).Path
if (-not (Test-Path -LiteralPath (Join-Path $taskConfigPath 'agent.json'))) { throw 'Enrollment agent.json not found' }
$taskAction = New-ScheduledTaskAction -Execute $taskAgentPath -Argument ('--background --config-dir "' + $taskConfigPath + '"')
$taskTrigger = New-ScheduledTaskTrigger -AtLogOn -User ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
$taskPrincipal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
$taskSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 10 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName 'MICHMAN Agent (background)' -Action $taskAction -Trigger $taskTrigger -Principal $taskPrincipal -Settings $taskSettings -Description 'Background managed endpoint agent. Desktop assistance always requires local consent.' -Force
