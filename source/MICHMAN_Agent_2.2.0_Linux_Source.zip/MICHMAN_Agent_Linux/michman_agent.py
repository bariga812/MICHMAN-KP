"""Visible, opt-in Windows/Linux administration agent with mutual TLS."""
import argparse
import base64
import hashlib
import io
import json
import os
import platform
import queue
import re
import shutil
import socket
import ssl
import subprocess
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request,urlopen
from michman_identity import require
from michman_utils import atomic_write_json

MAX_BODY=2*1024*1024
CHUNK=1024*1024
KEYBOARD_LOCK=threading.RLock()
CONSENT_PROMPT_LOCK=threading.Lock()
TLS12_CIPHERS='ECDHE+AESGCM:ECDHE+CHACHA20'
REQUIRED_ENROLLMENT_FILES=('agent.json','ca.pem','server.pem','server-key.pem')
AGENT_VERSION='2.2.0'


def startup_trace(stage):
    path=os.environ.get('MICHMAN_AGENT_STARTUP_TRACE')
    if path:
        with open(path,'a',encoding='utf-8') as handle:handle.write(stage+'\n')


def secure_tls_context(context):
    """Require authenticated modern TLS; TLS 1.3 remains preferred when available."""
    context.minimum_version=ssl.TLSVersion.TLSv1_2
    context.options|=getattr(ssl,'OP_NO_COMPRESSION',0)
    context.set_ciphers(TLS12_CIPHERS)
    return context


def atomic_hotkey(backend,keys):
    # Always release keys owned by this atomic chord, even after fail-safe.
    with KEYBOARD_LOCK:
        pressed=[]
        try:
            for key in keys:
                pressed.append(key);backend.keyDown(key,_pause=False)
        finally:
            failsafe=backend.FAILSAFE
            try:
                backend.FAILSAFE=False
                for key in reversed(pressed):backend.keyUp(key,_pause=False)
            finally:backend.FAILSAFE=failsafe



def run_process(args,timeout=30):
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0) if os.name=='nt' else 0
    result=subprocess.run(args,capture_output=True,timeout=timeout,encoding='utf-8',errors='replace',creationflags=flags)
    return {'returncode':result.returncode,'stdout':result.stdout[-250000:],'stderr':result.stderr[-250000:]}


def powershell(script,timeout=30):
    encoded=base64.b64encode(script.encode('utf-16-le')).decode()
    return run_process(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded],timeout)


def telemetry(agent_id):
    import psutil
    disks=[]
    for partition in psutil.disk_partitions(all=False):
        try:
            usage=psutil.disk_usage(partition.mountpoint)
            disks.append({'mountpoint':partition.mountpoint,'total':usage.total,'free':usage.free,'percent':usage.percent})
        except (OSError,PermissionError): pass
    memory=psutil.virtual_memory()
    macs=[]
    for addresses in psutil.net_if_addrs().values():
        for address in addresses:
            value=str(address.address or '').upper().replace('-',':')
            if re.fullmatch(r'[0-9A-F]{2}(?::[0-9A-F]{2}){5}',value) and value!='00:00:00:00:00:00' and value not in macs:
                macs.append(value)
    return {'agent_id':agent_id,'agent_version':AGENT_VERSION,'name':socket.gethostname(),'os':platform.platform(),'cpu_percent':psutil.cpu_percent(interval=.2),
            'ram_percent':memory.percent,'ram_total':memory.total,'ram_available':memory.available,'disks':disks,
            'mac_addresses':macs,'primary_mac':macs[0] if macs else '',
            'uptime':int(time.time()-psutil.boot_time()),'collected_at':time.time()}


def hardware_snapshot():
    import psutil
    memory=psutil.virtual_memory();frequency=psutil.cpu_freq()
    return {
        'hostname':socket.gethostname(),'fqdn':socket.getfqdn(),'os':platform.platform(),
        'system':platform.system(),'release':platform.release(),'version':platform.version(),
        'architecture':platform.machine(),'processor':platform.processor(),
        'cpu_physical':psutil.cpu_count(logical=False),'cpu_logical':psutil.cpu_count(logical=True),
        'cpu_frequency_mhz':round(frequency.current,1) if frequency else None,
        'ram_total':memory.total,'boot_time':psutil.boot_time(),
    }


def network_snapshot():
    import psutil
    adapters=[];stats=psutil.net_if_stats();counters=psutil.net_io_counters(pernic=True)
    for name,addresses in psutil.net_if_addrs().items():
        item={'name':name,'up':bool(stats.get(name) and stats[name].isup),'speed_mbps':stats[name].speed if name in stats else 0,
              'mtu':stats[name].mtu if name in stats else 0,'addresses':[]}
        for address in addresses:
            item['addresses'].append({'family':str(address.family),'address':str(address.address),'netmask':str(address.netmask or '')})
        traffic=counters.get(name)
        item.update({'rx_bytes':traffic.bytes_recv if traffic else 0,'tx_bytes':traffic.bytes_sent if traffic else 0,
                     'rx_errors':traffic.errin if traffic else 0,'tx_errors':traffic.errout if traffic else 0,
                     'rx_drops':traffic.dropin if traffic else 0,'tx_drops':traffic.dropout if traffic else 0})
        adapters.append(item)
    return {'hostname':socket.gethostname(),'adapters':adapters,'collected_at':time.time()}


def health_snapshot():
    import psutil
    memory=psutil.virtual_memory();cpu=psutil.cpu_percent(interval=.25,percpu=True)
    disks=[]
    for partition in psutil.disk_partitions(all=False):
        try:
            usage=psutil.disk_usage(partition.mountpoint)
            disks.append({'mountpoint':partition.mountpoint,'total':usage.total,'free':usage.free,'percent':usage.percent})
        except (OSError,PermissionError):pass
    try:
        battery=psutil.sensors_battery()
        battery_data={'percent':battery.percent,'plugged':battery.power_plugged,'seconds_left':battery.secsleft} if battery else None
    except (AttributeError,OSError):battery_data=None
    temperatures=[]
    try:
        for group,entries in (psutil.sensors_temperatures() or {}).items():
            for entry in entries[:16]:temperatures.append({'group':group,'label':entry.label,'current':entry.current,'high':entry.high,'critical':entry.critical})
    except (AttributeError,OSError):pass
    max_disk=max((disk['percent'] for disk in disks),default=0);cpu_average=sum(cpu)/len(cpu) if cpu else 0
    warnings=[]
    if cpu_average>=90:warnings.append('Критичне завантаження CPU')
    if memory.percent>=90:warnings.append('Критичне використання RAM')
    if max_disk>=90:warnings.append('На одному з дисків залишилося менше 10%')
    if battery_data and not battery_data['plugged'] and battery_data['percent']<=15:warnings.append('Низький заряд батареї')
    if any(t.get('critical') and t['current']>=t['critical'] for t in temperatures):warnings.append('Критична температура')
    score=max(0,100-25*len(warnings)-max(0,int(max(cpu_average,memory.percent,max_disk)-80)))
    return {'score':score,'status':'CRITICAL' if score<50 else 'WARNING' if score<80 else 'OK',
            'cpu_percent':round(cpu_average,1),'cpu_per_core':[round(value,1) for value in cpu],
            'ram_percent':memory.percent,'ram_available':memory.available,'disks':disks,'max_disk_percent':max_disk,
            'battery':battery_data,'temperatures':temperatures,'warnings':warnings,'collected_at':time.time()}


class AgentRuntime:
    def __init__(self,directory,consent=None):
        self.directory=Path(directory).resolve()
        self.config=json.loads((self.directory/'agent.json').read_text(encoding='utf-8'))
        self.root=(self.directory/self.config.get('file_root','shared')).resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.consent=consent
        self.lock=threading.RLock()
        self.sessions={}
        self.uploads={}
        self.audit_lock=threading.Lock()

    def audit(self,user,action,result):
        from logging import getLogger,Formatter,INFO
        from logging.handlers import RotatingFileHandler
        with self.audit_lock:
            logger=getLogger('michman-agent-'+str(self.directory))
            if not logger.handlers:
                handler=RotatingFileHandler(self.directory/'agent-audit.jsonl',maxBytes=5*1024*1024,backupCount=10,encoding='utf-8')
                handler.setFormatter(Formatter('%(message)s'))
                logger.addHandler(handler);logger.setLevel(INFO);logger.propagate=False
            logger.info(json.dumps({'ts':time.time(),'actor':user,'action':action,'result':result},ensure_ascii=False))

    def path(self,value):
        candidate=(self.root/str(value)).resolve()
        if not candidate.is_relative_to(self.root):
            raise PermissionError('Доступ дозволено лише в shared-папці агента.')
        return candidate

    def session(self,user,token):
        with self.lock:
            session=self.sessions.get(token)
            if not session or session['user']!=user or (session.get('expires') is not None and session['expires']<time.monotonic()):
                raise PermissionError('Немає активної згоди користувача на віддалену допомогу.')
            return session

    def revoke_assistance(self):
        with self.lock: self.sessions.clear()

    def rpc(self,user,role,action,p):
        if action=='assist_input':
            with KEYBOARD_LOCK:return self._rpc(user,role,action,p)
        return self._rpc(user,role,action,p)

    def _rpc(self,user,role,action,p):
        capability={'telemetry':'read','health':'read','hardware':'read','network_info':'read','agent_diagnostics':'read','processes':'read','services':'read','software':'read','events':'read','updates':'read',
            'files_list':'files','files_read':'files','files_stat':'files','files_mkdir':'files','upload_start':'files','upload_chunk':'files','upload_finish':'files','upload_cancel':'files','files_delete':'files',
            'service_control':'service','terminate':'command','command':'command','power':'power','install_updates':'deploy',
            'assist_request':'assist','assist_frame':'assist','assist_input':'assist','assist_stop':'assist','revoke_user':'users'}.get(action)
        if not capability: raise ValueError('Невідома дія')
        require(role,capability)
        if action=='telemetry':
            result=telemetry(self.config['agent_id'])
            result['services']={}
            for name in self.config.get('monitored_services',[])[:50]:
                try:
                    if os.name=='nt':
                        import psutil
                        result['services'][name]=psutil.win_service_get(name).status()
                    else:
                        result['services'][name]=run_process(['systemctl','is-active','--',name],5)['stdout'].strip()
                except Exception as error:result['services'][name]='unavailable'
            return result
        if action=='health':return health_snapshot()
        if action=='hardware':return hardware_snapshot()
        if action=='network_info':return network_snapshot()
        if action=='agent_diagnostics':
            try:
                certificate=ssl._ssl._test_decode_cert(str(self.directory/'server.pem'))
                certificate_info={'subject':certificate.get('subject'),'issuer':certificate.get('issuer'),'not_after':certificate.get('notAfter')}
            except Exception:certificate_info={}
            return {'agent_id':self.config.get('agent_id'),'agent_version':AGENT_VERSION,'bind':self.config.get('bind','0.0.0.0'),
                    'port':int(self.config.get('port',8743)),'file_root':str(self.root),'active_sessions':len(self.sessions),
                    'active_uploads':len(self.uploads),'audit_size':(self.directory/'agent-audit.jsonl').stat().st_size if (self.directory/'agent-audit.jsonl').exists() else 0,
                    'tls_minimum':'TLS 1.2','mutual_tls':True,'certificate':certificate_info,'collected_at':time.time()}
        if action=='processes':
            import psutil
            return [proc.info for proc in psutil.process_iter(['pid','name','username','memory_percent','status'])][:2000]
        if action=='services':
            if os.name=='nt':
                import psutil
                values=[]
                for service in psutil.win_service_iter():
                    try: values.append(service.as_dict())
                    except Exception: pass
                return values
            return run_process(['systemctl','list-units','--type=service','--all','--no-pager','--plain'])
        if action=='software':
            if os.name=='nt':
                return powershell("Get-ItemProperty 'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*' -ErrorAction SilentlyContinue | Where-Object DisplayName | Select-Object DisplayName,DisplayVersion,Publisher | ConvertTo-Json -Depth 3")
            import shutil
            return run_process(['dpkg-query','-W'] if shutil.which('dpkg-query') else ['rpm','-qa'])
        if action=='events':
            if os.name=='nt': return powershell("Get-WinEvent -LogName System -MaxEvents 100 | Select-Object TimeCreated,Id,LevelDisplayName,ProviderName,Message | ConvertTo-Json -Depth 3")
            return run_process(['journalctl','-n','100','--no-pager','-o','json'])
        if action=='updates':
            if os.name!='nt': return run_process(['sh','-c','if command -v apt >/dev/null; then apt list --upgradable; elif command -v dnf >/dev/null; then dnf check-update; else exit 2; fi'],60)
            return powershell("$s=New-Object -ComObject Microsoft.Update.Session; $r=$s.CreateUpdateSearcher().Search('IsInstalled=0 and IsHidden=0'); $r.Updates | Select-Object Title,IsDownloaded | ConvertTo-Json -Depth 3",120)
        if action=='install_updates':
            if not self.config.get('allow_updates'): raise PermissionError('Встановлення оновлень не дозволене локальною політикою.')
            if os.name!='nt': raise ValueError('Для Linux додайте дозволену команду оновлення до agent.json.')
            script="$s=New-Object -ComObject Microsoft.Update.Session; $r=$s.CreateUpdateSearcher().Search('IsInstalled=0 and IsHidden=0'); $c=New-Object -ComObject Microsoft.Update.UpdateColl; foreach($u in $r.Updates){if(-not $u.EulaAccepted){$u.AcceptEula()};[void]$c.Add($u)}; if($c.Count){$d=$s.CreateUpdateDownloader();$d.Updates=$c;[void]$d.Download();$i=$s.CreateUpdateInstaller();$i.Updates=$c;$i.Install() | Select-Object ResultCode,RebootRequired | ConvertTo-Json}else{'No updates'}"
            return powershell(script,1200)
        if action=='service_control':
            name=str(p.get('name',''));verb=p.get('verb')
            if not self.config.get('allow_service_control') or name not in self.config.get('allowed_services',[]):
                raise PermissionError('Служба не входить до локального списку дозволених.')
            if verb not in ('start','stop','restart'): raise ValueError('Невідома операція служби')
            if os.name=='nt':
                if verb=='restart':
                    result=run_process(['sc.exe','stop',name])
                    if result['returncode']: return result
                    import psutil
                    deadline=time.monotonic()+20
                    while psutil.win_service_get(name).status()!='stopped' and time.monotonic()<deadline: time.sleep(.3)
                    return run_process(['sc.exe','start',name])
                return run_process(['sc.exe',verb,name])
            return run_process(['systemctl',verb,'--',name])
        if action=='terminate':
            if not self.config.get('allow_process_terminate'): raise PermissionError('Завершення процесів не дозволене локально.')
            import psutil
            pid=int(p['pid'])
            if pid in (0,1,os.getpid()): raise PermissionError('Захищений процес')
            psutil.Process(pid).terminate()
            return {'requested':True,'pid':pid}
        if action=='command':
            command=self.config.get('commands',{}).get(p.get('id'))
            if not isinstance(command,list) or not command or not all(isinstance(x,str) for x in command):
                raise PermissionError('Команда не дозволена. Укажіть її ID з agent.json.')
            return run_process(command,120)
        if action=='power':
            if not self.config.get('allow_power'): raise PermissionError('Керування живленням не дозволене локально.')
            verb=p.get('verb')
            if verb not in ('reboot','shutdown'): raise ValueError('Невідома дія живлення')
            return run_process(['shutdown.exe','/r' if verb=='reboot' else '/s','/t','30','/c','MICHMAN authorized administration'] if os.name=='nt' else ['shutdown','-r' if verb=='reboot' else '-h','+1'])
        if action=='files_list':
            path=self.path(p.get('path',''))
            return [{'name':item.name,'directory':item.is_dir(),'size':item.stat().st_size} for item in list(path.iterdir())[:2000] if not item.is_symlink()]
        if action=='files_read':
            path=self.path(p['path']);offset=int(p.get('offset',0))
            if offset<0: raise ValueError('Некоректний offset')
            with path.open('rb') as handle:
                handle.seek(offset);data=handle.read(CHUNK)
            stat=path.stat()
            return {'data':base64.b64encode(data).decode(),'size':stat.st_size,'mtime_ns':stat.st_mtime_ns,'sha256_chunk':hashlib.sha256(data).hexdigest()}
        if action=='files_stat':
            path=self.path(p['path']);stat=path.stat()
            if not path.is_file():raise ValueError('Це не файл')
            with path.open('rb') as handle:digest=hashlib.file_digest(handle,'sha256').hexdigest()
            return {'size':stat.st_size,'mtime_ns':stat.st_mtime_ns,'sha256':digest}
        if action=='files_mkdir':
            path=self.path(p['path']);path.mkdir(parents=True,exist_ok=False)
            return {'created':True}
        if action=='files_delete':
            self.path(p['path']).unlink()
            return {'deleted':True}
        if action=='upload_start':
            with self.lock:
                for old_token,old_upload in list(self.uploads.items()):
                    if old_upload['expires']<time.monotonic():
                        old_upload['temporary'].unlink(missing_ok=True)
                        del self.uploads[old_token]
                if len(self.uploads)>=16:raise RuntimeError('Забагато одночасних передач файлів')
            target=self.path(p['path'])
            size=int(p['size'])
            if not 0<=size<=2*1024**3: raise ValueError('Максимум 2 GiB на файл')
            if target.exists() and not p.get('overwrite'): raise FileExistsError('Файл уже існує')
            target.parent.mkdir(parents=True,exist_ok=True)
            token=uuid.uuid4().hex
            temporary=target.parent/('.michman-upload-'+token)
            temporary.touch(exist_ok=False)
            with self.lock:
                self.uploads[token]={'user':user,'target':target,'temporary':temporary,'size':size,'offset':0,'expires':time.monotonic()+900}
            return {'token':token}
        if action=='upload_cancel':
            with self.lock:
                upload=self.uploads.get(p['token'])
                if upload and upload['user']!=user:raise PermissionError('Чужа передача')
                if upload:
                    upload['temporary'].unlink(missing_ok=True);del self.uploads[p['token']]
            return {'cancelled':True}
        if action in ('upload_chunk','upload_finish'):
            with self.lock:
                upload=self.uploads.get(p['token'])
                if not upload or upload['user']!=user or upload['expires']<time.monotonic(): raise PermissionError('Upload session недійсна')
                if action=='upload_chunk':
                    data=base64.b64decode(p['data'],validate=True)
                    supplied_hash=str(p.get('sha256_chunk',''))
                    if supplied_hash and not hmac_equal(hashlib.sha256(data).hexdigest(),supplied_hash):raise ValueError('SHA-256 блоку не збігається')
                    requested_offset=int(p['offset'])
                    if len(data)>CHUNK or requested_offset<0 or requested_offset+len(data)>upload['size']: raise ValueError('Некоректний блок файлу')
                    # A repeated block is safe after a lost HTTP response: verify it
                    # instead of appending it twice.
                    if requested_offset<upload['offset']:
                        if requested_offset+len(data)>upload['offset']:raise ValueError('Блок перекриває межу передачі')
                        with upload['temporary'].open('rb') as handle:
                            handle.seek(requested_offset);existing=handle.read(len(data))
                        if not hmac_equal(hashlib.sha256(existing).hexdigest(),hashlib.sha256(data).hexdigest()):raise ValueError('Повторний блок відрізняється')
                        return {'offset':upload['offset'],'duplicate':True}
                    if requested_offset!=upload['offset']:raise ValueError('Некоректна послідовність блоків')
                    with upload['temporary'].open('ab') as handle: handle.write(data)
                    upload['offset']+=len(data);upload['expires']=time.monotonic()+900
                    return {'offset':upload['offset']}
                if upload['offset']!=upload['size']: raise ValueError('Файл неповний')
                with upload['temporary'].open('rb') as handle:
                    digest=hashlib.file_digest(handle,'sha256').hexdigest()
                if not hmac_equal(digest,p['sha256']): raise ValueError('SHA-256 не збігається')
                os.replace(upload['temporary'],upload['target'])
                del self.uploads[p['token']]
                return {'sha256':digest}
        if action=='assist_request':
            if not self.consent: raise PermissionError('Для допомоги агент має працювати у видимому користувацькому сеансі.')
            if not self.consent(user): raise PermissionError('Користувач відмовив або не відповів.')
            token=uuid.uuid4().hex
            with self.lock:self.sessions[token]={'user':user,'expires':None}
            return {'token':token,'expires_seconds':None,'unlimited':True}
        if action=='assist_stop':
            self.session(user,p['token'])
            with self.lock: self.sessions.pop(p['token'],None)
            return {'stopped':True}
        if action in ('assist_frame','assist_input'):
            self.session(user,p['token'])
            import pyautogui
            if action=='assist_frame':
                try:
                    from PIL import ImageGrab
                    image=ImageGrab.grab()
                except Exception:
                    image=pyautogui.screenshot()
                original=image.size
                width=int(p.get('width',0) or 0);height=int(p.get('height',0) or 0)
                if width>0 and height>0:
                    image.thumbnail((max(640,min(7680,width)),max(360,min(4320,height))))
                output=io.BytesIO();image.convert('RGB').save(output,format='JPEG',quality=max(35,min(95,int(p.get('quality',72)))),optimize=False,subsampling=2)
                return {'image':base64.b64encode(output.getvalue()).decode(),'original_width':original[0],'original_height':original[1]}
            verb=p.get('verb')
            try:
                if verb=='click':
                    width,height=pyautogui.size()
                    x=max(0,min(width-1,int(float(p['x'])*width)));y=max(0,min(height-1,int(float(p['y'])*height)))
                    button=p.get('button','left')
                    if button not in ('left','right'): raise ValueError('Невідома кнопка')
                    pyautogui.click(x,y,button=button)
                elif verb=='key':
                    key=p.get('key','')
                    if key not in pyautogui.KEYBOARD_KEYS: raise ValueError('Невідома клавіша')
                    pyautogui.press(key,_pause=False)
                elif verb=='text':
                    text=str(p.get('text',''))[:1000]
                    if text.isascii():pyautogui.write(text,interval=0,_pause=False)
                    else:
                        import pyperclip
                        pyperclip.copy(text);atomic_hotkey(pyautogui,['ctrl','v'])
                elif verb=='scroll':pyautogui.scroll(max(-20,min(20,int(p.get('amount',0)))))
                elif verb=='move':
                    width,height=pyautogui.size()
                    x=max(0,min(width-1,int(float(p['x'])*width)));y=max(0,min(height-1,int(float(p['y'])*height)))
                    pyautogui.moveTo(x,y,duration=0,_pause=False)
                elif verb=='drag':
                    width,height=pyautogui.size()
                    coords=[max(0,min(1,float(p[key]))) for key in ('x','y','end_x','end_y')]
                    pyautogui.moveTo(int(coords[0]*(width-1)),int(coords[1]*(height-1)))
                    pyautogui.dragTo(int(coords[2]*(width-1)),int(coords[3]*(height-1)),duration=.4,button='left')
                elif verb=='hotkey':
                    keys=p.get('keys',[])
                    if not 1<=len(keys)<=5 or not all(k in pyautogui.KEYBOARD_KEYS for k in keys): raise ValueError('Некоректне сполучення')
                    atomic_hotkey(pyautogui,keys)
                else: raise ValueError('Невідома дія введення')
            except pyautogui.FailSafeException:
                self.revoke_assistance()
                raise PermissionError('Локальний користувач зупинив керування через fail-safe.')
            return {'ok':True}
        if action=='revoke_user':
            serial=str(p['serial'])
            self.config.setdefault('revoked_serials',[]).append(serial)
            atomic_write_json(self.directory/'agent.json',self.config)
            self.revoke_assistance()
            return {'revoked':serial}


def hmac_equal(a,b):
    import hmac
    return hmac.compare_digest(str(a),str(b))


class AgentServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    slots=threading.BoundedSemaphore(16)
    def process_request(self,request,client_address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try: super().process_request(request,client_address)
        except Exception:
            self.slots.release();raise
    def process_request_thread(self,request,client_address):
        try: super().process_request_thread(request,client_address)
        finally: self.slots.release()
    def get_request(self):
        sock,address=self.socket.accept()
        sock.settimeout(10)
        try: return self.tls.wrap_socket(sock,server_side=True),address
        except Exception:
            sock.close();raise


class AgentHandler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_POST(self):
        runtime=self.server.runtime
        user,action='unknown','unknown'
        try:
            if self.path!='/rpc': raise ValueError('Невідомий endpoint')
            cert=self.connection.getpeercert()
            subject={k:v for rdn in cert['subject'] for k,v in rdn}
            user=subject.get('commonName','')
            role=subject.get('organizationalUnitName','')
            serial=str(int(cert['serialNumber'],16))
            if serial in runtime.config.get('revoked_serials',[]): raise PermissionError('Сертифікат відкликано')
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=MAX_BODY: raise ValueError('Некоректний розмір запиту')
            packet=json.loads(self.rfile.read(length))
            action=packet['action']
            if not isinstance(packet.get('params',{}),dict): raise ValueError('Некоректні параметри')
            if action=='assist_stream':
                self.stream(user,role,serial,packet.get('params',{}));return
            result=runtime.rpc(user,role,action,packet.get('params',{}))
            code,body=200,{'ok':True,'result':result}
            if action not in ('assist_frame','assist_input','telemetry'): runtime.audit(user,action,'OK')
        except Exception as error:
            code=403 if isinstance(error,PermissionError) else 400
            body={'ok':False,'error':str(error)[:1000]}
            runtime.audit(user,action,'DENIED/ERROR: '+str(error)[:500])
        encoded=json.dumps(body,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(encoded)));self.end_headers()
        try: self.wfile.write(encoded)
        except (BrokenPipeError,ConnectionResetError): pass

    def stream(self,user,role,serial,params):
        import struct
        runtime=self.server.runtime
        fps=max(1,min(60,int(params.get('fps',30))))
        # Validate role and consent before committing a streaming response.
        frame=runtime.rpc(user,role,'assist_frame',params)
        self.send_response(200)
        self.send_header('Content-Type','application/x-michman-jpeg-stream')
        self.send_header('Cache-Control','no-store');self.send_header('Connection','close');self.end_headers()
        self.close_connection=True;self.connection.settimeout(2)
        runtime.audit(user,'ASSIST_STREAM','START')
        try:
            while True:
                started=time.monotonic()
                if serial in runtime.config.get('revoked_serials',[]):break
                runtime.session(user,params['token'])
                data=base64.b64decode(frame['image'])
                self.wfile.write(struct.pack('!I',len(data))+data);self.wfile.flush()
                time.sleep(max(0,1/fps-(time.monotonic()-started)))
                frame=runtime.rpc(user,role,'assist_frame',params)
        except (OSError,PermissionError):pass
        except Exception as error:runtime.audit(user,'ASSIST_STREAM','ERROR: '+str(error)[:300])
        finally:runtime.audit(user,'ASSIST_STREAM','STOP')


def start_server(runtime):
    context=secure_tls_context(ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER))
    context.verify_mode=ssl.CERT_REQUIRED
    context.load_verify_locations(str(runtime.directory/'ca.pem'))
    context.load_cert_chain(str(runtime.directory/'server.pem'),str(runtime.directory/'server-key.pem'))
    server=AgentServer((runtime.config.get('bind','0.0.0.0'),int(runtime.config.get('port',8743))),AgentHandler)
    server.runtime=runtime;server.tls=context
    threading.Thread(target=server.serve_forever,daemon=True).start()
    return server


class AgentClient:
    def __init__(self,host,port,context):
        if not isinstance(context,ssl.SSLContext) or context.verify_mode!=ssl.CERT_REQUIRED or not context.check_hostname:
            raise ValueError('Канал агента потребує перевірки сертифіката сервера та персонального клієнтського сертифіката.')
        secure_tls_context(context)
        self.url=f'https://[{host}]:{int(port)}/rpc' if ':' in host else f'https://{host}:{int(port)}/rpc'
        self.context=context;self.host=host;self.port=int(port)
    def call(self,action,params=None,timeout=45):
        from urllib.error import HTTPError
        request=Request(self.url,data=json.dumps({'action':action,'params':params or {}}).encode(),headers={'Content-Type':'application/json'},method='POST')
        try:
            with urlopen(request,context=self.context,timeout=timeout) as response: payload=json.loads(response.read(32*1024*1024))
        except HTTPError as error:
            detail=json.loads(error.read(4096))
            raise RuntimeError(detail.get('error','Agent request failed')) from None
        if not payload.get('ok'): raise RuntimeError(payload.get('error','Agent request failed'))
        return payload['result']
    def frames(self,token,stop,fps=20,width=1280,height=720,quality=65):
        import struct
        request=Request(self.url,data=json.dumps({'action':'assist_stream','params':{'token':token,'fps':fps,'width':width,'height':height,'quality':quality}}).encode(),headers={'Content-Type':'application/json'},method='POST')
        with urlopen(request,context=self.context,timeout=5) as response:
            if response.headers.get_content_type()!='application/x-michman-jpeg-stream':raise RuntimeError('Оновіть агент до 2.0.4 для потоку екрана та клавіатури')
            def read_exact(size):
                data=bytearray()
                while len(data)<size:
                    if stop.is_set():return None
                    chunk=response.read(size-len(data))
                    if not chunk:raise EOFError('Трансляцію завершено або з’єднання втрачено')
                    data.extend(chunk)
                return bytes(data)
            while not stop.is_set():
                header=read_exact(4)
                if header is None:return
                size=struct.unpack('!I',header)[0]
                if not 0<size<=32*1024*1024:raise ValueError('Некоректний розмір кадру')
                data=read_exact(size)
                if data is None:return
                yield data

    def _retry_call(self,action,params,attempts=3,timeout=45):
        error=None
        for attempt in range(attempts):
            try:return self.call(action,params,timeout)
            except (OSError,TimeoutError,EOFError) as exc:
                error=exc
                if attempt+1<attempts:time.sleep(.15*(2**attempt))
        raise error
    def upload(self,local,remote,overwrite=False,progress=None,cancel=None):
        local=Path(local)
        token=self.call('upload_start',{'path':remote,'size':local.stat().st_size,'overwrite':overwrite})['token']
        digest=hashlib.sha256();offset=0;total=local.stat().st_size
        try:
            with local.open('rb') as handle:
                for chunk in iter(lambda:handle.read(CHUNK),b''):
                    if cancel and cancel.is_set():raise InterruptedError('Передачу скасовано')
                    digest.update(chunk)
                    payload={'token':token,'offset':offset,'data':base64.b64encode(chunk).decode(),'sha256_chunk':hashlib.sha256(chunk).hexdigest()}
                    self._retry_call('upload_chunk',payload)
                    offset+=len(chunk)
                    if progress:progress(offset,total)
            if cancel and cancel.is_set():raise InterruptedError('Передачу скасовано')
            result=self.call('upload_finish',{'token':token,'sha256':digest.hexdigest()})
            if progress:progress(offset,total)
            return result
        except Exception:
            try:self.call('upload_cancel',{'token':token},timeout=5)
            except Exception:pass
            raise
    def download(self,remote,local,progress=None,cancel=None):
        local=Path(local);temporary=local.with_name(local.name+'.michman-part')
        if temporary.exists():raise FileExistsError('Існує незавершений локальний файл: '+str(temporary))
        remote_info=self._retry_call('files_stat',{'path':remote})
        offset=0;created=False
        try:
            with temporary.open('xb') as handle:
                created=True
                while True:
                    if cancel and cancel.is_set():raise InterruptedError('Передачу скасовано')
                    result=self._retry_call('files_read',{'path':remote,'offset':offset})
                    if result['size']!=remote_info['size'] or result.get('mtime_ns')!=remote_info.get('mtime_ns'):raise IOError('Файл на агенті змінився під час передачі')
                    chunk=base64.b64decode(result['data'],validate=True)
                    if hashlib.sha256(chunk).hexdigest()!=result['sha256_chunk']: raise ValueError('SHA-256 chunk mismatch')
                    handle.write(chunk);offset+=len(chunk)
                    if progress:progress(offset,result['size'])
                    if offset>=result['size']: break
                    if not chunk: raise IOError('Файл змінився або передача перервана')
            if cancel and cancel.is_set():raise InterruptedError('Передачу скасовано')
            with temporary.open('rb') as handle:local_hash=hashlib.file_digest(handle,'sha256').hexdigest()
            if not hmac_equal(local_hash,remote_info['sha256']):raise ValueError('SHA-256 завантаженого файла не збігається')
            os.replace(temporary,local)
            return {'bytes':offset,'sha256':local_hash}
        finally:
            if created and temporary.exists():temporary.unlink()


def default_agent_directory():
    base=Path(os.environ.get('LOCALAPPDATA') or Path.home()/'.local'/'share')
    return (base/'MichmanAgent'/'enrollment').resolve()


def valid_agent_directory(directory):
    folder=Path(directory).resolve()
    return all((folder/name).is_file() for name in REQUIRED_ENROLLMENT_FILES)


def import_enrollment(source,destination=None):
    source=Path(source).resolve();destination=Path(destination or default_agent_directory()).resolve()
    if not valid_agent_directory(source):
        raise ValueError('Пакет реєстрації неповний: потрібні agent.json, ca.pem, server.pem і server-key.pem.')
    config=json.loads((source/'agent.json').read_text(encoding='utf-8'))
    for key in ('agent_id','host_identity','port'):
        if key not in config:raise ValueError('У пакеті реєстрації відсутнє поле: '+key)
    if source==destination:return destination
    destination.mkdir(parents=True,exist_ok=True)
    for name in REQUIRED_ENROLLMENT_FILES+('language.json',):
        path=source/name
        if path.is_file():shutil.copy2(path,destination/name)
    return destination


def configured_agent_directory(explicit=None):
    if explicit:
        folder=Path(explicit).resolve()
        if not valid_agent_directory(folder):raise ValueError('У вказаній папці немає повного пакета реєстрації агента.')
        return folder
    managed=default_agent_directory()
    if valid_agent_directory(managed):return managed
    current=Path.cwd().resolve()
    return current if valid_agent_directory(current) else None


def acquire_agent_instance(agent_id):
    if os.name!='nt':return True
    import ctypes
    from ctypes import wintypes
    name='Local\\MICHMAN-Agent-'+re.sub(r'[^A-Za-z0-9_.-]','_',str(agent_id))
    kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel32.CreateMutexW.argtypes=(wintypes.LPVOID,wintypes.BOOL,wintypes.LPCWSTR)
    kernel32.CreateMutexW.restype=wintypes.HANDLE
    kernel32.CloseHandle.argtypes=(wintypes.HANDLE,);kernel32.CloseHandle.restype=wintypes.BOOL
    ctypes.set_last_error(0);handle=kernel32.CreateMutexW(None,False,name)
    if not handle:raise ctypes.WinError()
    if ctypes.get_last_error()==183:
        kernel32.CloseHandle(handle);return None
    return handle


def release_agent_instance(handle):
    if os.name=='nt' and handle:
        import ctypes
        from ctypes import wintypes
        kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel32.CloseHandle.argtypes=(wintypes.HANDLE,);kernel32.CloseHandle.restype=wintypes.BOOL
        kernel32.CloseHandle(handle)


def windows_message(title,message,question=False):
    import ctypes
    flags=(0x00000004 if question else 0x00000000)|0x00000020|0x00010000|0x00040000
    result=ctypes.windll.user32.MessageBoxW(None,str(message),str(title),flags)
    return result==6 if question else True


def choose_windows_enrollment_directory():
    script=("Add-Type -AssemblyName System.Windows.Forms;"
        "$dialog=New-Object System.Windows.Forms.FolderBrowserDialog;"
        "$dialog.Description='Select the MICHMAN Agent enrollment package';"
        "if($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Out.Write($dialog.SelectedPath)}")
    encoded=base64.b64encode(script.encode('utf-16-le')).decode()
    result=run_process(['powershell.exe','-NoProfile','-STA','-EncodedCommand',encoded],300)
    return result['stdout'].strip() if result['returncode']==0 else ''


def main():
    startup_trace('main')
    parser=argparse.ArgumentParser(description='MICHMAN managed endpoint agent')
    parser.add_argument('--config-dir')
    parser.add_argument('--headless',action='store_true',help='No desktop assistance; for an explicitly installed service')
    parser.add_argument('--background',action='store_true',help='Run in the interactive user session without a permanent window')
    args=parser.parse_args()
    try:config_directory=configured_agent_directory(args.config_dir)
    except Exception as error:
        if args.headless:raise
        config_directory=None;configuration_error=str(error)
    else:configuration_error=''
    if config_directory is None and not args.headless:
        if os.name=='nt':
            if configuration_error:windows_message('MICHMAN Agent',configuration_error)
            folder=choose_windows_enrollment_directory()
        else:
            import tkinter as tk
            from tkinter import filedialog,messagebox
            chooser=tk.Tk();chooser.withdraw()
            if configuration_error:messagebox.showerror('MICHMAN Agent',configuration_error,parent=chooser)
            folder=filedialog.askdirectory(title='Оберіть пакет реєстрації MICHMAN Agent (agent.json та сертифікати)')
        if not folder:
            if os.name!='nt':chooser.destroy()
            return
        try:config_directory=import_enrollment(folder)
        except Exception as error:
            if os.name=='nt':windows_message('MICHMAN Agent',str(error))
            else:messagebox.showerror('MICHMAN Agent',str(error),parent=chooser);chooser.destroy()
            return
        if os.name!='nt':chooser.destroy()
    if config_directory is None:raise ValueError('Не налаштовано пакет реєстрації агента.')
    if args.headless:
        runtime=AgentRuntime(config_directory)
        server=start_server(runtime)
        print('MICHMAN Agent active:',server.server_address,flush=True)
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt: server.shutdown();server.server_close()
        return
    if os.name=='nt':
        from michman_i18n import Localizer
        agent_i18n=Localizer(config_directory)
        def consent(user):
            with CONSENT_PROMPT_LOCK:
                title=agent_i18n.translate('Запит віддаленої допомоги')
                message=agent_i18n.translate(f'{user} просить бачити екран і керувати мишею/клавіатурою без обмеження часу — до завершення сеансу. Дозволити?')
                return windows_message(title,message,True)
        runtime=AgentRuntime(config_directory,consent);startup_trace('runtime')
        instance=acquire_agent_instance(runtime.config['agent_id'])
        if instance is None:startup_trace('duplicate');return
        startup_trace('mutex');server=start_server(runtime);startup_trace('server')
        try:
            startup_trace('background-loop')
            while True:time.sleep(1)
        except KeyboardInterrupt:pass
        finally:
            runtime.revoke_assistance();server.shutdown();server.server_close();release_agent_instance(instance)
        return
    startup_trace('interactive-imports')
    import tkinter as tk
    from tkinter import ttk,messagebox
    startup_trace('tk-imported')
    from michman_i18n import LANGUAGES,Localizer,install_tk_hooks
    startup_trace('i18n-imported')
    agent_i18n=Localizer(config_directory)
    startup_trace('localizer')
    install_tk_hooks(agent_i18n,tk,ttk,messagebox,__import__('tkinter.simpledialog',fromlist=['simpledialog']),__import__('tkinter.filedialog',fromlist=['filedialog']))
    startup_trace('hooks')
    from michman_windows import install_window_policy
    startup_trace('windows-imported')
    install_window_policy()
    startup_trace('window-policy')
    root=tk.Tk();root.withdraw();startup_trace('tk-hidden')
    requests=queue.Queue()
    def consent(user):
        done=threading.Event();result={}
        requests.put((user,done,result))
        return done.wait(60) and result.get('allowed',False)
    runtime=AgentRuntime(config_directory,consent);startup_trace('runtime')
    instance=acquire_agent_instance(runtime.config['agent_id'])
    if instance is None:root.destroy();startup_trace('duplicate');return
    startup_trace('mutex');server=start_server(runtime);startup_trace('server')
    def tick():
        while not requests.empty():
            user,done,result=requests.get_nowait()
            result['allowed']=messagebox.askyesno('Запит віддаленої допомоги',f'{user} просить бачити екран і керувати мишею/клавіатурою без обмеження часу — до завершення сеансу. Дозволити?',parent=root)
            done.set()
        root.after(250,tick)
    root.after(250,tick)
    try:startup_trace('mainloop');root.mainloop()
    finally:
        runtime.revoke_assistance();server.shutdown();server.server_close()
        release_agent_instance(instance)


if __name__=='__main__':
    try:main()
    except Exception as error:
        import traceback
        try:
            folder=default_agent_directory().parent;folder.mkdir(parents=True,exist_ok=True)
            (folder/'agent-startup-error.log').write_text(
                time.strftime('%Y-%m-%d %H:%M:%S')+'\n'+''.join(traceback.format_exception(error)),encoding='utf-8')
        except Exception:pass
        raise

