"""Five-language UI localisation for MICHMAN KP.

The monitoring engine keeps its canonical internal values unchanged.  This
module translates only Tk/ttk presentation text, dialog messages, headings and
StringVar values.  Language selection is stored locally and never transmitted.
"""

from __future__ import annotations

import json
import os
import weakref
from pathlib import Path


LANGUAGES = (
    ("uk", "Українська"),
    ("en", "English"),
    ("pl", "Polski"),
    ("de", "Deutsch"),
    ("es", "Español"),
)
LANGUAGE_CODES = tuple(code for code, _label in LANGUAGES)
LANGUAGE_LABELS = {code: label for code, label in LANGUAGES}


# source, Ukrainian, English, Polish, German, Spanish
_ROWS = [
    # Main shell and common controls.
    ("NETWORK OBSERVABILITY  •  DFIR  •  MIKROTIK", "МЕРЕЖЕВИЙ МОНІТОРИНГ  •  DFIR  •  MIKROTIK", "NETWORK OBSERVABILITY  •  DFIR  •  MIKROTIK", "MONITORING SIECI  •  DFIR  •  MIKROTIK", "NETZWERKÜBERWACHUNG  •  DFIR  •  MIKROTIK", "MONITORIZACIÓN DE RED  •  DFIR  •  MIKROTIK"),
    ("SYSTEM MODULES", "СИСТЕМНІ МОДУЛІ", "SYSTEM MODULES", "MODUŁY SYSTEMOWE", "SYSTEMMODULE", "MÓDULOS DEL SISTEMA"),
    ("MONITOR CONTROL", "КЕРУВАННЯ МОНІТОРИНГОМ", "MONITOR CONTROL", "STEROWANIE MONITORINGIEM", "ÜBERWACHUNGSSTEUERUNG", "CONTROL DEL MONITOR"),
    ("SELECTED NODE", "ВИБРАНИЙ ВУЗОЛ", "SELECTED NODE", "WYBRANY WĘZEŁ", "AUSGEWÄHLTER KNOTEN", "NODO SELECCIONADO"),
    ("EVENT STREAM", "ПОТІК ПОДІЙ", "EVENT STREAM", "STRUMIEŃ ZDARZEŃ", "EREIGNISSTROM", "FLUJO DE EVENTOS"),
    ("SYSTEM READY", "СИСТЕМА ГОТОВА", "SYSTEM READY", "SYSTEM GOTOWY", "SYSTEM BEREIT", "SISTEMA LISTO"),
    ("LANGUAGE", "МОВА", "LANGUAGE", "JĘZYK", "SPRACHE", "IDIOMA"),
    ("◈  МІЧМАН КП", "◈  МІЧМАН КП", "◈  MICHMAN KP", "◈  MICHMAN KP", "◈  MICHMAN KP", "◈  MICHMAN KP"),
    ("DEVICES  //  0 NODES", "ПРИСТРОЇ  //  0 ВУЗЛІВ", "DEVICES  //  0 NODES", "URZĄDZENIA  //  0 WĘZŁÓW", "GERÄTE  //  0 KNOTEN", "DISPOSITIVOS  //  0 NODOS"),
    ("DOUBLE CLICK  //  OPEN NODE DETAILS", "ПОДВІЙНИЙ КЛІК  //  ВІДКРИТИ ДЕТАЛІ ВУЗЛА", "DOUBLE CLICK  //  OPEN NODE DETAILS", "PODWÓJNE KLIKNIĘCIE  //  SZCZEGÓŁY WĘZŁA", "DOPPELKLICK  //  KNOTENDETAILS ÖFFNEN", "DOBLE CLIC  //  ABRIR DETALLES DEL NODO"),
    ("ЦИКЛ", "ЦИКЛ", "INTERVAL", "INTERWAŁ", "INTERVALL", "INTERVALO"),
    ("TIMEOUT", "ТАЙМ-АУТ", "TIMEOUT", "LIMIT CZASU", "ZEITLIMIT", "TIEMPO LÍMITE"),
    ("ЛІЦЕНЗІЯ", "ЛІЦЕНЗІЯ", "LICENSE", "LICENCJA", "LIZENZ", "LICENCIA"),
    ("▶  START", "▶  СТАРТ", "▶  START", "▶  START", "▶  START", "▶  INICIAR"),
    ("■  STOP", "■  СТОП", "■  STOP", "■  STOP", "■  STOPP", "■  DETENER"),
    ("＋  Додати IP", "＋  Додати IP", "＋  Add IP", "＋  Dodaj IP", "＋  IP hinzufügen", "＋  Añadir IP"),
    ("МОНІТОРИНГ", "МОНІТОРИНГ", "MONITORING", "MONITORING", "ÜBERWACHUNG", "MONITORIZACIÓN"),
    ("ЖУРНАЛ ПОДІЙ", "ЖУРНАЛ ПОДІЙ", "EVENT LOG", "DZIENNIK ZDARZEŃ", "EREIGNISPROTOKOLL", "REGISTRO DE EVENTOS"),
    ("УСЬОГО ВУЗЛІВ", "УСЬОГО ВУЗЛІВ", "TOTAL NODES", "WSZYSTKIE WĘZŁY", "KNOTEN GESAMT", "NODOS TOTALES"),
    ("ОЧІКУЮТЬ ПЕРЕВІРКИ", "ОЧІКУЮТЬ ПЕРЕВІРКИ", "AWAITING CHECK", "OCZEKUJĄ NA TEST", "PRÜFUNG AUSSTEHEND", "PENDIENTES DE COMPROBACIÓN"),
    ("Перейменувати", "Перейменувати", "Rename", "Zmień nazwę", "Umbenennen", "Renombrar"),
    ("Деталі / Історія", "Деталі / Історія", "Details / History", "Szczegóły / Historia", "Details / Verlauf", "Detalles / Historial"),
    ("Приховати", "Приховати", "Hide", "Ukryj", "Ausblenden", "Ocultar"),
    ("Приховані IP", "Приховані IP", "Hidden IPs", "Ukryte IP", "Ausgeblendete IPs", "IP ocultas"),
    ("Закріпити", "Закріпити", "Pin", "Przypnij", "Anheften", "Fijar"),
    ("MikroTik Security", "Безпека MikroTik", "MikroTik Security", "Bezpieczeństwo MikroTik", "MikroTik-Sicherheit", "Seguridad MikroTik"),
    ("Резервні копії роутерів", "Резервні копії роутерів", "Router backups", "Kopie zapasowe routerów", "Router-Sicherungen", "Copias de seguridad de routers"),
    ("Роутер:", "Роутер:", "Router:", "Router:", "Router:", "Router:"),
    ("MikroTik: зашифрований .backup та читабельний .rsc. Інші платформи: зашифрований AES-256-GCM файл .mrouter із безпечною командою експорту.\nАвтоматичне відновлення доступне лише для RouterOS; SSH host key має бути відомим системі або в known_hosts.", "MikroTik: зашифрований .backup та читабельний .rsc. Інші платформи: зашифрований AES-256-GCM файл .mrouter із безпечною командою експорту.\nАвтоматичне відновлення доступне лише для RouterOS; SSH host key має бути відомим системі або в known_hosts.", "MikroTik: encrypted .backup and readable .rsc. Other platforms: an AES-256-GCM encrypted .mrouter file created with a safe export command.\nAutomatic restore is available only for RouterOS; the SSH host key must be known to the system or stored in known_hosts.", "MikroTik: zaszyfrowany .backup i czytelny .rsc. Inne platformy: zaszyfrowany plik .mrouter AES-256-GCM tworzony bezpiecznym poleceniem eksportu.\nAutomatyczne przywracanie jest dostępne tylko dla RouterOS; klucz hosta SSH musi być znany systemowi lub zapisany w known_hosts.", "MikroTik: verschlüsselte .backup-Datei und lesbare .rsc-Datei. Andere Plattformen: AES-256-GCM-verschlüsselte .mrouter-Datei mit sicherem Exportbefehl.\nAutomatische Wiederherstellung ist nur für RouterOS verfügbar; der SSH-Hostschlüssel muss dem System oder known_hosts bekannt sein.", "MikroTik: .backup cifrado y .rsc legible. Otras plataformas: archivo .mrouter cifrado con AES-256-GCM mediante un comando de exportación seguro.\nLa restauración automática solo está disponible para RouterOS; la clave SSH del host debe ser conocida por el sistema o estar en known_hosts."),
    ("Порти / MAC", "Порти / MAC", "Ports / MAC", "Porty / MAC", "Ports / MAC", "Puertos / MAC"),
    ("Додати IP", "Додати IP", "Add IP", "Dodaj IP", "IP hinzufügen", "Añadir IP"),
    ("Видалити IP", "Видалити IP", "Remove IP", "Usuń IP", "IP entfernen", "Eliminar IP"),
    ("Пристрої", "Пристрої", "Devices", "Urządzenia", "Geräte", "Dispositivos"),
    ("MONITORED DEVICES", "ПРИСТРОЇ ПІД МОНІТОРИНГОМ", "MONITORED DEVICES", "MONITOROWANE URZĄDZENIA", "ÜBERWACHTE GERÄTE", "DISPOSITIVOS MONITORIZADOS"),
    ("IP вводяться у програмі та зберігаються локально", "IP вводяться у програмі та зберігаються локально", "IP addresses are entered in the app and stored locally", "Adresy IP są wprowadzane w aplikacji i zapisywane lokalnie", "IP-Adressen werden in der App eingegeben und lokal gespeichert", "Las IP se introducen en la aplicación y se guardan localmente"),
    ("ДОДАТИ IP-ДЛЯ МОНІТОРИНГУ", "ДОДАТИ IP-ДЛЯ МОНІТОРИНГУ", "ADD IP FOR MONITORING", "DODAJ IP DO MONITOROWANIA", "IP ZUR ÜBERWACHUNG HINZUFÜGEN", "AÑADIR IP PARA MONITORIZACIÓN"),
    ("Введіть одну або кілька IPv4-адрес (по одній у рядку). Формат: IP | Назва", "Введіть одну або кілька IPv4-адрес (по одній у рядку). Формат: IP | Назва", "Enter one or more IPv4 addresses (one per line). Format: IP | Name", "Wprowadź jeden lub więcej adresów IPv4 (po jednym w wierszu). Format: IP | Nazwa", "Geben Sie eine oder mehrere IPv4-Adressen ein (eine pro Zeile). Format: IP | Name", "Introduzca una o más direcciones IPv4 (una por línea). Formato: IP | Nombre"),
    ("Назва для рядків без назви:", "Назва для рядків без назви:", "Name for unnamed lines:", "Nazwa dla wierszy bez nazwy:", "Name für namenlose Zeilen:", "Nombre para líneas sin nombre:"),
    ("Скан мережі", "Скан мережі", "Network scan", "Skan sieci", "Netzwerkscan", "Escaneo de red"),
    ("Експорт CSV", "Експорт CSV", "Export CSV", "Eksport CSV", "CSV exportieren", "Exportar CSV"),
    ("Оновити потік", "Оновити потік", "Refresh stream", "Odśwież strumień", "Datenstrom aktualisieren", "Actualizar flujo"),
    ("Очистити екран", "Очистити екран", "Clear view", "Wyczyść widok", "Ansicht leeren", "Limpiar vista"),

    # Generic labels/actions.
    ("Назва", "Назва", "Name", "Nazwa", "Name", "Nombre"),
    ("Користувач", "Користувач", "User", "Użytkownik", "Benutzer", "Usuario"),
    ("Користувач:", "Користувач:", "User:", "Użytkownik:", "Benutzer:", "Usuario:"),
    ("Пароль:", "Пароль:", "Password:", "Hasło:", "Passwort:", "Contraseña:"),
    ("Метод", "Метод", "Method", "Metoda", "Methode", "Método"),
    ("Метод:", "Метод:", "Method:", "Metoda:", "Methode:", "Método:"),
    ("Порт", "Порт", "Port", "Port", "Port", "Puerto"),
    ("Порт:", "Порт:", "Port:", "Port:", "Port:", "Puerto:"),
    ("Статус", "Статус", "Status", "Status", "Status", "Estado"),
    ("Стан", "Стан", "State", "Stan", "Status", "Estado"),
    ("Час", "Час", "Time", "Czas", "Zeit", "Hora"),
    ("Подія", "Подія", "Event", "Zdarzenie", "Ereignis", "Evento"),
    ("Деталі", "Деталі", "Details", "Szczegóły", "Details", "Detalles"),
    ("Тип", "Тип", "Type", "Typ", "Typ", "Tipo"),
    ("Рівень", "Рівень", "Severity", "Poziom", "Stufe", "Nivel"),
    ("Результат", "Результат", "Result", "Wynik", "Ergebnis", "Resultado"),
    ("Джерело", "Джерело", "Source", "Źródło", "Quelle", "Origen"),
    ("Джерело даних", "Джерело даних", "Data source", "Źródło danych", "Datenquelle", "Fuente de datos"),
    ("Дія / доступ", "Дія / доступ", "Action / access", "Działanie / dostęp", "Aktion / Zugriff", "Acción / acceso"),
    ("Доказ / причина", "Доказ / причина", "Evidence / reason", "Dowód / przyczyna", "Nachweis / Grund", "Evidencia / motivo"),
    ("Шлях", "Шлях", "Path", "Ścieżka", "Pfad", "Ruta"),
    ("Виробник", "Виробник", "Vendor", "Producent", "Hersteller", "Fabricante"),
    ("Перевірки", "Перевірки", "Checks", "Sprawdzenia", "Prüfungen", "Comprobaciones"),
    ("Остання перевірка", "Остання перевірка", "Last check", "Ostatnie sprawdzenie", "Letzte Prüfung", "Última comprobación"),
    ("Відповідь / Метод", "Відповідь / Метод", "Response / Method", "Odpowiedź / Metoda", "Antwort / Methode", "Respuesta / Método"),
    ("Порт MikroTik", "Порт MikroTik", "MikroTik port", "Port MikroTik", "MikroTik-Port", "Puerto MikroTik"),
    ("IP-адреса", "IP-адреса", "IP address", "Adres IP", "IP-Adresse", "Dirección IP"),
    ("Інцидент", "Інцидент", "Incident", "Incydent", "Vorfall", "Incidente"),
    ("Інциденти", "Інциденти", "Incidents", "Incydenty", "Vorfälle", "Incidentes"),
    ("Додати", "Додати", "Add", "Dodaj", "Hinzufügen", "Añadir"),
    ("Редагувати", "Редагувати", "Edit", "Edytuj", "Bearbeiten", "Editar"),
    ("Видалити", "Видалити", "Delete", "Usuń", "Löschen", "Eliminar"),
    ("Зберегти", "Зберегти", "Save", "Zapisz", "Speichern", "Guardar"),
    ("Закрити", "Закрити", "Close", "Zamknij", "Schließen", "Cerrar"),
    ("Вийти", "Вийти", "Exit", "Wyjdź", "Beenden", "Salir"),
    ("Скасувати", "Скасувати", "Cancel", "Anuluj", "Abbrechen", "Cancelar"),
    ("MAC-адреса керованого ПК:", "MAC-адреса керованого ПК:", "Managed PC MAC address:", "Adres MAC zarządzanego komputera:", "MAC-Adresse des verwalteten PCs:", "Dirección MAC del PC administrado:"),
    ("Виберіть один або кілька файлів", "Виберіть один або кілька файлів", "Select one or more files", "Wybierz jeden lub więcej plików", "Eine oder mehrere Dateien auswählen", "Seleccione uno o varios archivos"),
    ("Передача файлів", "Передача файлів", "File transfer", "Transfer plików", "Dateiübertragung", "Transferencia de archivos"),
    ("Нова папка", "Нова папка", "New folder", "Nowy folder", "Neuer Ordner", "Nueva carpeta"),
    ("Назва папки:", "Назва папки:", "Folder name:", "Nazwa folderu:", "Ordnername:", "Nombre de la carpeta:"),
    ("Вікно 1:1", "Вікно 1:1", "1:1 window", "Okno 1:1", "1:1-Fenster", "Ventana 1:1"),
    ("Експорт стану ПК", "Експорт стану ПК", "Export PC health", "Eksport stanu komputerów", "PC-Status exportieren", "Exportar estado de los PC"),
    ("Дані читаються локальним агентом і передаються через mTLS. Модуль не змінює параметри ПК.", "Дані читаються локальним агентом і передаються через mTLS. Модуль не змінює параметри ПК.", "Data is read by the local agent and sent over mTLS. The module does not change PC settings.", "Dane są odczytywane przez lokalnego agenta i przesyłane przez mTLS. Moduł nie zmienia ustawień komputera.", "Die Daten werden vom lokalen Agenten gelesen und über mTLS übertragen. Das Modul ändert keine PC-Einstellungen.", "El agente local lee los datos y los transmite mediante mTLS. El módulo no cambia la configuración del PC."),
    ("Копіювати", "Копіювати", "Copy", "Kopiuj", "Kopieren", "Copiar"),
    ("Увімкнути", "Увімкнути", "Enable", "Włącz", "Aktivieren", "Activar"),
    ("Вимкнути", "Вимкнути", "Disable", "Wyłącz", "Deaktivieren", "Desactivar"),
    ("Сканувати", "Сканувати", "Scan", "Skanuj", "Scannen", "Escanear"),
    ("Готовий", "Готовий", "Ready", "Gotowy", "Bereit", "Listo"),
    ("с", "с", "s", "s", "s", "s"),

    # Hidden addresses and network scan.
    ("Виберіть IP, які потрібно показати у головному списку:", "Виберіть IP, які потрібно показати у головному списку:", "Select IP addresses to show in the main list:", "Wybierz adresy IP do pokazania na liście głównej:", "Wählen Sie IP-Adressen für die Hauptliste aus:", "Seleccione las IP que se mostrarán en la lista principal:"),
    ("Показати вибрані", "Показати вибрані", "Show selected", "Pokaż wybrane", "Ausgewählte anzeigen", "Mostrar seleccionadas"),
    ("Показати всі", "Показати всі", "Show all", "Pokaż wszystkie", "Alle anzeigen", "Mostrar todas"),
    ("Виберіть IP у головному списку.", "Виберіть IP у головному списку.", "Select an IP in the main list.", "Wybierz IP na liście głównej.", "Wählen Sie eine IP in der Hauptliste aus.", "Seleccione una IP en la lista principal."),
    ("Виберіть IP.", "Виберіть IP.", "Select an IP.", "Wybierz adres IP.", "Wählen Sie eine IP aus.", "Seleccione una IP."),
    ("Виберіть IP для видалення.", "Виберіть IP для видалення.", "Select an IP to remove.", "Wybierz adres IP do usunięcia.", "Wählen Sie eine IP zum Entfernen aus.", "Seleccione una IP para eliminar."),
    ("Видалити вибрані IP зі списку моніторингу?", "Видалити вибрані IP зі списку моніторингу?", "Remove the selected IPs from the monitoring list?", "Usunąć wybrane adresy IP z listy monitoringu?", "Ausgewählte IPs aus der Überwachungsliste entfernen?", "¿Eliminar las IP seleccionadas de la lista de monitorización?"),
    ("Виберіть хоча б один IP.", "Виберіть хоча б один IP.", "Select at least one IP.", "Wybierz co najmniej jeden adres IP.", "Wählen Sie mindestens eine IP aus.", "Seleccione al menos una IP."),
    ("Прихованих IP немає.", "Прихованих IP немає.", "There are no hidden IPs.", "Brak ukrytych adresów IP.", "Es gibt keine ausgeblendeten IPs.", "No hay IP ocultas."),
    ("Мережа CIDR:", "Мережа CIDR:", "CIDR network:", "Sieć CIDR:", "CIDR-Netz:", "Red CIDR:"),
    ("Експорт Excel", "Експорт Excel", "Export Excel", "Eksport Excel", "Excel exportieren", "Exportar Excel"),
    ("Зберегти CSV", "Зберегти CSV", "Save CSV", "Zapisz CSV", "CSV speichern", "Guardar CSV"),
    ("Експортувати результати сканування в Excel", "Експортувати результати сканування в Excel", "Export scan results to Excel", "Eksportuj wyniki skanowania do Excela", "Scanergebnisse nach Excel exportieren", "Exportar resultados del escaneo a Excel"),
    ("Немає отриманих даних для експорту.", "Немає отриманих даних для експорту.", "No collected data to export.", "Brak zebranych danych do eksportu.", "Keine erfassten Daten zum Exportieren.", "No hay datos recopilados para exportar."),
    ("Некоректна CIDR-мережа.", "Некоректна CIDR-мережа.", "Invalid CIDR network.", "Nieprawidłowa sieć CIDR.", "Ungültiges CIDR-Netz.", "Red CIDR no válida."),
    ("Мережа занадто велика.\nМаксимум: 4096 адрес.", "Мережа занадто велика.\nМаксимум: 4096 адрес.", "The network is too large.\nMaximum: 4096 addresses.", "Sieć jest zbyt duża.\nMaksimum: 4096 adresów.", "Das Netz ist zu groß.\nMaximum: 4096 Adressen.", "La red es demasiado grande.\nMáximo: 4096 direcciones."),
    ("Введіть хоча б одну нову коректну IPv4-адресу.", "Введіть хоча б одну нову коректну IPv4-адресу.", "Enter at least one new valid IPv4 address.", "Wprowadź co najmniej jeden nowy prawidłowy adres IPv4.", "Geben Sie mindestens eine neue gültige IPv4-Adresse ein.", "Introduzca al menos una nueva dirección IPv4 válida."),
    ("Введіть коректну IPv4-адресу.", "Введіть коректну IPv4-адресу.", "Enter a valid IPv4 address.", "Wprowadź poprawny adres IPv4.", "Geben Sie eine gültige IPv4-Adresse ein.", "Introduzca una dirección IPv4 válida."),
    ("Порт має бути в діапазоні 1–65535.", "Порт має бути в діапазоні 1–65535.", "The port must be between 1 and 65535.", "Port musi mieścić się w zakresie 1–65535.", "Der Port muss zwischen 1 und 65535 liegen.", "El puerto debe estar entre 1 y 65535."),
    ("Не знайдено коректних TCP-портів.", "Не знайдено коректних TCP-портів.", "No valid TCP ports were found.", "Nie znaleziono prawidłowych portów TCP.", "Keine gültigen TCP-Ports gefunden.", "No se encontraron puertos TCP válidos."),
    ("Некоректна MAC-адреса.\nФормат: AA:BB:CC:DD:EE:FF", "Некоректна MAC-адреса.\nФормат: AA:BB:CC:DD:EE:FF", "Invalid MAC address.\nFormat: AA:BB:CC:DD:EE:FF", "Nieprawidłowy adres MAC.\nFormat: AA:BB:CC:DD:EE:FF", "Ungültige MAC-Adresse.\nFormat: AA:BB:CC:DD:EE:FF", "Dirección MAC no válida.\nFormato: AA:BB:CC:DD:EE:FF"),

    # MikroTik configuration and security centre.
    ("Параметри MikroTik", "Параметри MikroTik", "MikroTik settings", "Ustawienia MikroTik", "MikroTik-Einstellungen", "Configuración de MikroTik"),
    ("Назва (напр. Router-1):", "Назва (напр. Router-1):", "Name (for example Router-1):", "Nazwa (np. Router-1):", "Name (z. B. Router-1):", "Nombre (por ejemplo, Router-1):"),
    ("IP / Hostname:", "IP / Hostname:", "IP / Hostname:", "IP / Nazwa hosta:", "IP / Hostname:", "IP / Nombre de host:"),
    ("Перевіряти TLS-сертифікат / SSH host key (рекомендовано)", "Перевіряти TLS-сертифікат / SSH host key (рекомендовано)", "Verify TLS certificate / SSH host key (recommended)", "Weryfikuj certyfikat TLS / klucz hosta SSH (zalecane)", "TLS-Zertifikat / SSH-Hostschlüssel prüfen (empfohlen)", "Verificar certificado TLS / clave de host SSH (recomendado)"),
    ("Для REST із перевіркою використовується HTTPS. Вимикайте лише для довіреної локальної мережі.", "Для REST із перевіркою використовується HTTPS. Вимикайте лише для довіреної локальної мережі.", "Verified REST uses HTTPS. Disable verification only on a trusted local network.", "Zweryfikowany REST używa HTTPS. Wyłączaj weryfikację tylko w zaufanej sieci lokalnej.", "Verifiziertes REST verwendet HTTPS. Nur in einem vertrauenswürdigen lokalen Netz deaktivieren.", "REST verificado usa HTTPS. Desactive la verificación solo en una red local de confianza."),
    ("Вкажіть IP/hostname та користувача MikroTik.", "Вкажіть IP/hostname та користувача MikroTik.", "Enter the MikroTik IP/hostname and user.", "Podaj IP/nazwę hosta oraz użytkownika MikroTik.", "Geben Sie IP/Hostname und MikroTik-Benutzer ein.", "Introduzca la IP/nombre de host y el usuario de MikroTik."),
    ("Центр безпеки", "Центр безпеки", "Security Center", "Centrum bezpieczeństwa", "Sicherheitscenter", "Centro de seguridad"),
    ("◈  MIKROTIK SECURITY CENTER", "◈  ЦЕНТР БЕЗПЕКИ MIKROTIK", "◈  MIKROTIK SECURITY CENTER", "◈  CENTRUM BEZPIECZEŃSTWA MIKROTIK", "◈  MIKROTIK-SICHERHEITSCENTER", "◈  CENTRO DE SEGURIDAD MIKROTIK"),
    ("AUDIT  •  SERVICES  •  FIREWALL  •  USERS", "АУДИТ  •  СЛУЖБИ  •  FIREWALL  •  КОРИСТУВАЧІ", "AUDIT  •  SERVICES  •  FIREWALL  •  USERS", "AUDYT  •  USŁUGI  •  FIREWALL  •  UŻYTKOWNICY", "AUDIT  •  DIENSTE  •  FIREWALL  •  BENUTZER", "AUDITORÍA  •  SERVICIOS  •  FIREWALL  •  USUARIOS"),
    ("SECURITY SCORE", "ОЦІНКА БЕЗПЕКИ", "SECURITY SCORE", "OCENA BEZPIECZEŃSTWA", "SICHERHEITSWERT", "PUNTUACIÓN DE SEGURIDAD"),
    ("ROUTER", "РОУТЕР", "ROUTER", "ROUTER", "ROUTER", "ROUTER"),
    ("АУДИТ", "АУДИТ", "AUDIT", "AUDYT", "AUDIT", "AUDITORÍA"),
    ("СЛУЖБИ", "СЛУЖБИ", "SERVICES", "USŁUGI", "DIENSTE", "SERVICIOS"),
    ("FIREWALL", "FIREWALL", "FIREWALL", "FIREWALL", "FIREWALL", "FIREWALL"),
    ("КОРИСТУВАЧІ", "КОРИСТУВАЧІ", "USERS", "UŻYTKOWNICY", "BENUTZER", "USUARIOS"),
    ("Ризик", "Ризик", "Risk", "Ryzyko", "Risiko", "Riesgo"),
    ("Перевірка", "Перевірка", "Check", "Kontrola", "Prüfung", "Comprobación"),
    ("Рекомендація", "Рекомендація", "Recommendation", "Zalecenie", "Empfehlung", "Recomendación"),
    ("Служба", "Служба", "Service", "Usługa", "Dienst", "Servicio"),
    ("Дозволені адреси", "Дозволені адреси", "Allowed addresses", "Dozwolone adresy", "Zulässige Adressen", "Direcciones permitidas"),
    ("Сертифікат", "Сертифікат", "Certificate", "Certyfikat", "Zertifikat", "Certificado"),
    ("Група", "Група", "Group", "Grupa", "Gruppe", "Grupo"),
    ("Група:", "Група:", "Group:", "Grupa:", "Gruppe:", "Grupo:"),
    ("Пріоритет:", "Пріоритет:", "Priority:", "Priorytet:", "Priorität:", "Prioridad:"),
    ("Назва для рядків без назви:", "Назва для рядків без назви:", "Name for unnamed lines:", "Nazwa dla wierszy bez nazwy:", "Name für namenlose Zeilen:", "Nombre para líneas sin nombre:"),
    ("Низький", "Низький", "Low", "Niski", "Niedrig", "Bajo"),
    ("Звичайний", "Звичайний", "Normal", "Zwykły", "Normal", "Normal"),
    ("Високий", "Високий", "High", "Wysoki", "Hoch", "Alto"),
    ("Критичний", "Критичний", "Critical", "Krytyczny", "Kritisch", "Crítico"),
    ("Останній вхід", "Останній вхід", "Last login", "Ostatnie logowanie", "Letzte Anmeldung", "Último acceso"),
    ("Оновити аудит", "Оновити аудит", "Refresh audit", "Odśwież audyt", "Audit aktualisieren", "Actualizar auditoría"),
    ("Зберегти JSON", "Зберегти JSON", "Save JSON", "Zapisz JSON", "JSON speichern", "Guardar JSON"),
    ("Export на роутері", "Export на роутері", "Export on router", "Eksport na routerze", "Export auf Router", "Exportar en el router"),
    ("Обмежити адреси", "Обмежити адреси", "Restrict addresses", "Ogranicz adresy", "Adressen beschränken", "Restringir direcciones"),
    ("Увімкнути / вимкнути правило", "Увімкнути / вимкнути правило", "Enable / disable rule", "Włącz / wyłącz regułę", "Regel aktivieren / deaktivieren", "Activar / desactivar regla"),
    ("Додати правило", "Додати правило", "Add rule", "Dodaj regułę", "Regel hinzufügen", "Añadir regla"),
    ("Увімкнути користувача", "Увімкнути користувача", "Enable user", "Włącz użytkownika", "Benutzer aktivieren", "Activar usuario"),
    ("Вимкнути користувача", "Вимкнути користувача", "Disable user", "Wyłącz użytkownika", "Benutzer deaktivieren", "Desactivar usuario"),
    ("NEW FIREWALL FILTER RULE", "НОВЕ ПРАВИЛО FIREWALL FILTER", "NEW FIREWALL FILTER RULE", "NOWA REGUŁA FILTRA FIREWALL", "NEUE FIREWALL-FILTERREGEL", "NUEVA REGLA DE FILTRO FIREWALL"),
    ("Спочатку додайте MikroTik та вкажіть логін і пароль.", "Спочатку додайте MikroTik та вкажіть логін і пароль.", "First add a MikroTik and enter the login and password.", "Najpierw dodaj MikroTik i podaj login oraz hasło.", "Fügen Sie zuerst einen MikroTik hinzu und geben Sie Benutzername und Passwort ein.", "Primero añada un MikroTik e introduzca el usuario y la contraseña."),
    ("Оберіть роутер та натисніть Оновити", "Оберіть роутер та натисніть Оновити", "Select a router and click Refresh", "Wybierz router i kliknij Odśwież", "Wählen Sie einen Router und klicken Sie auf Aktualisieren", "Seleccione un router y pulse Actualizar"),
    ("Спочатку виконайте аудит.", "Спочатку виконайте аудит.", "Run an audit first.", "Najpierw wykonaj audyt.", "Führen Sie zuerst einen Audit durch.", "Ejecute primero una auditoría."),
    ("Виберіть службу.", "Виберіть службу.", "Select a service.", "Wybierz usługę.", "Wählen Sie einen Dienst aus.", "Seleccione un servicio."),
    ("Виберіть firewall-правило.", "Виберіть firewall-правило.", "Select a firewall rule.", "Wybierz regułę firewalla.", "Wählen Sie eine Firewall-Regel aus.", "Seleccione una regla de firewall."),
    ("Виберіть користувача.", "Виберіть користувача.", "Select a user.", "Wybierz użytkownika.", "Wählen Sie einen Benutzer aus.", "Seleccione un usuario."),
    ("Поточний обліковий запис з’єднання вимкнути не можна.", "Поточний обліковий запис з’єднання вимкнути не можна.", "The account used by the current connection cannot be disabled.", "Nie można wyłączyć konta używanego przez bieżące połączenie.", "Das für die aktuelle Verbindung verwendete Konto kann nicht deaktiviert werden.", "No se puede desactivar la cuenta usada por la conexión actual."),
    ("Ця служба використовується поточним з’єднанням. Її вимкнення з цього вікна заблоковано.", "Ця служба використовується поточним з’єднанням. Її вимкнення з цього вікна заблоковано.", "This service is used by the current connection. Disabling it from this window is blocked.", "Ta usługa jest używana przez bieżące połączenie. Jej wyłączenie w tym oknie jest zablokowane.", "Dieser Dienst wird von der aktuellen Verbindung verwendet. Das Deaktivieren in diesem Fenster ist gesperrt.", "Este servicio lo usa la conexión actual. No se puede desactivar desde esta ventana."),
    ("Вкажіть IP/підмережі через кому.\nПриклад: 192.168.88.0/24,10.10.0.5/32\n\nПорожнє поле прибере обмеження служби.", "Вкажіть IP/підмережі через кому.\nПриклад: 192.168.88.0/24,10.10.0.5/32\n\nПорожнє поле прибере обмеження служби.", "Enter IPs/subnets separated by commas.\nExample: 192.168.88.0/24,10.10.0.5/32\n\nAn empty field removes the service restriction.", "Podaj adresy IP/podsieci oddzielone przecinkami.\nPrzykład: 192.168.88.0/24,10.10.0.5/32\n\nPuste pole usuwa ograniczenie usługi.", "Geben Sie IPs/Subnetze kommagetrennt ein.\nBeispiel: 192.168.88.0/24,10.10.0.5/32\n\nEin leeres Feld entfernt die Dienstbeschränkung.", "Introduzca IP/subredes separadas por comas.\nEjemplo: 192.168.88.0/24,10.10.0.5/32\n\nUn campo vacío elimina la restricción del servicio."),
    ("Правило буде додано в кінець списку. Після додавання перевірте його порядок у WinBox.", "Правило буде додано в кінець списку. Після додавання перевірте його порядок у WinBox.", "The rule will be appended to the list. Check its order in WinBox after adding it.", "Reguła zostanie dodana na końcu listy. Po dodaniu sprawdź jej kolejność w WinBox.", "Die Regel wird am Ende der Liste angefügt. Prüfen Sie danach die Reihenfolge in WinBox.", "La regla se añadirá al final de la lista. Compruebe su orden en WinBox después."),
    ("Додати це правило до MikroTik?\n\nПомилкове правило chain=input може заблокувати керування.", "Додати це правило до MikroTik?\n\nПомилкове правило chain=input може заблокувати керування.", "Add this rule to MikroTik?\n\nAn incorrect chain=input rule may block management access.", "Dodać tę regułę do MikroTik?\n\nBłędna reguła chain=input może zablokować zarządzanie.", "Diese Regel zu MikroTik hinzufügen?\n\nEine falsche chain=input-Regel kann den Verwaltungszugriff sperren.", "¿Añadir esta regla a MikroTik?\n\nUna regla chain=input incorrecta puede bloquear la administración."),
    ("Немає активних правил firewall у chain=input", "Немає активних правил firewall у chain=input", "No active firewall rules in chain=input", "Brak aktywnych reguł firewalla w chain=input", "Keine aktiven Firewall-Regeln in chain=input", "No hay reglas de firewall activas en chain=input"),
    ("У chain=input не знайдено правила drop/reject", "У chain=input не знайдено правила drop/reject", "No drop/reject rule found in chain=input", "Nie znaleziono reguły drop/reject w chain=input", "Keine drop/reject-Regel in chain=input gefunden", "No se encontró una regla drop/reject en chain=input"),
    ("Активний стандартний користувач admin", "Активний стандартний користувач admin", "Default admin user is active", "Domyślny użytkownik admin jest aktywny", "Standardbenutzer admin ist aktiv", "El usuario admin predeterminado está activo"),
    ("Декілька користувачів мають групу full", "Декілька користувачів мають групу full", "Several users belong to the full group", "Kilku użytkowników należy do grupy full", "Mehrere Benutzer gehören zur Gruppe full", "Varios usuarios pertenecen al grupo full"),
    ("www-ssl не має призначеного сертифіката", "www-ssl не має призначеного сертифіката", "www-ssl has no assigned certificate", "www-ssl nie ma przypisanego certyfikatu", "www-ssl hat kein zugewiesenes Zertifikat", "www-ssl no tiene un certificado asignado"),
    ("Обмежте доступ своєю адміністративною підмережею.", "Обмежте доступ своєю адміністративною підмережею.", "Restrict access to your administrative subnet.", "Ogranicz dostęp do swojej podsieci administracyjnej.", "Beschränken Sie den Zugriff auf Ihr Verwaltungs-Subnetz.", "Restrinja el acceso a su subred administrativa."),
    ("Створіть персонального адміністратора та вимкніть admin.", "Створіть персонального адміністратора та вимкніть admin.", "Create a personal administrator account and disable admin.", "Utwórz osobiste konto administratora i wyłącz admin.", "Erstellen Sie ein persönliches Administratorkonto und deaktivieren Sie admin.", "Cree una cuenta de administrador personal y desactive admin."),
    ("Залишайте повні права лише тим, кому вони необхідні.", "Залишайте повні права лише тим, кому вони необхідні.", "Grant full rights only to users who need them.", "Nadawaj pełne prawa tylko użytkownikom, którzy ich potrzebują.", "Gewähren Sie volle Rechte nur Benutzern, die sie benötigen.", "Conceda permisos completos solo a quienes los necesiten."),
    ("Доступ до самого роутера може бути недостатньо захищений.", "Доступ до самого роутера може бути недостатньо захищений.", "Access to the router itself may be insufficiently protected.", "Dostęp do samego routera może być niewystarczająco chroniony.", "Der Zugriff auf den Router selbst ist möglicherweise unzureichend geschützt.", "El acceso al propio router puede no estar suficientemente protegido."),
    ("Перевірте завершальну політику блокування небажаного трафіку.", "Перевірте завершальну політику блокування небажаного трафіку.", "Check the final policy that blocks unwanted traffic.", "Sprawdź końcową politykę blokowania niepożądanego ruchu.", "Prüfen Sie die abschließende Richtlinie zum Blockieren unerwünschten Datenverkehrs.", "Compruebe la política final de bloqueo del tráfico no deseado."),
    ("Налаштуйте сертифікат або використовуйте SSH/Winbox.", "Налаштуйте сертифікат або використовуйте SSH/Winbox.", "Configure a certificate or use SSH/WinBox.", "Skonfiguruj certyfikat albo użyj SSH/WinBox.", "Konfigurieren Sie ein Zertifikat oder verwenden Sie SSH/WinBox.", "Configure un certificado o utilice SSH/WinBox."),

    # Licensing.
    ("OFFLINE LICENSE CORE  //  DEVICE-BOUND ACTIVATION", "АВТОНОМНА ЛІЦЕНЗІЯ  //  ПРИВ’ЯЗКА ДО ПК", "OFFLINE LICENSE CORE  //  DEVICE-BOUND ACTIVATION", "LICENCJA OFFLINE  //  PRZYPISANIE DO KOMPUTERA", "OFFLINE-LIZENZ  //  GERÄTEBINDUNG", "LICENCIA SIN CONEXIÓN  //  VINCULADA AL EQUIPO"),
    ("СТАН ЛІЦЕНЗІЇ", "СТАН ЛІЦЕНЗІЇ", "LICENSE STATUS", "STAN LICENCJI", "LIZENZSTATUS", "ESTADO DE LA LICENCIA"),
    ("КОД ЦЬОГО КОМП’ЮТЕРА", "КОД ЦЬОГО КОМП’ЮТЕРА", "THIS COMPUTER CODE", "KOD TEGO KOMPUTERA", "CODE DIESES COMPUTERS", "CÓDIGO DE ESTE EQUIPO"),
    ("КЛЮЧ АКТИВАЦІЇ", "КЛЮЧ АКТИВАЦІЇ", "ACTIVATION KEY", "KLUCZ AKTYWACYJNY", "AKTIVIERUNGSSCHLÜSSEL", "CLAVE DE ACTIVACIÓN"),
    ("АКТИВУВАТИ", "АКТИВУВАТИ", "ACTIVATE", "AKTYWUJ", "AKTIVIEREN", "ACTIVAR"),
    ("НЕ АКТИВОВАНО", "НЕ АКТИВОВАНО", "NOT ACTIVATED", "NIEAKTYWOWANA", "NICHT AKTIVIERT", "NO ACTIVADA"),
    ("ПРОБНА • 24 ГОДИНИ", "ПРОБНА • 24 ГОДИНИ", "TRIAL • 24 HOURS", "PRÓBNA • 24 GODZINY", "TEST • 24 STUNDEN", "PRUEBA • 24 HORAS"),
    ("ПРОБНА • 30 ДНІВ", "ПРОБНА • 30 ДНІВ", "TRIAL • 30 DAYS", "PRÓBNA • 30 DNI", "TEST • 30 TAGE", "PRUEBA • 30 DÍAS"),
    ("ДОВІЧНА", "ДОВІЧНА", "LIFETIME", "DOŻYWOTNIA", "LEBENSLANG", "DE POR VIDA"),
    ("БЕЗСТРОКОВО", "БЕЗСТРОКОВО", "NO EXPIRATION", "BEZTERMINOWO", "UNBEFRISTET", "SIN CADUCIDAD"),
    ("Ліцензія активна.", "Ліцензія активна.", "License is active.", "Licencja jest aktywna.", "Die Lizenz ist aktiv.", "La licencia está activa."),
    ("Введіть ключ для активації програми.", "Введіть ключ для активації програми.", "Enter a key to activate the application.", "Wprowadź klucz, aby aktywować program.", "Geben Sie einen Schlüssel ein, um die Anwendung zu aktivieren.", "Introduzca una clave para activar la aplicación."),
    ("Ключ активації не розпізнано.", "Ключ активації не розпізнано.", "The activation key was not recognized.", "Nie rozpoznano klucza aktywacyjnego.", "Der Aktivierungsschlüssel wurde nicht erkannt.", "No se reconoció la clave de activación."),
    ("Файл ліцензії пошкоджено або перенесено з іншого ПК.", "Файл ліцензії пошкоджено або перенесено з іншого ПК.", "The license file is damaged or was moved from another computer.", "Plik licencji jest uszkodzony lub został przeniesiony z innego komputera.", "Die Lizenzdatei ist beschädigt oder wurde von einem anderen Computer übertragen.", "El archivo de licencia está dañado o fue trasladado desde otro equipo."),
    ("Ліцензія належить іншому комп’ютеру.", "Ліцензія належить іншому комп’ютеру.", "The license belongs to another computer.", "Licencja należy do innego komputera.", "Die Lizenz gehört zu einem anderen Computer.", "La licencia pertenece a otro equipo."),
    ("Пробний період завершився. Активуйте інший тариф.", "Пробний період завершився. Активуйте інший тариф.", "The trial has ended. Activate another plan.", "Okres próbny zakończył się. Aktywuj inny plan.", "Der Testzeitraum ist abgelaufen. Aktivieren Sie einen anderen Tarif.", "El periodo de prueba ha terminado. Active otro plan."),
    ("Цей пробний період уже використовувався на даному ПК.", "Цей пробний період уже використовувався на даному ПК.", "This trial has already been used on this computer.", "Ten okres próbny został już użyty na tym komputerze.", "Dieser Testzeitraum wurde auf diesem Computer bereits verwendet.", "Este periodo de prueba ya se utilizó en este equipo."),
    ("Системний час переведено назад. Виправте дату й час Windows.", "Системний час переведено назад. Виправте дату й час Windows.", "The system clock was moved backwards. Correct the Windows date and time.", "Zegar systemowy został cofnięty. Popraw datę i godzinę Windows.", "Die Systemzeit wurde zurückgestellt. Korrigieren Sie Datum und Uhrzeit in Windows.", "El reloj del sistema se atrasó. Corrija la fecha y hora de Windows."),
    ("На цьому ПК уже активована довічна ліцензія.", "На цьому ПК уже активована довічна ліцензія.", "A lifetime license is already active on this computer.", "Na tym komputerze jest już aktywna licencja dożywotnia.", "Auf diesem Computer ist bereits eine lebenslange Lizenz aktiv.", "Ya hay una licencia de por vida activa en este equipo."),
    ("Не можна замінити активовану ліцензію коротшим тарифом.", "Не можна замінити активовану ліцензію коротшим тарифом.", "An activated license cannot be replaced with a shorter plan.", "Nie można zastąpić aktywnej licencji krótszym planem.", "Eine aktivierte Lizenz kann nicht durch einen kürzeren Tarif ersetzt werden.", "Una licencia activa no puede sustituirse por un plan más corto."),
    ("Пробна ліцензія запускається один раз на цьому ПК. Переведення системного часу назад не продовжує пробний період.", "Пробна ліцензія запускається один раз на цьому ПК. Переведення системного часу назад не продовжує пробний період.", "Each trial can be started once on this computer. Moving the system clock backwards does not extend it.", "Każdy okres próbny można uruchomić raz na tym komputerze. Cofnięcie zegara systemowego go nie przedłuża.", "Jeder Testzeitraum kann auf diesem Computer einmal gestartet werden. Das Zurückstellen der Systemzeit verlängert ihn nicht.", "Cada prueba puede iniciarse una vez en este equipo. Atrasar el reloj del sistema no la prolonga."),
    ("Перевірка виконується локально. Інтернет не використовується.", "Перевірка виконується локально. Інтернет не використовується.", "Verification is performed locally. No internet connection is used.", "Weryfikacja odbywa się lokalnie. Internet nie jest używany.", "Die Prüfung erfolgt lokal. Es wird keine Internetverbindung verwendet.", "La verificación se realiza localmente. No se utiliza Internet."),
    ("АКТИВАЦІЮ ЗАВЕРШЕНО. Усі функції доступні.", "АКТИВАЦІЮ ЗАВЕРШЕНО. Усі функції доступні.", "ACTIVATION COMPLETE. All features are available.", "AKTYWACJA ZAKOŃCZONA. Wszystkie funkcje są dostępne.", "AKTIVIERUNG ABGESCHLOSSEN. Alle Funktionen sind verfügbar.", "ACTIVACIÓN COMPLETADA. Todas las funciones están disponibles."),
    ("Код ПК скопійовано.", "Код ПК скопійовано.", "Computer code copied.", "Kod komputera skopiowany.", "Computercode kopiert.", "Código del equipo copiado."),

    # ScanWatch and DFIR.
    ("ОЗНАКИ СКАНУВАННЯ / ПРОБ ПОРТІВ", "ОЗНАКИ СКАНУВАННЯ / ПРОБ ПОРТІВ", "SCAN / PORT PROBE INDICATORS", "OZNAKI SKANOWANIA / PRÓB PORTÓW", "ANZEICHEN FÜR SCANS / PORTTESTS", "INDICIOS DE ESCANEO / SONDEO DE PUERTOS"),
    ("Оновити зараз", "Оновити зараз", "Refresh now", "Odśwież teraz", "Jetzt aktualisieren", "Actualizar ahora"),
    ("Очистити список", "Очистити список", "Clear list", "Wyczyść listę", "Liste leeren", "Borrar lista"),
    ("Остання спроба", "Остання спроба", "Last attempt", "Ostatnia próba", "Letzter Versuch", "Último intento"),
    ("Перша спроба", "Перша спроба", "First attempt", "Pierwsza próba", "Erster Versuch", "Primer intento"),
    ("Спроб", "Спроб", "Attempts", "Próby", "Versuche", "Intentos"),
    ("Унік. портів", "Унік. портів", "Unique ports", "Unik. porty", "Eindeutige Ports", "Puertos únicos"),
    ("Порти", "Порти", "Ports", "Porty", "Ports", "Puertos"),
    ("Заблоковано", "Заблоковано", "Blocked", "Zablokowano", "Blockiert", "Bloqueado"),
    ("Очистити весь список виявлених сканувань?", "Очистити весь список виявлених сканувань?", "Clear the entire list of detected scans?", "Wyczyścić całą listę wykrytych skanów?", "Die gesamte Liste erkannter Scans löschen?", "¿Borrar toda la lista de escaneos detectados?"),
    ("Показуються лише спроби, які цей ПК реально бачить у Windows Security/Firewall logs. Це не означає, що програма бачить весь трафік усієї підмережі.", "Показуються лише спроби, які цей ПК реально бачить у Windows Security/Firewall logs. Це не означає, що програма бачить весь трафік усієї підмережі.", "Only attempts actually visible to this computer in Windows Security/Firewall logs are shown. This does not mean the application sees all subnet traffic.", "Wyświetlane są tylko próby rzeczywiście widoczne dla tego komputera w dziennikach Windows Security/Firewall. Program nie widzi całego ruchu podsieci.", "Es werden nur Versuche angezeigt, die dieser Computer tatsächlich in Windows-Sicherheits-/Firewall-Protokollen sieht. Die Anwendung sieht nicht den gesamten Subnetzverkehr.", "Solo se muestran los intentos visibles para este equipo en los registros de Seguridad/Firewall de Windows. La aplicación no ve todo el tráfico de la subred."),
    ("DFIR / INCIDENT RESPONSE", "DFIR / РЕАГУВАННЯ НА ІНЦИДЕНТИ", "DFIR / INCIDENT RESPONSE", "DFIR / REAGOWANIE NA INCYDENTY", "DFIR / REAKTION AUF VORFÄLLE", "DFIR / RESPUESTA A INCIDENTES"),
    ("Авторизований збір • без network discovery", "Авторизований збір • без виявлення мережі", "Authorized collection • no network discovery", "Autoryzowane zbieranie • bez wykrywania sieci", "Autorisierte Erfassung • keine Netzwerkerkennung", "Recopilación autorizada • sin descubrimiento de red"),
    ("Віддалений збір", "Віддалений збір", "Remote collection", "Zdalne zbieranie", "Remote-Erfassung", "Recopilación remota"),
    ("IP авторизованого ПК:", "IP авторизованого ПК:", "Authorized computer IP:", "IP autoryzowanego komputera:", "IP des autorisierten Computers:", "IP del equipo autorizado:"),
    ("Зібрати DFIR", "Зібрати DFIR", "Collect DFIR", "Zbierz DFIR", "DFIR erfassen", "Recopilar DFIR"),
    ("Вкажіть конкретний IP. Підмережі та перебір адрес DFIR-модулем не виконуються. Source IP: DIRECT = з самої події; HIGH/MEDIUM/LOW = корельований; UNKNOWN = доказів недостатньо.", "Вкажіть конкретний IP. Підмережі та перебір адрес DFIR-модулем не виконуються. Source IP: DIRECT = з самої події; HIGH/MEDIUM/LOW = корельований; UNKNOWN = доказів недостатньо.", "Enter one specific IP. The DFIR module does not enumerate subnets or addresses. Source IP: DIRECT = from the event; HIGH/MEDIUM/LOW = correlated; UNKNOWN = insufficient evidence.", "Podaj jeden konkretny adres IP. Moduł DFIR nie przeszukuje podsieci ani adresów. Source IP: DIRECT = ze zdarzenia; HIGH/MEDIUM/LOW = korelacja; UNKNOWN = niewystarczające dowody.", "Geben Sie eine konkrete IP ein. Das DFIR-Modul durchsucht keine Subnetze oder Adressen. Source IP: DIRECT = aus dem Ereignis; HIGH/MEDIUM/LOW = korreliert; UNKNOWN = unzureichende Nachweise.", "Introduzca una IP concreta. El módulo DFIR no enumera subredes ni direcciones. Source IP: DIRECT = del evento; HIGH/MEDIUM/LOW = correlacionado; UNKNOWN = evidencia insuficiente."),

    # General application messages.
    ("Закрити програму?", "Закрити програму?", "Close the application?", "Zamknąć program?", "Anwendung schließen?", "¿Cerrar la aplicación?"),
    ("Програма вже запущена. Закрийте попереднє вікно або скористайтеся ним.", "Програма вже запущена. Закрийте попереднє вікно або скористайтеся ним.", "The application is already running. Close or use the existing window.", "Program jest już uruchomiony. Zamknij lub użyj istniejącego okna.", "Die Anwendung läuft bereits. Schließen oder verwenden Sie das vorhandene Fenster.", "La aplicación ya está en ejecución. Cierre o utilice la ventana existente."),
    ("Список моніторингу порожній. Додайте IP кнопкою «Додати IP».", "Список моніторингу порожній. Додайте IP кнопкою «Додати IP».", "The monitoring list is empty. Add an IP with the “Add IP” button.", "Lista monitoringu jest pusta. Dodaj adres IP przyciskiem „Dodaj IP”.", "Die Überwachungsliste ist leer. Fügen Sie eine IP über „IP hinzufügen“ hinzu.", "La lista de monitorización está vacía. Añada una IP con «Añadir IP»."),
    ("Моніторинг запущено.", "Моніторинг запущено.", "Monitoring started.", "Monitoring uruchomiony.", "Überwachung gestartet.", "Monitorización iniciada."),
    ("Моніторинг зупинено.", "Моніторинг зупинено.", "Monitoring stopped.", "Monitoring zatrzymany.", "Überwachung gestoppt.", "Monitorización detenida."),
    ("Файл IP.txt не знайдено.", "Файл IP.txt не знайдено.", "IP.txt was not found.", "Nie znaleziono pliku IP.txt.", "IP.txt wurde nicht gefunden.", "No se encontró IP.txt."),
    ("Для експорту Excel потрібен пакет openpyxl.\n\nВстановіть його командою:\npip install openpyxl", "Для експорту Excel потрібен пакет openpyxl.\n\nВстановіть його командою:\npip install openpyxl", "Excel export requires the openpyxl package.\n\nInstall it with:\npip install openpyxl", "Eksport do Excela wymaga pakietu openpyxl.\n\nZainstaluj go poleceniem:\npip install openpyxl", "Für den Excel-Export ist openpyxl erforderlich.\n\nInstallieren Sie es mit:\npip install openpyxl", "La exportación a Excel requiere openpyxl.\n\nInstálelo con:\npip install openpyxl"),
]


from michman_i18n_extra import EXTRA_FRAGMENTS, EXTRA_ROWS

_ROWS.extend(EXTRA_ROWS)
_INDEX = {"uk": 1, "en": 2, "pl": 3, "de": 4, "es": 5}
_EXACT = {
    source: {code: row[_INDEX[code]] for code in LANGUAGE_CODES}
    for row in _ROWS
    for source in (row[0],)
}


# Safe fragments used for dynamic text containing an IP, count or router name.
_FRAGMENT_ROWS = [
    ("— Ліцензія", "— Ліцензія", "— License", "— Licencja", "— Lizenz", "— Licencia"),
    ("— Активація", "— Активація", "— Activation", "— Aktywacja", "— Aktivierung", "— Activación"),
    ("— Підтвердження", "— Підтвердження", "— Confirmation", "— Potwierdzenie", "— Bestätigung", "— Confirmación"),
    ("— Список MikroTik", "— Список MikroTik", "— MikroTik list", "— Lista MikroTik", "— MikroTik-Liste", "— Lista MikroTik"),
    ("— Приховані IP", "— Приховані IP", "— Hidden IPs", "— Ukryte IP", "— Ausgeblendete IPs", "— IP ocultas"),
    ("— Хто сканував", "— Хто сканував", "— Scan sources", "— Źródła skanowania", "— Scan-Quellen", "— Orígenes de escaneo"),
    ("— Сканування мережі", "— Сканування мережі", "— Network scan", "— Skan sieci", "— Netzwerkscan", "— Escaneo de red"),
    ("— Нове firewall-правило", "— Нове firewall-правило", "— New firewall rule", "— Nowa reguła firewalla", "— Neue Firewall-Regel", "— Nueva regla de firewall"),
    ("Підключення до", "Підключення до", "Connecting to", "Łączenie z", "Verbindung mit", "Conectando con"),
    ("Аудит завершено", "Аудит завершено", "Audit complete", "Audyt zakończony", "Audit abgeschlossen", "Auditoría completada"),
    ("Частковий аудит:", "Частковий аудит:", "Partial audit:", "Częściowy audyt:", "Teilweiser Audit:", "Auditoría parcial:"),
    ("Помилка підключення", "Помилка підключення", "Connection error", "Błąd połączenia", "Verbindungsfehler", "Error de conexión"),
    ("Зміни застосовано.", "Зміни застосовано.", "Changes applied.", "Zmiany zastosowano.", "Änderungen angewendet.", "Cambios aplicados."),
    ("Зміни не застосовано", "Зміни не застосовано", "Changes not applied", "Zmian nie zastosowano", "Änderungen nicht angewendet", "Cambios no aplicados"),
    ("Перед змінами створено", "Перед змінами створено", "Created before changes:", "Utworzono przed zmianami:", "Vor den Änderungen erstellt:", "Creado antes de los cambios:"),
    ("Export створено", "Export створено", "Export created", "Eksport utworzony", "Export erstellt", "Exportación creada"),
    ("Export не створено", "Export не створено", "Export not created", "Eksport nie został utworzony", "Export nicht erstellt", "Exportación no creada"),
    ("На роутері створено файл", "На роутері створено файл", "File created on router:", "Plik utworzony na routerze:", "Datei auf Router erstellt:", "Archivo creado en el router:"),
    ("Знімок аудиту збережено:", "Знімок аудиту збережено:", "Audit snapshot saved:", "Migawka audytu zapisana:", "Audit-Snapshot gespeichert:", "Instantánea de auditoría guardada:"),
    ("Активовано ліцензію:", "Активовано ліцензію:", "License activated:", "Aktywowano licencję:", "Lizenz aktiviert:", "Licencia activada:"),
    ("LIC // НЕ АКТИВОВАНО", "ЛІЦ // НЕ АКТИВОВАНО", "LIC // NOT ACTIVATED", "LIC // NIEAKTYWOWANA", "LIZ // NICHT AKTIVIERT", "LIC // NO ACTIVADA"),
    ("LIC // ПОТРІБНА АКТИВАЦІЯ", "ЛІЦ // ПОТРІБНА АКТИВАЦІЯ", "LIC // ACTIVATION REQUIRED", "LIC // WYMAGANA AKTYWACJA", "LIZ // AKTIVIERUNG ERFORDERLICH", "LIC // ACTIVACIÓN NECESARIA"),
    ("Записів:", "Записів:", "Records:", "Rekordy:", "Einträge:", "Registros:"),
    ("Оновлення...", "Оновлення...", "Refreshing...", "Odświeżanie...", "Aktualisierung...", "Actualizando..."),
    ("Аналіз уже виконується...", "Аналіз уже виконується...", "Analysis is already running...", "Analiza już trwa...", "Analyse läuft bereits...", "El análisis ya está en curso..."),
    ("Перевірено подій:", "Перевірено подій:", "Events checked:", "Sprawdzone zdarzenia:", "Geprüfte Ereignisse:", "Eventos comprobados:"),
    ("виявлень у поточному вікні:", "виявлень у поточному вікні:", "detections in current window:", "wykrycia w bieżącym oknie:", "Erkennungen im aktuellen Fenster:", "detecciones en la ventana actual:"),
    ("Помилка збору", "Помилка збору", "Collection error", "Błąd zbierania", "Erfassungsfehler", "Error de recopilación"),
    ("Додано IP:", "Додано IP:", "IP added:", "Dodano IP:", "IP hinzugefügt:", "IP añadida:"),
    ("Додано IP у програмі:", "Додано IP у програмі:", "IP added in the app:", "Adres IP dodany w aplikacji:", "IP in der App hinzugefügt:", "IP añadida en la aplicación:"),
    ("Видалено IP:", "Видалено IP:", "IP removed:", "Usunięto IP:", "IP entfernt:", "IP eliminada:"),
    ("Видалено IP з програми:", "Видалено IP з програми:", "IP removed from the app:", "Adres IP usunięty z aplikacji:", "IP aus der App entfernt:", "IP eliminada de la aplicación:"),
    ("Додано адрес:", "Додано адрес:", "Addresses added:", "Dodane adresy:", "Hinzugefügte Adressen:", "Direcciones añadidas:"),
    ("дублікати пропущено:", "дублікати пропущено:", "duplicates skipped:", "pominięte duplikaty:", "übersprungene Duplikate:", "duplicados omitidos:"),
    ("некоректні рядки пропущено:", "некоректні рядки пропущено:", "invalid lines skipped:", "pominięte nieprawidłowe wiersze:", "übersprungene ungültige Zeilen:", "líneas no válidas omitidas:"),
    ("Старий список IP перенесено у monitored_devices.json", "Старий список IP перенесено у monitored_devices.json", "Old IP list migrated to monitored_devices.json", "Stara lista IP została przeniesiona do monitored_devices.json", "Alte IP-Liste nach monitored_devices.json migriert", "Lista IP antigua migrada a monitored_devices.json"),
    ("Не вдалося перенести старий список IP:", "Не вдалося перенести старий список IP:", "Could not migrate the old IP list:", "Nie udało się przenieść starej listy IP:", "Die alte IP-Liste konnte nicht migriert werden:", "No se pudo migrar la lista IP antigua:"),
    ("IP вводяться у програмі та зберігаються локально", "IP вводяться у програмі та зберігаються локально", "IP addresses are entered in the app and stored locally", "Adresy IP są wprowadzane w aplikacji i zapisywane lokalnie", "IP-Adressen werden in der App eingegeben und lokal gespeichert", "Las IP se introducen en la aplicación y se guardan localmente"),
    ("Введіть хоча б одну нову коректну IPv4-адресу.", "Введіть хоча б одну нову коректну IPv4-адресу.", "Enter at least one new valid IPv4 address.", "Wprowadź co najmniej jeden nowy prawidłowy adres IPv4.", "Geben Sie mindestens eine neue gültige IPv4-Adresse ein.", "Introduzca al menos una nueva dirección IPv4 válida."),
    ("Виберіть IP для видалення.", "Виберіть IP для видалення.", "Select an IP to remove.", "Wybierz adres IP do usunięcia.", "Wählen Sie eine IP zum Entfernen aus.", "Seleccione una IP para eliminar."),
    ("Видалити вибрані IP зі списку моніторингу?", "Видалити вибрані IP зі списку моніторингу?", "Remove the selected IPs from the monitoring list?", "Usunąć wybrane adresy IP z listy monitoringu?", "Ausgewählte IPs aus der Überwachungsliste entfernen?", "¿Eliminar las IP seleccionadas de la lista de monitorización?"),
    (" вузлів", " вузлів", " nodes", " węzłów", " Knoten", " nodos"),
    ("Перевірок:", "Перевірок:", "Checks:", "Sprawdzenia:", "Prüfungen:", "Comprobaciones:"),
    ("Відключень:", "Відключень:", "Disconnects:", "Rozłączenia:", "Unterbrechungen:", "Desconexiones:"),
    ("Найдовше відключення:", "Найдовше відключення:", "Longest outage:", "Najdłuższa przerwa:", "Längster Ausfall:", "Interrupción más larga:"),
    ("Середній ping:", "Середній ping:", "Average ping:", "Średni ping:", "Durchschnittlicher Ping:", "Ping medio:"),
    (" дн. ", " дн. ", " days ", " dni ", " Tage ", " días "),
    (" год. ", " год. ", " h ", " godz. ", " Std. ", " h "),
    (" год.", " год.", " h", " godz.", " Std.", " h"),
    (" хв.", " хв.", " min", " min", " Min.", " min"),
]
_FRAGMENT_ROWS.extend(EXTRA_FRAGMENTS)

_FRAGMENTS = [
    (row[0], {code: row[_INDEX[code]] for code in LANGUAGE_CODES})
    for row in _FRAGMENT_ROWS
]
_FRAGMENTS.sort(key=lambda item: len(item[0]), reverse=True)


class Localizer:
    def __init__(self, base_dir):
        self.base_dir = Path(base_dir)
        self.path = self.base_dir / "ui_language.json"
        self.code = self._load()
        # tkinter.Variable instances are weak-referenceable but unhashable,
        # therefore WeakSet cannot store them.  Keep weak references by id so
        # language switching does not prolong a dialog variable's lifetime.
        self._variables = {}

    def _load(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            code = str(data.get("language", "uk"))
            if code in LANGUAGE_CODES:
                return code
        except (OSError, ValueError, TypeError):
            pass
        return "uk"

    def set_language(self, code):
        code = str(code or "").lower()
        if code not in LANGUAGE_CODES:
            raise ValueError("Unsupported interface language")
        changed = code != self.code
        self.code = code
        self.base_dir.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps({"language": code}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temporary, self.path)
        return changed

    def translate(self, value):
        if not isinstance(value, str) or not value:
            return value

        stripped = value.strip()
        prefix = value[: len(value) - len(value.lstrip())]
        suffix = value[len(value.rstrip()):]
        exact = _EXACT.get(stripped)
        if exact is not None:
            return prefix + exact[self.code] + suffix

        translated = value
        for source, targets in _FRAGMENTS:
            if source in translated:
                translated = translated.replace(source, targets[self.code])
        return translated

    def register_variable(self, variable):
        key = id(variable)

        def discard(_reference, item_key=key):
            self._variables.pop(item_key, None)

        self._variables[key] = weakref.ref(variable, discard)

    def retranslate(self, root):
        for key, reference in list(self._variables.items()):
            variable = reference()
            if variable is None:
                self._variables.pop(key, None)
                continue
            try:
                variable._i18n_refresh()
            except Exception:
                pass

        def walk(widget):
            try:
                refresher = getattr(widget, "_i18n_refresh", None)
                if refresher:
                    refresher()
            except Exception:
                pass
            try:
                children = widget.winfo_children()
            except Exception:
                children = []
            for child in children:
                walk(child)

        walk(root)


_ACTIVE_LOCALIZER = None
_HOOKS_INSTALLED = False


def install_tk_hooks(localizer, tk, ttk, messagebox, simpledialog, filedialog=None):
    """Install presentation-only translation hooks once for this process."""
    global _ACTIVE_LOCALIZER, _HOOKS_INSTALLED
    _ACTIVE_LOCALIZER = localizer
    if _HOOKS_INSTALLED:
        return
    _HOOKS_INSTALLED = True

    def tr(value):
        return _ACTIVE_LOCALIZER.translate(value)

    original_string_var = tk.StringVar

    class LocalizedStringVar(original_string_var):
        def __init__(self, master=None, value=None, name=None):
            self._i18n_source_value = "" if value is None else value
            super().__init__(master=master, value=None, name=name)
            _ACTIVE_LOCALIZER.register_variable(self)
            if value is not None:
                original_string_var.set(self, tr(value))

        def set(self, value):
            self._i18n_source_value = value
            return original_string_var.set(self, tr(value))

        def _i18n_refresh(self):
            original_string_var.set(self, tr(self._i18n_source_value))

    tk.StringVar = LocalizedStringVar

    def localized_widget_class(original):
        class LocalizedWidget(original):
            def __init__(self, *args, **kwargs):
                self._i18n_text_source = kwargs.get("text", None)
                if "text" in kwargs:
                    kwargs["text"] = tr(kwargs["text"])
                super().__init__(*args, **kwargs)

            def configure(self, cnf=None, **kwargs):
                if isinstance(cnf, dict) and "text" in cnf:
                    cnf = dict(cnf)
                    self._i18n_text_source = cnf["text"]
                    cnf["text"] = tr(cnf["text"])
                if "text" in kwargs:
                    self._i18n_text_source = kwargs["text"]
                    kwargs["text"] = tr(kwargs["text"])
                return original.configure(self, cnf, **kwargs)

            config = configure

            def _i18n_refresh(self):
                if self._i18n_text_source is not None:
                    original.configure(
                        self,
                        text=tr(self._i18n_text_source),
                    )

        LocalizedWidget.__name__ = f"Localized{original.__name__}"
        return LocalizedWidget

    for module, names in (
        (ttk, ("Label", "Button", "Checkbutton", "Radiobutton", "Labelframe")),
        (tk, ("Label", "Button", "Checkbutton", "Radiobutton", "LabelFrame")),
    ):
        for name in names:
            if hasattr(module, name):
                setattr(module, name, localized_widget_class(getattr(module, name)))

    original_treeview = ttk.Treeview

    class LocalizedTreeview(original_treeview):
        def __init__(self, *args, **kwargs):
            self._i18n_headings = {}
            self._i18n_values = {}
            super().__init__(*args, **kwargs)

        def heading(self, column, option=None, **kwargs):
            if "text" in kwargs:
                self._i18n_headings[column] = kwargs["text"]
                kwargs["text"] = tr(kwargs["text"])
            return original_treeview.heading(self, column, option, **kwargs)

        def insert(self, parent, index, iid=None, **kwargs):
            source_values = kwargs.get("values")
            if source_values is not None:
                kwargs["values"] = tuple(tr(item) for item in source_values)
            item_id = original_treeview.insert(
                self,
                parent,
                index,
                iid=iid,
                **kwargs,
            )
            if source_values is not None:
                self._i18n_values[item_id] = tuple(source_values)
            return item_id

        def item(self, item, option=None, **kwargs):
            if "values" in kwargs:
                source_values = tuple(kwargs["values"])
                self._i18n_values[item] = source_values
                kwargs["values"] = tuple(tr(value) for value in source_values)
            return original_treeview.item(self, item, option, **kwargs)

        def delete(self, *items):
            for item in items:
                self._i18n_values.pop(item, None)
            return original_treeview.delete(self, *items)

        def _i18n_refresh(self):
            for column, source in list(self._i18n_headings.items()):
                try:
                    original_treeview.heading(self, column, text=tr(source))
                except Exception:
                    pass
            for item, source_values in list(self._i18n_values.items()):
                try:
                    original_treeview.item(
                        self,
                        item,
                        values=tuple(tr(value) for value in source_values),
                    )
                except Exception:
                    self._i18n_values.pop(item, None)

    ttk.Treeview = LocalizedTreeview

    original_combobox = ttk.Combobox

    class LocalizedCombobox(original_combobox):
        def __init__(self, *args, **kwargs):
            self._i18n_values_source = tuple(kwargs.get("values", ()))
            if "values" in kwargs:
                kwargs["values"] = tuple(tr(value) for value in self._i18n_values_source)
            super().__init__(*args, **kwargs)

        def configure(self, cnf=None, **kwargs):
            if isinstance(cnf, dict) and "values" in cnf:
                cnf = dict(cnf)
                self._i18n_values_source = tuple(cnf["values"])
                cnf["values"] = tuple(tr(value) for value in self._i18n_values_source)
            if "values" in kwargs:
                self._i18n_values_source = tuple(kwargs["values"])
                kwargs["values"] = tuple(tr(value) for value in self._i18n_values_source)
            return original_combobox.configure(self, cnf, **kwargs)

        config = configure

        def _i18n_refresh(self):
            original_combobox.configure(self, values=tuple(tr(value) for value in self._i18n_values_source))

    ttk.Combobox = LocalizedCombobox

    original_notebook = ttk.Notebook

    class LocalizedNotebook(original_notebook):
        def __init__(self, *args, **kwargs):
            self._i18n_tabs = {}
            super().__init__(*args, **kwargs)

        def add(self, child, **kwargs):
            if "text" in kwargs:
                self._i18n_tabs[str(child)] = kwargs["text"]
                kwargs["text"] = tr(kwargs["text"])
            return original_notebook.add(self, child, **kwargs)

        def tab(self, tab_id, option=None, **kwargs):
            if "text" in kwargs:
                self._i18n_tabs[str(tab_id)] = kwargs["text"]
                kwargs["text"] = tr(kwargs["text"])
            return original_notebook.tab(self, tab_id, option, **kwargs)

        def _i18n_refresh(self):
            for child in self.tabs():
                source = self._i18n_tabs.get(str(child))
                if source is not None:
                    try:
                        original_notebook.tab(self, child, text=tr(source))
                    except Exception:
                        pass

    ttk.Notebook = LocalizedNotebook

    original_menu = tk.Menu

    class LocalizedMenu(original_menu):
        def add_command(self, cnf=None, **kwargs):
            if isinstance(cnf, dict):
                cnf = dict(cnf)
                if "label" in cnf:
                    cnf["label"] = tr(cnf["label"])
            if "label" in kwargs:
                kwargs["label"] = tr(kwargs["label"])
            return original_menu.add_command(self, cnf, **kwargs)

        def add_checkbutton(self, cnf=None, **kwargs):
            if isinstance(cnf, dict):
                cnf = dict(cnf)
                if "label" in cnf:
                    cnf["label"] = tr(cnf["label"])
            if "label" in kwargs:
                kwargs["label"] = tr(kwargs["label"])
            return original_menu.add_checkbutton(self, cnf, **kwargs)

        def add_cascade(self, cnf=None, **kwargs):
            if isinstance(cnf, dict):
                cnf = dict(cnf)
                if "label" in cnf:
                    cnf["label"] = tr(cnf["label"])
            if "label" in kwargs:
                kwargs["label"] = tr(kwargs["label"])
            return original_menu.add_cascade(self, cnf, **kwargs)

    tk.Menu = LocalizedMenu

    original_title = tk.Wm.title

    def localized_title(self, string=None):
        if string is None:
            return original_title(self)
        self._i18n_title_source = string
        return original_title(self, tr(string))

    tk.Wm.title = localized_title

    def refresh_window_title(widget):
        source = getattr(widget, "_i18n_title_source", None)
        if source is not None:
            try:
                original_title(widget, tr(source))
            except Exception:
                pass

    # Tk and Toplevel already inherit Wm; attach refresh only when no widget
    # translator has supplied one.
    for cls in (tk.Tk, tk.Toplevel):
        old_refresh = getattr(cls, "_i18n_refresh", None)

        def window_refresh(self, previous=old_refresh):
            if previous:
                previous(self)
            refresh_window_title(self)

        cls._i18n_refresh = window_refresh

    for name in (
        "showinfo", "showwarning", "showerror", "askquestion",
        "askokcancel", "askyesno", "askyesnocancel", "askretrycancel",
    ):
        if not hasattr(messagebox, name):
            continue
        original = getattr(messagebox, name)

        def wrapper(title=None, message=None, _original=original, **options):
            if "detail" in options:
                options["detail"] = tr(options["detail"])
            return _original(tr(title), tr(message), **options)

        setattr(messagebox, name, wrapper)

    for name in ("askstring", "askinteger", "askfloat"):
        if not hasattr(simpledialog, name):
            continue
        original = getattr(simpledialog, name)

        def wrapper(title, prompt, _original=original, **options):
            return _original(tr(title), tr(prompt), **options)

        setattr(simpledialog, name, wrapper)

    if filedialog is not None:
        for name in (
            "askopenfilename", "askopenfilenames", "asksaveasfilename",
            "askdirectory",
        ):
            if not hasattr(filedialog, name):
                continue
            original = getattr(filedialog, name)

            def wrapper(_original=original, **options):
                if "title" in options:
                    options["title"] = tr(options["title"])
                return _original(**options)

            setattr(filedialog, name, wrapper)


__all__ = [
    "LANGUAGES",
    "LANGUAGE_CODES",
    "LANGUAGE_LABELS",
    "Localizer",
    "install_tk_hooks",
]
