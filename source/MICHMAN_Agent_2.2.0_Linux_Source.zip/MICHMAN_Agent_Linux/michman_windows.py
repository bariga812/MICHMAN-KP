"""Consistent Tk window visibility, placement and responsive toolbars."""
import tkinter as tk
from tkinter import ttk


def present(window, width=None, height=None, modal=False, focus=None):
    if not window.winfo_exists():
        return
    owner = window.master
    # Windows hides transient windows together with a withdrawn owner.
    try:
        if owner is not None and not owner.winfo_viewable():
            window.transient('')
    except tk.TclError:
        pass
    window.update_idletasks()
    sw, sh = window.winfo_screenwidth(), window.winfo_screenheight()
    available_w, available_h = max(320, sw-40), max(240, sh-100)
    old_min_w, old_min_h = window.minsize()
    window.minsize(min(old_min_w, available_w), min(old_min_h, available_h))
    requested = getattr(window, '_michman_requested_size', (0, 0))
    wanted_w = width or requested[0] or max(window.winfo_width(), window.winfo_reqwidth())
    wanted_h = height or requested[1] or max(window.winfo_height(), window.winfo_reqheight())
    w, h = min(int(wanted_w), available_w), min(int(wanted_h), available_h)
    x, y = max(0, (sw-w)//2), max(0, (sh-h)//2)
    window.geometry(f'{w}x{h}+{x}+{y}')
    window.deiconify()
    window.lift()
    window.update_idletasks()
    if modal:
        if not window.winfo_viewable():
            window.wait_visibility()
        window.grab_set()
    try:
        (focus or window).focus_set()
    except tk.TclError:
        pass


def install_window_policy():
    """Apply placement after each completed Toplevel constructor, once only."""
    if getattr(tk.Toplevel, '_michman_window_policy', False):
        return
    original = tk.Toplevel.__init__
    original_geometry = tk.Toplevel.geometry
    def geometry(self, specification=None):
        if specification:
            import re
            match = re.match(r'^(\d+)x(\d+)', specification)
            if match:
                self._michman_requested_size = tuple(map(int, match.groups()))
        return original_geometry(self, specification)
    def initialize(self, *args, **kwargs):
        original(self, *args, **kwargs)
        def ready():
            try:
                if self.winfo_exists() and not getattr(self, '_michman_presented', False):
                    self._michman_presented = True
                    present(self)
            except tk.TclError:
                pass
        self.after_idle(ready)
    tk.Toplevel.__init__ = initialize
    tk.Toplevel.geometry = geometry
    tk.Toplevel._michman_window_policy = True


def restore(window):
    if window.state() in ('iconic', 'withdrawn'):
        window.deiconify()
    window.lift()
    window.focus_set()


class WrapToolbar(ttk.Frame):
    """Wrap directly packed controls without hiding controls beyond the edge."""
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self._scheduled = None
        self.bind('<Configure>', self._schedule, add='+')
        self.after_idle(self._layout)
    def _schedule(self, _event=None):
        if self._scheduled is None:
            self._scheduled = self.after_idle(self._layout)
    def _layout(self):
        self._scheduled = None
        if not self.winfo_exists(): return
        controls = self.winfo_children()
        if not controls: return
        width = max(8, self.winfo_width())
        x = y = row_height = 0
        for child in controls:
            if child.winfo_manager() == 'pack': child.pack_forget()
            w, h = min(child.winfo_reqwidth(), max(1, width-8)), child.winfo_reqheight()
            if x and x+w+8 > width:
                x=0; y+=row_height+6; row_height=0
            child.place(x=x+4, y=y+3, width=w, height=h)
            x+=w+8; row_height=max(row_height,h)
        self.configure(height=y+row_height+6)
