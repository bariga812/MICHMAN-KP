"""Small, independently testable helpers for device input and durable exports."""
import csv
import ipaddress
import json
import os
import tempfile
import threading


_JSON_WRITE_LOCK = threading.RLock()


def atomic_write_json(path, data):
    # Windows can reject overlapping replacements of the same destination.
    with _JSON_WRITE_LOCK:
        _atomic_write_json(path, data)


def _atomic_write_json(path, data):
    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8",
                                         dir=os.path.dirname(path),
                                         prefix=".michman-", suffix=".tmp",
                                         delete=False) as handle:
            temporary = handle.name
            json.dump(data, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def safe_csv_cell(value):
    if isinstance(value, str) and value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
        return "'" + value
    if isinstance(value, str) and value.startswith(("\t", "\r", "\n")):
        return "'" + value
    return value


class SafeCSVWriter:
    def __init__(self, handle, **kwargs):
        self.writer = csv.writer(handle, **kwargs)

    def writerow(self, row):
        return self.writer.writerow([safe_csv_cell(value) for value in row])


def parse_device_input(text, existing=(), default_name="", group="Загальні",
                       priority="Звичайний", limit=4096):
    """Validate the whole batch before returning; cap expansion before iteration."""
    seen = set(existing)
    additions, duplicates = [], set()
    expanded = 0
    for number, raw in enumerate(text.splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        address, name = line, default_name
        for separator in ("|", " - "):
            if separator in line:
                address, name = (part.strip() for part in line.split(separator, 1))
                name = name or default_name
                break
        try:
            if "/" in address:
                network = ipaddress.IPv4Network(address, strict=False)
                count = network.num_addresses if network.prefixlen >= 31 else network.num_addresses - 2
                addresses = network.hosts()
            elif "-" in address:
                start, end = (ipaddress.IPv4Address(part.strip()) for part in address.split("-", 1))
                count = int(end) - int(start) + 1
                if count <= 0:
                    raise ValueError("зворотний діапазон")
                addresses = (ipaddress.IPv4Address(value) for value in range(int(start), int(end) + 1))
            else:
                addresses = (ipaddress.IPv4Address(address),)
                count = 1
            expanded += count
            if expanded > limit:
                raise ValueError(f"не більше {limit} адрес за одне додавання")
            for value in addresses:
                ip = str(value)
                if ip in seen:
                    duplicates.add(ip)
                else:
                    additions.append((ip, name, group, priority))
                    seen.add(ip)
        except ValueError as error:
            raise ValueError(f"Рядок {number}: {error}") from error
    return additions, duplicates
