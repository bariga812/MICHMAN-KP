"""Local accounts and an on-premise CA. Roles are signed into client certificates."""
import base64
import hashlib
import hmac
import ipaddress
import json
import os
import re
import ssl
import time
from datetime import datetime,timedelta,timezone
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID,ExtendedKeyUsageOID
from michman_utils import atomic_write_json

ROLES = {
    'Viewer': {'read'},
    'Operator': {'read','monitor','ack','assist'},
    'Helpdesk': {'read','monitor','ack','assist','files','service'},
    'Administrator': {'read','monitor','ack','assist','files','service','command','power','deploy','users','enroll','configure','backup','security'},
    'Security Administrator': {'read','monitor','ack','security','baseline','export'},
}


def require(role, capability):
    if capability not in ROLES.get(role,set()) and not (role=='Administrator'):
        raise PermissionError(f'Роль {role} не має дозволу: {capability}')


def password_hash(password,salt):
    return hashlib.scrypt(password.encode('utf-8'),salt=salt,n=16384,r=8,p=1).hex()


def validate_password(password):
    if len(password)<12:
        raise ValueError('Пароль має містити щонайменше 12 символів.')


def private_pem(key,password=None):
    return key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,
        serialization.BestAvailableEncryption(password.encode()) if password else serialization.NoEncryption())


def issue(ca_cert,ca_key,common_name,role,public_key,hosts=(),days=365):
    now=datetime.now(timezone.utc)
    subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,common_name),x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME,role)])
    builder=x509.CertificateBuilder().subject_name(subject).issuer_name(ca_cert.subject).public_key(public_key)
    builder=builder.serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=days))
    builder=builder.add_extension(x509.BasicConstraints(ca=False,path_length=None),critical=True)
    builder=builder.add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=True,
        data_encipherment=False,key_agreement=False,key_cert_sign=False,crl_sign=False,encipher_only=False,decipher_only=False),critical=True)
    builder=builder.add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH if hosts else ExtendedKeyUsageOID.CLIENT_AUTH]),critical=False)
    if hosts:
        names=[]
        for host in hosts:
            try: names.append(x509.IPAddress(ipaddress.ip_address(host)))
            except ValueError: names.append(x509.DNSName(host))
        builder=builder.add_extension(x509.SubjectAlternativeName(names),critical=False)
    return builder.sign(ca_key,hashes.SHA256())


class IdentityStore:
    def __init__(self,directory):
        self.directory=Path(directory)/'identity'
        self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory/'users.json'
        self.failures={}

    def users(self):
        return json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}

    def bootstrap(self,user,password):
        if self.path.exists():
            raise ValueError('Облікові записи вже створені.')
        validate_password(password)
        key=rsa.generate_private_key(public_exponent=65537,key_size=3072)
        now=datetime.now(timezone.utc)
        name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'MICHMAN Local Authority')])
        cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
              .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=3650))
              .add_extension(x509.BasicConstraints(ca=True,path_length=0),True)
              .add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=False,data_encipherment=False,
                 key_agreement=False,key_cert_sign=True,crl_sign=True,encipher_only=False,decipher_only=False),True).sign(key,hashes.SHA256()))
        (self.directory/'ca.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        (self.directory/'ca-key.pem').write_bytes(private_pem(key,password))
        self.create_user(user,password,'Administrator',password)

    def authority(self,password):
        cert=x509.load_pem_x509_certificate((self.directory/'ca.pem').read_bytes())
        key=serialization.load_pem_private_key((self.directory/'ca-key.pem').read_bytes(),password=password.encode())
        return cert,key

    def create_user(self,user,password,role,authority_password):
        if not re.fullmatch(r'[A-Za-z0-9_.-]{3,40}',user) or role not in ROLES:
            raise ValueError('Логін: 3–40 латинських літер, цифр, крапка, _ або -.')
        validate_password(password)
        users=self.users()
        if user in users:
            raise ValueError('Такий користувач уже існує.')
        ca,key=self.authority(authority_password)
        client_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        cert=issue(ca,key,user,role,client_key.public_key())
        (self.directory/(user+'.pem')).write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        (self.directory/(user+'-key.pem')).write_bytes(private_pem(client_key,password))
        salt=os.urandom(16)
        users[user]={'role':role,'salt':salt.hex(),'hash':password_hash(password,salt),'enabled':True,'serial':str(cert.serial_number)}
        atomic_write_json(self.path,users)

    def login(self,user,password):
        count,until=self.failures.get(user,(0,0))
        if until>time.monotonic():
            raise PermissionError('Забагато спроб. Зачекайте хвилину.')
        account=self.users().get(user)
        valid=account and account.get('enabled') and hmac.compare_digest(account['hash'],password_hash(password,bytes.fromhex(account['salt'])))
        if not valid:
            count+=1
            self.failures[user]=(count,time.monotonic()+60 if count>=5 else 0)
            raise PermissionError('Невірний логін або пароль.')
        self.failures.pop(user,None)
        context=ssl.create_default_context(cafile=str(self.directory/'ca.pem'))
        context.minimum_version=ssl.TLSVersion.TLSv1_2
        context.options|=getattr(ssl,'OP_NO_COMPRESSION',0)
        context.set_ciphers('ECDHE+AESGCM:ECDHE+CHACHA20')
        context.load_cert_chain(str(self.directory/(user+'.pem')),str(self.directory/(user+'-key.pem')),password=password)
        return {'user':user,'role':account['role'],'ssl_context':context}

    def provision_agent(self,host,directory,authority_password,port=8743):
        if not host or any(c.isspace() for c in host):
            raise ValueError('Вкажіть IP/DNS агента.')
        ca,key=self.authority(authority_password)
        folder=Path(directory)
        folder.mkdir(parents=True,exist_ok=False)
        server_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        agent_id=os.urandom(16).hex()
        cert=issue(ca,key,agent_id,'Agent',server_key.public_key(),hosts=[host])
        (folder/'server.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        (folder/'server-key.pem').write_bytes(private_pem(server_key))
        (folder/'ca.pem').write_bytes(ca.public_bytes(serialization.Encoding.PEM))
        config={'agent_id':agent_id,'host_identity':host,'bind':'0.0.0.0','port':int(port),'file_root':'shared',
                'allow_power':False,'allow_service_control':False,'allow_process_terminate':False,
                'allowed_services':[],'monitored_services':[],'allow_updates':False,'commands':{},'revoked_serials':[]}
        atomic_write_json(folder/'agent.json',config)
        return folder


def login_dialog(root,store):
    import tkinter as tk
    from tkinter import ttk
    from michman_windows import present
    setup=not store.path.exists()
    win=tk.Toplevel(root)
    win.title('МІЧМАН — '+('Перший адміністратор' if setup else 'Вхід'))
    win.geometry('560x400')
    body=ttk.Frame(win,padding=24)
    body.pack(fill='both',expand=True)
    ttk.Label(body,text='Створіть адміністратора та пароль локального центру сертифікації.' if setup else 'Увійдіть до робочого простору.',wraplength=460).pack(pady=8)
    user,password=tk.StringVar(value='admin' if setup else ''),tk.StringVar()
    ttk.Label(body,text='Логін').pack(anchor='w')
    ttk.Entry(body,textvariable=user).pack(fill='x')
    ttk.Label(body,text='Пароль (при створенні — від 12 символів)').pack(anchor='w',pady=(8,0))
    entry=ttk.Entry(body,textvariable=password,show='*')
    entry.pack(fill='x')
    feedback=tk.StringVar()
    ttk.Label(body,textvariable=feedback,wraplength=460).pack(pady=8)
    result={}
    def submit():
        try:
            if setup and not store.path.exists(): store.bootstrap(user.get().strip(),password.get())
            result.update(store.login(user.get().strip(),password.get()))
            win.destroy()
        except Exception as error: feedback.set(str(error))
    ttk.Button(body,text='Створити та увійти' if setup else 'Увійти',command=submit).pack()
    entry.bind('<Return>',lambda _:submit())
    if root.winfo_viewable():
        win.transient(root)
    win._michman_presented = True
    win.update_idletasks()
    present(win, 560, max(400, win.winfo_reqheight()), modal=True, focus=entry)
    root.wait_window(win)
    return result or None
