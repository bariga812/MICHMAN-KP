import tempfile
import tkinter as tk
from tkinter import ttk
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import MichmanKP_Protected as main


def run():
    with tempfile.TemporaryDirectory() as directory:
        variables={'BASE_DIR':directory}
        for key in ('DEVICES_FILE','NAMES_FILE','DB_FILE','DEVICE_CONFIG_FILE','MIKROTIK_CONFIG_FILE','HIDDEN_PINNED_FILE','NETWORK_SCAN_WATCH_FILE','LEGACY_IP_FILE'):
            variables[key]=str(Path(directory)/Path(getattr(main,key)).name)
        with patch.multiple(main,**variables):
            root=tk.Tk();root.withdraw()
            status=SimpleNamespace(valid=True,label='Test fixture',remaining_seconds=None,plan='test')
            app=main.MichmanKP(root,license_manager=SimpleNamespace(),license_status=status,
                identity_session={'user':'test','role':'Administrator','ssl_context':None})
            host=main.Host('192.0.2.1','Fixture')
            app.hosts[host.ip]=host
            app.apply_check_result(host,{'online':True,'ping':12,'current_mac':'','mac_match':None,'icmp_successes':3,'tcp_success_ports':[],'response_method':'ICMP'})
            assert app.platform_core.rows('SELECT * FROM p_assets WHERE ip=?',(host.ip,))
            app.mikrotik_config_dialog();root.update_idletasks()
            router_windows=[widget for widget in root.winfo_children() if isinstance(widget,tk.Toplevel) and 'Роутери' in widget.title()]
            assert len(router_windows)==1
            router_window=router_windows[0]
            router_trees=[widget for widget in router_window.winfo_children() if isinstance(widget,ttk.Treeview)]
            assert router_trees and 'platform' in router_trees[0]['columns']
            assert router_window.winfo_width()>=760 and router_window.winfo_height()>=420
            router_window.destroy()
            app.open_platform();app.platform_window.window.withdraw();root.update_idletasks()
            assert app.platform_window.alive
            app.close(confirm=False);app.platform_core.close()
    print('Main application: unified router window, unchanged activation, shared telemetry, platform open/close OK')


if __name__=='__main__':run()
