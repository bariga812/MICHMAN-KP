@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo MICHMAN KP 2.0.0 DEVICES - COMPATIBILITY BUILD
echo This PyInstaller build is easier to build but less resistant to analysis.
echo.

if not exist "MichmanKP_Icon.ico" (
  echo MichmanKP_Icon.ico was not found beside this script.
  goto :error
)

py -m pip install --upgrade pip
if errorlevel 1 goto :error

py -m pip install openpyxl "paramiko>=3.5,<6" "pysnmp==7.1.27" "pycryptodomex>=3.23,<4" pyinstaller
if errorlevel 1 goto :error

py -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --onedir ^
  --name MichmanKP_Protected ^
  --icon "MichmanKP_Icon.ico" ^
  --hidden-import michman_license ^
  --hidden-import michman_i18n ^
  --collect-all openpyxl ^
  --collect-all paramiko ^
  --collect-all pysnmp ^
  --collect-all pyasn1 ^
  --collect-all Cryptodome ^
  --collect-all psutil ^
  --collect-all PIL ^
  --collect-all pyautogui ^
  MichmanKP_Protected.py
if errorlevel 1 goto :error

echo.
echo BUILD COMPLETED
echo Program: dist\MichmanKP_Protected\MichmanKP_Protected.exe
pause
exit /b 0

:error
echo.
echo BUILD FAILED. Review the messages above.
pause
exit /b 1
