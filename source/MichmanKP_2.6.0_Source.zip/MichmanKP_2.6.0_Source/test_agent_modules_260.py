import unittest

from michman_agent import hardware_snapshot, health_snapshot, network_snapshot


class AgentReadOnlyModulesTests(unittest.TestCase):
    def test_health_has_bounded_score_and_storage(self):
        result=health_snapshot()
        self.assertGreaterEqual(result['score'],0)
        self.assertLessEqual(result['score'],100)
        self.assertIn(result['status'],('OK','WARNING','CRITICAL'))
        self.assertIsInstance(result['disks'],list)

    def test_hardware_inventory_has_host_and_cpu_counts(self):
        result=hardware_snapshot()
        self.assertTrue(result['hostname'])
        self.assertGreaterEqual(result['cpu_logical'] or 0,1)
        self.assertGreater(result['ram_total'],0)

    def test_network_inventory_has_structured_counters(self):
        result=network_snapshot()
        self.assertIsInstance(result['adapters'],list)
        if result['adapters']:
            adapter=result['adapters'][0]
            for key in ('name','addresses','rx_bytes','tx_bytes','rx_errors','tx_errors'):
                self.assertIn(key,adapter)


if __name__=='__main__':unittest.main()
