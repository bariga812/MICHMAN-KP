"""Synthetic UI integration: no desktop capture or remote control."""
import io,time,threading,tkinter as tk
from types import SimpleNamespace
from PIL import Image
from michman_platform_ui import RemoteViewer

root=tk.Tk();root.withdraw();errors=[]
root.report_callback_exception=lambda *args:errors.append(str(args[1]))
callbacks=[];lock=threading.Lock();input_calls=[];stream_options=[]
def gui(callback):
    with lock:callbacks.append(callback)
class Client:
    port=8743
    def frames(self,token,stop,**_options):
        stream_options.append(_options)
        while not stop.is_set():
            output=io.BytesIO();Image.new('RGB',(640,360),'navy').save(output,format='JPEG')
            yield output.getvalue();time.sleep(.01)
    def call(self,action,params,**kwargs):
        if action=='assist_input':input_calls.append(params)
        return {}
owner=SimpleNamespace(window=root,viewers=[],core=SimpleNamespace(audit=lambda *args:None),user='test',
    app=SimpleNamespace(run_on_gui=gui),status=tk.StringVar(),file_manager=lambda endpoint:None)
viewer=RemoteViewer(owner,Client(),'fixture','synthetic')
assert viewer.window.resizable()==(1,1)
viewer.resize_window(800,600);root.update()
assert viewer.window.winfo_width()<=800 and viewer.window.winfo_height()<=600
viewer.change_profile('economy')
viewer.send({'verb':'text','text':'abc'})
viewer.send({'verb':'key','key':'enter'})
viewer.send({'verb':'hotkey','keys':['ctrl','a']})
viewer.send({'verb':'text','text':'Україна'})
started=time.monotonic()
while time.monotonic()-started<.7:
    root.update();time.sleep(.01)
assert viewer.received>10,viewer.received
assert stream_options[-1]=={'fps':10,'width':960,'height':540,'quality':50},stream_options
assert hasattr(viewer,'image')
assert viewer.latest is None or len(viewer.latest)==3
assert [(p['verb'],p.get('text',p.get('key',p.get('keys')))) for p in input_calls]==[('text','abc'),('key','enter'),('hotkey',['ctrl','a']),('text','Україна')],input_calls
viewer.close();root.update();root.destroy()
assert viewer.stream_stop.is_set();assert not owner.viewers;assert not errors,errors
print('Synthetic desktop stream UI: frames rendered, bounded latest-frame slot, close stops receiver OK')
