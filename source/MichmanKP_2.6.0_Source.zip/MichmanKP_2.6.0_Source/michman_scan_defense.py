"""Local-only response helpers for ScanWatch.

The module deliberately limits the response to this Windows computer's
firewall.  It never connects to, probes, or runs commands on the source host.
"""

from __future__ import annotations

import base64
import ctypes
import ipaddress
import os
import subprocess
import sys


RULE_PREFIX = "MICHMAN KP Scan Defense"
FILTERING_PLATFORM_PACKET_DROP = "{0CCE9225-69AE-11D9-BED3-505054503030}"
FILTERING_PLATFORM_CONNECTION = "{0CCE9226-69AE-11D9-BED3-505054503030}"


def blockable_ipv4(value: str) -> str:
    """Return a canonical unicast IPv4 address suitable for a firewall rule."""
    address = ipaddress.ip_address(str(value or "").strip())
    if address.version != 4:
        raise ValueError("Only IPv4 sources are supported")
    if (
        address.is_loopback
        or address.is_multicast
        or address.is_unspecified
        or address == ipaddress.ip_address("255.255.255.255")
    ):
        raise ValueError("This IPv4 address cannot be blocked")
    return str(address)


def rule_name(source_ip: str) -> str:
    return f"{RULE_PREFIX} {blockable_ipv4(source_ip)}"


def is_windows_admin() -> bool:
    if not sys.platform.startswith("win"):
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _encoded_firewall_script(source_ip: str, blocked: bool) -> str:
    source_ip = blockable_ipv4(source_ip)
    name = rule_name(source_ip)
    # Values interpolated below have already been reduced to a canonical IPv4
    # address and a constant prefix.  EncodedCommand prevents shell parsing in
    # the unelevated launcher process.
    lines = [
        "$ErrorActionPreference='Stop'",
        f"$rule='{name}'",
        f"$ip='{source_ip}'",
        "& netsh.exe advfirewall firewall delete rule name=$rule | Out-Null",
    ]
    if blocked:
        lines.extend(
            [
                "& netsh.exe advfirewall firewall add rule name=$rule dir=in action=block remoteip=$ip profile=any enable=yes | Out-Null",
                "if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }",
            ]
        )
    lines.append("exit 0")
    script = "\r\n".join(lines)
    return base64.b64encode(script.encode("utf-16le")).decode("ascii")


def _encoded_scan_sensor_script() -> str:
    """Build the local Windows audit/logging setup used by ScanWatch."""
    lines = [
        "$ErrorActionPreference='Stop'",
        "$logDir=Join-Path $env:SystemRoot 'System32\\LogFiles\\Firewall'",
        "New-Item -ItemType Directory -Path $logDir -Force | Out-Null",
        f"& auditpol.exe /set /subcategory:'{FILTERING_PLATFORM_PACKET_DROP}' /success:enable /failure:enable | Out-Null",
        "if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }",
        f"& auditpol.exe /set /subcategory:'{FILTERING_PLATFORM_CONNECTION}' /success:enable /failure:enable | Out-Null",
        "if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }",
        "$logFile=Join-Path $logDir 'pfirewall.log'",
        "Set-NetFirewallProfile -Profile Domain,Private,Public -LogBlocked True -LogAllowed True -LogFileName $logFile -LogMaxSizeKilobytes 32767",
        "exit 0",
    ]
    return base64.b64encode("\r\n".join(lines).encode("utf-16le")).decode("ascii")


def enable_windows_scan_sensor(
    *,
    allow_elevation: bool = True,
    timeout: int = 90,
) -> tuple[bool, str]:
    """Enable local Windows Firewall and Filtering Platform event logging.

    The operation only changes audit/logging settings on this computer.  It
    does not capture payloads, scan the network, or contact another host.
    """
    if not sys.platform.startswith("win"):
        return False, "Сенсор сканування доступний лише у Windows."

    encoded = _encoded_scan_sensor_script()
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    common = [
        "powershell.exe",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
    ]
    if is_windows_admin():
        command = common + ["-EncodedCommand", encoded]
    elif allow_elevation:
        launcher = (
            "$p=Start-Process -FilePath 'powershell.exe' -Verb RunAs "
            "-WindowStyle Hidden -Wait -PassThru -ArgumentList "
            f"@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand','{encoded}'); "
            "exit $p.ExitCode"
        )
        command = common + ["-Command", launcher]
    else:
        return False, "Для ввімкнення сенсора потрібні права адміністратора."

    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=max(15, int(timeout)),
            creationflags=flags,
            env=os.environ.copy(),
        )
    except subprocess.TimeoutExpired:
        return False, "Перевищено час очікування налаштування сенсора/UAC."
    except OSError as exc:
        return False, f"Не вдалося запустити налаштування сенсора: {exc}"

    if completed.returncode == 0:
        return True, "Сенсор активовано: Windows записує дозволені та заблоковані вхідні з’єднання."
    details = (completed.stderr or completed.stdout or "").strip()
    first = next((line.strip() for line in details.splitlines() if line.strip()), "")
    if completed.returncode == 1223 or "canceled" in first.lower():
        return False, "Запит UAC скасовано; сенсор не активовано."
    return False, first[:240] or "Не вдалося активувати локальний сенсор Windows."


def set_windows_firewall_block(
    source_ip: str,
    blocked: bool = True,
    *,
    allow_elevation: bool = True,
    timeout: int = 90,
) -> tuple[bool, str]:
    """Add or remove one inbound Windows Firewall block rule.

    When the app is not elevated, Windows displays its standard UAC prompt.
    The function returns a short user-facing status and performs no network IO.
    """
    source_ip = blockable_ipv4(source_ip)
    if not sys.platform.startswith("win"):
        return False, "Windows Firewall доступний лише у Windows."

    encoded = _encoded_firewall_script(source_ip, blocked)
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    common = [
        "powershell.exe",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
    ]

    if is_windows_admin():
        command = common + ["-EncodedCommand", encoded]
    elif allow_elevation:
        launcher = (
            "$p=Start-Process -FilePath 'powershell.exe' -Verb RunAs "
            "-WindowStyle Hidden -Wait -PassThru -ArgumentList "
            f"@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand','{encoded}'); "
            "exit $p.ExitCode"
        )
        command = common + ["-Command", launcher]
    else:
        return False, "Потрібні права адміністратора для Windows Firewall."

    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=max(15, int(timeout)),
            creationflags=flags,
            env=os.environ.copy(),
        )
    except subprocess.TimeoutExpired:
        return False, "Перевищено час очікування Windows Firewall/UAC."
    except OSError as exc:
        return False, f"Windows Firewall недоступний: {exc}"

    if completed.returncode == 0:
        if blocked:
            return True, f"IP {source_ip} заблоковано локальним Windows Firewall."
        return True, f"Локальне блокування IP {source_ip} видалено."

    details = (completed.stderr or completed.stdout or "").strip()
    first = next((line.strip() for line in details.splitlines() if line.strip()), "")
    if completed.returncode == 1223 or "canceled" in first.lower():
        return False, "Запит UAC скасовано; IP не заблоковано."
    return False, first[:240] or "Не вдалося змінити правило Windows Firewall."
