import tempfile
import tkinter as tk
import unittest
from tkinter import ttk
from unittest.mock import patch
from pathlib import Path
from michman_windows import present,restore,WrapToolbar,install_window_policy
from michman_identity import IdentityStore,login_dialog


class WindowTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw();install_window_policy()
    def tearDown(self):
        try:self.root.destroy()
        except tk.TclError:pass
    def test_login_visible_with_withdrawn_owner(self):
        result={}
        def inspect():
            children=[w for w in self.root.winfo_children() if isinstance(w,tk.Toplevel)]
            if children:
                win=children[0];result['visible']=win.winfo_viewable();result['transient']=str(win.transient())
                result['children']=len(win.winfo_children());win.destroy()
        with tempfile.TemporaryDirectory() as directory:
            self.root.after(250,inspect)
            self.assertIsNone(login_dialog(self.root,IdentityStore(directory)))
        self.assertTrue(result['visible']);self.assertEqual(result['transient'],'');self.assertGreater(result['children'],0)
    def test_size_clamped_including_minimum(self):
        win=tk.Toplevel(self.root);win.geometry('1260x860');win.minsize(1000,700)
        with patch.object(win,'winfo_screenwidth',return_value=1024),patch.object(win,'winfo_screenheight',return_value=768):
            present(win,1260,860)
            self.root.update()
            self.assertLessEqual(win.winfo_width(),984);self.assertLessEqual(win.winfo_height(),668)
            self.assertLessEqual(win.minsize()[1],668)
    def test_restore_withdrawn_window(self):
        win=tk.Toplevel(self.root);self.root.update();win.withdraw();restore(win);self.root.update()
        self.assertTrue(win.winfo_viewable())
    def test_toolbar_controls_wrap_inside_width(self):
        win=tk.Toplevel(self.root);win.geometry('600x500')
        bar=WrapToolbar(win);bar.pack(fill='x')
        for i in range(12):ttk.Button(bar,text=f'Довга кнопка {i}').pack(side='left')
        self.root.update()
        self.assertGreater(bar.winfo_height(),50)
        for child in bar.winfo_children():
            self.assertLessEqual(child.winfo_x()+child.winfo_width(),bar.winfo_width())
            self.assertLessEqual(child.winfo_y()+child.winfo_height(),bar.winfo_height())


if __name__=='__main__':unittest.main()
