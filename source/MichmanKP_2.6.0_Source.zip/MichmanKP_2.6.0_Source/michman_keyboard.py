"""Translate focused Tk keyboard input into atomic remote actions.

Modifiers are never held on the remote host between requests.
"""
MODIFIERS={'Control_L':'ctrl','Control_R':'ctrl','Shift_L':'shift','Shift_R':'shift','Alt_L':'alt','Alt_R':'alt','Super_L':'win','Super_R':'win','Win_L':'win','Win_R':'win'}
KEYS={'Return':'enter','KP_Enter':'enter','BackSpace':'backspace','Tab':'tab','ISO_Left_Tab':'tab','Escape':'esc','Delete':'delete','Insert':'insert','Home':'home','End':'end','Prior':'pageup','Next':'pagedown','Left':'left','Right':'right','Up':'up','Down':'down','space':'space','Caps_Lock':'capslock','Num_Lock':'numlock','Scroll_Lock':'scrolllock','Print':'printscreen','Pause':'pause','KP_Add':'add','KP_Subtract':'subtract','KP_Multiply':'multiply','KP_Divide':'divide','KP_Decimal':'decimal'}
KEYS.update({f'F{i}':f'f{i}' for i in range(1,25)})
KEYS.update({f'KP_{i}':str(i) for i in range(10)})

class KeyboardInput:
    def __init__(self):self.held=set()
    def reset(self):self.held.clear()
    def release(self,keysym):self.held.discard(keysym)
    def press(self,keysym,char='',keycode=0,state=0):
        if keysym in MODIFIERS:self.held.add(keysym);return None
        mods={MODIFIERS[k] for k in self.held}
        if state & 4:mods.add('ctrl')
        if state & 1:mods.add('shift')
        if keysym=='Escape' and {'ctrl','alt'}<=mods:
            self.reset();return {'local_release':True}
        # Printable characters include the local keyboard layout and Shift.
        # AltGr produces text even though Windows reports Ctrl+Alt.
        if char and char.isprintable() and (not mods.intersection({'ctrl','alt','win'}) or 'Alt_R' in self.held):
            return {'verb':'text','text':char}
        key=KEYS.get(keysym)
        if key is None:
            if 65<=keycode<=90:key=chr(keycode).lower()
            elif len(keysym)==1 and keysym.isascii():key=keysym.lower()
        if not key:return None
        ordered=[m for m in ('ctrl','alt','shift','win') if m in mods]
        return {'verb':'hotkey','keys':ordered+[key]} if ordered else {'verb':'key','key':key}
