import unittest
from types import SimpleNamespace
from michman_keyboard import KeyboardInput
from michman_agent import atomic_hotkey

class KeyboardTests(unittest.TestCase):
 def setUp(self):self.keys=KeyboardInput()
 def test_unicode_text(self):
  self.assertEqual(self.keys.press('Cyrillic_ya','я',90),{'verb':'text','text':'я'})
 def test_ctrl_uses_physical_letter_with_cyrillic_layout(self):
  self.keys.press('Control_L')
  self.assertEqual(self.keys.press('Cyrillic_es','',67),{'verb':'hotkey','keys':['ctrl','c']})
 def test_shift_tab(self):
  self.keys.press('Shift_L')
  self.assertEqual(self.keys.press('Tab','\t'),{'verb':'hotkey','keys':['shift','tab']})
 def test_focus_reset_does_not_retain_modifiers(self):
  self.keys.press('Control_L');self.keys.reset()
  self.assertEqual(self.keys.press('a','a',65),{'verb':'text','text':'a'})
 def test_release_right_modifier_keeps_left(self):
  self.keys.press('Control_L');self.keys.press('Control_R');self.keys.release('Control_R')
  self.assertEqual(self.keys.press('a','',65)['keys'],['ctrl','a'])
 def test_local_escape(self):
  self.keys.press('Control_L');self.keys.press('Alt_L')
  self.assertTrue(self.keys.press('Escape')['local_release']);self.assertFalse(self.keys.held)
 def test_altgr_text(self):
  self.keys.press('Control_L');self.keys.press('Alt_R')
  self.assertEqual(self.keys.press('at','@',81,4)['text'],'@')
 def test_special_keys(self):
  for symbol,key in [('F12','f12'),('Delete','delete'),('Left','left'),('Return','enter')]:
   self.assertEqual(self.keys.press(symbol),{'verb':'key','key':key})
 def test_hotkey_releases_on_failure(self):
  calls=[]
  def down(key,**kwargs):
   calls.append(('down',key))
   if key=='c':raise RuntimeError('fail-safe')
  backend=SimpleNamespace(FAILSAFE=True,keyDown=down,keyUp=lambda key,**kwargs:calls.append(('up',key)))
  with self.assertRaises(RuntimeError):atomic_hotkey(backend,['ctrl','c'])
  self.assertEqual(calls[-2:],[('up','c'),('up','ctrl')]);self.assertTrue(backend.FAILSAFE)

if __name__=='__main__':unittest.main()
