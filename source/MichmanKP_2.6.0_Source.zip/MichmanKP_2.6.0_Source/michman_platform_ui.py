from michman_windows import install_window_policy, WrapToolbar, restore, present
install_window_policy()
"""Role-specific unified operations workspace and managed endpoint console."""
import base64
import copy
import io
import json
import os
import re
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog,filedialog

from michman_identity import ROLES,require
from michman_agent import AgentClient
from michman_platform_core import SyslogReceiver

WORKSPACES={'Network Operations':['Огляд','Канали / Карта','Інциденти','Syslog / Звіти'],
    'IT Administration':['Огляд','Канали / Карта','Керовані ПК','Стан ПК','Інциденти','Syslog / Звіти'],
    'Security Operations':['Огляд','Baseline / Безпека','Інциденти','Syslog / Звіти'],
    'Full Workspace':['Огляд','Канали / Карта','Керовані ПК','Стан ПК','Baseline / Безпека','Інциденти','Syslog / Звіти']}


def fmt_time(value):
    return datetime.fromtimestamp(value).strftime('%Y-%m-%d %H:%M:%S') if value else '—'


class PlatformWindow:
    def __init__(self,app):
        self.app,self.core,self.session=app,app.platform_core,app.identity_session
        self.role,self.user=self.session['role'],self.session['user']
        self.window=tk.Toplevel(app.root);self.window.title('МІЧМАН КП 2.0 — NOC · IT · SOC')
        self.window.geometry('1260x860');self.window.minsize(1000,700)
        self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.alive=True;self.busy=set();self.selected_ip=None;self.agent_snapshots={};self.health_snapshots={};self.viewers=[]
        self.receiver=None;self.next_agents=0;self.next_health=0;self.alert_seen=set()
        self.status=tk.StringVar(value=f'{self.user} / {self.role}')
        header=ttk.Frame(self.window,padding=12);header.pack(fill='x')
        ttk.Label(header,text='MICHMAN KP 2.0  /  ЄДИНИЙ РОБОЧИЙ ПРОСТІР').pack(side='left')
        self.workspace=tk.StringVar(value=self.core.setting('workspace:'+self.user,'Full Workspace'))
        chooser=ttk.Combobox(header,textvariable=self.workspace,values=list(WORKSPACES),state='readonly',width=25)
        chooser.pack(side='right');chooser.bind('<<ComboboxSelected>>',lambda _:self.apply_workspace())
        self.tabs=ttk.Notebook(self.window);self.tabs.pack(fill='both',expand=True,padx=12)
        self.pages={}
        for title in WORKSPACES['Full Workspace']:
            frame=ttk.Frame(self.tabs,padding=10);self.pages[title]=frame;self.tabs.add(frame,text=title)
        self.overview();self.links();self.endpoints();self.endpoint_health();self.security();self.incidents();self.logs()
        ttk.Label(self.window,textvariable=self.status,wraplength=1190,padding=10).pack(fill='x')
        self.apply_workspace();self.refresh();self.timer=self.window.after(1000,self.tick)

    def permit(self,cap):
        try: require(self.role,cap);return True
        except PermissionError as error: messagebox.showerror('Доступ',str(error),parent=self.window);return False

    def close(self):
        if any(key.startswith('action:') for key in self.busy):
            messagebox.showinfo('Операція триває','Дочекайтеся завершення віддаленої дії.',parent=self.window);return
        self.alive=False;self.window.after_cancel(self.timer)
        for viewer in list(self.viewers):viewer.close()
        if self.receiver: self.receiver.close();self.receiver=None
        self.window.destroy()

    def apply_workspace(self):
        for frame in self.pages.values(): self.tabs.hide(frame)
        for title in WORKSPACES.get(self.workspace.get(),WORKSPACES['Full Workspace']): self.tabs.add(self.pages[title],text=title)
        self.core.set_setting('workspace:'+self.user,self.workspace.get())

    def job(self,key,work,done):
        if key in self.busy:return
        self.busy.add(key);self.status.set('Виконується: '+key)
        def worker():
            try: result,error=work(),None
            except Exception as exc: result,error=None,str(exc) or type(exc).__name__
            def finish():
                self.busy.discard(key)
                if not self.alive:return
                if error:self.status.set('Помилка: '+error)
                else:
                    self.status.set('Завершено: '+key);done(result)
            self.app.run_on_gui(finish)
        threading.Thread(target=worker,name='Platform-'+key,daemon=True).start()

    def tree(self,parent,columns,height=10,selectmode='browse'):
        frame=ttk.Frame(parent);frame.pack(fill='both',expand=True,pady=5)
        tree=ttk.Treeview(frame,columns=[c[0] for c in columns],show='headings',height=height,selectmode=selectmode)
        for key,text,width in columns:tree.heading(key,text=text);tree.column(key,width=width,minwidth=60)
        y=ttk.Scrollbar(frame,command=tree.yview);x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
        tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        tree.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew')
        frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        return tree

    def text_window(self,title,text):
        win=tk.Toplevel(self.window);win.title(title);win.geometry('1050x700')
        view=tk.Text(win,wrap='none');bar=ttk.Scrollbar(win,command=view.yview)
        bar.pack(side='right',fill='y')
        horizontal=ttk.Scrollbar(win,orient='horizontal',command=view.xview);horizontal.pack(side='bottom',fill='x')
        view.configure(yscrollcommand=bar.set,xscrollcommand=horizontal.set);view.pack(fill='both',expand=True)
        view.insert('1.0',text if isinstance(text,str) else json.dumps(text,ensure_ascii=False,indent=2,default=str));view.configure(state='disabled')
        return win

    def overview(self):
        page=self.pages['Огляд'];bar=WrapToolbar(page);bar.pack(fill='x')
        for label,command in [('Оновити',self.refresh),('SNMP / MikroTik / Backup',self.app.open_network_center),
            ('Облікові записи',self.users_dialog),('Журнал адміністратора',self.show_audit)]:ttk.Button(bar,text=label,command=command).pack(side='left',padx=4)
        self.summary=tk.StringVar();ttk.Label(page,textvariable=self.summary,padding=10).pack(fill='x')
        self.inventory=self.tree(page,[('ip','IP',140),('name','Назва',180),('online','Мережа',90),('ping','Ping ms',80),('cpu','CPU %',75),('ram','RAM %',75),('mac','MAC',160),('seen','Остання телеметрія',170)])
        self.inventory.bind('<<TreeviewSelect>>',self.select_asset)
        ttk.Label(page,text='Спільний облік із головним моніторингом. Агент доповнює CPU/RAM/диски; ONLINE визначається мережевим ядром.',wraplength=1120).pack(fill='x')

    def select_asset(self,_=None):
        selected=self.inventory.selection()
        if selected:self.selected_ip=selected[0];self.link_ip.set(selected[0]);self.baseline_ip.set(selected[0])

    def links(self):
        page=self.pages['Канали / Карта'];bar=WrapToolbar(page);bar.pack(fill='x')
        self.link_ip=tk.StringVar();ttk.Entry(bar,textvariable=self.link_ip,width=20).pack(side='left')
        self.period=tk.StringVar(value='1h');ttk.Combobox(bar,textvariable=self.period,values=['1h','24h','7d','30d'],state='readonly',width=7).pack(side='left',padx=6)
        ttk.Button(bar,text='Історія каналу',command=self.show_link).pack(side='left')
        ttk.Button(bar,text='Залежність parent → child',command=self.add_dependency).pack(side='left',padx=6)
        ttk.Button(bar,text='Видалити залежність',command=self.delete_dependency).pack(side='left')
        ttk.Button(bar,text='Communication Map',command=self.communication_map).pack(side='left',padx=6)
        self.link_summary=tk.StringVar(value='Виберіть пристрій в огляді або введіть IP.')
        ttk.Label(page,textvariable=self.link_summary,wraplength=1150,padding=8).pack(fill='x')
        self.chart=tk.Canvas(page,background='#0b1722',height=250);self.chart.pack(fill='both',expand=True)
        self.dependencies=self.tree(page,[('parent','Підтверджений parent',200),('child','Підлеглий пристрій',200)],height=5)

    def show_link(self):
        ip=self.link_ip.get().strip();seconds={'1h':3600,'24h':86400,'7d':604800,'30d':2592000}[self.period.get()]
        def done(m):
            values={k:(round(v,2) if isinstance(v,float) else v) for k,v in m.items() if k!='history'}
            self.link_summary.set(json.dumps(values,ensure_ascii=False)+' · uptime — частка успішних перевірок')
            self.chart.delete('all');history=m['history'];width=max(800,self.chart.winfo_width());height=max(240,self.chart.winfo_height())
            if not history:return
            ceiling=max(1,max((d.get('ping') or 0 for _,d in history)))
            first,last=history[0][0],history[-1][0];previous=None
            step=max(1,len(history)//1500)
            for ts,data in history[::step]:
                x=30+(ts-first)/max(1,last-first)*(width-60)
                if data.get('online') is False:self.chart.create_line(x,20,x,height-30,fill='#ff4d6d');previous=None;continue
                ping=data.get('ping')
                if ping is None:previous=None;continue
                y=height-30-ping/ceiling*(height-60)
                if previous:self.chart.create_line(*previous,x,y,fill='#20f6a7',width=2)
                previous=x,y
            self.chart.create_text(10,10,text=f'{ceiling:.1f} ms',anchor='nw',fill='white')
            self.chart.create_text(30,height-12,text=fmt_time(first),anchor='w',fill='white')
            self.chart.create_text(width-20,height-12,text=fmt_time(last),anchor='e',fill='white')
        self.job('link-history',lambda:self.core.link_metrics(ip,seconds),done)

    def add_dependency(self):
        if not self.permit('configure'):return
        value=simpledialog.askstring('Залежність','Введіть parent IP → child IP (через пробіл):',parent=self.window)
        if value:
            try:
                parent,child=value.split();self.core.set_dependency(parent,child);self.core.audit(self.user,child,'DEPENDENCY',parent);self.refresh()
            except Exception as error:self.status.set(str(error))

    def delete_dependency(self):
        if not self.permit('configure'):return
        selection=self.dependencies.selection()
        if selection:
            child=self.dependencies.item(selection[0],'values')[1];self.core.remove_dependency(child);self.core.audit(self.user,child,'REMOVE_DEPENDENCY','OK');self.refresh()

    def communication_map(self):
        assets={r['ip']:r for r in self.core.rows('SELECT * FROM p_assets')};links=self.core.rows('SELECT * FROM p_dependencies')
        children={}
        for edge in links:children.setdefault(edge['parent'],[]).append(edge['child'])
        roots=sorted(set(assets)-{edge['child'] for edge in links})
        win=tk.Toplevel(self.window);win.title('Communication Map — підтверджені залежності');win.geometry('1100x760')
        canvas=tk.Canvas(win,background='#0b1722');ybar=ttk.Scrollbar(win,command=canvas.yview);ybar.pack(side='right',fill='y')
        xbar=ttk.Scrollbar(win,orient='horizontal',command=canvas.xview);xbar.pack(side='bottom',fill='x')
        canvas.configure(yscrollcommand=ybar.set,xscrollcommand=xbar.set);canvas.pack(fill='both',expand=True)
        positions={};row=[0]
        def draw(ip,depth=0):
            if ip in positions:return
            y=50+row[0]*80;x=150+depth*250;row[0]+=1;positions[ip]=(x,y)
            asset=assets.get(ip,{});data=json.loads(asset.get('latest','{}'));state=data.get('online')
            color='#20f6a7' if state is True else '#ff4d6d' if state is False else '#9ec2ce'
            canvas.create_rectangle(x-110,y-30,x+110,y+30,outline=color,fill='#132d3d')
            canvas.create_text(x,y,text=f"{asset.get('name',ip)}\n{ip} · {data.get('ping','—')} ms / {data.get('loss','—')}%",fill=color,width=215)
            for child in children.get(ip,[]):
                draw(child,depth+1);cx,cy=positions[child];canvas.create_line(x+110,y,cx-110,cy,fill='#9ec2ce')
        for ip in roots:draw(ip)
        for ip in assets:
            if ip not in positions:draw(ip)
        canvas.configure(scrollregion=canvas.bbox('all'))

    def endpoints(self):
        page=self.pages['Керовані ПК'];bar=WrapToolbar(page);bar.pack(fill='x')
        for label,command in [('Зареєструвати агент',self.enroll),('Додати адресу агента',self.add_endpoint),('Додати MAC агента',self.add_endpoint_mac),('Опитати',self.poll_agents),
            ('Процеси',lambda:self.remote('processes')),('Служби',lambda:self.remote('services')),('ПЗ',lambda:self.remote('software'))]:ttk.Button(bar,text=label,command=command).pack(side='left',padx=3)
        bar2=WrapToolbar(page);bar2.pack(fill='x',pady=5)
        for label,command in [('Події',lambda:self.remote('events')),('Оновлення',lambda:self.remote('updates')),
            ('Terminal / PowerShell',self.command),('Файли',self.file_manager),('Служба: дія',self.service_action),
            ('Remote Assistance',self.assistance),('RDP',self.rdp)]:ttk.Button(bar2,text=label,command=command).pack(side='left',padx=3)
        bar3=WrapToolbar(page);bar3.pack(fill='x')
        for label,command in [('Перезавантажити',lambda:self.power('reboot')),('Вимкнути',lambda:self.power('shutdown')),
            ('Завершити процес',self.terminate),('Розгорнути файл / пакет',self.deploy),('Встановити Windows Update',self.install_updates),
            ('Видалити адресу',self.remove_endpoint)]:ttk.Button(bar3,text=label,command=command).pack(side='left',padx=3)
        self.endpoint_tree=self.tree(page,[('host','IP / DNS',150),('mac','MAC',145),('port','TLS',60),('state','Стан агента',190),('os','OS',250),('cpu','CPU %',65),('ram','RAM %',65),('uptime','Uptime s',100)],selectmode='extended')
        ttk.Label(page,text='Ctrl + клацання: групові дії. mTLS, персональні ролі та локальна політика агента перевіряються для кожного запиту.\n'
            'Команди — лише ID із дозволеного списку; Remote Assistance — тільки після згоди користувача.',wraplength=1150).pack(fill='x')

    def endpoint_configs(self):return self.core.setting('endpoints',[])

    def selected_endpoints(self):
        selected=set(self.endpoint_tree.selection())
        return [e for e in self.endpoint_configs() if e['host'] in selected]

    def client(self,endpoint):
        host=endpoint['host']
        if endpoint.get('mac'):
            resolved=self.app.resolve_mac_address(endpoint['mac'])
            if resolved:host=resolved
        return AgentClient(host,endpoint.get('port',8743),self.session['ssl_context'])

    def add_endpoint(self):
        if not self.permit('enroll'):return
        host=simpledialog.askstring('Агент','IP/DNS, який внесено в сертифікат агента:',parent=self.window)
        if not host:return
        port=simpledialog.askinteger('Агент','TLS-порт:',initialvalue=8743,minvalue=1,maxvalue=65535,parent=self.window)
        if not port:return
        endpoints=self.endpoint_configs()
        if any(e['host']==host for e in endpoints):self.status.set('Адреса вже додана');return
        endpoints.append({'host':host,'port':port});self.core.set_setting('endpoints',endpoints)
        self.core.audit(self.user,host,'ADD_AGENT','OK')
        # Add valid IPv4 endpoints to the existing monitored device registry.
        self.app.register_platform_host(host)
        self.refresh()

    def add_endpoint_mac(self):
        if not self.permit('enroll'):return
        mac=simpledialog.askstring('Агент','MAC-адреса керованого ПК:',parent=self.window)
        if mac is None:return
        mac=mac.strip().upper().replace('-',':')
        if not re.fullmatch(r'[0-9A-F]{2}(?::[0-9A-F]{2}){5}',mac):self.status.set('Некоректна MAC-адреса');return
        host=self.app.resolve_mac_address(mac)
        if not host:self.status.set('MAC не знайдено у локальній таблиці сусідів');return
        port=simpledialog.askinteger('Агент','TLS-порт:',initialvalue=8743,minvalue=1,maxvalue=65535,parent=self.window)
        if not port:return
        endpoints=self.endpoint_configs()
        if any(e.get('mac')==mac or e['host']==host for e in endpoints):self.status.set('Агент уже доданий');return
        endpoints.append({'host':host,'mac':mac,'port':port});self.core.set_setting('endpoints',endpoints)
        self.core.audit(self.user,host,'ADD_AGENT_MAC',mac);self.app.register_platform_host(host);self.refresh()

    def remove_endpoint(self):
        if not self.permit('enroll'):return
        targets=self.selected_endpoints()
        if targets and messagebox.askyesno('Видалити адресу','Припинити опитування вибраних агентів? Це не видаляє агент із ПК.',parent=self.window):
            self.core.set_setting('endpoints',[e for e in self.endpoint_configs() if e not in targets]);self.refresh()

    def enroll(self):
        if not self.permit('enroll'):return
        host=simpledialog.askstring('Реєстрація','IP/DNS керованого ПК:',parent=self.window)
        if not host:return
        folder=filedialog.askdirectory(parent=self.window,title='Папка для нового пакета реєстрації')
        if not folder:return
        password=simpledialog.askstring('Центр сертифікації','Пароль CA (пароль першого адміністратора на момент створення):',show='*',parent=self.window)
        if not password:return
        target=Path(folder)/('agent-'+''.join(c if c.isalnum() else '_' for c in host)+'-'+str(int(time.time())))
        def done(path):
            self.core.audit(self.user,host,'ENROLL_AGENT','certificate issued')
            messagebox.showinfo('Пакет агента',f'Створено {path}\nСкопіюйте цю папку на керований ПК. Запустіть MICHMAN_Agent.exe --config-dir <папка>.\nПотім додайте адресу агента в консоль.',parent=self.window)
        self.job('enroll',lambda:self.app.identity_store.provision_agent(host,target,password),done)

    def poll_agents(self):
        endpoints=copy.deepcopy(self.endpoint_configs())
        if not endpoints:return
        def work():
            def poll(endpoint):
                try:
                    data=self.client(endpoint).call('telemetry');self.core.ingest(endpoint['host'],data,data.get('name'));return endpoint['host'],data,None
                except Exception as error:
                    self.core.throttled_event(endpoint['host'],'AGENT_UNREACHABLE','WARNING',str(error));return endpoint['host'],{},str(error)
            with ThreadPoolExecutor(max_workers=4) as executor:return list(executor.map(poll,endpoints))
        def done(rows):
            endpoints=self.endpoint_configs();changed=False
            for host,data,error in rows:
                self.agent_snapshots[host]=(data,error)
                if data:
                    reported=str(data.get('primary_mac') or '').upper()
                    for endpoint in endpoints:
                        if endpoint['host']==host and reported and endpoint.get('mac')!=reported:
                            endpoint['mac']=reported;changed=True
            if changed:self.core.set_setting('endpoints',endpoints)
            self.next_agents=time.monotonic()+30;self.refresh()
        self.job('agent-poll',work,done)

    def remote(self,action,params=None,cap='read',confirm=False,timeout=45):
        if not self.permit(cap):return
        targets=self.selected_endpoints()
        if not targets:self.status.set('Виберіть керований ПК');return
        if confirm and not messagebox.askyesno('Підтвердити групову дію',f'{action}\nЦілі: '+', '.join(e['host'] for e in targets),parent=self.window):return
        def work():
            def call(endpoint):
                self.core.audit(self.user,endpoint['host'],action,'REQUESTED')
                try:
                    result=self.client(endpoint).call(action,params,timeout)
                    failed=isinstance(result,dict) and result.get('returncode',0)!=0
                    self.core.audit(self.user,endpoint['host'],action,'FAILED_EXIT' if failed else 'COMPLETED')
                    if failed:self.core.event(endpoint['host'],'REMOTE_ACTION_FAILED','WARNING',action+' returned a non-zero exit code')
                    return endpoint['host'],result
                except Exception as error:
                    self.core.audit(self.user,endpoint['host'],action,'FAILED: '+str(error));return endpoint['host'],{'error':str(error)}
            with ThreadPoolExecutor(max_workers=4) as executor:return dict(executor.map(call,targets))
        self.job('action:'+action,work,lambda result:self.text_window(action,result))

    def command(self):
        if not self.permit('command'):return
        value=simpledialog.askstring('Terminal / PowerShell','ID дозволеної команди з локальної політики agent.json (довільний shell не відкривається):',parent=self.window)
        if value:self.remote('command',{'id':value},'command',True,150)

    def service_action(self):
        if not self.permit('service'):return
        value=simpledialog.askstring('Служба','Назва служби та start / stop / restart через пробіл:',parent=self.window)
        if value:
            try:name,verb=value.split();self.remote('service_control',{'name':name,'verb':verb},'service',True)
            except ValueError:self.status.set('Формат: ServiceName restart')

    def power(self,verb):self.remote('power',{'verb':verb},'power',True)
    def install_updates(self):self.remote('install_updates',{},'deploy',True,1250)
    def terminate(self):
        if not self.permit('command'):return
        pid=simpledialog.askinteger('Процес','PID для завершення на вибраних ПК:',minvalue=2,parent=self.window)
        if pid:self.remote('terminate',{'pid':pid},'command',True)

    def rdp(self):
        if not self.permit('assist'):return
        targets=self.selected_endpoints()
        if len(targets)!=1:return
        host=targets[0]['host']
        if any(c.isspace() for c in host) or host.startswith(('/','-')):return
        subprocess.Popen(['mstsc.exe','/v:'+host]);self.core.audit(self.user,host,'RDP','native client opened')

    def file_manager(self,endpoint=None):
        if not self.permit('files'):return
        if endpoint is None:
            targets=self.selected_endpoints()
            if len(targets)!=1:self.status.set('Для файлового менеджера виберіть один ПК');return
            endpoint=targets[0]
        client=self.client(endpoint)
        win=tk.Toplevel(self.window);win.title('Файли — '+endpoint['host']);win.geometry('850x580')
        path=tk.StringVar(value='');ttk.Entry(win,textvariable=path).pack(fill='x',padx=10,pady=8)
        tree=self.tree(win,[('name','Назва',350),('type','Тип',100),('size','Bytes',140)])
        def done(items):
            if not win.winfo_exists():return
            tree.delete(*tree.get_children())
            for item in items:tree.insert('','end',values=(item['name'],'DIR' if item['directory'] else 'FILE',item['size']))
        # Capture Tk values before entering workers.
        def list_safe():
            remote_path=path.get();self.job('files-list',lambda:client.call('files_list',{'path':remote_path}),done)
        def select_path():
            chosen=tree.selection()
            if not chosen:return None
            return str(Path(path.get())/tree.item(chosen[0],'values')[0]).replace('\\','/')
        def enter(_):
            chosen=tree.selection()
            if chosen and tree.item(chosen[0],'values')[1]=='DIR':path.set(select_path());list_safe()
        tree.bind('<Double-1>',enter)
        cancel=threading.Event();active=[False]
        progress_text=tk.StringVar(value='Передача файлів у межах shared-папки агента')
        ttk.Label(win,textvariable=progress_text).pack(fill='x',padx=10)
        meter=ttk.Progressbar(win,maximum=100);meter.pack(fill='x',padx=10,pady=4)
        def transfer(action,work,remote_path):
            if active[0]:return
            active[0]=True;cancel.clear();started=time.monotonic()
            key='action:files:'+str(win);self.busy.add(key)
            def progress(done,total):
                elapsed=max(.001,time.monotonic()-started)
                value=100*done/total if total else 100
                text=f'{value:.0f}% · {done/1048576:.1f} / {total/1048576:.1f} MiB · {done/1048576/elapsed:.1f} MiB/s'
                def show():
                    if win.winfo_exists():meter.configure(value=value);progress_text.set(text)
                self.app.run_on_gui(show)
            def worker():
                try:work(progress,cancel);error=None
                except Exception as exc:error=str(exc)
                self.core.audit(self.user,endpoint['host'],action,error or remote_path)
                def finish():
                    self.busy.discard(key);active[0]=False
                    if win.winfo_exists():
                        progress_text.set(error or 'Передачу завершено');list_safe()
                self.app.run_on_gui(finish)
            threading.Thread(target=worker,daemon=True).start()
        def close_files():cancel.set();win.destroy()
        win.protocol('WM_DELETE_WINDOW',close_files)
        def download():
            remote_path=select_path()
            if not remote_path:return
            local=filedialog.asksaveasfilename(parent=win,initialfile=Path(remote_path).name)
            if local:transfer('DOWNLOAD',lambda progress,cancel:client.download(remote_path,local,progress,cancel),remote_path)
        def upload():
            locals=filedialog.askopenfilenames(parent=win,title='Виберіть один або кілька файлів')
            if not locals:return
            if not messagebox.askyesno('Передача файлів',f'Файлів: {len(locals)}\n→ {endpoint["host"]}:{path.get() or "/"}\nДозволити заміну наявних файлів?',parent=win):return
            total=sum(Path(local).stat().st_size for local in locals)
            def batch(progress,cancel):
                completed=0
                for local in locals:
                    remote_path=str(Path(path.get())/Path(local).name).replace('\\','/')
                    size=Path(local).stat().st_size
                    client.upload(local,remote_path,True,lambda done,_size,base=completed:progress(base+done,total),cancel)
                    completed+=size
                return {'files':len(locals),'bytes':completed}
            transfer('UPLOAD_BATCH',batch,f'{len(locals)} files')
        def mkdir():
            name=simpledialog.askstring('Нова папка','Назва папки:',parent=win)
            if not name:return
            if '/' in name or '\\' in name or name in ('.','..'):progress_text.set('Некоректна назва папки');return
            remote_path=str(Path(path.get())/name).replace('\\','/')
            self.job('action:mkdir',lambda:client.call('files_mkdir',{'path':remote_path}),lambda _result:list_safe())
        def delete():
            remote_path=select_path()
            if remote_path and messagebox.askyesno('Видалення','Видалити '+remote_path+'?',parent=win):
                self.job('action:delete',lambda:client.call('files_delete',{'path':remote_path}),lambda result:(self.core.audit(self.user,endpoint['host'],'DELETE',remote_path),list_safe()))
        bar=WrapToolbar(win);bar.pack(fill='x')
        for label,command in [('Оновити',list_safe),('Завантажити з ПК',download),('Надіслати файли',upload),('Нова папка',mkdir),('Скасувати передачу',cancel.set),('Видалити файл',delete)]:ttk.Button(bar,text=label,command=command).pack(side='left',padx=5,pady=8)
        list_safe()

    def deploy(self):
        if not self.permit('deploy'):return
        targets=self.selected_endpoints()
        if not targets:return
        local=filedialog.askopenfilename(parent=self.window)
        if not local:return
        command=simpledialog.askstring('Розгортання','ID дозволеної команди встановлення (порожньо — лише передати файл):',parent=self.window)
        if command is None:return
        if not messagebox.askyesno('Групове розгортання',f'{Path(local).name}\nЦілі: '+', '.join(e['host'] for e in targets),parent=self.window):return
        def work():
            results={}
            for endpoint in targets:
                try:
                    client=self.client(endpoint);result=client.upload(local,Path(local).name,True)
                    if command:result=client.call('command',{'id':command},timeout=150)
                    results[endpoint['host']]=result;self.core.audit(self.user,endpoint['host'],'DEPLOY','COMPLETED')
                except Exception as error:results[endpoint['host']]={'error':str(error)};self.core.audit(self.user,endpoint['host'],'DEPLOY','FAILED')
            return results
        self.job('action:deploy',work,lambda results:self.text_window('Розгортання',results))

    def assistance(self):
        if not self.permit('assist'):return
        targets=self.selected_endpoints()
        if len(targets)!=1:return
        endpoint=targets[0];client=self.client(endpoint)
        self.job('action:assistance-request',lambda:client.call('assist_request',timeout=70),lambda result:RemoteViewer(self,client,endpoint['host'],result['token']))

    def endpoint_health(self):
        page=self.pages['Стан ПК'];bar=WrapToolbar(page);bar.pack(fill='x')
        for label,command in [('Оновити стан',self.poll_health),('Обладнання',lambda:self.health_detail('hardware')),
            ('Мережеві адаптери',lambda:self.health_detail('network_info')),('Діагностика агента',lambda:self.health_detail('agent_diagnostics')),
            ('Експорт JSON',self.export_fleet_health)]:ttk.Button(bar,text=label,command=command).pack(side='left',padx=4)
        self.health_summary=tk.StringVar(value='Виберіть ПК або оновіть стан усього парку.')
        ttk.Label(page,textvariable=self.health_summary,padding=8,wraplength=1150).pack(fill='x')
        self.health_tree=self.tree(page,[('host','IP / DNS',150),('state','Стан',90),('score','Оцінка',70),('cpu','CPU %',70),
            ('ram','RAM %',70),('disk','Диск max %',95),('battery','Батарея',90),('rx','RX MiB',90),('tx','TX MiB',90),
            ('version','Агент',85),('advice','Попередження / рекомендація',360)],selectmode='extended')
        ttk.Label(page,text='Дані читаються локальним агентом і передаються через mTLS. Модуль не змінює параметри ПК.',wraplength=1150).pack(fill='x')

    def health_targets(self):
        selected=set(self.health_tree.selection())
        return [endpoint for endpoint in self.endpoint_configs() if endpoint['host'] in selected] or self.endpoint_configs()

    def poll_health(self):
        targets=copy.deepcopy(self.health_targets())
        if not targets:self.next_health=time.monotonic()+60;self.status.set('Немає налаштованих агентів');return
        def work():
            def read(endpoint):
                try:
                    client=self.client(endpoint)
                    return endpoint['host'],{'health':client.call('health'),'network':client.call('network_info')},None
                except Exception as error:return endpoint['host'],{},str(error)
            with ThreadPoolExecutor(max_workers=4) as executor:return list(executor.map(read,targets))
        def done(rows):
            for host,data,error in rows:self.health_snapshots[host]=(data,error)
            good=sum(1 for _host,data,error in rows if not error and data.get('health',{}).get('status')=='OK')
            warnings=sum(1 for _host,data,error in rows if not error and data.get('health',{}).get('status')!='OK')
            self.health_summary.set(f'Перевірено: {len(rows)} · норма: {good} · потребують уваги: {warnings} · недоступні: {sum(bool(error) for _h,_d,error in rows)}')
            self.next_health=time.monotonic()+60
            self.refresh()
        self.job('health-poll',work,done)

    def health_detail(self,action):
        selected=self.health_tree.selection()
        if len(selected)!=1:self.status.set('Виберіть один ПК у вкладці «Стан ПК»');return
        endpoint=next((item for item in self.endpoint_configs() if item['host']==selected[0]),None)
        if endpoint:self.job('health:'+action,lambda:self.client(endpoint).call(action),lambda result:self.text_window(action+' — '+endpoint['host'],result))

    def export_fleet_health(self):
        path=filedialog.asksaveasfilename(parent=self.window,title='Експорт стану ПК',defaultextension='.json',filetypes=[('JSON','*.json')])
        if not path:return
        report={'generated_at':time.time(),'application':'MICHMAN KP','endpoints':{}}
        for endpoint in self.endpoint_configs():
            data,error=self.health_snapshots.get(endpoint['host'],({},'Ще не перевірено'))
            report['endpoints'][endpoint['host']]={'mac':endpoint.get('mac',''),'error':error,'data':data}
        from michman_utils import atomic_write_json
        atomic_write_json(path,report);self.status.set('Звіт збережено: '+path)

    def security(self):
        page=self.pages['Baseline / Безпека'];bar=WrapToolbar(page);bar.pack(fill='x')
        self.baseline_ip=tk.StringVar();ttk.Entry(bar,textvariable=self.baseline_ip,width=22).pack(side='left')
        for label,command in [('Прийняти baseline',self.accept_baseline),('Показати baseline',self.show_baseline),
            ('ScanWatch',self.app.open_scan_watch_window),('DFIR',self.app.open_dfir_window),('Security Audit MikroTik',self.app.open_mikrotik_security_center)]:ttk.Button(bar,text=label,command=command).pack(side='left',padx=4)
        self.security_tree=self.tree(page,[('ts','Час',160),('ip','IP',140),('kind','Подія',150),('severity','Рівень',95),('details','Деталі',500)])

    def accept_baseline(self):
        if not (self.permit('baseline') if self.role!='Administrator' else True):return
        ip=self.baseline_ip.get().strip()
        if ip and messagebox.askyesno('Baseline','Прийняти поточні MAC/порти як очікувані для '+ip+'?',parent=self.window):self.core.accept_baseline(ip,self.user);self.refresh()
    def show_baseline(self):
        rows=self.core.rows('SELECT * FROM p_assets WHERE ip=?',(self.baseline_ip.get().strip(),))
        if rows:self.text_window('Asset Baseline',rows[0])

    def incidents(self):
        page=self.pages['Інциденти'];bar=WrapToolbar(page);bar.pack(fill='x')
        for label,command in [('Timeline',self.timeline),('Підтвердити',lambda:self.set_incident('ACKNOWLEDGED')),('Закрити інцидент',lambda:self.set_incident('CLOSED')),
            ('FREEZE',self.freeze),('Експорт Flight Recorder',self.export_incident)]:ttk.Button(bar,text=label,command=command).pack(side='left',padx=4)
        self.incident_tree=self.tree(page,[('id','Incident',120),('time','Початок',160),('root','Ймовірне джерело',150),('severity','Severity',90),('status','Стан',130),('affected','Пристроїв',80),('summary','Опис',300)])
        ttk.Label(page,text='Flight Recorder: 10 хв до + 5 хв після початку інциденту. Контекст накопичується, поки програма працює.\n'
            'Кореляція — припущення за часом та підтвердженими залежностями; це не автоматичний доказ першопричини.',wraplength=1130).pack(fill='x')
    def selected_incident(self):
        selection=self.incident_tree.selection();return selection[0] if selection else None
    def timeline(self):
        incident=self.selected_incident()
        if incident:self.job('timeline',lambda:self.core.rows('SELECT ts,ip,kind,severity,details FROM p_events WHERE incident=? ORDER BY ts',(incident,)),lambda rows:self.text_window('Incident '+incident,rows))
    def set_incident(self,status):
        if not self.permit('ack'):return
        incident=self.selected_incident()
        if incident:self.core.incident_status(incident,status,self.user);self.refresh()
    def freeze(self):
        if not self.permit('ack'):return
        ip=self.selected_ip or simpledialog.askstring('FREEZE','IP пристрою:',parent=self.window)
        if ip:self.core.freeze(ip,self.user);self.refresh()
    def export_incident(self):
        incident=self.selected_incident()
        if incident:
            path=filedialog.asksaveasfilename(parent=self.window,defaultextension='.zip',initialfile='Incident-'+incident+'.zip')
            if path:self.job('export-incident',lambda:self.core.export_incident(incident,path),lambda _:self.status.set('Збережено '+path))

    def logs(self):
        page=self.pages['Syslog / Звіти'];bar=WrapToolbar(page);bar.pack(fill='x')
        self.syslog_bind=tk.StringVar(value='127.0.0.1');self.syslog_port=tk.StringVar(value='5514');self.syslog_allowed=tk.StringVar()
        for title,var,width in [('Bind',self.syslog_bind,15),('UDP port',self.syslog_port,7),('Дозволені CIDR через кому',self.syslog_allowed,35)]:ttk.Label(bar,text=title).pack(side='left');ttk.Entry(bar,textvariable=var,width=width).pack(side='left',padx=4)
        ttk.Button(bar,text='Старт / Стоп Syslog',command=self.toggle_syslog).pack(side='left',padx=4)
        ttk.Button(page,text='Звіт доступності CSV за 24h',command=self.export_report).pack(anchor='w',pady=8)
        self.log_tree=self.tree(page,[('ts','Час',160),('ip','IP',130),('severity','Рівень',100),('message','Повідомлення',700)])
        ttk.Label(page,text='Syslog UDP — джерело не автентифіковане. Список дозволених IP, ліміт 100 повідомлень/с та обрізання до 8 KiB.\n'
            'Сповіщення про нові інциденти показуються в цьому вікні; зовнішні повідомлення не надсилаються.',wraplength=1120).pack(fill='x')
    def toggle_syslog(self):
        if not self.permit('configure'):return
        if self.receiver:self.receiver.close();self.receiver=None;self.status.set('Syslog зупинено');return
        try:
            self.receiver=SyslogReceiver(self.core,self.syslog_bind.get().strip(),int(self.syslog_port.get()),self.syslog_allowed.get().split(','));self.status.set('Syslog працює')
        except Exception as error:self.status.set(str(error))
    def export_report(self):
        path=filedialog.asksaveasfilename(parent=self.window,defaultextension='.csv')
        if path:self.job('report',lambda:self.core.report(path),lambda _:self.status.set('Звіт збережено: '+path))
    def show_audit(self):self.text_window('Журнал хто → ціль → дія → результат',self.core.rows('SELECT * FROM p_audit ORDER BY id DESC LIMIT 1000'))

    def users_dialog(self):
        if not self.permit('users'):return
        win=tk.Toplevel(self.window);win.title('Облікові записи');win.geometry('750x480')
        tree=self.tree(win,[('name','Користувач',180),('role','Роль',220),('enabled','Активний',100)])
        def refresh():
            tree.delete(*tree.get_children())
            for name,data in self.app.identity_store.users().items():tree.insert('','end',iid=name,values=(name,data['role'],data['enabled']))
        def create():
            user=simpledialog.askstring('Користувач','Новий логін:',parent=win)
            if not user:return
            password=simpledialog.askstring('Пароль','Пароль нового користувача, від 12 символів:',show='*',parent=win)
            if not password:return
            role=simpledialog.askstring('Роль','Роль: '+', '.join(ROLES),parent=win)
            if not role:return
            ca_password=simpledialog.askstring('CA','Пароль центру сертифікації:',show='*',parent=win)
            if not ca_password:return
            def done(_):self.core.audit(self.user,user,'CREATE_USER',role);refresh()
            self.job('create-user',lambda:self.app.identity_store.create_user(user,password,role,ca_password),done)
        def disable():
            selected=tree.selection()
            if not selected or selected[0]==self.user:return
            target=selected[0];users=self.app.identity_store.users();serial=users[target]['serial']
            if not messagebox.askyesno('Вимкнути користувача','Вимкнути '+target+' та відкликати його сертифікат на налаштованих агентах?',parent=win):return
            users[target]['enabled']=False
            from michman_utils import atomic_write_json
            atomic_write_json(self.app.identity_store.path,users)
            endpoints=copy.deepcopy(self.endpoint_configs())
            def work():
                result={}
                for endpoint in endpoints:
                    try:result[endpoint['host']]=self.client(endpoint).call('revoke_user',{'serial':serial})
                    except Exception as error:result[endpoint['host']]={'error':str(error),'revocation_pending':True}
                return result
            def done(result):refresh();self.core.audit(self.user,target,'DISABLE_USER','See revocation results');self.text_window('Відкликання: офлайн-агенти потребують повтору',result)
            self.job('action:revoke',work,done)
        bar=WrapToolbar(win);bar.pack(fill='x')
        ttk.Button(bar,text='Створити',command=create).pack(side='left',padx=8,pady=8)
        ttk.Button(bar,text='Вимкнути / повторити відкликання',command=disable).pack(side='left',padx=8)
        refresh()

    def refresh(self):
        selected=self.inventory.selection();self.inventory.delete(*self.inventory.get_children())
        assets=self.core.rows('SELECT * FROM p_assets ORDER BY ip')
        for asset in assets:
            data=json.loads(asset['latest']);online=data.get('online')
            self.inventory.insert('','end',iid=asset['ip'],values=(asset['ip'],asset['name'],'ONLINE' if online is True else 'OFFLINE' if online is False else '—',
                data.get('ping','—'),data.get('cpu_percent','—'),data.get('ram_percent','—'),data.get('current_mac') or data.get('mt_mac','—'),fmt_time(asset['last_seen'])))
        if selected and self.inventory.exists(selected[0]):self.inventory.selection_set(selected[0])
        self.dependencies.delete(*self.dependencies.get_children())
        for edge in self.core.rows('SELECT * FROM p_dependencies'):self.dependencies.insert('','end',values=(edge['parent'],edge['child']))
        selected_agents=self.endpoint_tree.selection();self.endpoint_tree.delete(*self.endpoint_tree.get_children())
        for endpoint in self.endpoint_configs():
            data,error=self.agent_snapshots.get(endpoint['host'],({},None))
            mac=endpoint.get('mac') or data.get('primary_mac') or '—'
            self.endpoint_tree.insert('','end',iid=endpoint['host'],values=(endpoint['host'],mac,endpoint.get('port',8743),error or ('OK' if data else 'Очікує'),data.get('os','—'),data.get('cpu_percent','—'),data.get('ram_percent','—'),data.get('uptime','—')))
        for selected_agent in selected_agents:
            if self.endpoint_tree.exists(selected_agent):self.endpoint_tree.selection_add(selected_agent)
        selected_health=self.health_tree.selection();self.health_tree.delete(*self.health_tree.get_children())
        for endpoint in self.endpoint_configs():
            host=endpoint['host'];bundle,error=self.health_snapshots.get(host,({},None));health=bundle.get('health',{});network=bundle.get('network',{})
            adapters=network.get('adapters',[]);rx=sum(item.get('rx_bytes',0) for item in adapters)/1048576;tx=sum(item.get('tx_bytes',0) for item in adapters)/1048576
            battery=health.get('battery');battery_text=(str(round(battery.get('percent',0)))+'%'+(' AC' if battery.get('plugged') else '')) if battery else '—'
            warnings='; '.join(health.get('warnings',[])) or ('Норма' if health else 'Ще не перевірено')
            self.health_tree.insert('','end',iid=host,values=(host,error or health.get('status','—'),health.get('score','—'),health.get('cpu_percent','—'),
                health.get('ram_percent','—'),health.get('max_disk_percent','—'),battery_text,f'{rx:.1f}',f'{tx:.1f}',
                self.agent_snapshots.get(host,({},None))[0].get('agent_version','—'),error or warnings))
        for item in selected_health:
            if self.health_tree.exists(item):self.health_tree.selection_add(item)
        selection=self.incident_tree.selection();self.incident_tree.delete(*self.incident_tree.get_children())
        incidents=self.core.rows('SELECT i.*,COUNT(a.ip) affected FROM p_incidents i LEFT JOIN p_affected a ON a.incident=i.id GROUP BY i.id ORDER BY started DESC LIMIT 300')
        for incident in incidents:
            self.incident_tree.insert('','end',iid=incident['id'],values=(incident['id'],fmt_time(incident['started']),incident['root'],incident['severity'],incident['status'],incident['affected'],incident['summary']))
        if selection and self.incident_tree.exists(selection[0]):self.incident_tree.selection_set(selection[0])
        self.security_tree.delete(*self.security_tree.get_children())
        for event in self.core.rows("SELECT * FROM p_events WHERE kind IN ('NEW_DEVICE','MAC_CHANGE','IP_CHANGE','SERVICE_CHANGE','ADMIN_ACTION') ORDER BY ts DESC LIMIT 200"):
            self.security_tree.insert('','end',values=(fmt_time(event['ts']),event['ip'],event['kind'],event['severity'],event['details']))
        self.log_tree.delete(*self.log_tree.get_children())
        for event in self.core.rows("SELECT * FROM p_events WHERE kind='SYSLOG' ORDER BY ts DESC LIMIT 300"):
            self.log_tree.insert('','end',values=(fmt_time(event['ts']),event['ip'],event['severity'],event['details']))
        opened=[i for i in incidents if i['status']!='CLOSED']
        self.summary.set(f'Активів: {len(assets)} · Агентів: {len(self.endpoint_configs())} · Відкритих інцидентів: {len(opened)} · Користувач: {self.user} / {self.role}')
        new=[i for i in opened if i['id'] not in self.alert_seen]
        if new:
            self.window.bell();self.status.set(f"НОВИЙ ІНЦИДЕНТ {new[0]['id']}: {new[0]['summary']}")
        self.alert_seen.update(i['id'] for i in incidents)

    def tick(self):
        if not self.alive:return
        if time.monotonic()>=self.next_agents:self.poll_agents()
        if time.monotonic()>=self.next_health:self.poll_health()
        self.refresh();self.core.maintenance();self.timer=self.window.after(5000,self.tick)


class RemoteViewer:
    def __init__(self,owner,client,host,token):
        self.owner,self.client,self.host,self.token=owner,client,host,token
        owner.viewers.append(self)
        self.alive,self.busy=True,False
        self.window=tk.Toplevel(owner.window);self.window.title('Віддалена допомога — '+host);self.window.geometry('1100x760')
        self.window.minsize(640,420);self.window.resizable(True,True)
        self.window.protocol('WM_DELETE_WINDOW',self.close)
        ttk.Label(self.window,text='Користувач надав доступ без обмеження часу. Доступ діє до завершення сеансу, перезапуску агента або fail-safe.').pack(fill='x')
        from michman_keyboard import KeyboardInput
        from collections import deque
        self.keyboard=KeyboardInput();self.inputs=deque();self.input_condition=threading.Condition();self.input_stopping=False
        self.label=tk.Label(self.window,bg='black',takefocus=True);self.label.pack(fill='both',expand=True)
        self.label.bind('<KeyPress>',self.key_press)
        self.label.bind('<KeyRelease>',self.key_release)
        self.label.bind('<FocusOut>',lambda _:self.keyboard.reset())
        ttk.Label(self.window,text='Клавіатура: клацніть екран. Ctrl+Alt+Esc — повернути керування локальному ПК.').pack(fill='x')
        self.label.bind('<ButtonPress-1>',self.press);self.label.bind('<ButtonRelease-1>',self.release)
        self.label.bind('<Button-3>',lambda e:self.click(e,'right'))
        self.label.bind('<Motion>',self.motion)
        self.label.bind('<MouseWheel>',lambda e:self.send({'verb':'scroll','amount':int(e.delta/120)}))
        self.text=tk.StringVar();bar=WrapToolbar(self.window);bar.pack(fill='x')
        ttk.Entry(bar,textvariable=self.text,width=45).pack(side='left')
        ttk.Button(bar,text='Надіслати текст',command=lambda:self.send({'verb':'text','text':self.text.get()})).pack(side='left')
        for key in ('enter','tab','esc','backspace'):
            ttk.Button(bar,text=key,command=lambda k=key:self.send({'verb':'key','key':k})).pack(side='left')
        ttk.Button(bar,text='F11 → ПК',command=lambda:self.send({'verb':'key','key':'f11'})).pack(side='left')
        ttk.Button(bar,text='Ctrl+C',command=lambda:self.send({'verb':'hotkey','keys':['ctrl','c']})).pack(side='left')
        ttk.Button(bar,text='Ctrl+V',command=lambda:self.send({'verb':'hotkey','keys':['ctrl','v']})).pack(side='left')
        ttk.Button(bar,text='800×600',command=lambda:self.resize_window(800,600)).pack(side='left')
        ttk.Button(bar,text='1100×760',command=lambda:self.resize_window(1100,760)).pack(side='left')
        ttk.Button(bar,text='Повний екран (F11)',command=self.toggle_fullscreen).pack(side='left')
        owner.core.audit(owner.user,host,'ASSISTANCE','CONSENT_GRANTED')
        ttk.Button(bar,text='Передати файли',command=lambda:owner.file_manager({'host':host,'port':client.port})).pack(side='left')
        ttk.Button(bar,text='Зберегти кадр',command=self.save_frame).pack(side='left')
        for title,profile in [('Економний','economy'),('Збалансований','balanced'),('Нативний','native')]:
            ttk.Button(bar,text=title,command=lambda value=profile:self.change_profile(value)).pack(side='left')
        ttk.Button(bar,text='Вікно 1:1',command=self.native_window).pack(side='left')
        ttk.Button(bar,text='Перепідключити відео',command=lambda:self.start_stream(manual=True)).pack(side='left')
        self.stream_status=tk.StringVar(value='Підключення потоку екрана…')
        ttk.Label(self.window,textvariable=self.stream_status).pack(fill='x')
        self.frame_lock=threading.Lock();self.latest=None
        self.stream_error=None;self.received=0;self.stream_started=time.monotonic()
        self.source_image=None;self.render_signature=None;self.fullscreen=False
        self.profiles={'economy':(15,1280,720,55),'balanced':(30,0,0,72),'native':(45,0,0,85)}
        self.profile='balanced';self.stream_generation=0;self.reconnect_attempts=0
        self.scale_mode='fit';self.last_motion_sent=0.0
        self.next_reconnect=0
        self.window.bind('<F11>',lambda _event:self.toggle_fullscreen())
        self.window.bind('<Escape>',lambda _event:self.leave_fullscreen())
        self.start_stream()
        threading.Thread(target=self.input_worker,daemon=True,name='Desktop-input').start()
        self.window.after(16,self.frame)
    def start_stream(self,manual=False):
        if not self.alive:return
        previous=getattr(self,'stream_stop',None)
        if previous:previous.set()
        if manual:self.reconnect_attempts=0
        self.stream_generation+=1;generation=self.stream_generation
        stop=threading.Event();self.stream_stop=stop;self.stream_error=None
        self.received=0;self.stream_started=time.monotonic();self.latest=None
        fps,width,height,quality=self.profiles[self.profile]
        self.stream_status.set('Підключення потоку екрана…')
        def receive():
            try:
                from PIL import Image
                for data in self.client.frames(self.token,stop,fps=fps,width=width,height=height,quality=quality):
                    image=Image.open(io.BytesIO(data));image.load()
                    with self.frame_lock:
                        if generation!=self.stream_generation:return
                        self.latest=(image,time.monotonic(),len(data));self.received+=1;self.reconnect_attempts=0
                if not stop.is_set() and generation==self.stream_generation:raise EOFError('Потік завершено')
            except Exception as error:
                if not stop.is_set() and generation==self.stream_generation:
                    self.stream_error=str(error);self.next_reconnect=time.monotonic()+2
        threading.Thread(target=receive,daemon=True,name='Desktop-stream').start()
    def change_profile(self,profile):
        if profile in self.profiles:
            self.profile=profile;self.start_stream(manual=True)
    def save_frame(self):
        if self.source_image is None:return
        path=filedialog.asksaveasfilename(parent=self.window,title='Зберегти кадр',defaultextension='.png',filetypes=[('PNG','*.png'),('JPEG','*.jpg')])
        if path:
            image=self.source_image.copy();image.save(path);self.owner.status.set('Кадр збережено: '+path)
    def frame(self):
        if not self.alive:return
        if self.stream_error:
            if self.reconnect_attempts<3 and time.monotonic()>=self.next_reconnect:
                self.reconnect_attempts+=1;self.start_stream();return
            self.stream_status.set('Потік екрана: '+self.stream_error+' · спроба '+str(self.reconnect_attempts)+'/3')
        with self.frame_lock:latest=self.latest;self.latest=None
        if latest:
            image,received,size=latest
            self.source_image=image
            fps=self.received/max(.001,time.monotonic()-self.stream_started)
            target=self.profiles[self.profile][0]
            self.stream_status.set(f'{fps:.1f} кадрів/с · {size/1024:.0f} KiB/кадр · ціль {target} · джерело {image.width}×{image.height} · кадри без обрізання')
        self.render_screen()
        self.window.after(16,self.frame)
    def render_screen(self):
        if self.source_image is None:return
        available=(max(100,self.label.winfo_width()),max(100,self.label.winfo_height()))
        signature=(id(self.source_image),available)
        if signature==self.render_signature:return
        from PIL import Image,ImageTk
        image=self.source_image.copy()
        if self.scale_mode!='native':image.thumbnail(available,Image.Resampling.BILINEAR)
        self.size=image.size;self.image=ImageTk.PhotoImage(image);self.label.configure(image=self.image)
        self.render_signature=signature
    def native_window(self):
        if self.source_image is None:return
        self.scale_mode='native' if self.scale_mode!='native' else 'fit'
        if self.scale_mode=='native':
            width,height=self.source_image.size
            self.leave_fullscreen();present(self.window,width,min(height+180,self.window.winfo_screenheight()),focus=self.label)
        self.render_signature=None
    def resize_window(self,width,height):
        self.leave_fullscreen();present(self.window,width,height,focus=self.label)
        self.render_signature=None
    def toggle_fullscreen(self):
        self.fullscreen=not self.fullscreen;self.window.attributes('-fullscreen',self.fullscreen)
        self.render_signature=None;self.label.focus_set()
    def leave_fullscreen(self):
        if self.fullscreen:
            self.fullscreen=False;self.window.attributes('-fullscreen',False);self.render_signature=None
    def click(self,event,button):
        if not hasattr(self,'size'):return
        width,height=self.size
        x=(event.x-(self.label.winfo_width()-width)/2)/width;y=(event.y-(self.label.winfo_height()-height)/2)/height
        if 0<=x<=1 and 0<=y<=1:self.send({'verb':'click','x':x,'y':y,'button':button})
    def normalized(self,event):
        if not hasattr(self,'size'):return None
        width,height=self.size
        x=(event.x-(self.label.winfo_width()-width)/2)/width;y=(event.y-(self.label.winfo_height()-height)/2)/height
        return (x,y) if 0<=x<=1 and 0<=y<=1 else None
    def motion(self,event):
        now=time.monotonic()
        if now-self.last_motion_sent<1/60:return
        point=self.normalized(event)
        if point:
            self.last_motion_sent=now;self.send({'verb':'move','x':point[0],'y':point[1]})
    def press(self,event):
        self.label.focus_set();self.drag_start=self.normalized(event)
    def release(self,event):
        start=getattr(self,'drag_start',None);end=self.normalized(event)
        if not start or not end:return
        if abs(start[0]-end[0])+abs(start[1]-end[1])>.015:self.send({'verb':'drag','x':start[0],'y':start[1],'end_x':end[0],'end_y':end[1]})
        else:self.click(event,'left')
    def key_press(self,event):
        if event.keysym=='F11' and not self.keyboard.held:
            self.toggle_fullscreen();return 'break'
        if event.keysym=='Escape' and self.fullscreen and not self.keyboard.held:
            self.leave_fullscreen();return 'break'
        action=self.keyboard.press(event.keysym,event.char,event.keycode,event.state)
        if action and action.get('local_release'):
            self.window.focus_set()
        elif action:self.send(action)
        return 'break'
    def key_release(self,event):
        self.keyboard.release(event.keysym);return 'break'
    def send(self,params):
        if not self.alive:return
        with self.input_condition:
            if len(self.inputs)>=256:
                self.owner.status.set('Канал введення перевантажено. Сеанс зупинено, щоб не виконувати застарілі команди.')
                self.close();return
            self.inputs.append(dict(params));self.input_condition.notify()
    def input_worker(self):
        try:
            while True:
                with self.input_condition:
                    self.input_condition.wait_for(lambda:self.inputs or self.input_stopping)
                    if self.input_stopping:return
                    params=self.inputs.popleft()
                    if params.get('verb')=='text':
                        while self.inputs and self.inputs[0].get('verb')=='text' and len(params['text'])+len(self.inputs[0]['text'])<=1000:
                            params['text']+=self.inputs.popleft()['text']
                self.client.call('assist_input',{'token':self.token,**params},timeout=5)
        except Exception as error:
            message=str(error)
            def failed():
                if self.alive:self.owner.status.set('Введення: '+message);self.close()
            self.owner.app.run_on_gui(failed)
        finally:
            try:self.client.call('assist_stop',{'token':self.token},timeout=5)
            except Exception:pass
    def close(self):
        if not self.alive:return
        self.alive=False;self.stream_stop.set();self.keyboard.reset()
        with self.input_condition:
            self.input_stopping=True;self.inputs.clear();self.input_condition.notify()
        self.window.destroy()
        if self in self.owner.viewers:self.owner.viewers.remove(self)
        self.owner.core.audit(self.owner.user,self.host,'ASSISTANCE','STOPPED')


def open_platform(app):
    current=getattr(app,'platform_window',None)
    if current and current.alive:restore(current.window);return
    app.platform_window=PlatformWindow(app)
