@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

set "DEBUG_DIR=%LOCALAPPDATA%\MichmanKP"
if not exist "%DEBUG_DIR%" mkdir "%DEBUG_DIR%"
set "DEBUG_LOG=%DEBUG_DIR%\startup_console.log"

echo Running MICHMAN KP with a visible console...
echo Console output will be saved to:
echo %DEBUG_LOG%
echo.

where py >nul 2>&1
if errorlevel 1 (
  echo Python Launcher ^(py.exe^) was not found.
  pause
  exit /b 1
)

py -3.12 MichmanKP_Protected.py > "%DEBUG_LOG%" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"

echo.
echo Program exit code: %EXIT_CODE%
echo ------------------------------------------------------------
type "%DEBUG_LOG%"
echo ------------------------------------------------------------
echo A second diagnostic file, if startup reached the application:
echo %DEBUG_DIR%\startup_error.log
pause
exit /b %EXIT_CODE%
