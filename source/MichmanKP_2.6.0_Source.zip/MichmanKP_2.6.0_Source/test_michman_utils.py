import csv
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor

from michman_utils import atomic_write_json, SafeCSVWriter, parse_device_input


class DeviceInputTests(unittest.TestCase):
    def test_legacy_names_comments_and_duplicates(self):
        rows, duplicates = parse_device_input(
            '192.168.1.1 | Роутер\n192.168.1.2 - ПК # comment\n192.168.1.1',
            existing=['192.168.1.2'])
        self.assertEqual(rows, [('192.168.1.1', 'Роутер', 'Загальні', 'Звичайний')])
        self.assertEqual(duplicates, {'192.168.1.1', '192.168.1.2'})

    def test_subnet_excludes_network_and_broadcast(self):
        rows, _ = parse_device_input('192.168.1.0/30 | LAN')
        self.assertEqual([r[0] for r in rows], ['192.168.1.1', '192.168.1.2'])
        self.assertTrue(all(r[1] == 'LAN' for r in rows))

    def test_small_subnets(self):
        self.assertEqual(len(parse_device_input('10.0.0.0/31')[0]), 2)
        self.assertEqual(len(parse_device_input('10.0.0.1/32')[0]), 1)

    def test_range(self):
        rows, _ = parse_device_input('10.0.0.254-10.0.1.1', default_name='Test')
        self.assertEqual(len(rows), 4)
        self.assertEqual(rows[-1][0], '10.0.1.1')

    def test_invalid_batch_is_rejected(self):
        for value in ['garbage', '::1', '10.0.0.2-10.0.0.1', '10.0.0.1/99']:
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, 'Рядок 2'):
                parse_device_input('10.0.0.1\n' + value)

    def test_large_expansion_rejected(self):
        for value in ['0.0.0.0/0', '0.0.0.0-255.255.255.255']:
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, '4096'):
                parse_device_input(value)

    def test_limit_counts_whole_batch(self):
        with self.assertRaises(ValueError):
            parse_device_input('10.0.0.1\n10.0.0.2', limit=1)


class StorageAndExportTests(unittest.TestCase):
    def test_unicode_roundtrip(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'data.json'
            atomic_write_json(path, {'name': 'Мережа'})
            self.assertEqual(json.loads(path.read_text(encoding='utf-8')), {'name': 'Мережа'})

    def test_failed_replace_preserves_original_and_cleans_temp(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'data.json'
            atomic_write_json(path, ['original'])
            with patch('michman_utils.os.replace', side_effect=OSError('disk failure')):
                with self.assertRaises(OSError):
                    atomic_write_json(path, ['new'])
            self.assertEqual(json.loads(path.read_text()), ['original'])
            self.assertEqual(list(Path(folder).iterdir()), [path])

    def test_serialization_failure_preserves_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'data.json'
            atomic_write_json(path, [1])
            with self.assertRaises(TypeError):
                atomic_write_json(path, {1, 2})
            self.assertEqual(json.loads(path.read_text()), [1])
            self.assertEqual(list(Path(folder).iterdir()), [path])

    def test_concurrent_writes_remain_valid(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'data.json'
            with ThreadPoolExecutor(max_workers=4) as executor:
                list(executor.map(lambda i: atomic_write_json(path, [i] * 100), range(20)))
            data = json.loads(path.read_text())
            self.assertEqual(len(data), 100)
            self.assertEqual(len(set(data)), 1)
            self.assertEqual(list(Path(folder).iterdir()), [path])

    def test_csv_formulas_and_numeric_types(self):
        output = io.StringIO(newline='')
        values = ['=1+1', '+SUM(A1)', '-cmd', '@SUM(A1)', '  =1', '\ttext', 'ПК;"1"', -3, 2.5]
        SafeCSVWriter(output, delimiter=';').writerow(values)
        row = next(csv.reader(io.StringIO(output.getvalue()), delimiter=';'))
        self.assertTrue(all(value.startswith("'") for value in row[:6]))
        self.assertEqual(row[6:], ['ПК;"1"', '-3', '2.5'])


if __name__ == '__main__':
    unittest.main()
