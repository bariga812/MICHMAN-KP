import unittest
from unittest import mock

import MichmanKP_Protected as app
import michman_agent


class MacMonitoringTests(unittest.TestCase):
    def test_device_record_preserves_mac_tracking(self):
        rows = app._normalise_device_records([{
            'ip': '192.168.10.25',
            'name': 'Workstation',
            'address_mode': 'mac',
            'tracking_mac': 'aa-bb-cc-dd-ee-ff',
        }])
        self.assertEqual(rows[0]['address_mode'], 'mac')
        self.assertEqual(rows[0]['tracking_mac'], 'AA:BB:CC:DD:EE:FF')

    def test_invalid_tracking_mac_falls_back_to_ip(self):
        row = app._normalise_device_records([{
            'ip': '192.168.10.25', 'address_mode': 'mac', 'tracking_mac': 'invalid'
        }])[0]
        self.assertEqual(row['address_mode'], 'ip')
        self.assertEqual(row['tracking_mac'], '')

    def test_agent_telemetry_reports_normalized_macs(self):
        address = type('Address', (), {'address': 'aa-bb-cc-dd-ee-ff'})()
        memory = type('Memory', (), {'percent': 20, 'total': 100, 'available': 80})()
        partition = type('Partition', (), {'mountpoint': 'C:/'})()
        usage = type('Usage', (), {'total': 100, 'free': 80, 'percent': 20})()
        fake_psutil = mock.Mock()
        fake_psutil.disk_partitions.return_value = [partition]
        fake_psutil.disk_usage.return_value = usage
        fake_psutil.virtual_memory.return_value = memory
        fake_psutil.cpu_percent.return_value = 1
        fake_psutil.boot_time.return_value = 0
        fake_psutil.net_if_addrs.return_value = {'Ethernet': [address]}
        with mock.patch.dict('sys.modules', {'psutil': fake_psutil}):
            data = michman_agent.telemetry('agent')
        self.assertEqual(data['primary_mac'], 'AA:BB:CC:DD:EE:FF')
        self.assertEqual(data['mac_addresses'], ['AA:BB:CC:DD:EE:FF'])


if __name__ == '__main__':
    unittest.main()
