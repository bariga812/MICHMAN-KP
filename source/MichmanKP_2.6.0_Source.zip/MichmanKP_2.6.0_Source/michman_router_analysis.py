"""Read-only analysis of a decoded router snapshot."""


def analyze_router_snapshot(snapshot):
    issues=[]
    def add(severity,category,message,**details):
        issues.append({'severity':severity,'category':category,'message':message,**details})
    cpu=snapshot.get('cpu_percent')
    if isinstance(cpu,(int,float)) and cpu>=90:add('CRITICAL','CPU',f'CPU {cpu:.1f}%')
    elif isinstance(cpu,(int,float)) and cpu>=75:add('WARNING','CPU',f'CPU {cpu:.1f}%')
    total,used=snapshot.get('ram_total'),snapshot.get('ram_used')
    if total and isinstance(used,(int,float)):
        percent=100*used/total
        if percent>=90:add('CRITICAL','RAM',f'RAM використано {percent:.1f}%')
        elif percent>=80:add('WARNING','RAM',f'RAM використано {percent:.1f}%')
    temperature=snapshot.get('temperature_c')
    if isinstance(temperature,(int,float)):
        if temperature>=85:add('CRITICAL','TEMPERATURE',f'Температура {temperature:.1f} °C')
        elif temperature>=70:add('WARNING','TEMPERATURE',f'Температура {temperature:.1f} °C')
    for interface in snapshot.get('interfaces',[]):
        name=interface.get('name') or interface.get('index') or '?'
        if interface.get('admin_status')==1 and interface.get('status') not in (1,None):
            add('WARNING','INTERFACE',f'{name}: адміністративно UP, але лінк не UP',interface=name)
        for direction in ('rx','tx'):
            speed,rate=interface.get('speed_bps'),interface.get(direction+'_bps')
            if speed and isinstance(rate,(int,float)) and rate/speed>=.85:
                add('WARNING','UTILIZATION',f'{name}: {direction.upper()} {100*rate/speed:.1f}% швидкості порту',interface=name)
        errors=sum(value for value in (interface.get('rx_errors'),interface.get('tx_errors')) if isinstance(value,int))
        drops=sum(value for value in (interface.get('rx_discards'),interface.get('tx_discards')) if isinstance(value,int))
        if errors:add('WARNING','ERRORS',f'{name}: накопичено помилок RX/TX: {errors}',interface=name)
        if drops:add('INFO','DROPS',f'{name}: накопичено відкидань RX/TX: {drops}',interface=name)
    for warning in snapshot.get('warnings',[]):add('INFO','SNMP',str(warning))
    order={'CRITICAL':0,'WARNING':1,'INFO':2}
    issues.sort(key=lambda item:(order.get(item['severity'],9),item['category'],item['message']))
    return issues


def router_inventory_summary(snapshot):
    capabilities=snapshot.get('capabilities',{})
    return {
        'device':{'host':snapshot.get('host'),'name':snapshot.get('name'),'vendor':snapshot.get('vendor'),
            'platform':snapshot.get('platform'),'description':snapshot.get('sys_descr'),'object_id':snapshot.get('sys_object_id'),
            'contact':snapshot.get('sys_contact'),'location':snapshot.get('sys_location'),'uptime':snapshot.get('uptime')},
        'resources':{'cpu_percent':snapshot.get('cpu_percent'),'ram_used':snapshot.get('ram_used'),
            'ram_total':snapshot.get('ram_total'),'temperature_c':snapshot.get('temperature_c'),'ups':snapshot.get('ups',{})},
        'counts':{'interfaces':len(snapshot.get('interfaces',[])),'ip_addresses':len(snapshot.get('ip_addresses',[])),
            'routes':len(snapshot.get('routes',[])),'arp':len(snapshot.get('arp',[])),'lldp_neighbors':len(snapshot.get('neighbors',[])),
            'fdb_entries':len(snapshot.get('bridge_fdb',[])),'vlans':len(snapshot.get('vlans',[])),
            'hardware_components':len(snapshot.get('hardware',[])),'sensors':len(snapshot.get('sensors',[])),
            'raw_oids':len(snapshot.get('raw_oids',{}))},
        'capabilities':capabilities,
        'issues':analyze_router_snapshot(snapshot),
    }


def detect_router_changes(previous,current):
    if not previous:return []
    changes=[]
    def add(category,severity,message):changes.append({'category':category,'severity':severity,'message':message})
    old_if={str(row.get('index')):(row.get('admin_status'),row.get('status'),row.get('name')) for row in previous.get('interfaces',[])}
    new_if={str(row.get('index')):(row.get('admin_status'),row.get('status'),row.get('name')) for row in current.get('interfaces',[])}
    changed=[(new_if[index][2] or index,old_if[index][1],new_if[index][1]) for index in old_if.keys()&new_if.keys() if old_if[index][:2]!=new_if[index][:2]]
    if changed:
        down=any(new not in (1,None) for _name,_old,new in changed)
        add('INTERFACE_STATE','WARNING' if down else 'INFO','; '.join(f'{name}: {old} → {new}' for name,old,new in changed[:20]))
    def identities(rows,fields):return {tuple(str(row.get(field,'')) for field in fields) for row in rows}
    pairs=(('IP_CONFIG_CHANGE','IP-адреси',('address','netmask','interface_index'),'ip_addresses'),
        ('ROUTE_CHANGE','Маршрути',('destination','netmask','next_hop','interface_index'),'routes'),
        ('VLAN_CHANGE','VLAN',('index','name','egress_ports','untagged_ports'),'vlans'),
        ('HARDWARE_CHANGE','Апаратний склад',('index','serial_number','model','firmware_revision'),'hardware'))
    for category,label,fields,key in pairs:
        old,new=identities(previous.get(key,[]),fields),identities(current.get(key,[]),fields)
        if old!=new:
            severity='WARNING' if category=='HARDWARE_CHANGE' else 'INFO'
            add(category,severity,f'{label}: додано {len(new-old)}, видалено {len(old-new)}')
    return changes
