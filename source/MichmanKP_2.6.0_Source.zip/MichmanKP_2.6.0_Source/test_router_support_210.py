import tempfile
import unittest
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from michman_router_support import (PLATFORMS, compare_universal_backups,
    create_universal_backup, identify_router, read_universal_backup,
    UniversalRouterSession, validate_router_profile)
from michman_snmp import SYSTEM, decode_snapshot


class FakeSession:
    def __init__(self, text):
        self.profile = validate_router_profile({'name': 'core', 'host': '192.0.2.1',
            'user': 'backup', 'platform': 'junos', 'port': 22})
        self.text = text

    def export(self):
        return self.text


class UniversalRouterSupportTests(unittest.TestCase):
    def test_major_platforms_are_identified(self):
        samples = {
            'Cisco IOS XE Software': 'cisco_ios',
            'Juniper Networks, Inc. junos': 'junos',
            'OpenWrt 23.05': 'openwrt',
            'MikroTik RouterOS': 'mikrotik',
            'Huawei VRP Software': 'huawei_vrp',
        }
        for description, expected in samples.items():
            with self.subTest(description=description):
                self.assertEqual(identify_router(description)['platform'], expected)
        self.assertGreaterEqual(len(PLATFORMS), 25)

    def test_enterprise_oid_identifies_vendor_without_os_text(self):
        self.assertEqual(identify_router('', '1.3.6.1.4.1.11863.5')['vendor'], 'TP-Link')
        self.assertEqual(identify_router('', '1.3.6.1.4.1.41112.1')['vendor'], 'Ubiquiti Networks')
        self.assertEqual(identify_router('', '1.3.6.1.4.1.12356.101')['platform'], 'fortios')

    def test_unknown_device_stays_available_as_generic_snmp(self):
        identity = identify_router('ACME home gateway')
        self.assertEqual(identity['platform'], 'custom')
        self.assertIn('SNMP', identity['vendor'])

    def test_custom_export_command_is_restricted_to_read_only(self):
        base = {'host': 'router.example', 'user': 'ops', 'platform': 'custom'}
        for command in ('show configuration', 'display current-configuration',
                        'cat /etc/config/network', 'uci export',
                        'vtysh -c "show running-config"'):
            self.assertEqual(validate_router_profile({**base, 'command': command})['command'], command)
        for command in ('reboot', 'show configuration; reboot', 'show x > /tmp/x',
                        'show x\nreboot', 'cat relative-file'):
            with self.subTest(command=command), self.assertRaises(ValueError):
                validate_router_profile({**base, 'command': command})

    def test_password_only_profile_does_not_require_username(self):
        profile=validate_router_profile({'host':'router.example','platform':'junos',
            'auth_mode':'password_only','user':'ignored'})
        self.assertEqual(profile['user'],'')
        self.assertEqual(profile['auth_mode'],'password_only')
        with self.assertRaises(ValueError):
            validate_router_profile({'host':'router.example','platform':'junos','auth_mode':'username'})

    def test_password_only_ssh_sends_empty_username_and_disables_keys(self):
        calls={}
        class Client:
            def load_system_host_keys(self):pass
            def set_missing_host_key_policy(self,_policy):pass
            def connect(self,**kwargs):calls.update(kwargs)
            def close(self):pass
        fake=SimpleNamespace(SSHClient=Client,RejectPolicy=lambda:object())
        profile={'host':'router.example','platform':'junos','auth_mode':'password_only'}
        with patch.dict(sys.modules,{'paramiko':fake}):
            with UniversalRouterSession(profile,'router-secret'):pass
        self.assertEqual(calls['username'],'');self.assertEqual(calls['password'],'router-secret')
        self.assertFalse(calls['look_for_keys']);self.assertFalse(calls['allow_agent'])

    def test_encrypted_backup_round_trip_and_diff(self):
        password = 'correct horse battery staple'
        with tempfile.TemporaryDirectory() as directory:
            first = create_universal_backup(FakeSession('system { host-name core; }\n'), directory, password)['path']
            second = create_universal_backup(FakeSession('system { host-name edge; }\n'), directory, password)['path']
            self.assertNotEqual(first, second)
            self.assertNotIn(b'host-name core', Path(first).read_bytes())
            metadata, text = read_universal_backup(first, password)
            self.assertEqual(metadata['platform'], 'junos')
            self.assertIn('host-name core', text)
            self.assertIn('-system { host-name core; }', compare_universal_backups(first, password, second, password))
            with self.assertRaises(Exception):
                read_universal_backup(first, 'this is the wrong password')

    def test_snmp_snapshot_includes_router_identity(self):
        snapshot = decode_snapshot('192.0.2.1', {
            SYSTEM + '.1.0': 'Arista Networks EOS',
            SYSTEM + '.2.0': '1.3.6.1.4.1.30065',
            SYSTEM + '.5.0': 'leaf-1',
        })
        self.assertEqual(snapshot['platform'], 'arista_eos')
        self.assertEqual(snapshot['name'], 'leaf-1')
        self.assertEqual(snapshot['sys_object_id'], '1.3.6.1.4.1.30065')


if __name__ == '__main__':
    unittest.main()
