"""Offline dependency diagnostics for the packaged Windows application."""
import importlib
import json
import platform
from pathlib import Path


def run(directory):
    results = {'python': platform.python_version(), 'checks': {}, 'ok': True}
    for name in ('tkinter', 'paramiko', 'openpyxl', 'Cryptodome.Cipher.AES',
                 'pysnmp.hlapi.v3arch.asyncio', 'pysnmp.smi.mibs.SNMPv2-MIB',
                 'michman_snmp', 'michman_topology', 'michman_backup', 'michman_network_ui',
                 'psutil', 'PIL.Image', 'michman_platform_core', 'michman_platform_ui', 'michman_identity', 'michman_agent'):
        try:
            if name == 'pysnmp.smi.mibs.SNMPv2-MIB':
                from pysnmp.entity.engine import SnmpEngine
                engine = SnmpEngine()
                engine.get_mib_builder().load_modules('SNMPv2-MIB')
                engine.close_dispatcher()
            else:
                importlib.import_module(name)
            results['checks'][name] = 'OK'
        except Exception as error:
            results['checks'][name] = str(error)
            results['ok'] = False
    path = Path(directory) / 'runtime_diagnostics.json'
    path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    return results
