"""Offline licensing for MICHMAN KP.

The customer build contains only hashes of the three activation codes.  A
successful activation is bound to the current Windows installation and stored
with Windows DPAPI (LocalMachine scope).  Trial usage is mirrored separately so
that deleting the main licence file does not normally restart a trial.

This is deliberately a local, privacy-preserving design: it performs no network
requests and never transmits hardware identifiers.
"""

from __future__ import annotations

import base64
import ctypes
import hashlib
import hmac
import json
import os
import platform
import re
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Optional


PRODUCT_ID = "MICHMAN-KP"
LICENSE_SCHEMA = 1

# Only SHA-256 digests are kept in the customer source.  The original keys are
# intentionally not present here as plain text.
_KEY_SPECS = {
    "a2bf516b34c0840c0d285b6f979be70785cf98ea806bb1297cca1e21ab0da4f6": {
        "plan": "trial_24h",
        "label": "ПРОБНА • 24 ГОДИНИ",
        "duration_seconds": 24 * 60 * 60,
        "rank": 10,
    },
    "a3da3e3a16aa0d9256b0ee8a857710f3b8c16aa176c59004c98983ae929d735f": {
        "plan": "trial_30d",
        "label": "ПРОБНА • 30 ДНІВ",
        "duration_seconds": 30 * 24 * 60 * 60,
        "rank": 20,
    },
    "e665824f451d8dc0442bfa1a199e098cdcc406f1d8f021d471e641bf96544f5b": {
        "plan": "lifetime",
        "label": "ДОВІЧНА",
        "duration_seconds": None,
        "rank": 100,
    },
}

_PLAN_LABELS = {
    spec["plan"]: str(spec["label"])
    for spec in _KEY_SPECS.values()
}

# This key is only a second integrity layer around the DPAPI-protected blob.  It
# is not treated as an irreplaceable secret; machine binding and DPAPI are the
# primary local controls.
_STATE_MAC_KEY = bytes.fromhex(
    "a9ed552378191284ed5f817ec03193e7"
    "8c147f81662d253cf4ce22fa7038891c"
)
_DPAPI_ENTROPY = hashlib.sha256(
    b"MICHMAN-KP|OFFLINE-LICENCE|DPAPI|V1"
).digest()

_STATE_FILENAME = "michman_license.dat"
_GUARD_FILENAME = "michman_trial_guard.dat"
_CLOCK_ROLLBACK_TOLERANCE = timedelta(hours=2)


@dataclass(frozen=True)
class LicenseStatus:
    valid: bool
    code: str
    message: str
    device_code: str
    plan: str = ""
    label: str = "НЕ АКТИВОВАНО"
    activated_at: str = ""
    expires_at: str = ""
    remaining_seconds: Optional[int] = None

    @property
    def lifetime(self) -> bool:
        return self.plan == "lifetime" and self.valid


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds")


def _parse_iso(value: str) -> datetime:
    parsed = datetime.fromisoformat(str(value))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _normalise_key(value: str) -> str:
    value = str(value or "").strip()
    value = value.replace("–", "-").replace("—", "-").replace("−", "-")
    value = re.sub(r"\s+", "", value)
    return value.upper()


def _key_digest(value: str) -> str:
    normalised = _normalise_key(value)
    return hashlib.sha256(
        f"{PRODUCT_ID}|{normalised}".encode("utf-8")
    ).hexdigest()


def _canonical_json(data: dict) -> bytes:
    return json.dumps(
        data,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _pack_payload(payload: dict) -> bytes:
    body = _canonical_json(payload)
    signature = hmac.new(_STATE_MAC_KEY, body, hashlib.sha256).hexdigest()
    envelope = {
        "payload": base64.b64encode(body).decode("ascii"),
        "mac": signature,
    }
    return _canonical_json(envelope)


def _unpack_payload(blob: bytes) -> dict:
    envelope = json.loads(blob.decode("utf-8"))
    encoded = envelope.get("payload", "")
    signature = str(envelope.get("mac", ""))
    body = base64.b64decode(encoded, validate=True)
    expected = hmac.new(_STATE_MAC_KEY, body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, expected):
        raise ValueError("licence integrity check failed")
    payload = json.loads(body.decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("invalid licence payload")
    return payload


class _DataBlob(ctypes.Structure):
    _fields_ = [
        ("cbData", ctypes.c_ulong),
        ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
    ]


def _blob_from_bytes(value: bytes):
    buffer = ctypes.create_string_buffer(value)
    blob = _DataBlob(
        len(value),
        ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)),
    )
    return blob, buffer


def _dpapi_protect(value: bytes) -> bytes:
    """Protect bytes for this Windows machine using DPAPI."""
    if not sys.platform.startswith("win"):
        # Development/test fallback.  Production is a Windows-only application.
        return b"DEV1" + base64.b64encode(value)

    input_blob, input_buffer = _blob_from_bytes(value)
    entropy_blob, entropy_buffer = _blob_from_bytes(_DPAPI_ENTROPY)
    output_blob = _DataBlob()

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    crypt32.CryptProtectData.argtypes = [
        ctypes.POINTER(_DataBlob),
        ctypes.c_wchar_p,
        ctypes.POINTER(_DataBlob),
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.POINTER(_DataBlob),
    ]
    crypt32.CryptProtectData.restype = ctypes.c_bool
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    cryptprotect_ui_forbidden = 0x01
    cryptprotect_local_machine = 0x04
    flags = cryptprotect_ui_forbidden | cryptprotect_local_machine

    # Keep backing buffers alive until CryptProtectData returns.
    _ = input_buffer, entropy_buffer
    if not crypt32.CryptProtectData(
        ctypes.byref(input_blob),
        "MICHMAN KP offline licence",
        ctypes.byref(entropy_blob),
        None,
        None,
        flags,
        ctypes.byref(output_blob),
    ):
        raise ctypes.WinError()

    try:
        return ctypes.string_at(output_blob.pbData, output_blob.cbData)
    finally:
        kernel32.LocalFree(output_blob.pbData)


def _dpapi_unprotect(value: bytes) -> bytes:
    if value.startswith(b"DEV1") and not sys.platform.startswith("win"):
        return base64.b64decode(value[4:], validate=True)
    if not sys.platform.startswith("win"):
        raise RuntimeError("Windows DPAPI data cannot be opened on this system")

    input_blob, input_buffer = _blob_from_bytes(value)
    entropy_blob, entropy_buffer = _blob_from_bytes(_DPAPI_ENTROPY)
    output_blob = _DataBlob()

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    crypt32.CryptUnprotectData.argtypes = [
        ctypes.POINTER(_DataBlob),
        ctypes.c_void_p,
        ctypes.POINTER(_DataBlob),
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.POINTER(_DataBlob),
    ]
    crypt32.CryptUnprotectData.restype = ctypes.c_bool
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    _ = input_buffer, entropy_buffer
    if not crypt32.CryptUnprotectData(
        ctypes.byref(input_blob),
        None,
        ctypes.byref(entropy_blob),
        None,
        None,
        0x01,
        ctypes.byref(output_blob),
    ):
        raise ctypes.WinError()

    try:
        return ctypes.string_at(output_blob.pbData, output_blob.cbData)
    finally:
        kernel32.LocalFree(output_blob.pbData)


def _read_windows_machine_guid() -> str:
    if not sys.platform.startswith("win"):
        return ""
    try:
        import winreg

        access = winreg.KEY_READ
        if hasattr(winreg, "KEY_WOW64_64KEY"):
            access |= winreg.KEY_WOW64_64KEY
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
            0,
            access,
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
            return str(value).strip()
    except Exception:
        return ""


def _read_windows_volume_serial() -> str:
    if not sys.platform.startswith("win"):
        return ""
    try:
        system_drive = os.environ.get("SystemDrive", "C:").rstrip("\\/")
        root_path = system_drive + "\\"
        serial = ctypes.c_ulong(0)
        max_component = ctypes.c_ulong(0)
        flags = ctypes.c_ulong(0)
        ok = ctypes.windll.kernel32.GetVolumeInformationW(
            ctypes.c_wchar_p(root_path),
            None,
            0,
            ctypes.byref(serial),
            ctypes.byref(max_component),
            ctypes.byref(flags),
            None,
            0,
        )
        return f"{serial.value:08X}" if ok else ""
    except Exception:
        return ""


def _fallback_machine_id() -> str:
    for path in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            value = path.read_text(encoding="utf-8").strip()
            if value:
                return value
        except OSError:
            pass
    return platform.node()


def machine_fingerprint() -> str:
    components = [
        _read_windows_machine_guid(),
        _read_windows_volume_serial(),
        os.environ.get("COMPUTERNAME", ""),
        platform.machine(),
    ]
    if not any(components[:2]):
        components.append(_fallback_machine_id())
    material = "|".join(str(item).strip().upper() for item in components)
    return hashlib.sha256(
        f"{PRODUCT_ID}|DEVICE|V1|{material}".encode("utf-8")
    ).hexdigest()


def format_device_code(device_hash: str) -> str:
    compact = str(device_hash).upper()[:24]
    groups = [compact[index:index + 4] for index in range(0, len(compact), 4)]
    return "MPC-" + "-".join(groups)


def format_remaining(seconds: Optional[int]) -> str:
    if seconds is None:
        return "БЕЗСТРОКОВО"
    seconds = max(0, int(seconds))
    days, remainder = divmod(seconds, 24 * 60 * 60)
    hours, remainder = divmod(remainder, 60 * 60)
    minutes = remainder // 60
    if days:
        return f"{days} дн. {hours} год."
    if hours:
        return f"{hours} год. {minutes} хв."
    return f"{minutes} хв."


class LicenseManager:
    """Validate and persist a completely offline, machine-bound licence."""

    def __init__(
        self,
        base_dir: str | os.PathLike[str],
        *,
        now_provider: Optional[Callable[[], datetime]] = None,
        device_id_override: Optional[str] = None,
        use_registry_guard: bool = True,
    ):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.base_dir / _STATE_FILENAME
        self.guard_path = self.base_dir / _GUARD_FILENAME
        self._now_provider = now_provider or _utc_now
        self.device_hash = device_id_override or machine_fingerprint()
        self.device_code = format_device_code(self.device_hash)
        self.use_registry_guard = bool(use_registry_guard)

    def _now(self) -> datetime:
        value = self._now_provider()
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @staticmethod
    def identify_key(key: str) -> Optional[dict]:
        digest = _key_digest(key)
        for expected, spec in _KEY_SPECS.items():
            if hmac.compare_digest(digest, expected):
                result = dict(spec)
                result["digest"] = expected
                return result
        return None

    def _atomic_write(self, path: Path, value: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(
            prefix=path.name + ".",
            suffix=".tmp",
            dir=str(path.parent),
        )
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(value)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, path)
        finally:
            try:
                os.unlink(tmp_name)
            except FileNotFoundError:
                pass

    def _save_protected(self, path: Path, payload: dict) -> None:
        self._atomic_write(path, _dpapi_protect(_pack_payload(payload)))

    def _load_protected(self, path: Path) -> Optional[dict]:
        if not path.exists():
            return None
        raw = path.read_bytes()
        return _unpack_payload(_dpapi_unprotect(raw))

    def _read_registry_guard(self) -> set[str]:
        if not (self.use_registry_guard and sys.platform.startswith("win")):
            return set()
        try:
            import winreg

            used = set()
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\MichmanKP\License",
            ) as key:
                for plan, value_name in (
                    ("trial_24h", "Trial24Used"),
                    ("trial_30d", "Trial30Used"),
                ):
                    try:
                        value, _ = winreg.QueryValueEx(key, value_name)
                        if int(value):
                            used.add(plan)
                    except OSError:
                        pass
            return used
        except Exception:
            return set()

    def _write_registry_guard(self, used: set[str]) -> None:
        if not (self.use_registry_guard and sys.platform.startswith("win")):
            return
        try:
            import winreg

            with winreg.CreateKeyEx(
                winreg.HKEY_CURRENT_USER,
                r"Software\MichmanKP\License",
                0,
                winreg.KEY_SET_VALUE,
            ) as key:
                winreg.SetValueEx(
                    key,
                    "Device",
                    0,
                    winreg.REG_SZ,
                    self.device_code,
                )
                if "trial_24h" in used:
                    winreg.SetValueEx(key, "Trial24Used", 0, winreg.REG_DWORD, 1)
                if "trial_30d" in used:
                    winreg.SetValueEx(key, "Trial30Used", 0, winreg.REG_DWORD, 1)
        except Exception:
            # The protected file guard still remains available.
            pass

    def _read_used_trials(self) -> set[str]:
        used = self._read_registry_guard()
        try:
            guard = self._load_protected(self.guard_path) or {}
            if guard.get("device_hash") == self.device_hash:
                used.update(
                    item
                    for item in guard.get("used_trials", [])
                    if item in ("trial_24h", "trial_30d")
                )
        except Exception:
            # A damaged guard is treated conservatively: current licence state
            # can still prove which trial has already been used.
            pass
        try:
            state = self._load_protected(self.state_path) or {}
            if state.get("device_hash") == self.device_hash:
                plan = state.get("plan")
                if plan in ("trial_24h", "trial_30d"):
                    used.add(plan)
                used.update(
                    item
                    for item in state.get("used_trials", [])
                    if item in ("trial_24h", "trial_30d")
                )
        except Exception:
            pass
        return used

    def _save_used_trials(self, used: set[str], now: datetime) -> None:
        payload = {
            "schema": LICENSE_SCHEMA,
            "product": PRODUCT_ID,
            "device_hash": self.device_hash,
            "used_trials": sorted(used),
            "updated_at": _iso(now),
        }
        self._save_protected(self.guard_path, payload)
        self._write_registry_guard(used)

    def activate(self, key: str) -> LicenseStatus:
        spec = self.identify_key(key)
        if spec is None:
            return LicenseStatus(
                False,
                "invalid_key",
                "Ключ активації не розпізнано.",
                self.device_code,
            )

        now = self._now()
        plan = str(spec["plan"])
        used = self._read_used_trials()

        existing = None
        try:
            existing = self._load_protected(self.state_path)
        except Exception:
            existing = None

        if existing and existing.get("device_hash") == self.device_hash:
            current_plan = str(existing.get("plan", ""))
            current_rank = max(
                (
                    int(item["rank"])
                    for item in _KEY_SPECS.values()
                    if item["plan"] == current_plan
                ),
                default=0,
            )
            if current_plan == "lifetime" and plan != "lifetime":
                return LicenseStatus(
                    True,
                    "already_lifetime",
                    "На цьому ПК уже активована довічна ліцензія.",
                    self.device_code,
                    plan="lifetime",
                    label=_PLAN_LABELS["lifetime"],
                    activated_at=str(existing.get("activated_at", "")),
                )
            if int(spec["rank"]) < current_rank:
                return LicenseStatus(
                    False,
                    "downgrade",
                    "Не можна замінити активовану ліцензію коротшим тарифом.",
                    self.device_code,
                    plan=current_plan,
                    label=_PLAN_LABELS.get(current_plan, "ЛІЦЕНЗІЯ"),
                )

        if plan in ("trial_24h", "trial_30d") and plan in used:
            return LicenseStatus(
                False,
                "trial_used",
                "Цей пробний період уже використовувався на даному ПК.",
                self.device_code,
                plan=plan,
                label=str(spec["label"]),
            )

        activated_at = now
        duration_seconds = spec["duration_seconds"]
        expires_at = (
            activated_at + timedelta(seconds=int(duration_seconds))
            if duration_seconds is not None
            else None
        )

        if plan in ("trial_24h", "trial_30d"):
            used.add(plan)

        payload = {
            "schema": LICENSE_SCHEMA,
            "product": PRODUCT_ID,
            "device_hash": self.device_hash,
            "plan": plan,
            "key_id": str(spec["digest"])[:16],
            "activated_at": _iso(activated_at),
            "expires_at": _iso(expires_at) if expires_at else "",
            "last_seen_at": _iso(now),
            "used_trials": sorted(used),
        }

        self._save_protected(self.state_path, payload)
        self._save_used_trials(used, now)
        return self.check(update_last_seen=False)

    def check(self, *, update_last_seen: bool = True) -> LicenseStatus:
        try:
            payload = self._load_protected(self.state_path)
        except Exception:
            return LicenseStatus(
                False,
                "damaged",
                "Файл ліцензії пошкоджено або перенесено з іншого ПК.",
                self.device_code,
            )

        if not payload:
            return LicenseStatus(
                False,
                "not_activated",
                "Введіть ключ для активації програми.",
                self.device_code,
            )

        if payload.get("schema") != LICENSE_SCHEMA or payload.get("product") != PRODUCT_ID:
            return LicenseStatus(
                False,
                "wrong_product",
                "Ліцензія має невідомий формат.",
                self.device_code,
            )

        if not hmac.compare_digest(
            str(payload.get("device_hash", "")),
            self.device_hash,
        ):
            return LicenseStatus(
                False,
                "wrong_device",
                "Ліцензія належить іншому комп’ютеру.",
                self.device_code,
            )

        plan = str(payload.get("plan", ""))
        if plan not in _PLAN_LABELS:
            return LicenseStatus(
                False,
                "unknown_plan",
                "Тип ліцензії не розпізнано.",
                self.device_code,
            )

        now = self._now()
        activated_text = str(payload.get("activated_at", ""))
        expires_text = str(payload.get("expires_at", ""))
        last_seen_text = str(payload.get("last_seen_at", activated_text))

        if plan == "lifetime":
            remaining_seconds = None
        else:
            try:
                expires = _parse_iso(expires_text)
                last_seen = _parse_iso(last_seen_text)
            except Exception:
                return LicenseStatus(
                    False,
                    "damaged_time",
                    "У ліцензії пошкоджено часові дані.",
                    self.device_code,
                    plan=plan,
                    label=_PLAN_LABELS[plan],
                )

            if now + _CLOCK_ROLLBACK_TOLERANCE < last_seen:
                return LicenseStatus(
                    False,
                    "clock_rollback",
                    "Системний час переведено назад. Виправте дату й час Windows.",
                    self.device_code,
                    plan=plan,
                    label=_PLAN_LABELS[plan],
                    activated_at=activated_text,
                    expires_at=expires_text,
                )

            remaining_seconds = int((expires - now).total_seconds())
            if remaining_seconds <= 0:
                return LicenseStatus(
                    False,
                    "expired",
                    "Пробний період завершився. Активуйте інший тариф.",
                    self.device_code,
                    plan=plan,
                    label=_PLAN_LABELS[plan],
                    activated_at=activated_text,
                    expires_at=expires_text,
                    remaining_seconds=0,
                )

        if update_last_seen and plan != "lifetime":
            try:
                previous = _parse_iso(last_seen_text)
                if now > previous:
                    payload["last_seen_at"] = _iso(now)
                    self._save_protected(self.state_path, payload)
            except Exception:
                pass

        return LicenseStatus(
            True,
            "valid",
            "Ліцензія активна.",
            self.device_code,
            plan=plan,
            label=_PLAN_LABELS[plan],
            activated_at=activated_text,
            expires_at=expires_text,
            remaining_seconds=remaining_seconds,
        )


__all__ = [
    "LicenseManager",
    "LicenseStatus",
    "format_remaining",
    "format_device_code",
    "machine_fingerprint",
]
