import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from michman_snmp import (validate_profile, decode_snapshot, add_rates, _value, SYSTEM, CPU, STORAGE, IFTABLE, IFX,
    TEMPERATURE,IPADDR,ROUTES,BRIDGE_PORT,BRIDGE_FDB,VLANS,ENTITY,SENSORS)
from michman_topology import build_graph, collect_router_tables
from michman_backup import create_backup, verify_backup, compare_backups, restore_backup, validate_restore, quote, RouterSession


class SNMPTests(unittest.TestCase):
    def test_standard_temperature_and_ups(self):
        from michman_snmp import SENSORS, UPS
        snapshot=decode_snapshot('x',{SENSORS+'.1.1':8,SENSORS+'.2.1':9,SENSORS+'.3.1':1,
            SENSORS+'.4.1':425,SENSORS+'.5.1':1,UPS+'.2.4.0':85,UPS+'.2.3.0':12})
        self.assertEqual(snapshot['temperature_c'],42.5)
        self.assertEqual(snapshot['ups']['charge_percent'],85)
    def test_v3_password_validation(self):
        base = {'host': '192.0.2.1', 'version': '3', 'user': 'monitor', 'auth_key': '12345678', 'priv_key': 'abcdefgh'}
        self.assertEqual(validate_profile(base)['interval'], 30)
        for changes in [{'priv_key': ''}, {'auth_key': ''}, {'level': 'bad'}, {'port': 0}, {'interval': 1}]:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                validate_profile({**base, **changes})

    def test_v2_and_noauth(self):
        profile=validate_profile({'host': 'localhost', 'version': '2c', 'community': 'test',
            'extra_oids':'1.3.6.1.4.1.14988, 1.3.6.1.4.1.9'})
        self.assertEqual(profile['extra_oids'],['1.3.6.1.4.1.14988','1.3.6.1.4.1.9'])
        validate_profile({'host': 'localhost', 'version': '3', 'user': 'x', 'level': 'noAuthNoPriv'})
        with self.assertRaises(ValueError):validate_profile({'host':'x','version':'2c','community':'x','extra_oids':'bad.oid'})

    def test_typed_values(self):
        from pysnmp.proto.rfc1902 import OctetString, Counter64, ObjectIdentifier
        self.assertEqual(_value(OctetString('123')), '123')
        self.assertEqual(_value(Counter64(2**40)), 2**40)
        self.assertEqual(_value(ObjectIdentifier('1.3.6.1')), '1.3.6.1')

    def snapshot(self):
        data = {SYSTEM+'.5.0': 'Router', SYSTEM+'.3.0': 10000,
            CPU+'.1': 20, CPU+'.2': 40, TEMPERATURE: 455,
            STORAGE+'.2.1': '1.3.6.1.2.1.25.2.1.2', STORAGE+'.4.1': 1024,
            STORAGE+'.5.1': 1024, STORAGE+'.6.1': 512,
            IFTABLE+'.2.1': 'ether1', IFTABLE+'.8.1': 1, IFTABLE+'.14.1': 2,
            IFTABLE+'.20.1': 3, IFX+'.6.1': 1000, IFX+'.10.1': 2000,
            IFX+'.15.1': 1000, IFX+'.19.1': 0}
        return decode_snapshot('192.0.2.1', data)

    def test_cpu_ram_temperature_and_counter64(self):
        snap = self.snapshot()
        self.assertEqual(snap['cpu_percent'], 30)
        self.assertEqual(snap['ram_used'], 512*1024)
        self.assertEqual(snap['ram_total'], 1024*1024)
        self.assertEqual(snap['temperature_c'], 45.5)
        self.assertEqual(snap['interfaces'][0]['bits'], 64)

    def test_missing_values_are_not_zero(self):
        snap = decode_snapshot('x', {})
        self.assertIsNone(snap['cpu_percent'])
        self.assertIsNone(snap['ram_total'])
        self.assertIsNone(snap['temperature_c'])

    def test_extended_router_inventory(self):
        data={SYSTEM+'.1.0':'Router OS',IFTABLE+'.2.1':'uplink',IFTABLE+'.3.1':6,IFTABLE+'.4.1':1500,
            IFTABLE+'.6.1':'0x001122334455',IFTABLE+'.7.1':1,IFTABLE+'.8.1':1,IFX+'.18.1':'WAN',
            IPADDR+'.1.192.0.2.1':'192.0.2.1',IPADDR+'.2.192.0.2.1':1,IPADDR+'.3.192.0.2.1':'255.255.255.0',
            ROUTES+'.1.0.0.0.0.0.0.0.192.0.2.254':'0.0.0.0',ROUTES+'.4.0.0.0.0.0.0.0.192.0.2.254':'192.0.2.254',
            BRIDGE_PORT+'.2.5':1,BRIDGE_FDB+'.1.0.17.34.51.68.85':'0x001122334455',BRIDGE_FDB+'.2.0.17.34.51.68.85':5,
            VLANS+'.1.20':'Office',ENTITY+'.7.1':'Chassis',ENTITY+'.11.1':'SERIAL-1',ENTITY+'.13.1':'MODEL-1',
            SENSORS+'.1.7':6,SENSORS+'.2.7':9,SENSORS+'.3.7':1,SENSORS+'.4.7':123,SENSORS+'.5.7':1}
        snap=decode_snapshot('192.0.2.1',data)
        self.assertEqual(snap['interfaces'][0]['alias'],'WAN');self.assertEqual(snap['interfaces'][0]['mac'],'00:11:22:33:44:55')
        self.assertEqual(snap['ip_addresses'][0]['netmask'],'255.255.255.0')
        self.assertEqual(snap['routes'][0]['next_hop'],'192.0.2.254')
        self.assertEqual(snap['bridge_fdb'][0]['interface_index'],1)
        self.assertEqual(snap['vlans'][0]['name'],'Office');self.assertEqual(snap['hardware'][0]['serial_number'],'SERIAL-1')
        self.assertEqual(snap['sensors'][0]['unit'],'W');self.assertTrue(snap['capabilities']['routes'])
        self.assertEqual(len(snap['raw_oids']),len(data))

    def test_rates(self):
        previous = self.snapshot()
        current = copy.deepcopy(previous)
        current['monotonic'] += 10
        current['uptime'] += 1000
        current['interfaces'][0]['rx'] += 1250000
        self.assertEqual(add_rates(current, previous)['interfaces'][0]['rx_bps'], 1000000)

    def test_resets_and_discontinuities(self):
        previous = self.snapshot()
        for change in ['uptime', 'rx', 'discontinuity', 'name']:
            current = copy.deepcopy(previous)
            current['monotonic'] += 10
            if change == 'uptime':
                current['uptime'] = 1
            else:
                current['interfaces'][0][change] = {'rx': 1, 'discontinuity': 5, 'name': 'renamed'}[change]
            with self.subTest(change=change):
                self.assertIsNone(add_rates(current, previous)['interfaces'][0]['rx_bps'])

    def test_counter32_multiple_wrap_is_unknown(self):
        previous = self.snapshot()
        previous['interfaces'][0]['bits'] = 32
        current = copy.deepcopy(previous)
        current['monotonic'] += 60
        current['interfaces'][0]['rx'] += 100
        self.assertIsNone(add_rates(current, previous)['interfaces'][0]['rx_bps'])


class TopologyTests(unittest.TestCase):
    def test_evidence_and_merging(self):
        router = {'host': '192.0.2.1', 'name': 'R1', 'tables': {
            'arp': [{'address': '192.0.2.2', 'interface': 'bridge'}],
            'dhcp': [{'address': '192.0.2.2', 'host-name': 'PC'}],
            'neighbors': [{'address': '192.0.2.3', 'identity': 'R2', 'interface': 'ether2'}]}}
        graph = build_graph([router])
        self.assertEqual(len(graph['nodes']), 3)
        self.assertEqual(len(graph['edges']), 3)
        self.assertEqual([e['relation'] for e in graph['edges']], ['observed', 'observed', 'neighbor'])

    def test_mac_only_neighbors_not_dropped(self):
        graph = build_graph([{'host': 'x', 'name': 'R', 'tables': {'neighbors': [{'mac-address': 'AA:BB:CC:DD:EE:FF'}]}}])
        self.assertEqual(len(graph['nodes']), 2)

    def test_snmp_evidence(self):
        graph = build_graph([], [{'host': 'x', 'name': 'R', 'arp': [{'address': '192.0.2.3'}]}])
        self.assertEqual(graph['edges'][0]['evidence'], 'SNMP ARP')

    def test_partial_failure_and_no_probes(self):
        class Client:
            method, host, name = 'REST', '192.0.2.1', 'R'
            def _rest_request(self, path):
                calls.append(path)
                if 'lease' in path:
                    raise RuntimeError('permission denied')
                return []
        calls = []
        result = collect_router_tables(Client())
        self.assertEqual(calls, ['/ip/arp', '/ip/dhcp-server/lease', '/ip/neighbor'])
        self.assertEqual(len(result['errors']), 1)


class FakeRouter:
    def __init__(self):
        self.commands, self.uploads, self.restores = [], [], []
        self.device = {'host': '192.0.2.1', 'device_id': 'SERIAL1', 'version': '7.20', 'board': 'test', 'identity': 'R1'}
        self.export = '# generated date\n/interface bridge\nadd name=bridge1\n'
    def metadata(self):
        return dict(self.device)
    def command(self, command):
        self.commands.append(command)
        return self.export if command.startswith('/export') else 'Configuration backup saved'
    def download(self, remote, local):
        Path(local).write_bytes(b'encrypted-binary-fixture')
    def remove(self, remote):
        pass
    def upload(self, local, remote):
        self.uploads.append((local, remote))
    def restore(self, remote, password):
        self.restores.append(remote)
        return 'restore requested'


class BackupTests(unittest.TestCase):
    def test_interactive_restore_confirmation(self):
        class Channel:
            closed = False
            def __init__(self):
                self.messages = [b'Restore and reboot? [y/N]: ', b'System configuration restored, rebooting now']
                self.sent = []
            def get_pty(self, **kwargs):
                pass
            def exec_command(self, command):
                self.command = command
            def recv_ready(self):
                return bool(self.messages)
            def recv(self, size):
                return self.messages.pop(0)
            def sendall(self, value):
                self.sent.append(value)
            def exit_status_ready(self):
                return False
            def close(self):
                self.closed = True
        from unittest.mock import MagicMock
        channel = Channel()
        session = RouterSession({})
        session.client = MagicMock()
        session.client.get_transport.return_value.open_session.return_value = channel
        result = session.restore('file.backup', 'password123')
        self.assertEqual(channel.sent, ['y\r\n'])
        self.assertTrue(channel.closed)
        self.assertIn('перезавантаження', result)

    def test_backup_requires_password(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            with self.assertRaises(ValueError):
                create_backup(router, directory, '')
            self.assertEqual(router.commands, [])

    def test_quote_injection_and_controls(self):
        self.assertEqual(quote('a";$x\\'), '"a\\";\\$x\\\\"')
        with self.assertRaises(ValueError):
            quote('x\n/system reset-configuration')

    def test_complete_backup_and_no_password_in_manifest(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            result = create_backup(router, directory, 'secret123')
            manifest = verify_backup(result['folder'])
            self.assertTrue(manifest['encrypted'])
            self.assertNotIn('secret123', json.dumps(manifest))
            self.assertIn('encryption=aes-sha256 dont-encrypt=no', router.commands[0])
            self.assertIn('show-sensitive=no', router.commands[1])

    def test_corruption_blocks_restore(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            folder = create_backup(router, directory, 'secret123')['folder']
            (Path(folder) / 'config.backup').write_bytes(b'tampered')
            with self.assertRaises(ValueError):
                restore_backup(router, folder, 'secret123', directory, 'safety123')
            self.assertEqual(router.restores, [])
            self.assertEqual(router.uploads, [])

    def test_mismatched_device_and_version_block(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            manifest = create_backup(router, directory, 'secret123')['manifest']
            for key in ('device_id', 'version', 'board'):
                with self.subTest(key=key), self.assertRaises(ValueError):
                    validate_restore(manifest, {**router.device, key: 'OTHER'})

    def test_diff_ignores_header_only(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            first = create_backup(router, directory, 'secret123')['folder']
            router.export = '# new date\n/interface bridge\nadd name=bridge2\n'
            second = create_backup(router, directory, 'secret123')['folder']
            diff = compare_backups(first, second)
            self.assertIn('-add name=bridge1', diff)
            self.assertIn('+add name=bridge2', diff)
            self.assertNotIn('new date', diff)

    def test_safety_copy_precedes_restore(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            folder = create_backup(router, directory, 'secret123')['folder']
            restore_backup(router, folder, 'secret123', directory, 'safety123')
            self.assertEqual(len(list(Path(directory).glob('*/manifest.json'))), 2)
            self.assertEqual(len(router.uploads), 1)
            self.assertEqual(len(router.restores), 1)

    def test_safety_failure_blocks_restore(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            folder = create_backup(router, directory, 'secret123')['folder']
            with patch.object(router, 'download', side_effect=OSError('disk full')):
                with self.assertRaises(OSError):
                    restore_backup(router, folder, 'secret123', directory, 'safety123')
            self.assertEqual(router.restores, [])
            self.assertEqual(router.uploads, [])

    def test_manifest_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            router = FakeRouter()
            folder = Path(create_backup(router, directory, 'secret123')['folder'])
            manifest = json.loads((folder/'manifest.json').read_text())
            manifest['files']['../outside'] = '0'*64
            (folder/'manifest.json').write_text(json.dumps(manifest))
            with self.assertRaises(ValueError):
                verify_backup(folder)


if __name__ == '__main__':
    unittest.main()
