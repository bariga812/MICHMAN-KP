import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from michman_agent import (REQUIRED_ENROLLMENT_FILES, configured_agent_directory,
    default_agent_directory, import_enrollment, valid_agent_directory)


class AgentBackgroundTests(unittest.TestCase):
    def make_package(self, folder):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        (folder/'agent.json').write_text(json.dumps({'agent_id':'agent-1',
            'host_identity':'pc.example','port':8743}),encoding='utf-8')
        for name in REQUIRED_ENROLLMENT_FILES[1:]:
            (folder/name).write_text('test certificate material',encoding='utf-8')
        return folder

    def test_first_run_imports_enrollment_to_stable_local_folder(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);source=self.make_package(root/'source')
            with patch.dict(os.environ,{'LOCALAPPDATA':str(root/'local')},clear=False):
                target=import_enrollment(source)
                self.assertEqual(target,default_agent_directory())
                self.assertTrue(valid_agent_directory(target))
                self.assertEqual(configured_agent_directory(),target)
                self.assertEqual((target/'server-key.pem').read_text(encoding='utf-8'),'test certificate material')

    def test_incomplete_package_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary);(folder/'agent.json').write_text('{}',encoding='utf-8')
            with self.assertRaises(ValueError):import_enrollment(folder,folder/'copy')

    def test_windows_installer_registers_background_autostart(self):
        installer=(Path(__file__).parent/'MICHMAN_Agent.iss').read_text(encoding='utf-8')
        self.assertIn('Microsoft\\Windows\\CurrentVersion\\Run',installer)
        self.assertIn('--background',installer)
        self.assertIn('uninsdeletevalue',installer)
        self.assertIn('AppVersion=2.2.0',installer)


if __name__=='__main__':unittest.main()
