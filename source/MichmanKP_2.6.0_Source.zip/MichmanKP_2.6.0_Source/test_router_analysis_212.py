import unittest
from michman_router_analysis import analyze_router_snapshot,router_inventory_summary,detect_router_changes


class RouterAnalysisTests(unittest.TestCase):
    def test_detects_resources_link_errors_and_utilization(self):
        snapshot={'host':'x','cpu_percent':92,'ram_total':100,'ram_used':91,'temperature_c':75,
            'interfaces':[{'name':'uplink','admin_status':1,'status':2,'speed_bps':1000,'rx_bps':900,
                'tx_bps':10,'rx_errors':3,'tx_errors':2,'rx_discards':0,'tx_discards':4}]}
        issues=analyze_router_snapshot(snapshot);categories={item['category'] for item in issues}
        self.assertTrue({'CPU','RAM','TEMPERATURE','INTERFACE','UTILIZATION','ERRORS','DROPS'}<=categories)
        self.assertEqual(issues[0]['severity'],'CRITICAL')

    def test_summary_reports_inventory_counts(self):
        summary=router_inventory_summary({'host':'x','interfaces':[{}],'routes':[{},{}],
            'vlans':[{}],'raw_oids':{'1':1},'capabilities':{'routes':True}})
        self.assertEqual(summary['counts']['routes'],2)
        self.assertEqual(summary['counts']['raw_oids'],1)
        self.assertTrue(summary['capabilities']['routes'])

    def test_detects_router_configuration_changes(self):
        old={'interfaces':[{'index':1,'name':'WAN','admin_status':1,'status':1}],
            'ip_addresses':[{'address':'192.0.2.1','netmask':'255.255.255.0','interface_index':1}],
            'routes':[{'destination':'0.0.0.0','next_hop':'192.0.2.254'}],'vlans':[{'index':'10','name':'Old'}]}
        new={'interfaces':[{'index':1,'name':'WAN','admin_status':1,'status':2}],
            'ip_addresses':[{'address':'192.0.2.2','netmask':'255.255.255.0','interface_index':1}],
            'routes':[],'vlans':[{'index':'20','name':'New'}]}
        changes=detect_router_changes(old,new);categories={item['category'] for item in changes}
        self.assertEqual(categories,{'INTERFACE_STATE','IP_CONFIG_CHANGE','ROUTE_CHANGE','VLAN_CHANGE'})
        self.assertEqual(changes[0]['severity'],'WARNING')


if __name__=='__main__':unittest.main()
