import base64
import unittest

from MichmanKP_Protected import SingleMikroTikClient


class MikroTikPasswordOnlyTests(unittest.TestCase):
    def test_blank_login_uses_routeros_admin_account(self):
        client=SingleMikroTikClient('router','192.0.2.1','', 'secret','REST',443,False)
        self.assertTrue(client.is_configured());self.assertEqual(client.user,'');self.assertEqual(client.auth_user,'admin')
        _url,headers,_context=client._rest_connection_data()
        credentials=base64.b64decode(headers['Authorization'].split()[1]).decode()
        self.assertEqual(credentials,'admin:secret')

    def test_blank_login_without_password_is_not_configured(self):
        self.assertFalse(SingleMikroTikClient('router','192.0.2.1','','','REST').is_configured())

    def test_explicit_login_is_preserved(self):
        client=SingleMikroTikClient('router','192.0.2.1','operator','secret','SSH')
        self.assertEqual(client.auth_user,'operator')


if __name__=='__main__':unittest.main()
