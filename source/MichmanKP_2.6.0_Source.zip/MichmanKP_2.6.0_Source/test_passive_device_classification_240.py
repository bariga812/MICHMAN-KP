import inspect
import time
import unittest
from unittest.mock import patch

from MichmanKP_Protected import Host, MichmanKP


class PassiveDeviceClassificationTests(unittest.TestCase):
    def make_app(self, gateways=(), routers=()):
        app = object.__new__(MichmanKP)
        app._default_gateway_cache = (time.time(), set(gateways))
        app.mikrotik_list = [{"host": ip} for ip in routers]
        return app

    @patch("MichmanKP_Protected.get_arp_mac", return_value="")
    def test_default_gateway_is_confirmed_router(self, _arp):
        host = Host("192.168.1.1", "Gateway")
        result = self.make_app(gateways={host.ip}).classify_host_passively(host)
        self.assertEqual((result["kind"], result["confidence"]), ("Роутер", "HIGH"))

    @patch("MichmanKP_Protected.get_arp_mac", return_value="")
    def test_configured_authorized_router_is_confirmed(self, _arp):
        host = Host("192.168.88.1")
        result = self.make_app(routers={host.ip}).classify_host_passively(host)
        self.assertEqual((result["kind"], result["confidence"]), ("Роутер", "HIGH"))

    @patch("MichmanKP_Protected.get_arp_mac", return_value="")
    def test_dhcp_style_computer_name_is_probabilistic(self, _arp):
        host = Host("192.168.1.20")
        host.mt_hostname = "DESKTOP-ABC123"
        result = self.make_app().classify_host_passively(host)
        self.assertEqual((result["kind"], result["confidence"]), ("Комп’ютер", "MEDIUM"))

    @patch("MichmanKP_Protected.get_arp_mac", return_value="AA-BB-CC-DD-EE-FF")
    @patch("MichmanKP_Protected.get_mac_vendor", return_value="MikroTik")
    def test_cached_arp_vendor_can_indicate_router(self, _vendor, _arp):
        host = Host("192.168.1.30")
        result = self.make_app().classify_host_passively(host)
        self.assertEqual((result["kind"], result["confidence"]), ("Роутер", "MEDIUM"))

    @patch("MichmanKP_Protected.get_arp_mac", return_value="")
    def test_unknown_is_preserved_when_evidence_is_insufficient(self, _arp):
        result = self.make_app().classify_host_passively(Host("192.168.1.40"))
        self.assertEqual((result["kind"], result["confidence"]), ("Невідомий", "LOW"))

    def test_classifier_has_no_active_network_probe(self):
        source = inspect.getsource(MichmanKP.classify_host_passively)
        self.assertNotIn("ping_once", source)
        self.assertNotIn("tcp_probe", source)
        self.assertNotIn("socket.", source)
        self.assertIn("get_arp_mac", source)

    def test_agent_windows_platform_is_presented_readably(self):
        self.assertEqual(
            MichmanKP._windows_identity("Windows-11-10.0.26100-SP0"),
            "Windows 11 (10.0.26100)",
        )

    def test_identity_is_shown_in_existing_hostname_column_value(self):
        host = Host("192.168.1.50")
        host.mt_hostname = "DESKTOP-OFFICE"
        host.device_identity = "Windows 11 (10.0.26100)"
        label = self.make_app()._hostname_identity(host)
        self.assertEqual(label, "DESKTOP-OFFICE / Windows 11 (10.0.26100)")

    def test_identity_audit_metadata_is_in_snapshot(self):
        host = Host("192.168.1.60")
        host.device_identity_source = "mTLS агент"
        host.device_identified_at = "2026-09-13T16:00:00+00:00"
        snapshot = host.snapshot()
        self.assertEqual(snapshot["device_identity_source"], "mTLS агент")
        self.assertEqual(snapshot["device_identified_at"], "2026-09-13T16:00:00+00:00")

    def test_online_retry_is_rate_limited(self):
        source = inspect.getsource(MichmanKP.apply_check_result)
        self.assertIn("device_identification_last_attempt >= 1800", source)
        self.assertIn("schedule_host_identification", source)


if __name__ == "__main__":
    unittest.main()
