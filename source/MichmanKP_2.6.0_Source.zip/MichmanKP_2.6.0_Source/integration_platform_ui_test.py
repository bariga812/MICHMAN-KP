import queue
import tempfile
import time
import tkinter as tk
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from michman_platform_core import PlatformCore
from michman_platform_ui import PlatformWindow
from michman_windows import WrapToolbar


def run():
    callbacks=queue.Queue();errors=[]
    root=tk.Tk();root.withdraw();root.report_callback_exception=lambda *args:errors.append(str(args[1]))
    with tempfile.TemporaryDirectory() as directory:
        core=PlatformCore(Path(directory)/'test.db')
        app=SimpleNamespace(root=root,platform_core=core,identity_session={'user':'tester','role':'Administrator','ssl_context':None},
            run_on_gui=callbacks.put,open_network_center=lambda:None,open_scan_watch_window=lambda:None,
            open_dfir_window=lambda:None,open_mikrotik_security_center=lambda:None)
        window=PlatformWindow(app)
        window.window.minsize(800,500);window.window.geometry('984x668')
        root.update()
        def check_toolbar(widget):
            if isinstance(widget,WrapToolbar) and widget.winfo_viewable():
                for child in widget.winfo_children():
                    assert child.winfo_x()+child.winfo_width()<=widget.winfo_width(),str(child)
                    assert child.winfo_y()+child.winfo_height()<=widget.winfo_height(),str(child)
            for child in widget.winfo_children():check_toolbar(child)
        for page in window.pages.values():
            window.tabs.select(page);root.update();check_toolbar(page)
            assert page.winfo_height()>200,page.winfo_height()
        window.window.withdraw()
        core.ingest('192.0.2.1',{'online':True,'ping':10},'Router')
        core.ingest('192.0.2.2',{'online':False,'ping':None},'Server')
        core.set_dependency('192.0.2.1','192.0.2.2')
        window.refresh()
        assert len(window.inventory.get_children())==2
        assert len(window.pages)==6
        window.workspace.set('Security Operations');window.apply_workspace()
        assert all(window.tabs.tab(window.pages[name],'state')=='normal' for name in ['Огляд','Baseline / Безпека','Інциденти','Syslog / Звіти'])
        window.link_ip.set('192.0.2.1');window.show_link();window.communication_map()
        for _ in range(30):
            root.update()
            while not callbacks.empty():callbacks.get_nowait()()
            if not window.busy:break
            time.sleep(.03)
        window.close();core.close()
    root.destroy()
    assert not errors,errors
    print('Platform Tk: workspace switching, shared inventory, dependencies, link chart and close OK')


if __name__=='__main__':run()
