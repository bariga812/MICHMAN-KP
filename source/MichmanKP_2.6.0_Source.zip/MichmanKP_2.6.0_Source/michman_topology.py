"""Topology from device tables only: no subnet enumeration, ping or port probes."""
import ipaddress
from datetime import datetime, timezone


def ipv4(value):
    try:
        return str(ipaddress.IPv4Address(str(value)))
    except ValueError:
        return ''


def collect_router_tables(client):
    tables, errors = {}, []
    for name, path in [('arp', '/ip/arp'), ('dhcp', '/ip/dhcp-server/lease'), ('neighbors', '/ip/neighbor')]:
        try:
            if client.method == 'REST':
                rows = client._rest_request(path)
            else:
                rows = client._parse_terse_records(client._ssh_execute(path.replace('/', ' ') + ' print terse without-paging'))
            if not isinstance(rows, list):
                raise ValueError('Очікувалася таблиця RouterOS')
            tables[name] = rows
        except Exception as error:
            errors.append(f'{client.name} / {name}: {error}')
    return {'host': client.host, 'name': client.name, 'tables': tables, 'errors': errors}


def build_graph(routers, snmp_snapshots=()):
    nodes, edges, warnings = {}, {}, []
    stamp = datetime.now(timezone.utc).isoformat()

    def node(key, label, kind, **attributes):
        item = nodes.setdefault(key, {'id': key, 'label': str(label), 'kind': kind})
        if kind == 'router':
            item.update(label=str(label), kind=kind)
        elif item['label'] == item.get('address') and str(label) != item['label']:
            item['label'] = str(label)
        for k, value in attributes.items():
            if value:
                item[k] = str(value)
        return key

    def source(host, name):
        return node('ip:' + host, name or host, 'router', address=host)

    def observations(root, host, tables, prefix='', observed_at=None):
        for table, records in tables.items():
            for index, record in enumerate(records):
                address = ipv4(record.get('address') or record.get('active-address'))
                mac = str(record.get('mac-address') or record.get('active-mac-address') or record.get('mac') or '')
                name = record.get('identity') or record.get('host-name') or address or mac or 'Сусід'
                interface = str(record.get('interface') or record.get('interface_index') or record.get('server') or '?')
                # Non-IP records are scoped to their reporting device to avoid false global merges.
                identity = mac or record.get('chassis-id') or f'{interface}:{index}:{name}'
                key = 'ip:' + address if address else f'observed:{host}:{identity}'
                node(key, name, 'device', address=address, mac=mac)
                if key == root:
                    continue
                evidence = prefix + table.upper()
                edge_key = (root, key, interface, evidence)
                edges[edge_key] = {'source': root, 'target': key, 'interface': interface,
                    'evidence': evidence, 'relation': 'neighbor' if table == 'neighbors' else 'observed',
                    'state': str(record.get('status', '')), 'remote_port': str(record.get('remote-port', '')),
                    'observed_at': observed_at or stamp}

    for router in routers:
        root = source(router['host'], router['name'])
        observations(root, router['host'], router['tables'])
        warnings.extend(router.get('errors', []))
    for snapshot in snmp_snapshots:
        root = source(snapshot['host'], snapshot['name'])
        observations(root, snapshot['host'], {'arp': snapshot.get('arp', []),
                                              'neighbors': snapshot.get('neighbors', []),
                                              'fdb':snapshot.get('bridge_fdb',[])}, 'SNMP ', snapshot.get('collected_at'))
        warnings.extend(f"{snapshot['host']}: {w}" for w in snapshot.get('warnings', []))
    return {'created_at': stamp, 'nodes': list(nodes.values()), 'edges': list(edges.values()), 'warnings': warnings}
