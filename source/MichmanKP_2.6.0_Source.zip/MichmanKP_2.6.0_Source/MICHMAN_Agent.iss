#ifndef SourceDir
  #define SourceDir "dist\MICHMAN_Agent"
#endif
#ifndef OutputDirPath
  #define OutputDirPath "installer_output"
#endif
[Setup]
AppId={{A02A180D-621C-4818-9B54-BD8E2B399A02}
AppName=MICHMAN Agent
AppVersion=2.2.0
AppPublisher=Ihor Stepanenko
DefaultDirName={localappdata}\Programs\MichmanAgent
DefaultGroupName=MICHMAN Agent
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir={#OutputDirPath}
OutputBaseFilename=MICHMAN_Agent_Setup_2.2.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=MichmanKP_Icon.ico
[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "AGENT_2.2_UA.md"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{group}\MICHMAN Agent"; Filename: "{app}\MICHMAN_Agent.exe"
[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "MICHMAN Agent"; ValueData: """{app}\MICHMAN_Agent.exe"" --background"; Flags: uninsdeletevalue
[Run]
Filename: "{app}\MICHMAN_Agent.exe"; Parameters: "--background"; Description: "Configure and start MICHMAN Agent"; Flags: nowait postinstall skipifsilent

