"""Standards-based router identification and encrypted SSH configuration export."""
import base64
import difflib
import hashlib
import json
import os
import re
import time
import uuid
import ssl
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from datetime import datetime,timezone
from pathlib import Path

from michman_utils import atomic_write_json

MAX_CONFIG_BYTES=32*1024*1024
PLATFORMS={
 'auto':('Автовизначення',(),()),
 'cisco_ios_xr':('Cisco IOS XR',('ios xr',),('show running-config',)),
 'cisco_ios':('Cisco IOS/IOS XE',('cisco ios','ios xe'),('show running-config',)),
 'cisco_nxos':('Cisco NX-OS',('nx-os','nexus'),('show running-config',)),
 'cisco_asa':('Cisco ASA/FTD',('adaptive security appliance','cisco asa','firepower threat defense'),('show running-config',)),
 'junos':('Juniper Junos',('junos','juniper'),('show configuration | display set | no-more',)),
 'arista_eos':('Arista EOS',('arista','eos'),('show running-config',)),
 'aruba':('Aruba AOS-CX/ProCurve',('aruba','procurve','aos-cx'),('show running-config',)),
 'huawei_vrp':('Huawei VRP',('huawei','vrp'),('display current-configuration',)),
 'h3c':('H3C Comware',('h3c','comware'),('display current-configuration',)),
 'fortios':('Fortinet FortiOS',('fortios','fortigate'),('show full-configuration',)),
 'panos':('Palo Alto PAN-OS',('pan-os','palo alto'),('show config running',)),
 'checkpoint_gaia':('Check Point Gaia',('check point gaia','gaia os'),('show configuration',)),
 'extreme_exos':('Extreme Networks EXOS',('extremexos','extreme exos'),('show configuration',)),
 'ruckus_icx':('Ruckus/Brocade ICX',('ruckus icx','brocade icx','fastiron'),('show running-config',)),
 'dell_os10':('Dell SmartFabric OS10',('smartfabric os10','dell os10'),('show running-configuration',)),
 'nokia_sros':('Nokia SR OS',('nokia sr os','timos'),('admin display-config',)),
 'alliedware':('Allied Telesis AlliedWare Plus',('alliedware plus',),('show running-config',)),
 'edgeos':('Ubiquiti EdgeOS',('edgeos','edgerouter'),('show configuration commands',)),
 'vyos':('VyOS/Vyatta',('vyos','vyatta'),('show configuration commands',)),
 'frr':('FRRouting',('frrouting','quagga','frr'),('vtysh -c "show running-config"',)),
 'openwrt':('OpenWrt',('openwrt',),('uci export',)),
 'pfsense':('pfSense',('pfsense',),('cat /cf/conf/config.xml',)),
 'opnsense':('OPNsense',('opnsense',),('cat /conf/config.xml',)),
 'mikrotik':('MikroTik RouterOS',('routeros','mikrotik'),('/export show-sensitive=no',)),
 'mercusys':('Mercusys (домашній)',('mercusys','mwlogin'),()),
 'tplink_home':('TP-Link (домашній)',('tp-link','tplinkwifi','tplinkmodem'),()),
 'asuswrt':('ASUS / ASUSWRT',('asuswrt','asus wireless router'),('nvram show',)),
 'keenetic':('Keenetic / Zyxel Keenetic',('keenetic','ndms'),('show running-config',)),
 'dlink_home':('D-Link (домашній)',('d-link','dlinkrouter'),()),
 'tenda_home':('Tenda (домашній)',('tenda','tendawifi'),()),
 'netgear_home':('NETGEAR (домашній)',('netgear','routerlogin.net'),()),
 'linksys_home':('Linksys (домашній)',('linksys','linksyssmartwifi'),()),
 'xiaomi_home':('Xiaomi / Mi Router',('xiaomi router','miwifi'),('uci export',)),
 'zyxel_home':('Zyxel (домашній)',('zyxel',),()),
 'custom':('Користувацький SSH',(),()),
}

HOME_WEB_PLATFORMS={'mercusys','tplink_home','asuswrt','keenetic','dlink_home','tenda_home',
                    'netgear_home','linksys_home','xiaomi_home','zyxel_home'}
LEGACY_KEX=('diffie-hellman-group-exchange-sha1','diffie-hellman-group14-sha1','diffie-hellman-group1-sha1')
LEGACY_KEYS=('ssh-rsa','ssh-dss')

# Enterprise OIDs identify a manufacturer even when sysDescr does not reveal an OS.
# A generic vendor match stays on the custom profile until a safe export dialect is known.
VENDOR_SIGNATURES=(
 ('.1.3.6.1.4.1.9.','Cisco','cisco_ios'),('.1.3.6.1.4.1.2636.','Juniper Networks','junos'),
 ('.1.3.6.1.4.1.14988.','MikroTik','mikrotik'),('.1.3.6.1.4.1.2011.','Huawei','huawei_vrp'),
 ('.1.3.6.1.4.1.25506.','H3C','h3c'),('.1.3.6.1.4.1.30065.','Arista Networks','arista_eos'),
 ('.1.3.6.1.4.1.12356.','Fortinet','fortios'),('.1.3.6.1.4.1.25461.','Palo Alto Networks','panos'),
 ('.1.3.6.1.4.1.1916.','Extreme Networks','extreme_exos'),('.1.3.6.1.4.1.674.','Dell Technologies','custom'),
 ('.1.3.6.1.4.1.6527.','Nokia','nokia_sros'),('.1.3.6.1.4.1.41112.','Ubiquiti Networks','custom'),
 ('.1.3.6.1.4.1.14823.','Aruba Networks','aruba'),('.1.3.6.1.4.1.11.','HPE/Aruba','custom'),
 ('.1.3.6.1.4.1.11863.','TP-Link','tplink_home'),('.1.3.6.1.4.1.171.','D-Link','dlink_home'),
 ('.1.3.6.1.4.1.890.','Zyxel','zyxel_home'),('.1.3.6.1.4.1.4526.','NETGEAR','netgear_home'),
)


def identify_router(sys_descr='',sys_object_id=''):
    haystack=(str(sys_descr)+' '+str(sys_object_id)).lower()
    for key,(label,patterns,_commands) in PLATFORMS.items():
        if key not in ('auto','custom') and any(pattern in haystack for pattern in patterns):
            return {'platform':key,'vendor':label,'confidence':'sysDescr/sysObjectID'}
    oid='.'+str(sys_object_id).lstrip('.')+'.'
    for prefix,vendor,platform in VENDOR_SIGNATURES:
        if oid.startswith(prefix):return {'platform':platform,'vendor':vendor,'confidence':'sysObjectID'}
    return {'platform':'custom','vendor':'Стандартний SNMP-пристрій','confidence':'generic'}


def validate_router_profile(profile):
    result=dict(profile);result.setdefault('id',uuid.uuid4().hex)
    result.setdefault('auth_mode','password_only' if not result.get('user') else 'username')
    for key in ('name','host','user','platform','known_hosts','command','auth_mode'):
        result[key]=str(result.get(key,'')).strip()
    result['port']=int(result.get('port',22))
    result['legacy_ssh']=bool(result.get('legacy_ssh',False))
    if not result['host'] or any(c.isspace() or ord(c)<32 for c in result['host']):raise ValueError('Вкажіть коректний IP/DNS роутера.')
    if result['auth_mode'] not in ('username','password_only'):raise ValueError('Невідомий режим SSH-автентифікації.')
    if result['auth_mode']=='username' and not result['user']:raise ValueError('Вкажіть SSH-користувача або виберіть режим «Лише пароль».')
    if result['auth_mode']=='password_only':result['user']=''
    if result['platform'] not in PLATFORMS:raise ValueError('Невідома платформа роутера.')
    if not 1<=result['port']<=65535:raise ValueError('Некоректний SSH-порт.')
    if result['platform']=='custom':
        if not result['command']:raise ValueError('Для користувацького профілю вкажіть команду експорту конфігурації.')
        if any(c in result['command'] for c in '\r\n\x00'):raise ValueError('Команда повинна бути одним рядком.')
        lowered=result['command'].lower()
        if not re.match(r'^(show\b|display\b|cat\s+/|uci\s+export\b|vtysh\s+-c\s+["\']show\b)',lowered):
            raise ValueError('Користувацька команда повинна бути командою лише для читання: show, display, cat /..., uci export або vtysh -c "show...".')
        if any(token in result['command'] for token in (';','&&','||','`','$(','>')):
            raise ValueError('У користувацькій команді заборонені shell-оператори та перенаправлення.')
    return result


class UniversalRouterSession:
    def __init__(self,profile,password=''):
        self.profile=validate_router_profile(profile);self.password=password;self.client=None
    def __enter__(self):
        import paramiko
        if self.profile['auth_mode']=='password_only' and not self.password:
            raise ValueError('Для режиму без логіна введіть пароль роутера.')
        self.client=paramiko.SSHClient();self.client.load_system_host_keys()
        if self.profile['known_hosts']:self.client.load_host_keys(self.profile['known_hosts'])
        self.client.set_missing_host_key_policy(paramiko.RejectPolicy())
        password_only=self.profile['auth_mode']=='password_only'
        disabled=None if self.profile['legacy_ssh'] else {'kex':list(LEGACY_KEX),'keys':list(LEGACY_KEYS)}
        self.client.connect(hostname=self.profile['host'],port=self.profile['port'],username='' if password_only else self.profile['user'],
            password=self.password or None,look_for_keys=not password_only and not bool(self.password),allow_agent=not password_only and not bool(self.password),
            timeout=8,auth_timeout=10,banner_timeout=10,disabled_algorithms=disabled)
        return self
    def __exit__(self,*_args):
        if self.client:self.client.close()
    def command(self,command,timeout=60):
        channel=self.client.get_transport().open_session(timeout=10);channel.settimeout(2);channel.exec_command(command)
        output,errors=bytearray(),bytearray();deadline=time.monotonic()+timeout
        try:
            while True:
                if channel.recv_ready():output.extend(channel.recv(65536))
                if channel.recv_stderr_ready():errors.extend(channel.recv_stderr(65536))
                if len(output)+len(errors)>MAX_CONFIG_BYTES:raise RuntimeError('Конфігурація перевищує 32 MiB.')
                if channel.exit_status_ready() and not channel.recv_ready() and not channel.recv_stderr_ready():break
                if time.monotonic()>deadline:raise TimeoutError('Роутер не завершив команду вчасно.')
                time.sleep(.02)
            if channel.recv_exit_status()!=0:raise RuntimeError('Роутер відхилив команду експорту конфігурації.')
            text=output.decode('utf-8',errors='replace')
            if errors and not text.strip():raise RuntimeError(errors.decode('utf-8',errors='replace')[:500])
            if not text.strip():raise RuntimeError('Роутер повернув порожню конфігурацію.')
            return text
        finally:channel.close()
    def export(self):
        platform=self.profile['platform']
        if platform=='auto':raise ValueError('Виберіть визначену платформу перед SSH-експортом.')
        if not PLATFORMS[platform][2]:
            raise ValueError('Ця домашня платформа не має універсальної SSH-команди експорту. Використайте резервну копію у веб-панелі виробника.')
        command=self.profile['command'] if platform=='custom' else PLATFORMS[platform][2][0]
        return self.command(command)


class HomeRouterWebSession:
    """Read-only reachability and standards-based identity probe for home routers."""
    def __init__(self,profile):
        self.profile=dict(profile)

    def probe(self):
        host=str(self.profile.get('host','')).strip()
        port=int(self.profile.get('port') or 80)
        scheme='https' if port in (443,8443) or str(self.profile.get('method','')).upper()=='HTTPS' else 'http'
        context=ssl.create_default_context()
        if not self.profile.get('verify_peer',True):
            context.check_hostname=False;context.verify_mode=ssl.CERT_NONE
        base=f'{scheme}://{host}:{port}'
        password_manager=urllib.request.HTTPPasswordMgrWithDefaultRealm()
        password_manager.add_password(None,base,str(self.profile.get('user','')),str(self.profile.get('password','')))
        opener=urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=context),
            urllib.request.HTTPBasicAuthHandler(password_manager),
            urllib.request.HTTPDigestAuthHandler(password_manager),
        )
        found={}
        errors=[]
        for path in ('/','/rootDesc.xml','/description.xml','/upnp/IGD.xml'):
            url=base+path
            try:
                request=urllib.request.Request(url,headers={'User-Agent':'MICHMAN-KP/2.3 HomeRouterProbe','Accept':'text/html,application/xml,text/xml'})
                with opener.open(request,timeout=6) as response:
                    body=response.read(2*1024*1024+1)
                    if len(body)>2*1024*1024:raise ValueError('Відповідь веб-панелі перевищує 2 MiB.')
                    text=body.decode(response.headers.get_content_charset() or 'utf-8',errors='replace')
                    found.update({'url':response.geturl(),'status':getattr(response,'status',200),'server':response.headers.get('Server','')})
                    if path=='/':
                        title=re.search(r'(?is)<title[^>]*>\s*(.*?)\s*</title>',text)
                        if title:found['title']=re.sub(r'\s+',' ',title.group(1))[:200]
                    elif text.lstrip().startswith('<'):
                        try:
                            root=ET.fromstring(text)
                            for element in root.iter():
                                name=element.tag.rsplit('}',1)[-1]
                                if name in ('friendlyName','manufacturer','modelName','modelNumber','serialNumber') and element.text:
                                    found[name]=element.text.strip()[:200]
                        except ET.ParseError:pass
            except urllib.error.HTTPError as error:
                # 401/403 still proves that the configured management server exists.
                if error.code in (401,403):found.update({'url':url,'status':error.code,'server':error.headers.get('Server','')});break
                errors.append(f'{path}: HTTP {error.code}')
            except Exception as error:errors.append(f'{path}: {error}')
        if not found:raise ConnectionError('Веб-панель роутера недоступна. '+'; '.join(errors[:2]))
        found['platform']=self.profile.get('platform','auto')
        found['vendor']=PLATFORMS.get(found['platform'],('Домашній роутер',(),()))[0]
        return found


def _key(password,salt):
    if len(password)<12:raise ValueError('Пароль архіву повинен містити щонайменше 12 символів.')
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    return PBKDF2HMAC(algorithm=hashes.SHA256(),length=32,salt=salt,iterations=600000).derive(password.encode())


def create_universal_backup(session,directory,password):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    profile=session.profile;text=session.export().encode('utf-8')
    if len(text)>MAX_CONFIG_BYTES:raise ValueError('Конфігурація перевищує 32 MiB.')
    salt,nonce=os.urandom(16),os.urandom(12);created=datetime.now(timezone.utc).isoformat()
    metadata={'schema':1,'created_at':created,'host':profile['host'],'name':profile['name'] or profile['host'],
              'platform':profile['platform'],'vendor':PLATFORMS[profile['platform']][0],'encrypted':'AES-256-GCM','kdf':'PBKDF2-SHA256-600000'}
    aad=json.dumps(metadata,sort_keys=True,separators=(',',':')).encode()
    payload=AESGCM(_key(password,salt)).encrypt(nonce,text,aad)
    packet={**metadata,'salt':base64.b64encode(salt).decode(),'nonce':base64.b64encode(nonce).decode(),
            'payload':base64.b64encode(payload).decode(),'plaintext_sha256':hashlib.sha256(text).hexdigest()}
    folder=Path(directory);folder.mkdir(parents=True,exist_ok=True)
    path=folder/(datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f_')+re.sub(r'[^A-Za-z0-9_.-]','_',metadata['name'])+'.mrouter')
    atomic_write_json(path,packet);return {'path':str(path),'metadata':metadata}


def read_universal_backup(path,password):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    packet=json.loads(Path(path).read_text(encoding='utf-8'))
    metadata={key:packet[key] for key in ('schema','created_at','host','name','platform','vendor','encrypted','kdf')}
    if metadata['schema']!=1 or metadata['encrypted']!='AES-256-GCM':raise ValueError('Непідтримуваний формат архіву роутера.')
    aad=json.dumps(metadata,sort_keys=True,separators=(',',':')).encode()
    text=AESGCM(_key(password,base64.b64decode(packet['salt'],validate=True))).decrypt(
        base64.b64decode(packet['nonce'],validate=True),base64.b64decode(packet['payload'],validate=True),aad)
    if hashlib.sha256(text).hexdigest()!=packet['plaintext_sha256']:raise ValueError('Контрольна сума конфігурації не збігається.')
    return metadata,text.decode('utf-8')


def compare_universal_backups(first,first_password,second,second_password):
    left,a=read_universal_backup(first,first_password);right,b=read_universal_backup(second,second_password)
    if left['host']!=right['host'] or left['platform']!=right['platform']:raise ValueError('Оберіть копії одного роутера та платформи.')
    return ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=left['created_at'],tofile=right['created_at'])) or 'Змін немає.\n'
