import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import os
import sys
import json
import time
import threading
import subprocess
import re
import socket
import sqlite3
import csv
import queue
import ipaddress
import concurrent.futures
import urllib.request
import urllib.parse
import urllib.error
import ssl
import base64
import hashlib
import ctypes
import shutil
import logging
import shlex
import traceback
import uuid
try:
    import winsound
except ImportError:
    winsound = None
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta, timezone
from collections import deque

from michman_windows import install_window_policy, WrapToolbar
install_window_policy()

from michman_utils import atomic_write_json, SafeCSVWriter, parse_device_input

from michman_license import LicenseManager, LicenseStatus, format_remaining
from michman_i18n import LANGUAGES, Localizer, install_tk_hooks
from michman_scan_defense import enable_windows_scan_sensor, is_windows_admin, set_windows_firewall_block


APP_NAME = "МІЧМАН КП"
APP_VERSION = "2.6.0-fleet-health"

INSTALL_DIR = os.path.dirname(
    os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__)
)

if getattr(sys, "frozen", False) and sys.platform.startswith("win"):
    BASE_DIR = os.path.join(
        os.environ.get("LOCALAPPDATA", INSTALL_DIR),
        "MichmanKP",
    )
    os.makedirs(BASE_DIR, exist_ok=True)

    # One-time migration from older portable builds that stored writable
    # state next to the executable. Existing user data always wins.
    for legacy_name in (
        "IP.txt",
        "IP_names.json",
        "michman.db",
        "michman.db-wal",
        "michman.db-shm",
        "IP_devices.json",
        "mikrotik_config.json",
        "IP_visibility.json",
        "network_scan_watch.json",
        "network_port_attempts.json",
        "scan_defense_settings.json",
    ):
        legacy_path = os.path.join(INSTALL_DIR, legacy_name)
        migrated_path = os.path.join(BASE_DIR, legacy_name)

        if os.path.isfile(legacy_path) and not os.path.exists(migrated_path):
            try:
                shutil.copy2(legacy_path, migrated_path)
            except OSError:
                pass
else:
    BASE_DIR = INSTALL_DIR

# IP.txt is retained only as a one-time migration source for older builds.
# The running application never creates, watches or edits this file.
LEGACY_IP_FILE = os.path.join(BASE_DIR, "IP.txt")
DEVICES_FILE = os.path.join(BASE_DIR, "monitored_devices.json")
NAMES_FILE = os.path.join(BASE_DIR, "IP_names.json")
DB_FILE = os.path.join(BASE_DIR, "michman.db")
DEVICE_CONFIG_FILE = os.path.join(BASE_DIR, "IP_devices.json")
MIKROTIK_CONFIG_FILE = os.path.join(BASE_DIR, "mikrotik_config.json")
HIDDEN_PINNED_FILE = os.path.join(BASE_DIR, "IP_visibility.json")
NETWORK_SCAN_WATCH_FILE = os.path.join(BASE_DIR, "network_scan_watch.json")
NETWORK_PORT_ATTEMPTS_FILE = os.path.join(BASE_DIR, "network_port_attempts.json")
SCAN_DEFENSE_SETTINGS_FILE = os.path.join(BASE_DIR, "scan_defense_settings.json")
TECHNICAL_LOG_FILE = os.path.join(BASE_DIR, "michman_app.log")
STARTUP_ERROR_FILE = os.path.join(BASE_DIR, "startup_error.log")

# Presentation-only localization. It is installed before any UI widget is
# created, so monitoring, RouterOS and DFIR values remain unchanged internally.
I18N = Localizer(BASE_DIR)
install_tk_hooks(
    I18N,
    tk,
    ttk,
    messagebox,
    simpledialog,
    filedialog,
)
NETWORK_SCAN_WINDOW_SECONDS = 120
NETWORK_SCAN_UNIQUE_PORTS = 8
NETWORK_SCAN_ATTEMPTS = 20
NETWORK_SCAN_RETENTION_DAYS = 30
SCAN_WATCH_POLL_MS = 5000
SCAN_WATCH_ACTIVE_SECONDS = 45
SCAN_WATCH_ALERT_COOLDOWN_SECONDS = 60
SCAN_WATCH_BLOCK_RETRY_SECONDS = 600

PING_LIMIT_MS = 800.0
WARN_PING_MS = 800.0
PING_TIMEOUT = 2
DEFAULT_INTERVAL = 5
HISTORY_SECONDS = 3600
STATISTICS_PERIOD = 3600
ICMP_ATTEMPTS = 3
TCP_TIMEOUT = 1.2
MAX_LOG_LINES = 3000
MAX_WORKERS = 64
DB_BUSY_TIMEOUT_MS = 5000
MIN_HIGH_PING_TIMEOUT = 3
HIGH_PING_LOG_EVERY = 3
DB_CHECK_SAMPLE_SECONDS = 60
DB_CHECK_RETENTION_DAYS = 30
DB_EVENT_RETENTION_DAYS = 180
DB_MAINTENANCE_INTERVAL_SECONDS = 86400

# Futuristic dark interface palette. These constants affect presentation only;
# monitoring and ONLINE/OFFLINE decisions remain unchanged.
UI_BG = "#0B1722"
UI_HEADER = "#0F2331"
UI_SURFACE = "#132D3D"
UI_PANEL = "#194257"
UI_PANEL_HOVER = "#235A70"
UI_BORDER = "#2C7186"
UI_BORDER_BRIGHT = "#42AFC8"
UI_TEXT = "#E8FAFF"
UI_MUTED = "#9EC2CE"
UI_CYAN = "#00E5FF"
UI_CYAN_SOFT = "#0B5E70"
UI_GREEN = "#20F6A7"
UI_RED = "#FF4D6D"
UI_AMBER = "#FFC857"
UI_MAGENTA = "#B67CFF"
UI_SELECTION_TEXT = "#021014"

LOGGER = logging.getLogger("michman")
LOGGER.setLevel(logging.INFO)
LOGGER.propagate = False

if not LOGGER.handlers:
    try:
        log_handler = RotatingFileHandler(
            TECHNICAL_LOG_FILE,
            maxBytes=2 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        log_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s | %(levelname)s | %(threadName)s | %(message)s"
            )
        )
        LOGGER.addHandler(log_handler)
    except OSError:
        LOGGER.addHandler(logging.NullHandler())

INSTANCE_MUTEX_HANDLE = None


def record_startup_failure(error):
    """Persist a useful launch traceback and show it when a GUI is available."""
    details = traceback.format_exc()
    if not details or details.strip() == "NoneType: None":
        details = "".join(
            traceback.format_exception(type(error), error, error.__traceback__)
        )

    try:
        os.makedirs(BASE_DIR, exist_ok=True)
        with open(STARTUP_ERROR_FILE, "w", encoding="utf-8") as handle:
            handle.write(
                "MICHMAN KP startup failure\n"
                f"APP_VERSION={APP_VERSION}\n\n"
                f"{details}"
            )
    except Exception:
        pass

    try:
        LOGGER.exception("Application startup failed")
    except Exception:
        pass

    try:
        error_root = tk.Tk()
        error_root.withdraw()
        messagebox.showerror(
            APP_NAME,
            "Не вдалося запустити програму.\n\n"
            f"Деталі збережено у:\n{STARTUP_ERROR_FILE}",
            parent=error_root,
        )
        error_root.destroy()
    except Exception:
        # If Tk itself is unavailable, the startup_error.log file remains.
        pass


def _bring_window_to_front(window):
    """Make a Tk window visible and bring it above other applications."""
    try:
        window.deiconify()
        window.state("normal")
        window.update_idletasks()
        window.lift()
        window.focus_force()
    except tk.TclError:
        # Continue with the topmost pulse even if one focus operation is not
        # supported by the current window manager.
        pass

    # A short topmost pulse fixes the common Windows case where a modal
    # Toplevel is created while its owner is withdrawn or minimized.  It is
    # immediately disabled again so MICHMAN KP does not remain always-on-top.
    try:
        window.attributes("-topmost", True)

        def clear_topmost():
            try:
                if window.winfo_exists():
                    window.attributes("-topmost", False)
            except tk.TclError:
                pass

        window.after(350, clear_topmost)
    except tk.TclError:
        pass


def _center_window(window, width, height, min_width=800, min_height=560):
    """Center a window and keep its requested size inside the screen."""
    try:
        screen_width = max(1, int(window.winfo_screenwidth()))
        screen_height = max(1, int(window.winfo_screenheight()))
        if screen_width < 640 or screen_height < 480:
            # Some window managers report placeholder dimensions before the
            # first expose event. Keep the requested geometry instead of
            # collapsing a window to a blank 1x1 rectangle.
            window.geometry(f"{int(width)}x{int(height)}")
            return
        safe_width = min(int(width), max(1, screen_width - 40))
        safe_height = min(int(height), max(1, screen_height - 100))
        safe_width = max(1, min(safe_width, int(min_width))) if screen_width < min_width else safe_width
        safe_height = max(1, min(safe_height, int(min_height))) if screen_height < min_height else safe_height
        x = max(0, (screen_width - safe_width) // 2)
        y = max(0, (screen_height - safe_height) // 2)
        window.geometry(f"{safe_width}x{safe_height}+{x}+{y}")
    except (tk.TclError, ValueError, TypeError):
        pass


def _show_child_window(
    window,
    width,
    height,
    min_width=None,
    min_height=None,
    modal=False,
):
    """Apply the same safe placement/focus policy to every Toplevel."""
    effective_min_width = int(min_width or width)
    effective_min_height = int(min_height or height)
    try:
        # Never let a requested minimum size force a child window outside a
        # small laptop display or a high-DPI scaled desktop.
        screen_width = int(window.winfo_screenwidth())
        screen_height = int(window.winfo_screenheight())
        effective_min_width = min(
            effective_min_width,
            max(1, screen_width - 40),
        )
        effective_min_height = min(
            effective_min_height,
            max(1, screen_height - 100),
        )
        window.minsize(effective_min_width, effective_min_height)
    except (tk.TclError, ValueError, TypeError):
        pass

    _center_window(
        window,
        width,
        height,
        min_width=effective_min_width,
        min_height=effective_min_height,
    )
    _bring_window_to_front(window)

    def refresh_after_map():
        try:
            if window.winfo_exists():
                window.deiconify()
                window.state("normal")
                window.update_idletasks()
                window.lift()
        except tk.TclError:
            pass

    try:
        window.after_idle(refresh_after_map)
    except tk.TclError:
        pass

    if modal:
        try:
            window.grab_set()
        except tk.TclError:
            pass


def _select_ttk_theme(style):
    """Select a theme that honors custom foreground/background colors."""
    try:
        available = tuple(style.theme_names())
    except tk.TclError:
        available = ()

    for theme_name in ("clam", "alt", "default", "classic"):
        if theme_name not in available:
            continue
        try:
            style.theme_use(theme_name)
            return theme_name
        except tk.TclError:
            continue
    return ""


def acquire_single_instance():
    """Prevent two Windows copies from writing the same database/configs."""
    global INSTANCE_MUTEX_HANDLE

    if not sys.platform.startswith("win"):
        return True

    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.argtypes = [
        ctypes.c_void_p,
        ctypes.c_bool,
        ctypes.c_wchar_p,
    ]
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel32.CloseHandle.restype = ctypes.c_bool

    handle = kernel32.CreateMutexW(
        None,
        False,
        "Local\\MichmanKP_NetworkMonitor_SingleInstance",
    )

    if not handle:
        LOGGER.error("CreateMutexW failed: %s", kernel32.GetLastError())
        return False

    if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        kernel32.CloseHandle(handle)
        return False

    INSTANCE_MUTEX_HANDLE = handle
    return True


def release_single_instance():
    global INSTANCE_MUTEX_HANDLE

    if INSTANCE_MUTEX_HANDLE and sys.platform.startswith("win"):
        try:
            ctypes.windll.kernel32.CloseHandle(INSTANCE_MUTEX_HANDLE)
        finally:
            INSTANCE_MUTEX_HANDLE = None


def enable_windows_dpi_awareness():
    if not sys.platform.startswith("win"):
        return

    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

COMMON_PORTS = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    135: "RPC",
    139: "NetBIOS",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    3389: "RDP",
    5900: "VNC",
    8080: "HTTP-Alt",
}


def current_time():
    return datetime.now()


def _normalise_device_records(data):
    """Return validated device records while preserving their order."""
    if isinstance(data, dict):
        nested = data.get("devices")
        if isinstance(nested, list):
            data = nested
        else:
            # Accept the old/simple {"ip": "name"} shape as well.
            data = [
                {"ip": ip, "name": name}
                for ip, name in data.items()
            ]

    if not isinstance(data, list):
        return []

    records = []
    seen = set()
    for item in data:
        if isinstance(item, str):
            item = {"ip": item}
        if not isinstance(item, dict):
            continue

        ip = str(item.get("ip", "") or "").strip()
        if not valid_ipv4(ip) or ip in seen:
            continue

        name = str(item.get("name", "") or "").strip()
        group = str(item.get("group", "Загальні") or "Загальні").strip()
        priority = str(item.get("priority", "Звичайний") or "Звичайний").strip()
        device_kind = str(item.get("device_kind", "Невідомий") or "Невідомий").strip()
        device_kind_confidence = str(item.get("device_kind_confidence", "LOW") or "LOW").strip().upper()
        device_kind_reason = str(item.get("device_kind_reason", "") or "").strip()
        device_identity = str(item.get("device_identity", "") or "").strip()
        device_identity_source = str(item.get("device_identity_source", "") or "").strip()
        device_identified_at = str(item.get("device_identified_at", "") or "").strip()
        tracking_mac = str(item.get("tracking_mac", "") or "").strip().upper().replace("-", ":")
        address_mode = "mac" if item.get("address_mode") == "mac" and valid_mac(tracking_mac) else "ip"
        try:
            device_identification_last_attempt = float(item.get("device_identification_last_attempt", 0) or 0)
        except (TypeError, ValueError):
            device_identification_last_attempt = 0.0
        records.append(
            {
                "ip": ip,
                "name": name,
                "group": group or "Загальні",
                "priority": priority or "Звичайний",
                "device_kind": device_kind or "Невідомий",
                "device_kind_confidence": device_kind_confidence if device_kind_confidence in ("LOW", "MEDIUM", "HIGH") else "LOW",
                "device_kind_reason": device_kind_reason[:500],
                "device_identity": device_identity[:500],
                "device_identity_source": device_identity_source[:120],
                "device_identified_at": device_identified_at[:64],
                "device_identification_last_attempt": max(0.0, device_identification_last_attempt),
                "address_mode": address_mode,
                "tracking_mac": tracking_mac if address_mode == "mac" else "",
            }
        )
        seen.add(ip)

    return records


def _read_device_records(path):
    """Read the current JSON device list; malformed data becomes empty."""
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return _normalise_device_records(json.load(handle))
    except (OSError, ValueError, TypeError):
        return []


def _write_device_records(path, records):
    """Atomically save the monitored device list."""
    atomic_write_json(path, _normalise_device_records(records))


def _read_legacy_ip_records(path, names=None):
    """Parse an old IP.txt once so existing installations keep their nodes."""
    names = names if isinstance(names, dict) else {}
    records = []
    seen = set()
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            lines = handle.readlines()
    except OSError:
        return records

    for raw in lines:
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue

        ip, name = line, ""
        if "|" in line:
            ip, name = [part.strip() for part in line.split("|", 1)]
        elif " - " in line:
            ip, name = [part.strip() for part in line.split(" - ", 1)]

        if not valid_ipv4(ip) or ip in seen:
            continue
        name = name or str(names.get(ip, "") or "").strip()
        records.append({"ip": ip, "name": name})
        seen.add(ip)
    return _normalise_device_records(records)


def ensure_initial_data_files():
    """Prepare JSON state without creating or watching the legacy IP.txt."""
    os.makedirs(BASE_DIR, exist_ok=True)

    # Do not create monitored_devices.json while an old IP.txt is present:
    # load_devices() must be able to perform the one-time migration first.
    if os.path.exists(DEVICES_FILE) or os.path.exists(LEGACY_IP_FILE):
        return

    try:
        _write_device_records(DEVICES_FILE, [])
    except OSError:
        pass


def fmt_dt(dt):
    return dt.strftime("%d.%m.%Y %H:%M:%S") if dt else "—"


def fmt_ping(value):
    return f"{value:.3f} ms" if value is not None else "N/A"


def effective_status(snapshot):
    if snapshot["online"] is True:
        return "ONLINE"
    if snapshot["online"] is False:
        return "OFFLINE"
    return "UNKNOWN"


def protect_secret(value):
    """Encrypt a secret for the current Windows user with DPAPI."""
    value = str(value or "")

    if not value or value.startswith("dpapi:"):
        return value

    if not sys.platform.startswith("win"):
        return value

    class DataBlob(ctypes.Structure):
        _fields_ = [
            ("cbData", ctypes.c_ulong),
            ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
        ]

    raw = value.encode("utf-8")
    raw_buffer = ctypes.create_string_buffer(raw)
    input_blob = DataBlob(
        len(raw),
        ctypes.cast(raw_buffer, ctypes.POINTER(ctypes.c_ubyte)),
    )
    output_blob = DataBlob()

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    cryptprotect_ui_forbidden = 0x01
    crypt32.CryptProtectData.argtypes = [
        ctypes.POINTER(DataBlob),
        ctypes.c_wchar_p,
        ctypes.POINTER(DataBlob),
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.POINTER(DataBlob),
    ]
    crypt32.CryptProtectData.restype = ctypes.c_bool
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    if not crypt32.CryptProtectData(
        ctypes.byref(input_blob),
        ctypes.c_wchar_p("MICHMAN MikroTik credential"),
        None,
        None,
        None,
        cryptprotect_ui_forbidden,
        ctypes.byref(output_blob),
    ):
        raise ctypes.WinError()

    try:
        encrypted = ctypes.string_at(
            output_blob.pbData,
            output_blob.cbData,
        )
        return "dpapi:" + base64.b64encode(encrypted).decode("ascii")
    finally:
        kernel32.LocalFree(output_blob.pbData)


def unprotect_secret(value):
    """Decrypt a DPAPI value; legacy plaintext values remain supported."""
    value = str(value or "")

    if not value.startswith("dpapi:"):
        return value

    if not sys.platform.startswith("win"):
        raise RuntimeError(
            "DPAPI credential can only be decrypted by the Windows user "
            "who saved it."
        )

    class DataBlob(ctypes.Structure):
        _fields_ = [
            ("cbData", ctypes.c_ulong),
            ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
        ]

    encrypted = base64.b64decode(value[6:], validate=True)
    encrypted_buffer = ctypes.create_string_buffer(encrypted)
    input_blob = DataBlob(
        len(encrypted),
        ctypes.cast(encrypted_buffer, ctypes.POINTER(ctypes.c_ubyte)),
    )
    output_blob = DataBlob()

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    cryptprotect_ui_forbidden = 0x01
    crypt32.CryptUnprotectData.argtypes = [
        ctypes.POINTER(DataBlob),
        ctypes.c_void_p,
        ctypes.POINTER(DataBlob),
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.POINTER(DataBlob),
    ]
    crypt32.CryptUnprotectData.restype = ctypes.c_bool
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    if not crypt32.CryptUnprotectData(
        ctypes.byref(input_blob),
        None,
        None,
        None,
        None,
        cryptprotect_ui_forbidden,
        ctypes.byref(output_blob),
    ):
        raise ctypes.WinError()

    try:
        decrypted = ctypes.string_at(
            output_blob.pbData,
            output_blob.cbData,
        )
        return decrypted.decode("utf-8")
    finally:
        kernel32.LocalFree(output_blob.pbData)


def clamp_int(value, default, minimum, maximum):
    try:
        number = int(value)
    except (TypeError, ValueError, tk.TclError):
        return default
    return max(minimum, min(maximum, number))


def parse_ping_ms(output):
    if re.search(
        r"(?:time|время|час)\s*<\s*1\s*(?:ms|мс)",
        output,
        re.IGNORECASE,
    ):
        return 0.5

    m = re.search(
        r"(?:time|время|час)\s*[=<]\s*(\d+(?:[.,]\d+)?)\s*(ms|мс|s|с)",
        output,
        re.IGNORECASE,
    )
    if not m:
        return None

    value = float(m.group(1).replace(",", "."))
    unit = m.group(2).lower()

    if unit in ("s", "с"):
        return value * 1000

    return value


def ping_windows(ip, timeout):
    wait_timeout = max(timeout, MIN_HIGH_PING_TIMEOUT)

    command = [
        "ping",
        "-n",
        "1",
        "-w",
        str(int(wait_timeout * 1000)),
        ip,
    ]

    flags = getattr(
        subprocess,
        "CREATE_NO_WINDOW",
        0x08000000,
    )

    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="cp866",
            errors="ignore",
            timeout=wait_timeout + 1,
            creationflags=flags,
        )

        output = result.stdout + "\n" + result.stderr
        ping = parse_ping_ms(output)

        if ping is not None:
            return True, ping, output.strip()

        return False, None, output.strip()

    except subprocess.TimeoutExpired:
        return False, None, "TIMEOUT"

    except Exception as e:
        return False, None, str(e)


def ping_host(ip, timeout=PING_TIMEOUT):
    if sys.platform.startswith("win"):
        return ping_windows(ip, timeout)

    try:
        wait_timeout = max(timeout, MIN_HIGH_PING_TIMEOUT)

        result = subprocess.run(
            [
                "ping",
                "-c",
                "1",
                "-W",
                str(max(1, int(wait_timeout))),
                ip,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="ignore",
            timeout=wait_timeout + 1,
        )

        output = result.stdout + "\n" + result.stderr
        ping = parse_ping_ms(output)

        if ping is not None:
            return True, ping, output.strip()

        return False, None, output.strip()

    except Exception as e:
        return False, None, str(e)


def valid_ipv4(ip):
    try:
        return str(ipaddress.IPv4Address(ip.strip())) == ip.strip()
    except (ipaddress.AddressValueError, ValueError):
        return False


def reverse_dns(ip):
    try:
        return socket.gethostbyaddr(ip)[0]
    except Exception:
        return "—"


def valid_mac(value):
    value = str(value or "").strip().upper().replace("-", ":")
    return bool(
        re.fullmatch(
            r"[0-9A-F]{2}(?::[0-9A-F]{2}){5}",
            value,
        )
    )


def parse_ports(value):
    result = []

    for part in str(value or "").split(","):
        part = part.strip()

        if not part:
            continue

        try:
            port = int(part)
        except ValueError:
            continue

        if 1 <= port <= 65535 and port not in result:
            result.append(port)

    return result


def tcp_probe(ip, port, timeout=TCP_TIMEOUT):
    try:
        with socket.create_connection(
            (ip, int(port)),
            timeout=timeout,
        ):
            return True

    except (
        OSError,
        ValueError,
        TimeoutError,
    ):
        return False


def get_arp_mac(ip):
    try:
        if sys.platform.startswith("win"):
            command = ["arp", "-a", ip]
            encoding = "cp866"
            flags = getattr(
                subprocess,
                "CREATE_NO_WINDOW",
                0x08000000,
            )
        else:
            command = ["arp", "-n", ip]
            encoding = "utf-8"
            flags = 0

        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding=encoding,
            errors="ignore",
            creationflags=flags,
            timeout=2,
        )

        output = result.stdout + "\n" + result.stderr

        match = re.search(
            r"([0-9A-Fa-f]{2}(?:[-:][0-9A-Fa-f]{2}){5})",
            output,
        )

        return (
            match.group(1).upper().replace("-", ":")
            if match
            else ""
        )

    except Exception:
        return ""


def get_arp_table():
    """Return the operating system's existing neighbor cache without scanning."""
    try:
        command = ["arp", "-a"] if sys.platform.startswith("win") else ["arp", "-n"]
        result = subprocess.run(
            command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            encoding="cp866" if sys.platform.startswith("win") else "utf-8",
            errors="ignore", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform.startswith("win") else 0,
            timeout=3,
        )
        table = {}
        pattern = re.compile(r"(?P<ip>\d{1,3}(?:\.\d{1,3}){3}).*?(?P<mac>[0-9A-Fa-f]{2}(?:[-:][0-9A-Fa-f]{2}){5})")
        for match in pattern.finditer(result.stdout):
            ip = match.group("ip")
            if valid_ipv4(ip):
                table[match.group("mac").upper().replace("-", ":")] = ip
        return table
    except Exception:
        return {}


def get_mac_vendor(mac):
    if not valid_mac(mac):
        return "—"

    clean_mac = (
        mac.replace(":", "")
        .replace("-", "")
        .upper()[:6]
    )

    known_ouis = {
        "000C29": "VMware",
        "005056": "VMware",
        "00155D": "Microsoft Hyper-V",
        "B827EB": "Raspberry Pi",
        "DCA632": "Raspberry Pi",
        "E45F01": "Raspberry Pi",
        "44D9E7": "Ubiquiti",
        "7483C2": "Ubiquiti",
        "F492BF": "Ubiquiti",
        "18E829": "Ubiquiti",
        "000C42": "MikroTik",
        "2C16DB": "MikroTik",
        "488F5A": "MikroTik",
        "64D154": "MikroTik",
        "B869F4": "MikroTik",
        "D4CA6D": "MikroTik",
        "E828C1": "MikroTik",
        "001132": "Synology",
        "00089B": "QNAP",
        "001A2B": "KEDACOM",
        "001212": "Hikvision",
        "105172": "Hikvision",
        "BC53B5": "Hikvision",
        "0002D1": "Dahua",
        "38AF29": "Dahua",
        "A0BDCD": "Dahua",
        "70B3D5": "Dahua",
        "001801": "D-Link",
        "1062EB": "D-Link",
        "001D7E": "Cisco",
        "00270D": "Cisco",
        "500604": "Cisco",
        "00059A": "Cisco",
        "F09FC2": "TP-Link",
        "50C7BF": "TP-Link",
        "98DAC4": "TP-Link",
        "E848B8": "TP-Link",
        "001E58": "WNC / Apple",
        "002500": "Apple",
        "F4D488": "Apple",
        "ACBC32": "Apple",
        "186590": "Apple",
        "F8E079": "Apple",
        "002170": "Dell",
        "1866DA": "Dell",
        "D4BED9": "Dell",
        "001E0B": "HP",
        "3C4A92": "HP",
        "A0B3CC": "HP",
        "001500": "Intel",
        "3C6AA7": "Intel",
        "8C8590": "Intel",
        "00166C": "Samsung",
        "508569": "Samsung",
        "8C71F8": "Samsung",
        "001A80": "ASUSTeK",
        "04D4C4": "ASUSTeK",
        "107B44": "ASUSTeK",
    }

    return known_ouis.get(clean_mac, "Unknown Vendor")


class Database:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self.closed = False
        self.last_saved_checks = {}
        self.pending_writes = 0
        self.last_commit = time.monotonic()
        self.last_maintenance = 0.0

        self.conn = sqlite3.connect(
            path,
            timeout=DB_BUSY_TIMEOUT_MS / 1000,
            check_same_thread=False,
        )

        self.conn.execute(
            f"PRAGMA busy_timeout={DB_BUSY_TIMEOUT_MS}"
        )
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT NOT NULL,
                timestamp REAL NOT NULL,
                online INTEGER NOT NULL,
                ping REAL
            )
        """)

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                ip TEXT,
                event TEXT NOT NULL,
                details TEXT
            )
        """)

        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS "
            "idx_checks_ip_timestamp "
            "ON checks(ip,timestamp)"
        )

        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS "
            "idx_events_ip_timestamp "
            "ON events(ip,timestamp)"
        )

        self.conn.commit()
        self._run_maintenance_locked(force=True)

    def _commit_if_needed_locked(self, force=False):
        if (
            force
            or self.pending_writes >= 100
            or time.monotonic() - self.last_commit >= 1.0
        ):
            self.conn.commit()
            self.pending_writes = 0
            self.last_commit = time.monotonic()

    def _run_maintenance_locked(self, force=False):
        now = time.time()

        if (
            not force
            and now - self.last_maintenance
            < DB_MAINTENANCE_INTERVAL_SECONDS
        ):
            return

        checks_cutoff = now - DB_CHECK_RETENTION_DAYS * 86400
        events_cutoff = now - DB_EVENT_RETENTION_DAYS * 86400
        self.conn.execute(
            "DELETE FROM checks WHERE timestamp < ?",
            (checks_cutoff,),
        )
        self.conn.execute(
            "DELETE FROM events WHERE timestamp < ?",
            (events_cutoff,),
        )
        self.conn.commit()
        self.pending_writes = 0
        self.last_commit = time.monotonic()
        self.last_maintenance = now

    def add_check(self, ip, online, ping):
        with self.lock:
            if self.closed:
                return

            now = time.time()
            previous = self.last_saved_checks.get(ip)

            if previous is not None:
                previous_time, previous_online = previous

                if (
                    previous_online == bool(online)
                    and now - previous_time < DB_CHECK_SAMPLE_SECONDS
                ):
                    return

            self.conn.execute(
                "INSERT INTO checks("
                "ip,timestamp,online,ping"
                ") VALUES(?,?,?,?)",
                (
                    ip,
                    now,
                    1 if online else 0,
                    ping,
                ),
            )
            self.last_saved_checks[ip] = (now, bool(online))
            self.pending_writes += 1
            self._commit_if_needed_locked()
            self._run_maintenance_locked()

    def add_event(self, ip, event, details=""):
        with self.lock:
            if self.closed:
                return

            self.conn.execute(
                "INSERT INTO events("
                "timestamp,ip,event,details"
                ") VALUES(?,?,?,?)",
                (
                    time.time(),
                    ip,
                    event,
                    details,
                ),
            )
            self.pending_writes += 1
            self._commit_if_needed_locked()
            self._run_maintenance_locked()

    def recent_checks(self, ip, seconds=3600):
        since = time.time() - seconds

        with self.lock:
            if self.closed:
                return []

            return self.conn.execute(
                "SELECT timestamp,online,ping "
                "FROM checks "
                "WHERE ip=? AND timestamp>=? "
                "ORDER BY timestamp ASC",
                (
                    ip,
                    since,
                ),
            ).fetchall()

    def all_events(self, ip=None, limit=1000):
        with self.lock:
            if self.closed:
                return []

            if ip:
                return self.conn.execute(
                    "SELECT timestamp,ip,event,details "
                    "FROM events "
                    "WHERE ip=? "
                    "ORDER BY timestamp DESC LIMIT ?",
                    (
                        ip,
                        limit,
                    ),
                ).fetchall()

            return self.conn.execute(
                "SELECT timestamp,ip,event,details "
                "FROM events "
                "ORDER BY timestamp DESC LIMIT ?",
                (limit,),
            ).fetchall()

    def close(self):
        with self.lock:
            if self.closed:
                return

            self.closed = True
            self._commit_if_needed_locked(force=True)
            self.conn.close()


class SingleMikroTikClient:
    def __init__(
        self,
        name,
        host,
        user,
        password,
        method="REST",
        port=None,
        verify_peer=True,
        platform="mikrotik",
        legacy_ssh=False,
    ):
        safe_name = str(name or "").strip()
        self.host = str(host or "").strip()
        self.name = safe_name or self.host
        self.user = str(user or "").strip()
        self.platform = str(platform or "mikrotik").strip().lower()
        # RouterOS uses the built-in admin account when its login field is
        # omitted by password-only device interfaces.
        self.auth_user = self.user or ("admin" if self.platform == "mikrotik" else "")
        self.password = password if password else ""
        self.method = str(method or "REST").upper()

        if self.method not in ("REST", "SSH"):
            self.method = "REST"

        try:
            parsed_port = int(port) if port is not None else None
        except (TypeError, ValueError):
            parsed_port = None

        self.port = (
            parsed_port
            if parsed_port is not None and 1 <= parsed_port <= 65535
            else None
        )
        self.verify_peer = bool(verify_peer)
        self.legacy_ssh = bool(legacy_ssh)
        self.last_error = ""

    def is_configured(self):
        return bool(self.host and (self.user or self.password))

    # ------------------------------------------------------------------
    # RouterOS security management helpers.
    #
    # These methods intentionally expose only a bounded set of defensive
    # operations.  There is no arbitrary command console in the customer UI.
    # ------------------------------------------------------------------

    def _rest_connection_data(self):
        port = self.port or 443
        protocol = (
            "https"
            if self.verify_peer or port in (443, 8443)
            else "http"
        )
        base_url = f"{protocol}://{self.host}:{port}/rest"

        context = ssl.create_default_context()
        if not self.verify_peer:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE

        auth_str = base64.b64encode(
            f"{self.auth_user}:{self.password}".encode("utf-8")
        ).decode("ascii")
        headers = {
            "Authorization": f"Basic {auth_str}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        return base_url, headers, context

    def _rest_request(
        self,
        endpoint,
        method="GET",
        payload=None,
        timeout=10,
    ):
        base_url, headers, context = self._rest_connection_data()
        endpoint = "/" + str(endpoint or "").lstrip("/")
        body = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")

        request = urllib.request.Request(
            base_url + endpoint,
            data=body,
            headers=headers,
            method=str(method).upper(),
        )

        try:
            with urllib.request.urlopen(
                request,
                timeout=timeout,
                context=context,
            ) as response:
                raw = response.read()
                if not raw:
                    return {}
                text = raw.decode("utf-8", errors="replace")
                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    return {"output": text}
        except urllib.error.HTTPError as error:
            try:
                details = error.read().decode("utf-8", errors="replace")
            except Exception:
                details = ""
            details = details.strip()
            raise RuntimeError(
                f"RouterOS REST {error.code}: {details or error.reason}"
            ) from error
        except urllib.error.URLError as error:
            raise RuntimeError(f"RouterOS REST: {error.reason}") from error

    def _ssh_execute(self, command, timeout=12):
        port = self.port or 22

        if self.password:
            try:
                import paramiko
            except ImportError as error:
                raise RuntimeError(
                    "Для SSH з паролем потрібен пакет paramiko."
                ) from error

            client = paramiko.SSHClient()
            client.load_system_host_keys()
            if self.verify_peer:
                client.set_missing_host_key_policy(paramiko.RejectPolicy())
            else:
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            try:
                client.connect(
                    hostname=self.host,
                    port=port,
                    username=self.auth_user,
                    password=self.password,
                    timeout=6,
                    auth_timeout=6,
                    banner_timeout=6,
                    look_for_keys=False,
                    allow_agent=False,
                    disabled_algorithms=(
                        None if self.legacy_ssh else {
                            "kex": [
                                "diffie-hellman-group-exchange-sha1",
                                "diffie-hellman-group14-sha1",
                                "diffie-hellman-group1-sha1",
                            ],
                            "keys": ["ssh-rsa", "ssh-dss"],
                        }
                    ),
                )
                _, stdout, stderr = client.exec_command(
                    command,
                    timeout=timeout,
                )
                output = stdout.read().decode("utf-8", errors="replace")
                error_text = stderr.read().decode(
                    "utf-8",
                    errors="replace",
                ).strip()
                if error_text and not output.strip():
                    raise RuntimeError(error_text)
                return output
            finally:
                client.close()

        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        result = subprocess.run(
            [
                "ssh",
                "-o",
                (
                    "StrictHostKeyChecking=yes"
                    if self.verify_peer
                    else "StrictHostKeyChecking=no"
                ),
                "-o",
                "ConnectTimeout=6",
                "-o",
                "BatchMode=yes",
                "-p",
                str(port),
                f"{self.auth_user}@{self.host}",
                command,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=flags,
        )
        if result.returncode != 0:
            raise RuntimeError(
                (result.stderr or "SSH connection failed").strip()
            )
        return result.stdout

    @staticmethod
    def _parse_terse_records(output):
        records = []
        for raw_line in str(output or "").splitlines():
            line = raw_line.strip()
            if not line or "=" not in line:
                continue
            try:
                tokens = shlex.split(line, posix=True)
            except ValueError:
                tokens = line.split()

            record = {}
            flags = []
            for token in tokens:
                if "=" in token:
                    key, value = token.split("=", 1)
                    record[key.lstrip(";")] = value.rstrip(";")
                elif token.isdigit() and ".number" not in record:
                    record[".number"] = token
                elif token.startswith("*") and ".id" not in record:
                    record[".id"] = token
                elif len(token) <= 5:
                    flags.append(token)
            if flags:
                record[".flags"] = "".join(flags)
            if record:
                records.append(record)
        return records

    @staticmethod
    def _first_record(value):
        if isinstance(value, list):
            return value[0] if value and isinstance(value[0], dict) else {}
        return value if isinstance(value, dict) else {}

    def get_security_snapshot(self):
        """Read defensive configuration without making any changes."""
        result = {
            "router": self.name,
            "host": self.host,
            "method": self.method,
            "collected_at": datetime.now(timezone.utc).isoformat(
                timespec="seconds"
            ),
            "identity": {},
            "resource": {},
            "services": [],
            "firewall_rules": [],
            "users": [],
            "errors": [],
        }

        if self.method == "REST":
            endpoints = (
                ("identity", "/system/identity"),
                ("resource", "/system/resource"),
                ("services", "/ip/service"),
                ("firewall_rules", "/ip/firewall/filter"),
                ("users", "/user"),
            )
            for key, endpoint in endpoints:
                try:
                    value = self._rest_request(endpoint)
                    if key in ("identity", "resource"):
                        result[key] = self._first_record(value)
                    else:
                        result[key] = value if isinstance(value, list) else []
                except Exception as error:
                    result["errors"].append(f"{key}: {error}")
        else:
            commands = (
                ("identity", "/system identity print terse without-paging"),
                ("resource", "/system resource print terse without-paging"),
                ("services", "/ip service print terse without-paging"),
                (
                    "firewall_rules",
                    "/ip firewall filter print terse without-paging",
                ),
                ("users", "/user print terse without-paging"),
            )
            for key, command in commands:
                try:
                    records = self._parse_terse_records(
                        self._ssh_execute(command)
                    )
                    if key in ("identity", "resource"):
                        result[key] = records[0] if records else {}
                    else:
                        result[key] = records
                except Exception as error:
                    result["errors"].append(f"{key}: {error}")

        if len(result["errors"]) == 5:
            self.last_error = "; ".join(result["errors"])
            raise RuntimeError(self.last_error)

        self.last_error = "; ".join(result["errors"])
        result["assessment"] = self.assess_security(result)
        return result

    @staticmethod
    def _is_disabled(record):
        value = str(record.get("disabled", "false")).strip().lower()
        if value in ("true", "yes", "1"):
            return True
        return "X" in str(record.get(".flags", "")).upper()

    @classmethod
    def assess_security(cls, snapshot):
        findings = []

        def add(severity, title, details):
            findings.append(
                {
                    "severity": severity,
                    "title": title,
                    "details": details,
                }
            )

        services = snapshot.get("services", [])
        risky = {
            "telnet": ("critical", "Telnet передає дані без шифрування."),
            "ftp": ("high", "FTP краще вимкнути, якщо він не потрібний."),
            "www": ("critical", "WebFig HTTP не шифрує облікові дані."),
            "api": ("high", "Незашифрований API краще вимкнути."),
        }
        administrative = {"ssh", "winbox", "www-ssl", "api-ssl"}

        for service in services:
            name = str(service.get("name", "")).lower()
            if cls._is_disabled(service):
                continue
            if name in risky:
                severity, details = risky[name]
                add(severity, f"Увімкнено службу {name}", details)
            address = str(service.get("address", "")).strip()
            if name in administrative and not address:
                add(
                    "medium",
                    f"Служба {name} доступна без списку дозволених адрес",
                    "Обмежте доступ своєю адміністративною підмережею.",
                )
            if (
                name == "www-ssl"
                and str(service.get("certificate", "none")).lower()
                in ("", "none")
            ):
                add(
                    "medium",
                    "www-ssl не має призначеного сертифіката",
                    "Налаштуйте сертифікат або використовуйте SSH/Winbox.",
                )

        active_users = [
            item for item in snapshot.get("users", []) if not cls._is_disabled(item)
        ]
        for user in active_users:
            if str(user.get("name", "")).lower() == "admin":
                add(
                    "high",
                    "Активний стандартний користувач admin",
                    "Створіть персонального адміністратора та вимкніть admin.",
                )

        full_users = [
            item
            for item in active_users
            if str(item.get("group", "")).lower() == "full"
        ]
        if len(full_users) > 1:
            add(
                "medium",
                "Декілька користувачів мають групу full",
                "Залишайте повні права лише тим, кому вони необхідні.",
            )

        active_input_rules = [
            item
            for item in snapshot.get("firewall_rules", [])
            if not cls._is_disabled(item)
            and str(item.get("chain", "")).lower() == "input"
        ]
        if not active_input_rules:
            add(
                "critical",
                "Немає активних правил firewall у chain=input",
                "Доступ до самого роутера може бути недостатньо захищений.",
            )
        elif not any(
            str(item.get("action", "")).lower() in ("drop", "reject")
            for item in active_input_rules
        ):
            add(
                "high",
                "У chain=input не знайдено правила drop/reject",
                "Перевірте завершальну політику блокування небажаного трафіку.",
            )

        deductions = {
            "critical": 24,
            "high": 14,
            "medium": 7,
            "low": 3,
        }
        score = max(
            0,
            100 - sum(deductions.get(item["severity"], 0) for item in findings),
        )
        return {"score": score, "findings": findings}

    @staticmethod
    def _normalise_address_list(value):
        value = str(value or "").strip()
        if not value:
            return ""
        networks = []
        for part in value.split(","):
            part = part.strip()
            if not part:
                continue
            try:
                parsed = ipaddress.ip_network(part, strict=False)
            except ValueError as error:
                raise ValueError(f"Некоректна адреса або підмережа: {part}") from error
            networks.append(str(parsed))
        if not networks:
            return ""
        return ",".join(networks)

    @staticmethod
    def _routeros_quote(value):
        value = str(value).replace("\\", "\\\\").replace('"', '\\"')
        value = value.replace("\r", " ").replace("\n", " ")
        return f'"{value}"'

    def set_service_disabled(self, service_name, disabled):
        allowed = {
            "telnet", "ftp", "www", "ssh", "www-ssl",
            "api", "winbox", "api-ssl",
        }
        name = str(service_name or "").strip().lower()
        if name not in allowed:
            raise ValueError("Невідома або некерована служба RouterOS.")

        value = "true" if disabled else "false"
        if self.method == "REST":
            services = self._rest_request("/ip/service")
            service = next(
                (
                    item
                    for item in services
                    if str(item.get("name", "")).lower() == name
                ),
                None,
            )
            if not service:
                raise RuntimeError(f"Службу {name} не знайдено.")
            target = str(service.get(".id") or name)
            target = urllib.parse.quote(target, safe="*")
            return self._rest_request(
                f"/ip/service/{target}",
                method="PATCH",
                payload={"disabled": value},
            )

        command = (
            f'/ip service set [find where name="{name}"] '
            f'disabled={"yes" if disabled else "no"}'
        )
        return {"output": self._ssh_execute(command)}

    def set_service_addresses(self, service_name, addresses):
        allowed = {"ssh", "winbox", "www-ssl", "api-ssl", "www", "api"}
        name = str(service_name or "").strip().lower()
        if name not in allowed:
            raise ValueError("Для цієї служби обмеження адрес не підтримується.")
        normalised = self._normalise_address_list(addresses)

        if self.method == "REST":
            services = self._rest_request("/ip/service")
            service = next(
                (
                    item
                    for item in services
                    if str(item.get("name", "")).lower() == name
                ),
                None,
            )
            if not service:
                raise RuntimeError(f"Службу {name} не знайдено.")
            target = urllib.parse.quote(
                str(service.get(".id") or name),
                safe="*",
            )
            return self._rest_request(
                f"/ip/service/{target}",
                method="PATCH",
                payload={"address": normalised},
            )

        command = (
            f'/ip service set [find where name="{name}"] '
            f"address={self._routeros_quote(normalised)}"
        )
        return {"output": self._ssh_execute(command)}

    def set_user_disabled(self, user_name, disabled):
        name = str(user_name or "").strip()
        if not name or len(name) > 64 or any(ch in name for ch in "\r\n"):
            raise ValueError("Некоректне ім’я користувача RouterOS.")
        if name == self.auth_user and disabled:
            raise ValueError("Не можна вимкнути обліковий запис поточного з’єднання.")

        if self.method == "REST":
            users = self._rest_request("/user")
            user = next(
                (
                    item
                    for item in users
                    if str(item.get("name", "")) == name
                ),
                None,
            )
            if not user:
                raise RuntimeError(f"Користувача {name} не знайдено.")
            target = urllib.parse.quote(
                str(user.get(".id") or name),
                safe="*",
            )
            return self._rest_request(
                f"/user/{target}",
                method="PATCH",
                payload={"disabled": "true" if disabled else "false"},
            )

        safe_name = self._routeros_quote(name)
        command = (
            f"/user set [find where name={safe_name}] "
            f'disabled={"yes" if disabled else "no"}'
        )
        return {"output": self._ssh_execute(command)}

    def set_firewall_rule_disabled(self, reference, disabled):
        reference = str(reference or "").strip()
        if not re.fullmatch(r"(?:\*[0-9A-Fa-f]+|\d+)", reference):
            raise ValueError("Некоректний ідентифікатор firewall-правила.")

        if self.method == "REST":
            target = urllib.parse.quote(reference, safe="*")
            return self._rest_request(
                f"/ip/firewall/filter/{target}",
                method="PATCH",
                payload={"disabled": "true" if disabled else "false"},
            )

        command = (
            f"/ip firewall filter set {reference} "
            f'disabled={"yes" if disabled else "no"}'
        )
        return {"output": self._ssh_execute(command)}

    @staticmethod
    def _normalise_ports(value):
        value = str(value or "").strip()
        if not value:
            return ""
        result = []
        for part in value.split(","):
            part = part.strip()
            match = re.fullmatch(r"(\d+)(?:-(\d+))?", part)
            if not match:
                raise ValueError(f"Некоректний порт або діапазон: {part}")
            start = int(match.group(1))
            end = int(match.group(2) or start)
            if not (1 <= start <= end <= 65535):
                raise ValueError(f"Порт поза діапазоном: {part}")
            result.append(str(start) if start == end else f"{start}-{end}")
        return ",".join(result)

    def add_firewall_rule(
        self,
        *,
        chain,
        action,
        protocol="",
        src_address="",
        dst_address="",
        dst_port="",
        comment="MICHMAN KP security rule",
    ):
        chain = str(chain or "").strip().lower()
        action = str(action or "").strip().lower()
        protocol = str(protocol or "").strip().lower()
        if chain not in ("input", "forward", "output"):
            raise ValueError("Дозволені chain: input, forward або output.")
        if action not in ("accept", "drop", "reject"):
            raise ValueError("Дозволені action: accept, drop або reject.")
        if protocol not in ("", "tcp", "udp", "icmp"):
            raise ValueError("Дозволені protocol: tcp, udp, icmp або порожньо.")

        def ipv4_network(value, label):
            value = str(value or "").strip()
            if not value:
                return ""
            try:
                parsed = ipaddress.ip_network(value, strict=False)
            except ValueError as error:
                raise ValueError(f"Некоректне поле {label}: {value}") from error
            if parsed.version != 4:
                raise ValueError(f"Поле {label} має бути IPv4-мережею.")
            return str(parsed)

        src_address = ipv4_network(src_address, "src-address")
        dst_address = ipv4_network(dst_address, "dst-address")
        dst_port = self._normalise_ports(dst_port)
        if dst_port and protocol not in ("tcp", "udp"):
            raise ValueError("dst-port можна вказувати лише для TCP або UDP.")
        comment = re.sub(r"[\r\n]+", " ", str(comment or "")).strip()[:120]

        payload = {
            "chain": chain,
            "action": action,
            "disabled": "false",
            "comment": comment or "MICHMAN KP security rule",
        }
        if protocol:
            payload["protocol"] = protocol
        if src_address:
            payload["src-address"] = src_address
        if dst_address:
            payload["dst-address"] = dst_address
        if dst_port:
            payload["dst-port"] = dst_port

        if self.method == "REST":
            return self._rest_request(
                "/ip/firewall/filter",
                method="PUT",
                payload=payload,
            )

        parts = [
            "/ip firewall filter add",
            f"chain={chain}",
            f"action={action}",
        ]
        for key in ("protocol", "src-address", "dst-address", "dst-port"):
            if key in payload:
                parts.append(f"{key}={payload[key]}")
        parts.append(f"comment={self._routeros_quote(payload['comment'])}")
        return {"output": self._ssh_execute(" ".join(parts))}

    def create_router_export(self):
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        file_name = f"michman_before_change_{stamp}"
        if self.method == "REST":
            try:
                self._rest_request(
                    "/export",
                    method="POST",
                    payload={
                        "compact": "",
                        "show-sensitive": "no",
                        "file": file_name,
                    },
                )
            except Exception:
                self._rest_request(
                    "/export",
                    method="POST",
                    payload={
                        "compact": "",
                        "hide-sensitive": "",
                        "file": file_name,
                    },
                )
        else:
            try:
                self._ssh_execute(
                    f"/export compact show-sensitive=no file={file_name}"
                )
            except Exception:
                self._ssh_execute(
                    f"/export compact hide-sensitive file={file_name}"
                )
        return file_name + ".rsc"

    def fetch_data(self):
        if not self.is_configured():
            return {}

        if self.method == "REST":
            return self._fetch_via_rest()

        return self._fetch_via_ssh()

    def _fetch_via_rest(self):
        port = self.port or 443

        protocol = (
            "https"
            if self.verify_peer or port in (443, 8443)
            else "http"
        )

        base_url = (
            f"{protocol}://{self.host}:{port}/rest"
        )

        ctx = ssl.create_default_context()

        if not self.verify_peer:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

        auth_str = base64.b64encode(
            f"{self.auth_user}:{self.password}".encode("utf-8")
        ).decode("ascii")

        headers = {
            "Authorization": f"Basic {auth_str}"
        }

        devices_map = {}
        errors = []

        def get_json(endpoint):
            req = urllib.request.Request(
                f"{base_url}{endpoint}",
                headers=headers,
            )

            with urllib.request.urlopen(
                req,
                timeout=3,
                context=ctx,
            ) as resp:

                if resp.status == 200:
                    return json.loads(
                        resp.read().decode("utf-8")
                    )

            return []

        try:
            arp_data = get_json("/ip/arp")

            for entry in arp_data:
                ip = entry.get("address")

                if ip:
                    mac = entry.get(
                        "mac-address",
                        "",
                    ).upper()

                    interface = entry.get(
                        "interface",
                        "—",
                    )

                    devices_map[ip] = {
                        "mac": mac,
                        "interface": (
                            f"{self.name}:{interface}"
                        ),
                        "hostname": "—",
                        "lease_status": "—",
                        "vendor": (
                            get_mac_vendor(mac)
                            if mac
                            else "—"
                        ),
                    }

        except Exception as e:
            errors.append(f"ARP: {e}")

        try:
            dhcp_data = get_json(
                "/ip/dhcp-server/lease"
            )

            for entry in dhcp_data:
                ip = entry.get("address")

                if ip:
                    mac = entry.get(
                        "mac-address",
                        "",
                    ).upper()

                    hostname = entry.get(
                        "host-name",
                        "—",
                    )

                    status = entry.get(
                        "status",
                        "—",
                    )

                    if ip not in devices_map:
                        devices_map[ip] = {
                            "mac": mac,
                            "interface": "—",
                            "hostname": hostname,
                            "lease_status": status,
                            "vendor": (
                                get_mac_vendor(mac)
                                if mac
                                else "—"
                            ),
                        }

                    else:
                        if mac:
                            devices_map[ip]["mac"] = mac
                            devices_map[ip]["vendor"] = (
                                get_mac_vendor(mac)
                            )

                        devices_map[ip]["hostname"] = hostname
                        devices_map[ip]["lease_status"] = status

        except Exception as e:
            errors.append(f"DHCP: {e}")

        self.last_error = "; ".join(errors)

        return devices_map

    def _fetch_via_ssh(self):
        port = self.port or 22
        devices_map = {}

        cmd = [
            "ssh",
            "-o",
            (
                "StrictHostKeyChecking=yes"
                if self.verify_peer
                else "StrictHostKeyChecking=no"
            ),
            "-o",
            "ConnectTimeout=3",
            "-o",
            "BatchMode=yes",
            "-p",
            str(port),
            f"{self.auth_user}@{self.host}",
            "/ip arp print terse; "
            "/ip dhcp-server lease print terse",
        ]

        flags = getattr(
            subprocess,
            "CREATE_NO_WINDOW",
            0x08000000,
        )

        try:
            if self.password:
                try:
                    import paramiko
                except ImportError as e:
                    raise RuntimeError(
                        "Для SSH з паролем потрібен пакет paramiko. "
                        "Встановіть: pip install paramiko"
                    ) from e

                client = paramiko.SSHClient()
                client.load_system_host_keys()

                if self.verify_peer:
                    client.set_missing_host_key_policy(
                        paramiko.RejectPolicy()
                    )
                else:
                    client.set_missing_host_key_policy(
                        paramiko.AutoAddPolicy()
                    )

                try:
                    client.connect(
                        hostname=self.host,
                        port=port,
                        username=self.auth_user,
                        password=self.password,
                        timeout=5,
                        auth_timeout=5,
                        banner_timeout=5,
                        look_for_keys=False,
                        allow_agent=False,
                    )
                    _, stdout, stderr = client.exec_command(
                        "/ip arp print terse; "
                        "/ip dhcp-server lease print terse",
                        timeout=5,
                    )
                    output = stdout.read().decode(
                        "utf-8",
                        errors="ignore",
                    )
                    error_text = stderr.read().decode(
                        "utf-8",
                        errors="ignore",
                    ).strip()

                    if error_text and not output:
                        raise RuntimeError(error_text)
                finally:
                    client.close()
            else:
                res = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding="utf-8",
                    errors="ignore",
                    timeout=7,
                    creationflags=flags,
                )

                if res.returncode != 0:
                    raise RuntimeError(
                        (res.stderr or "SSH connection failed").strip()
                    )

                output = res.stdout

            self.last_error = ""

            for line in output.splitlines():
                line = line.strip()

                if "address=" not in line:
                    continue

                ip_m = re.search(
                    r"address=([\d\.]+)",
                    line,
                )

                mac_m = re.search(
                    r"mac-address="
                    r"([0-9A-Fa-f]{2}:"
                    r"[0-9A-Fa-f]{2}:"
                    r"[0-9A-Fa-f]{2}:"
                    r"[0-9A-Fa-f]{2}:"
                    r"[0-9A-Fa-f]{2}:"
                    r"[0-9A-Fa-f]{2})",
                    line,
                )

                iface_m = re.search(
                    r"interface=([^\s]+)",
                    line,
                )

                host_m = re.search(
                    r'host-name=\"?([^\s\"]+)\"?',
                    line,
                )

                status_m = re.search(
                    r"status=([^\s]+)",
                    line,
                )

                if ip_m:
                    ip = ip_m.group(1)

                    mac = (
                        mac_m.group(1).upper()
                        if mac_m
                        else ""
                    )

                    iface = (
                        f"{self.name}:{iface_m.group(1)}"
                        if iface_m
                        else "—"
                    )

                    host = (
                        host_m.group(1)
                        if host_m
                        else "—"
                    )

                    st = (
                        status_m.group(1)
                        if status_m
                        else "—"
                    )

                    if ip not in devices_map:
                        devices_map[ip] = {
                            "mac": mac,
                            "interface": iface,
                            "hostname": host,
                            "lease_status": st,
                            "vendor": (
                                get_mac_vendor(mac)
                                if mac
                                else "—"
                            ),
                        }

                    else:
                        if mac:
                            devices_map[ip]["mac"] = mac
                            devices_map[ip]["vendor"] = (
                                get_mac_vendor(mac)
                            )

                        if iface != "—":
                            devices_map[ip]["interface"] = iface

                        if host != "—":
                            devices_map[ip]["hostname"] = host

                        if st != "—":
                            devices_map[ip]["lease_status"] = st

        except Exception as e:
            self.last_error = str(e)

        return devices_map


class MultiMikroTikManager:
    def __init__(self, configs_list):
        self.clients = [
            SingleMikroTikClient(
                cfg.get(
                    "name",
                    f"Router-{idx+1}",
                ),
                cfg.get("host"),
                cfg.get("user"),
                cfg.get("password"),
                cfg.get("method", "REST"),
                cfg.get("port"),
                cfg.get("verify_peer", True),
                cfg.get("platform", "mikrotik"),
                cfg.get("legacy_ssh", False),
            )
            for idx, cfg in enumerate(configs_list)
            if str(cfg.get("platform", "mikrotik")).lower() == "mikrotik"
        ]

        self.sync_lock = threading.RLock()
        self.last_added_ips = {}

    def get_last_errors(self):
        return {
            client.name: client.last_error
            for client in self.clients
            if client.last_error
        }

    def is_configured(self):
        return any(
            c.is_configured()
            for c in self.clients
        )

    def sync_with_devices_file(
        self,
        mikrotik_data,
        devices_file=DEVICES_FILE,
        names_file=NAMES_FILE,
    ):
        """Add newly discovered MikroTik leases to the app-owned JSON list."""
        if not isinstance(mikrotik_data, dict) or not mikrotik_data:
            with self.sync_lock:
                self.last_added_ips = {}
            return {}

        with self.sync_lock:
            if os.path.exists(devices_file):
                records = _read_device_records(devices_file)
            elif devices_file == DEVICES_FILE and os.path.exists(LEGACY_IP_FILE):
                records = _read_legacy_ip_records(LEGACY_IP_FILE)
            else:
                records = []
            existing_ips = {record["ip"] for record in records}
            names = {}
            try:
                with open(names_file, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                if isinstance(data, dict):
                    names = {
                        str(ip).strip(): str(name or "").strip()
                        for ip, name in data.items()
                        if valid_ipv4(str(ip).strip())
                    }
            except (OSError, ValueError, TypeError):
                names = {}

            added_ips = {}
            for raw_ip, info in mikrotik_data.items():
                ip = str(raw_ip).strip()
                if not valid_ipv4(ip) or ip in existing_ips:
                    continue
                info = info if isinstance(info, dict) else {}
                hostname = str(info.get("hostname", "") or "").strip()
                if hostname == "—":
                    hostname = ""
                added_ips[ip] = hostname

            if not added_ips:
                self.last_added_ips = {}
                return {}

            for ip, hostname in added_ips.items():
                records.append({"ip": ip, "name": hostname})
                existing_ips.add(ip)
                if ip not in names:
                    names[ip] = hostname

            try:
                _write_device_records(devices_file, records)
            except OSError:
                self.last_added_ips = {}
                return {}

            try:
                temporary = names_file + ".tmp"
                with open(temporary, "w", encoding="utf-8") as handle:
                    json.dump(names, handle, ensure_ascii=False, indent=2)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, names_file)
            except OSError:
                pass

            self.last_added_ips = dict(added_ips)
            return dict(added_ips)

    def get_last_added_ips(self):
        with self.sync_lock:
            result = dict(
                self.last_added_ips
            )

            self.last_added_ips = {}

            return result

    def fetch_data(self):
        aggregated = {}

        configured_clients = [
            c
            for c in self.clients
            if c.is_configured()
        ]

        if not configured_clients:
            self.last_added_ips = {}
            return aggregated

        # -------------------------------------------------------------
        # Опитування всіх MikroTik паралельно
        # -------------------------------------------------------------
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(
                16,
                len(configured_clients),
            )
        ) as executor:

            future_to_client = {
                executor.submit(
                    c.fetch_data
                ): c
                for c in configured_clients
            }

            for future in concurrent.futures.as_completed(
                future_to_client
            ):
                try:
                    data = future.result()

                    for ip, info in data.items():

                        if ip not in aggregated:
                            aggregated[ip] = {
                                "mac": info["mac"],
                                "vendor": info["vendor"],
                                "hostname": info["hostname"],
                                "interfaces": (
                                    [info["interface"]]
                                    if info["interface"] != "—"
                                    else []
                                ),
                                "lease_status": (
                                    info["lease_status"]
                                ),
                            }

                        else:

                            if (
                                not aggregated[ip]["mac"]
                                and info["mac"]
                            ):
                                aggregated[ip]["mac"] = (
                                    info["mac"]
                                )

                                aggregated[ip]["vendor"] = (
                                    info["vendor"]
                                )

                            if (
                                aggregated[ip]["hostname"]
                                == "—"
                                and info["hostname"] != "—"
                            ):
                                aggregated[ip]["hostname"] = (
                                    info["hostname"]
                                )

                            if (
                                aggregated[ip][
                                    "lease_status"
                                ] == "—"
                                and info[
                                    "lease_status"
                                ] != "—"
                            ):
                                aggregated[ip][
                                    "lease_status"
                                ] = info[
                                    "lease_status"
                                ]

                            if (
                                info["interface"] != "—"
                                and info["interface"]
                                not in aggregated[ip][
                                    "interfaces"
                                ]
                            ):
                                aggregated[ip][
                                    "interfaces"
                                ].append(
                                    info["interface"]
                                )

                except Exception:
                    pass

        # -------------------------------------------------------------
        # Формуємо фінальну карту після опитування ВСІХ MikroTik
        # -------------------------------------------------------------
        final_map = {}

        for ip, info in aggregated.items():
            final_map[ip] = {
                "mac": info["mac"],
                "vendor": info["vendor"],
                "hostname": info["hostname"],
                "interface": (
                    ", ".join(
                        info["interfaces"]
                    )
                    if info["interfaces"]
                    else "—"
                ),
                "lease_status": (
                    info["lease_status"]
                ),
            }

        # -------------------------------------------------------------
        # АВТОМАТИЧНА СИНХРОНІЗАЦІЯ
        #
        # Вона відбувається тільки після того, як усі MikroTik
        # вже опитані та final_map повністю сформований.
        # -------------------------------------------------------------
        try:
            self.sync_with_devices_file(final_map)
        except Exception:
            self.last_added_ips = {}

        return final_map


class Host:
    def __init__(self, ip, name=""):
        self.ip = ip
        self.name = name
        self.online = None
        self.last_ping = None
        self.last_check = None
        self.last_online = None
        self.last_offline = None
        self.history = deque()
        self.previous_online = None
        self.high_ping_events = 0
        self.disconnects = 0
        self.outage_started = None
        self.longest_outage = 0.0
        self.dns_name = "—"
        self.group = "Загальні"
        self.priority = "Звичайний"

        self.ports = []
        self.expected_mac = ""
        self.address_mode = "ip"
        self.tracking_mac = ""
        self.current_mac = ""
        self.mac_match = None
        self.response_method = "N/A"
        self.icmp_successes = 0
        self.tcp_success_ports = []
        self.consecutive_failures = 0
        self.consecutive_successes = 0

        self.mt_mac = "—"
        self.mt_vendor = "—"
        self.mt_hostname = "—"
        self.mt_interface = "—"
        self.mt_lease_status = "—"
        self.device_kind = "Невідомий"
        self.device_kind_confidence = "LOW"
        self.device_kind_reason = "Недостатньо пасивних локальних даних."
        self.device_identity = ""
        self.device_identity_source = ""
        self.device_identified_at = ""
        self.device_identification_last_attempt = 0.0

        self.lock = threading.Lock()

    def update_mikrotik_data(self, mt_dict):
        with self.lock:
            if not mt_dict:
                return

            if mt_dict.get("mac"):
                self.mt_mac = mt_dict["mac"]

            if mt_dict.get("vendor"):
                self.mt_vendor = mt_dict["vendor"]

            if (
                mt_dict.get("hostname")
                and mt_dict["hostname"] != "—"
            ):
                self.mt_hostname = mt_dict["hostname"]

            if (
                mt_dict.get("interface")
                and mt_dict["interface"] != "—"
            ):
                self.mt_interface = mt_dict["interface"]

            if (
                mt_dict.get("lease_status")
                and mt_dict["lease_status"] != "—"
            ):
                self.mt_lease_status = (
                    mt_dict["lease_status"]
                )

    def set_evidence(
        self,
        response_method,
        current_mac="",
        mac_match=None,
        icmp_successes=0,
        tcp_success_ports=None,
    ):
        with self.lock:
            self.response_method = (
                response_method or "N/A"
            )

            self.current_mac = (
                current_mac or ""
            )

            self.mac_match = mac_match

            self.icmp_successes = int(
                icmp_successes or 0
            )

            self.tcp_success_ports = list(
                tcp_success_ports or []
            )

    def add_result(self, online, ping):
        now = current_time()

        with self.lock:
            self.previous_online = self.online
            old = self.online

            self.online = online
            self.last_ping = ping
            self.last_check = now

            self.history.append(
                (
                    now,
                    online,
                    ping,
                )
            )

            cutoff = (
                now
                - timedelta(
                    seconds=HISTORY_SECONDS
                )
            )

            while (
                self.history
                and self.history[0][0] < cutoff
            ):
                self.history.popleft()

            if online:
                self.last_online = now

                if (
                    old is False
                    and self.outage_started
                ):
                    duration = (
                        now
                        - self.outage_started
                    ).total_seconds()

                    self.longest_outage = max(
                        self.longest_outage,
                        duration,
                    )

                    self.outage_started = None

            else:
                self.last_offline = now

                if old is True:
                    self.disconnects += 1

                if (
                    old is not False
                    and self.outage_started is None
                ):
                    self.outage_started = now

    def snapshot(self):
        with self.lock:
            history = list(
                self.history
            )

            pings = [
                p
                for _, online, p in history
                if online and p is not None
            ]

            checks = len(history)

            offline = sum(
                1
                for _, online, _ in history
                if not online
            )

            loss = (
                offline / checks * 100
                if checks
                else 0
            )

            avg = (
                sum(pings) / len(pings)
                if pings
                else None
            )

            mn = (
                min(pings)
                if pings
                else None
            )

            mx = (
                max(pings)
                if pings
                else None
            )

            disconnects = 0

            if history:
                previous_online = history[0][1]

                for _, online, _ in history[1:]:
                    if previous_online is True and online is False:
                        disconnects += 1

                    previous_online = online

            longest_outage = self.longest_outage

            if self.outage_started is not None:
                longest_outage = max(
                    longest_outage,
                    (current_time() - self.outage_started).total_seconds(),
                )

            return {
                "online": self.online,
                "ping": self.last_ping,
                "last_check": self.last_check,
                "last_online": self.last_online,
                "last_offline": self.last_offline,
                "checks": checks,
                "online_count": (
                    checks - offline
                ),
                "offline_count": offline,
                "loss": loss,
                "avg": avg,
                "min": mn,
                "max": mx,
                "disconnects": disconnects,
                "history": history,
                "dns": self.dns_name,
                "group": self.group,
                "priority": self.priority,
                "longest_outage": (
                    longest_outage
                ),
                "response_method": (
                    self.response_method
                ),
                "current_mac": (
                    self.current_mac
                ),
                "expected_mac": (
                    self.expected_mac
                ),
                "address_mode": self.address_mode,
                "tracking_mac": self.tracking_mac,
                "mac_match": self.mac_match,
                "icmp_successes": (
                    self.icmp_successes
                ),
                "tcp_success_ports": list(
                    self.tcp_success_ports
                ),
                "consecutive_failures": (
                    self.consecutive_failures
                ),
                "consecutive_successes": (
                    self.consecutive_successes
                ),
                "mt_mac": self.mt_mac,
                "mt_vendor": self.mt_vendor,
                "mt_hostname": self.mt_hostname,
                "mt_interface": self.mt_interface,
                "mt_lease_status": (
                    self.mt_lease_status
                ),
                "device_kind": self.device_kind,
                "device_kind_confidence": self.device_kind_confidence,
                "device_kind_reason": self.device_kind_reason,
                "device_identity": self.device_identity,
                "device_identity_source": self.device_identity_source,
                "device_identified_at": self.device_identified_at,
                "device_identification_last_attempt": self.device_identification_last_attempt,
            }


class MichmanKP:
    def _report_callback_exception(self, exc_type, exc_value, exc_traceback):
        """Show Tk callback failures instead of leaving an empty window."""
        details = "".join(
            traceback.format_exception(
                exc_type,
                exc_value,
                exc_traceback,
            )
        )
        try:
            LOGGER.error("Tk callback failed:\n%s", details)
        except Exception:
            pass
        try:
            messagebox.showerror(
                APP_NAME,
                "Помилка GUI під час відкриття або роботи вікна.\n\n"
                f"{exc_value}\n\n"
                f"Повний traceback записано у:\n{TECHNICAL_LOG_FILE}",
                parent=self.root,
            )
        except Exception:
            pass

    def apply_futuristic_theme(self):
        self.root.configure(background=UI_BG)
        self.root.option_add("*Font", ("Segoe UI", 10))
        self.root.option_add("*TCombobox*Listbox.background", UI_PANEL)
        self.root.option_add("*TCombobox*Listbox.foreground", UI_TEXT)
        self.root.option_add("*TCombobox*Listbox.selectBackground", UI_CYAN)
        self.root.option_add(
            "*TCombobox*Listbox.selectForeground",
            UI_SELECTION_TEXT,
        )
        self.root.option_add("*TFrame.background", UI_BG)
        self.root.option_add("*TLabel.background", UI_BG)
        self.root.option_add("*TLabel.foreground", UI_TEXT)
        self.root.option_add("*TButton.background", UI_PANEL)
        self.root.option_add("*TButton.foreground", UI_TEXT)
        self.root.option_add("*TEntry.background", UI_PANEL)
        self.root.option_add("*TEntry.foreground", UI_TEXT)
        self.root.option_add("*Toplevel.background", UI_BG)
        self.root.option_add("*Listbox.background", UI_SURFACE)
        self.root.option_add("*Listbox.foreground", UI_TEXT)
        self.root.option_add("*Listbox.selectBackground", UI_CYAN)
        self.root.option_add("*Listbox.selectForeground", UI_SELECTION_TEXT)
        self.root.option_add("*Listbox.highlightBackground", UI_BORDER)
        self.root.option_add("*Listbox.highlightColor", UI_CYAN)

        style = ttk.Style(self.root)
        selected_theme = _select_ttk_theme(style)
        if selected_theme:
            LOGGER.info("Using ttk theme: %s", selected_theme)
        else:
            LOGGER.warning("No ttk theme could be selected; using Tk default")

        style.configure(".", background=UI_BG, foreground=UI_TEXT)
        style.configure("TFrame", background=UI_BG)
        style.configure("Header.TFrame", background=UI_HEADER)
        style.configure("Toolbar.TFrame", background=UI_SURFACE)
        style.configure(
            "Metric.TFrame",
            background=UI_PANEL,
            borderwidth=1,
            relief="solid",
        )

        style.configure(
            "TLabel",
            background=UI_BG,
            foreground=UI_TEXT,
            font=("Segoe UI", 10),
        )
        style.configure(
            "Header.TLabel",
            background=UI_HEADER,
            foreground=UI_TEXT,
        )
        style.configure(
            "Brand.TLabel",
            background=UI_HEADER,
            foreground=UI_CYAN,
            font=("Segoe UI Semibold", 22),
        )
        style.configure(
            "BrandSub.TLabel",
            background=UI_HEADER,
            foreground=UI_MUTED,
            font=("Segoe UI", 9),
        )
        style.configure(
            "Section.TLabel",
            background=UI_SURFACE,
            foreground=UI_MUTED,
            font=("Segoe UI Semibold", 9),
        )
        style.configure(
            "MetricLabel.TLabel",
            background=UI_PANEL,
            foreground=UI_MUTED,
            font=("Segoe UI Semibold", 9),
        )

        for style_name, color in (
            ("Cyan.MetricValue.TLabel", UI_CYAN),
            ("Green.MetricValue.TLabel", UI_GREEN),
            ("Red.MetricValue.TLabel", UI_RED),
            ("Amber.MetricValue.TLabel", UI_AMBER),
            ("Muted.MetricValue.TLabel", UI_MUTED),
        ):
            style.configure(
                style_name,
                background=UI_PANEL,
                foreground=color,
                font=("Cascadia Mono", 18, "bold"),
            )

        style.configure(
            "StatusBar.TLabel",
            background=UI_HEADER,
            foreground=UI_MUTED,
            font=("Cascadia Mono", 9),
            padding=(14, 7),
        )
        style.configure(
            "Owner.TLabel",
            background=UI_HEADER,
            foreground=UI_CYAN,
            font=("Cascadia Mono", 9, "bold"),
            padding=(12, 7),
        )
        style.configure(
            "Footer.TLabel",
            background=UI_HEADER,
            foreground=UI_MUTED,
            font=("Segoe UI Semibold", 8),
            padding=(6, 7),
        )
        style.configure(
            "StateActive.TLabel",
            background=UI_HEADER,
            foreground=UI_GREEN,
            font=("Cascadia Mono", 10, "bold"),
        )
        style.configure(
            "StateIdle.TLabel",
            background=UI_HEADER,
            foreground=UI_MUTED,
            font=("Cascadia Mono", 10, "bold"),
        )

        style.configure(
            "TButton",
            background=UI_PANEL,
            foreground=UI_TEXT,
            bordercolor=UI_BORDER,
            lightcolor=UI_PANEL,
            darkcolor=UI_PANEL,
            relief="flat",
            borderwidth=1,
            padding=(11, 7),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "TButton",
            background=[
                ("pressed", UI_CYAN_SOFT),
                ("active", UI_PANEL_HOVER),
                ("disabled", UI_SURFACE),
            ],
            foreground=[
                ("pressed", UI_TEXT),
                ("active", UI_CYAN),
                ("disabled", UI_MUTED),
            ],
            bordercolor=[
                ("active", UI_BORDER_BRIGHT),
                ("focus", UI_CYAN),
            ],
        )
        style.configure(
            "Accent.TButton",
            background=UI_CYAN,
            foreground=UI_SELECTION_TEXT,
            bordercolor=UI_CYAN,
            lightcolor=UI_CYAN,
            darkcolor=UI_CYAN,
            padding=(14, 8),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "Accent.TButton",
            background=[
                ("pressed", "#00AFC4"),
                ("active", "#57F2FF"),
                ("disabled", UI_CYAN_SOFT),
            ],
            foreground=[("disabled", UI_MUTED)],
        )
        style.configure(
            "Danger.TButton",
            background="#39131E",
            foreground=UI_RED,
            bordercolor="#7A263A",
            lightcolor="#39131E",
            darkcolor="#39131E",
            padding=(14, 8),
        )
        style.map(
            "Danger.TButton",
            background=[
                ("pressed", "#611B2C"),
                ("active", "#4A1724"),
            ],
            foreground=[("active", "#FF8AA0")],
        )

        style.configure(
            "TEntry",
            fieldbackground=UI_PANEL,
            foreground=UI_TEXT,
            insertcolor=UI_CYAN,
            bordercolor=UI_BORDER,
            lightcolor=UI_PANEL,
            darkcolor=UI_PANEL,
            padding=7,
        )
        style.map(
            "TEntry",
            bordercolor=[("focus", UI_CYAN)],
            lightcolor=[("focus", UI_CYAN)],
            darkcolor=[("focus", UI_CYAN)],
        )
        style.configure(
            "TSpinbox",
            fieldbackground=UI_PANEL,
            foreground=UI_TEXT,
            arrowcolor=UI_CYAN,
            bordercolor=UI_BORDER,
            lightcolor=UI_PANEL,
            darkcolor=UI_PANEL,
            padding=5,
        )
        style.map(
            "TSpinbox",
            bordercolor=[("focus", UI_CYAN)],
        )
        style.configure(
            "TCombobox",
            fieldbackground=UI_PANEL,
            background=UI_PANEL,
            foreground=UI_TEXT,
            arrowcolor=UI_CYAN,
            bordercolor=UI_BORDER,
            lightcolor=UI_PANEL,
            darkcolor=UI_PANEL,
            padding=5,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", UI_PANEL)],
            foreground=[("readonly", UI_TEXT)],
            bordercolor=[("focus", UI_CYAN)],
        )

        style.configure(
            "TNotebook",
            background=UI_BG,
            bordercolor=UI_BORDER,
            lightcolor=UI_BG,
            darkcolor=UI_BG,
            tabmargins=(0, 0, 0, 0),
        )
        style.configure(
            "TNotebook.Tab",
            background=UI_SURFACE,
            foreground=UI_MUTED,
            bordercolor=UI_BORDER,
            lightcolor=UI_SURFACE,
            darkcolor=UI_SURFACE,
            padding=(18, 9),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "TNotebook.Tab",
            background=[
                ("selected", UI_PANEL),
                ("active", UI_PANEL_HOVER),
            ],
            foreground=[
                ("selected", UI_CYAN),
                ("active", UI_TEXT),
            ],
            bordercolor=[("selected", UI_CYAN_SOFT)],
        )

        style.configure(
            "Treeview",
            background=UI_SURFACE,
            fieldbackground=UI_SURFACE,
            foreground=UI_TEXT,
            bordercolor=UI_BORDER,
            lightcolor=UI_SURFACE,
            darkcolor=UI_SURFACE,
            relief="flat",
            rowheight=30,
            font=("Cascadia Mono", 9),
        )
        style.map(
            "Treeview",
            background=[("selected", UI_CYAN)],
            foreground=[("selected", UI_SELECTION_TEXT)],
        )
        style.configure(
            "Treeview.Heading",
            background=UI_PANEL,
            foreground=UI_CYAN,
            bordercolor=UI_BORDER,
            lightcolor=UI_PANEL,
            darkcolor=UI_PANEL,
            relief="flat",
            padding=(7, 9),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "Treeview.Heading",
            background=[("active", UI_PANEL_HOVER)],
            foreground=[("active", UI_TEXT)],
        )

        style.configure(
            "Vertical.TScrollbar",
            background=UI_PANEL,
            troughcolor=UI_BG,
            bordercolor=UI_BG,
            arrowcolor=UI_CYAN,
            lightcolor=UI_PANEL,
            darkcolor=UI_PANEL,
        )
        style.configure(
            "Horizontal.TScrollbar",
            background=UI_PANEL,
            troughcolor=UI_BG,
            bordercolor=UI_BG,
            arrowcolor=UI_CYAN,
            lightcolor=UI_PANEL,
            darkcolor=UI_PANEL,
        )
        style.configure(
            "TCheckbutton",
            background=UI_BG,
            foreground=UI_TEXT,
            indicatorbackground=UI_PANEL,
            indicatorforeground=UI_CYAN,
            padding=4,
        )
        style.map(
            "TCheckbutton",
            background=[("active", UI_BG)],
            foreground=[("active", UI_CYAN)],
            indicatorbackground=[
                ("selected", UI_CYAN),
                ("active", UI_PANEL_HOVER),
            ],
        )
        style.configure(
            "TLabelframe",
            background=UI_BG,
            foreground=UI_TEXT,
            bordercolor=UI_BORDER,
            lightcolor=UI_BG,
            darkcolor=UI_BG,
        )
        style.configure(
            "TLabelframe.Label",
            background=UI_BG,
            foreground=UI_CYAN,
        )

        self.ui_style = style

    def __init__(self, root, license_manager=None, license_status=None, identity_session=None, identity_store=None):
        self.identity_session = identity_session or {"user": "unavailable", "role": "Viewer"}
        self.identity_store = identity_store
        self.root = root
        self.root.report_callback_exception = self._report_callback_exception
        self.license_manager = license_manager or LicenseManager(BASE_DIR)
        self.license_status = license_status or self.license_manager.check()
        self.license_dialog_open = False
        self.root.title(APP_NAME)
        self.root.geometry("1640x900")
        try:
            screen_width = int(self.root.winfo_screenwidth())
            screen_height = int(self.root.winfo_screenheight())
            self.root.minsize(
                min(1180, max(800, screen_width - 40)),
                min(700, max(560, screen_height - 100)),
            )
        except (tk.TclError, ValueError, TypeError):
            self.root.minsize(1180, 700)
        self.apply_futuristic_theme()

        ensure_initial_data_files()
        self.db = Database(DB_FILE)
        from michman_platform_core import PlatformCore
        self.platform_core = PlatformCore(DB_FILE, connection=self.db.conn, lock=self.db.lock)

        self.hosts = {}
        self.rows = {}
        self.names = {}

        # Додатковий стан відображення IP. Приховані IP лише не показуються
        # у головному списку й не видаляються з app-owned device list.
        self.hidden_ips = set()
        self.pinned_ips = set()

        self.running = False
        self.stop_event = threading.Event()

        self.log_lines = 0

        self.gui_queue = queue.Queue()

        self.detail_windows = {}
        self.selected_ip = None
        self.monitor_thread = None
        self.monitor_generation = 0
        self.closed = False

        self.hosts_lock = threading.RLock()
        self.config_lock = threading.Lock()
        self.tcp_executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=64,
            thread_name_prefix="MichmanTCP",
        )

        self.interval_seconds = DEFAULT_INTERVAL
        self.timeout_seconds = PING_TIMEOUT

        self.cycle_elapsed = 0.0
        self.cycle_last_tick = time.monotonic()
        self.event_refresh_pending = False
        self.mikrotik_refresh_busy = False
        self.last_mikrotik_errors = {}

        self.interval = tk.IntVar(
            value=DEFAULT_INTERVAL
        )

        self.timeout = tk.IntVar(
            value=PING_TIMEOUT
        )

        self.load_visibility_config()

        # Пасивне виявлення ознак сканування цього ПК.
        # Не виконує ping sweep, port scan або перебір адрес.
        self.scan_watch_lock = threading.RLock()
        self.scan_watch_records = []
        self.scan_watch_probe_records = []
        self.scan_watch_busy = False
        self.scan_watch_last_error = ""
        self.scan_watch_window = None
        self.scan_watch_alert_windows = {}
        self.scan_watch_last_alert = {}
        self.scan_watch_block_attempts = {}
        self.scan_sensor_setup_busy = False
        self.scan_sensor_status = ""
        self.scan_sensor_sources = {}
        self._default_gateway_cache = (0.0, set())
        self.scan_defense_settings = self.load_scan_defense_settings()
        self.load_scan_watch_records()
        self.load_scan_watch_probe_records()

        self.load_names()
        self.load_device_config()
        self.load_mikrotik_config()

        self.build_ui()
        self.load_devices(True)

        self.root.after(
            250,
            self.process_gui_queue,
        )

        self.root.after(
            1000,
            self.refresh_gui,
        )

        # Пасивний аналіз локальних журналів Windows на ознаки
        # сканування. Жодного активного сканування мережі тут немає.
        self.root.after(
            5000,
            self.scan_watch_periodic,
        )

        # Installed builds configure this during setup.  When the application
        # itself already has administrator rights, repair the local sensor
        # silently as well.  Standard users are never shown an unexpected UAC
        # prompt; the ScanWatch window has an explicit activation button.
        if sys.platform.startswith("win") and is_windows_admin():
            self.root.after(1500, self._initialize_scan_sensor)

        self.root.after(
            60000,
            self.check_license_periodically,
        )

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.close,
        )

    def load_names(self):
        try:
            if os.path.exists(NAMES_FILE):
                with open(
                    NAMES_FILE,
                    "r",
                    encoding="utf-8",
                ) as f:
                    data = json.load(f)

                if isinstance(data, dict):
                    self.names = {
                        str(ip): str(name)
                        for ip, name in data.items()
                        if valid_ipv4(str(ip))
                        and str(name).strip()
                    }

        except Exception as e:
            self.names = {}

            self.db.add_event(
                None,
                "CONFIG_ERROR",
                f"Помилка читання назв: {e}",
            )

    def save_names(self):
        try:
            tmp_path = NAMES_FILE + ".tmp"

            with open(
                tmp_path,
                "w",
                encoding="utf-8",
            ) as f:
                json.dump(
                    self.names,
                    f,
                    ensure_ascii=False,
                    indent=2,
                )

            os.replace(
                tmp_path,
                NAMES_FILE,
            )

        except Exception as e:
            self.write_log(
                "Помилка збереження назв: "
                + str(e)
            )

    def load_mikrotik_config(self):
        self.mikrotik_list = []
        needs_secret_migration = False
        needs_schema_migration = False

        try:
            legacy_profiles = os.path.join(BASE_DIR, "router_profiles.json")
            if not os.path.exists(MIKROTIK_CONFIG_FILE) and os.path.isfile(legacy_profiles):
                with open(legacy_profiles, "r", encoding="utf-8") as f:
                    old_profiles = json.load(f)
                for profile in old_profiles if isinstance(old_profiles, list) else []:
                    if not isinstance(profile, dict) or not str(profile.get("host", "")).strip():
                        continue
                    self.mikrotik_list.append({
                        "id": str(profile.get("id") or uuid.uuid4().hex),
                        "name": str(profile.get("name") or profile.get("host") or ""),
                        "host": str(profile.get("host") or "").strip(),
                        "user": str(profile.get("user") or "").strip(),
                        "password": "",
                        "platform": str(profile.get("platform") or "auto"),
                        "auth_mode": str(profile.get("auth_mode") or ("username" if profile.get("user") else "password_only")),
                        "method": "SSH", "port": int(profile.get("port") or 22),
                        "verify_peer": True,
                        "known_hosts": str(profile.get("known_hosts") or ""),
                        "command": str(profile.get("command") or ""),
                    })
                if self.mikrotik_list:
                    self.save_mikrotik_config()

            if os.path.exists(
                MIKROTIK_CONFIG_FILE
            ):
                with open(
                    MIKROTIK_CONFIG_FILE,
                    "r",
                    encoding="utf-8",
                ) as f:
                    data = json.load(f)

                if isinstance(data, list):
                    self.mikrotik_list = data

                elif isinstance(data, dict):
                    self.mikrotik_list = [data]

                for item in self.mikrotik_list:
                    if not isinstance(item, dict):
                        continue

                    # 2.3 stores MikroTik and standards-based SSH routers in
                    # one list.  Older entries were implicitly RouterOS.
                    if not item.get("id"):
                        item["id"] = uuid.uuid4().hex
                        needs_schema_migration = True
                    if not item.get("platform"):
                        item["platform"] = "mikrotik"
                        needs_schema_migration = True
                    if "auth_mode" not in item:
                        item["auth_mode"] = (
                            "username" if str(item.get("user", "")).strip()
                            else "password_only"
                        )
                        needs_schema_migration = True
                    item.setdefault("known_hosts", "")
                    item.setdefault("command", "")
                    item.setdefault("legacy_ssh", False)

                    saved_password = str(
                        item.get("password", "") or ""
                    )

                    if (
                        saved_password
                        and not saved_password.startswith("dpapi:")
                        and sys.platform.startswith("win")
                    ):
                        needs_secret_migration = True

                    try:
                        item["password"] = unprotect_secret(
                            saved_password
                        )
                    except Exception as e:
                        item["password"] = ""
                        self.write_log(
                            "Не вдалося розшифрувати пароль MikroTik "
                            f"для {item.get('name') or item.get('host')}: {e}",
                            event="MIKROTIK_CREDENTIAL_ERROR",
                        )

                self.mikrotik_list = [
                    item
                    for item in self.mikrotik_list
                    if isinstance(item, dict)
                ]

                # Import profiles created by the retired separate
                # "Universal routers" tab.  Passwords were never stored in
                # that file, so imported records remain empty until edited.
                if os.path.isfile(legacy_profiles):
                    try:
                        with open(legacy_profiles, "r", encoding="utf-8") as f:
                            old_profiles = json.load(f)
                        existing_keys = {
                            (str(x.get("host", "")).casefold(), str(x.get("platform", "mikrotik")))
                            for x in self.mikrotik_list
                        }
                        for profile in old_profiles if isinstance(old_profiles, list) else []:
                            if not isinstance(profile, dict):
                                continue
                            key = (
                                str(profile.get("host", "")).strip().casefold(),
                                str(profile.get("platform", "auto") or "auto"),
                            )
                            if not key[0] or key in existing_keys:
                                continue
                            self.mikrotik_list.append({
                                "id": str(profile.get("id") or uuid.uuid4().hex),
                                "name": str(profile.get("name") or profile.get("host") or ""),
                                "host": str(profile.get("host") or "").strip(),
                                "user": str(profile.get("user") or "").strip(),
                                "password": "",
                                "platform": key[1],
                                "auth_mode": str(profile.get("auth_mode") or ("username" if profile.get("user") else "password_only")),
                                "method": "SSH",
                                "port": int(profile.get("port") or 22),
                                "verify_peer": True,
                                "known_hosts": str(profile.get("known_hosts") or ""),
                                "command": str(profile.get("command") or ""),
                            })
                            existing_keys.add(key)
                            needs_schema_migration = True
                    except Exception as e:
                        self.write_log("Не вдалося перенести старі профілі роутерів: " + str(e))

                if needs_secret_migration or needs_schema_migration:
                    self.save_mikrotik_config()

                    legacy_config = os.path.join(
                        INSTALL_DIR,
                        "mikrotik_config.json",
                    )

                    if (
                        os.path.abspath(legacy_config)
                        != os.path.abspath(MIKROTIK_CONFIG_FILE)
                        and os.path.isfile(legacy_config)
                    ):
                        self.write_log(
                            "Паролі MikroTik у новому сховищі зашифровано. "
                            "Старий mikrotik_config.json поруч з EXE може "
                            "містити відкритий пароль — після перевірки "
                            "налаштувань видаліть стару копію вручну.",
                            event="MIKROTIK_CREDENTIAL_WARNING",
                        )

        except Exception as e:
            self.write_log(
                "Помилка конфігурації MikroTik: "
                + str(e)
            )

    def save_mikrotik_config(self):
        try:
            tmp = (
                MIKROTIK_CONFIG_FILE
                + ".tmp"
            )

            safe_items = []

            for item in self.mikrotik_list:
                safe_item = dict(item)
                safe_item["password"] = protect_secret(
                    safe_item.get("password", "")
                )
                safe_items.append(safe_item)

            with open(
                tmp,
                "w",
                encoding="utf-8",
            ) as f:
                json.dump(
                    safe_items,
                    f,
                    ensure_ascii=False,
                    indent=2,
                )

            os.replace(
                tmp,
                MIKROTIK_CONFIG_FILE,
            )

        except Exception as e:
            self.write_log(
                "Помилка збереження конфігурації "
                "MikroTik: "
                + str(e)
            )

    def load_visibility_config(self):
        """Завантажує список прихованих та закріплених IP."""
        self.hidden_ips = set()
        self.pinned_ips = set()

        try:
            if not os.path.exists(HIDDEN_PINNED_FILE):
                return

            with open(
                HIDDEN_PINNED_FILE,
                "r",
                encoding="utf-8",
            ) as f:
                data = json.load(f)

            if not isinstance(data, dict):
                return

            hidden = data.get("hidden", [])
            pinned = data.get("pinned", [])

            if isinstance(hidden, list):
                self.hidden_ips = {
                    str(ip).strip()
                    for ip in hidden
                    if valid_ipv4(str(ip).strip())
                }

            if isinstance(pinned, list):
                self.pinned_ips = {
                    str(ip).strip()
                    for ip in pinned
                    if valid_ipv4(str(ip).strip())
                }

        except Exception as e:
            self.hidden_ips = set()
            self.pinned_ips = set()
            self.write_log(
                "Помилка читання налаштувань видимості IP: "
                + str(e),
                event="CONFIG_ERROR",
            )

    def save_visibility_config(self):
        """Зберігає приховані та закріплені IP окремо від списку пристроїв."""
        try:
            tmp_path = HIDDEN_PINNED_FILE + ".tmp"

            data = {
                "hidden": sorted(
                    self.hidden_ips,
                    key=lambda value: tuple(
                        int(part)
                        for part in value.split(".")
                    ),
                ),
                "pinned": sorted(
                    self.pinned_ips,
                    key=lambda value: tuple(
                        int(part)
                        for part in value.split(".")
                    ),
                ),
            }

            with open(
                tmp_path,
                "w",
                encoding="utf-8",
            ) as f:
                json.dump(
                    data,
                    f,
                    ensure_ascii=False,
                    indent=2,
                )

            os.replace(
                tmp_path,
                HIDDEN_PINNED_FILE,
            )

        except Exception as e:
            self.write_log(
                "Помилка збереження налаштувань видимості IP: "
                + str(e),
                event="CONFIG_ERROR",
            )

    def get_selected_main_ip(self):
        """Повертає IP, вибраний користувачем у головному списку."""
        ip = getattr(
            self,
            "selected_ip",
            None,
        )

        if ip:
            with self.hosts_lock:
                if ip in self.hosts:
                    return ip

        selection = self.tree.selection()

        if selection:
            values = self.tree.item(
                selection[0],
                "values",
            )

            if values:
                ip = values[0]
                if ip:
                    self.selected_ip = ip
                    return ip

        return None

    def reidentify_selected_device(self):
        ip = self.get_selected_main_ip()
        if not ip:
            messagebox.showinfo(APP_NAME, "Виберіть IP у головному списку.", parent=self.root)
            return
        with self.hosts_lock:
            host = self.hosts.get(ip)
        if host:
            with host.lock:
                host.device_identification_last_attempt = 0.0
            self.schedule_host_identification([host])
            self.write_log(f"{ip}: запущено повторне визначення пристрою", ip, "IDENTITY_REFRESH")

    def copy_selected_device_card(self):
        ip = self.get_selected_main_ip()
        if not ip:
            messagebox.showinfo(APP_NAME, "Виберіть IP у головному списку.", parent=self.root)
            return
        with self.hosts_lock:
            host = self.hosts.get(ip)
        if not host:
            return
        snapshot = host.snapshot()
        card = "\n".join((
            f"IP: {host.ip}",
            f"Назва: {host.name or '—'}",
            f"HOSTNAME: {self._hostname_identity(host, snapshot)}",
            f"Статус: {effective_status(snapshot)}",
            f"Ping: {fmt_ping(snapshot['ping'])}",
            f"MAC: {snapshot['current_mac'] or snapshot['mt_mac'] or '—'}",
            f"Виробник: {snapshot['mt_vendor'] or '—'}",
            f"Джерело ідентифікації: {snapshot['device_identity_source'] or '—'}",
            f"Визначено: {snapshot['device_identified_at'] or '—'}",
        ))
        self.root.clipboard_clear()
        self.root.clipboard_append(card)
        self.root.update_idletasks()
        self.write_log(f"{ip}: картку пристрою скопійовано", ip, "DEVICE_CARD_COPY")

    def hide_selected_ip(self):
        ip = self.get_selected_main_ip()

        if not ip:
            messagebox.showinfo(
                APP_NAME,
                "Виберіть IP у головному списку.",
                parent=self.root,
            )
            return

        if ip in self.hidden_ips:
            messagebox.showinfo(
                APP_NAME,
                f"{ip} вже прихований.",
                parent=self.root,
            )
            return

        self.hidden_ips.add(ip)
        self.save_visibility_config()

        self.write_log(
            f"IP приховано з головного списку: {ip}",
            ip,
            "HIDE",
        )

        self.selected_ip = None
        self.rebuild_tree()

    def show_hidden_ips_dialog(self):
        hidden = sorted(
            self.hidden_ips,
            key=lambda value: tuple(
                int(part)
                for part in value.split(".")
            ),
        )

        if not hidden:
            messagebox.showinfo(
                APP_NAME,
                "Прихованих IP немає.",
                parent=self.root,
            )
            return

        win = tk.Toplevel(self.root)
        win.configure(background=UI_BG)
        win.title(
            f"{APP_NAME} — Приховані IP"
        )
        win.geometry("520x480")
        win.minsize(420, 350)

        ttk.Label(
            win,
            text="Виберіть IP, які потрібно показати у головному списку:",
            padding=10,
        ).pack(
            fill="x"
        )

        frame = ttk.Frame(win)
        frame.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5,
        )

        scroll = ttk.Scrollbar(
            frame,
            orient="vertical",
        )
        scroll.pack(
            side="right",
            fill="y",
        )

        listbox = tk.Listbox(
            frame,
            selectmode="extended",
            yscrollcommand=scroll.set,
            font=("Cascadia Mono", 10),
            background=UI_SURFACE,
            foreground=UI_TEXT,
            selectbackground=UI_CYAN,
            selectforeground=UI_SELECTION_TEXT,
            highlightbackground=UI_BORDER,
            highlightcolor=UI_CYAN,
            borderwidth=0,
            relief="flat",
        )
        listbox.pack(
            fill="both",
            expand=True,
        )
        scroll.config(
            command=listbox.yview
        )

        for ip in hidden:
            listbox.insert(
                "end",
                ip,
            )

        buttons = ttk.Frame(
            win,
            padding=10,
        )
        buttons.pack(
            fill="x",
        )

        def show_selected():
            indexes = listbox.curselection()

            if not indexes:
                messagebox.showinfo(
                    APP_NAME,
                    "Виберіть хоча б один IP.",
                    parent=win,
                )
                return

            selected = [
                hidden[index]
                for index in indexes
            ]

            for ip in selected:
                self.hidden_ips.discard(ip)

            self.save_visibility_config()

            for ip in selected:
                self.write_log(
                    f"IP показано у головному списку: {ip}",
                    ip,
                    "UNHIDE",
                )

            self.rebuild_tree()
            win.destroy()

        def show_all():
            selected = list(hidden)

            for ip in selected:
                self.hidden_ips.discard(ip)

            self.save_visibility_config()

            for ip in selected:
                self.write_log(
                    f"IP показано у головному списку: {ip}",
                    ip,
                    "UNHIDE",
                )

            self.rebuild_tree()
            win.destroy()

        ttk.Button(
            buttons,
            text="Показати вибрані",
            command=show_selected,
        ).pack(
            side="left",
            padx=3,
        )

        ttk.Button(
            buttons,
            text="Показати всі",
            command=show_all,
        ).pack(
            side="left",
            padx=3,
        )

        ttk.Button(
            buttons,
            text="Закрити",
            command=win.destroy,
        ).pack(
            side="right",
            padx=3,
        )

        win.protocol("WM_DELETE_WINDOW", win.destroy)
        _show_child_window(
            win,
            520,
            480,
            min_width=420,
            min_height=350,
        )

    def toggle_pin_selected_ip(self):
        ip = self.get_selected_main_ip()

        if not ip:
            messagebox.showinfo(
                APP_NAME,
                "Виберіть IP у головному списку.",
                parent=self.root,
            )
            return

        if ip in self.pinned_ips:
            self.pinned_ips.discard(ip)
            action = "UNPIN"
            message = f"IP відкріплено: {ip}"
        else:
            self.pinned_ips.add(ip)
            action = "PIN"
            message = f"IP закріплено на початку списку: {ip}"

        self.save_visibility_config()
        self.write_log(
            message,
            ip,
            action,
        )

        self.rebuild_tree()

    def sort_hosts_for_display(self, hosts):
        """Закріплені IP завжди зверху; інші зберігають порядок додавання."""
        return [
            host
            for host in hosts
            if host.ip in self.pinned_ips
        ] + [
            host
            for host in hosts
            if host.ip not in self.pinned_ips
        ]

    def register_platform_host(self, ip):
        if not valid_ipv4(ip):
            return
        with self.hosts_lock:
            if ip in self.hosts:
                return
            self.hosts[ip] = Host(ip, ip)
        if not self.save_devices():
            with self.hosts_lock:
                self.hosts.pop(ip, None)
            raise OSError("Не вдалося зберегти пристрій")
        self.rebuild_tree()

    def open_platform(self):
        from michman_platform_ui import open_platform
        open_platform(self)

    def open_network_center(self):
        from michman_network_ui import open_network_center
        open_network_center(self, BASE_DIR, protect_secret, unprotect_secret, SingleMikroTikClient)

    def build_ui(self):
        header = ttk.Frame(
            self.root,
            style="Header.TFrame",
            padding=(16, 12),
        )
        header.pack(fill="x")

        brand = ttk.Frame(header, style="Header.TFrame")
        brand.pack(side="left")

        ttk.Label(
            brand,
            text="◈  МІЧМАН КП",
            style="Brand.TLabel",
        ).pack(anchor="w")
        ttk.Label(
            brand,
            text="NETWORK OBSERVABILITY  •  DFIR  •  MIKROTIK",
            style="BrandSub.TLabel",
        ).pack(anchor="w", pady=(1, 0))

        self.file_label = ttk.Label(
            header,
            text="DEVICES  //  0 NODES",
            style="Header.TLabel",
        )
        self.file_label.pack(side="left", padx=(28, 16))

        runtime = ttk.Frame(header, style="Header.TFrame")
        runtime.pack(side="left", padx=(0, 12))

        ttk.Label(
            runtime,
            text="ЦИКЛ",
            style="BrandSub.TLabel",
        ).grid(row=0, column=0, sticky="w")
        ttk.Spinbox(
            runtime,
            from_=1,
            to=3600,
            width=5,
            textvariable=self.interval,
        ).grid(row=1, column=0, padx=(0, 5), sticky="w")
        ttk.Label(
            runtime,
            text="с",
            style="Header.TLabel",
        ).grid(row=1, column=1, sticky="w")

        ttk.Label(
            runtime,
            text="TIMEOUT",
            style="BrandSub.TLabel",
        ).grid(row=0, column=2, padx=(14, 0), sticky="w")
        ttk.Spinbox(
            runtime,
            from_=1,
            to=60,
            width=5,
            textvariable=self.timeout,
        ).grid(row=1, column=2, padx=(14, 5), sticky="w")
        ttk.Label(
            runtime,
            text="с",
            style="Header.TLabel",
        ).grid(row=1, column=3, sticky="w")

        self.header_state_var = tk.StringVar(value="●  STANDBY")
        self.header_state_label = ttk.Label(
            header,
            textvariable=self.header_state_var,
            style="StateIdle.TLabel",
        )
        self.header_state_label.pack(side="right", padx=(14, 2))

        self.license_header_var = tk.StringVar()
        self.update_license_display()

        ttk.Button(
            header,
            text="ЛІЦЕНЗІЯ",
            command=self.open_license_window,
        ).pack(side="right", padx=(10, 3))

        ttk.Label(
            header,
            textvariable=self.license_header_var,
            style="Header.TLabel",
        ).pack(side="right", padx=(12, 0))

        # Keep monitor controls in their own full-width row. Packing START and
        # STOP into the crowded header made them disappear on smaller screens.
        run_controls = WrapToolbar(
            self.root,
            style="Toolbar.TFrame",
            padding=(14, 8),
        )
        run_controls.pack(fill="x", pady=(1, 0))
        ttk.Label(
            run_controls,
            text="MONITOR CONTROL",
            style="Section.TLabel",
        ).pack(side="left", padx=(0, 12))
        self.start_button = ttk.Button(
            run_controls,
            text="▶  START",
            command=self.start,
            style="Accent.TButton",
        )
        self.start_button.pack(side="left", padx=3)
        self.stop_button = ttk.Button(
            run_controls,
            text="■  STOP",
            command=self.stop,
            style="Danger.TButton",
        )
        self.stop_button.pack(side="left", padx=3)
        self.stop_button.configure(state="disabled")
        ttk.Button(
            run_controls,
            text="＋  Додати IP",
            command=self.add_ip_dialog,
            style="Accent.TButton",
        ).pack(side="left", padx=(14, 3))
        ttk.Button(
            run_controls,
            text="Пристрої",
            command=self.open_devices_dialog,
        ).pack(side="left", padx=3)
        ttk.Button(run_controls, text="NOC / IT / SOC", command=self.open_platform,
                   style="Accent.TButton").pack(side="left", padx=6)
        ttk.Button(run_controls, text="Мережевий центр", command=self.open_network_center,
                   style="Accent.TButton").pack(side="left", padx=8)
        ttk.Label(
            run_controls,
            text="IP вводяться у програмі та зберігаються локально",
            style="Section.TLabel",
        ).pack(side="right", padx=4)

        actions = WrapToolbar(
            self.root,
            style="Toolbar.TFrame",
            padding=(14, 9),
        )
        actions.pack(fill="x", pady=(1, 0))

        ttk.Label(
            actions,
            text="SYSTEM MODULES",
            style="Section.TLabel",
        ).pack(side="left", padx=(0, 12))

        for text, command in (
            ("Роутери", self.mikrotik_config_dialog),
            ("MikroTik Security", self.open_mikrotik_security_center),
            ("Порти / MAC", self.edit_selected_device),
            ("Додати IP", self.add_ip_dialog),
            ("Пристрої", self.open_devices_dialog),
            ("Скан мережі", self.network_scan_dialog),
            ("ScanWatch", self.open_scan_watch_window),
            ("DFIR / Інциденти", self.open_dfir_window),
            ("Експорт CSV", self.export_csv),
        ):
            ttk.Button(
                actions,
                text=text,
                command=command,
            ).pack(side="left", padx=3)

        ttk.Label(
            actions,
            text=f"ALERT THRESHOLD  {PING_LIMIT_MS:.0f} ms",
            style="Section.TLabel",
        ).pack(side="right", padx=(10, 2))

        metrics = ttk.Frame(
            self.root,
            padding=(14, 10),
        )
        metrics.pack(fill="x")

        self.metric_total_var = tk.StringVar(value="0")
        self.metric_online_var = tk.StringVar(value="0")
        self.metric_offline_var = tk.StringVar(value="0")
        self.metric_high_ping_var = tk.StringVar(value="0")
        self.metric_unknown_var = tk.StringVar(value="0")

        def metric_card(title, variable, value_style):
            card = ttk.Frame(
                metrics,
                style="Metric.TFrame",
                padding=(14, 10),
            )
            card.pack(
                side="left",
                fill="x",
                expand=True,
                padx=4,
            )
            ttk.Label(
                card,
                text=title,
                style="MetricLabel.TLabel",
            ).pack(anchor="w")
            ttk.Label(
                card,
                textvariable=variable,
                style=value_style,
            ).pack(anchor="w", pady=(2, 0))

        metric_card(
            "УСЬОГО ВУЗЛІВ",
            self.metric_total_var,
            "Cyan.MetricValue.TLabel",
        )
        metric_card(
            "ONLINE",
            self.metric_online_var,
            "Green.MetricValue.TLabel",
        )
        metric_card(
            "OFFLINE",
            self.metric_offline_var,
            "Red.MetricValue.TLabel",
        )
        metric_card(
            "PING > 800 ms",
            self.metric_high_ping_var,
            "Amber.MetricValue.TLabel",
        )
        metric_card(
            "ОЧІКУЮТЬ ПЕРЕВІРКИ",
            self.metric_unknown_var,
            "Muted.MetricValue.TLabel",
        )

        self.notebook = ttk.Notebook(
            self.root
        )

        self.notebook.pack(
            fill="both",
            expand=True,
            padx=14,
            pady=(0, 8),
        )

        self.monitor_tab = ttk.Frame(
            self.notebook
        )

        self.events_tab = ttk.Frame(
            self.notebook
        )

        self.notebook.add(
            self.monitor_tab,
            text="  МОНІТОРИНГ  ",
        )

        self.notebook.add(
            self.events_tab,
            text="  ЖУРНАЛ ПОДІЙ  ",
        )

        self.build_monitor_tab()
        self.build_events_tab()

        footer = ttk.Frame(
            self.root,
            style="Header.TFrame",
        )
        footer.pack(fill="x")

        self.status = ttk.Label(
            footer,
            text="SYSTEM READY",
            style="StatusBar.TLabel",
        )

        self.status.pack(
            side="left",
            fill="x",
            expand=True,
        )

        # The ownership notice is intentionally always English and remains in
        # the lower-right corner for every selected interface language.
        ttk.Label(
            footer,
            text="PROPERTY OF IHOR STEPANENKO",
            style="Owner.TLabel",
        ).pack(side="right", padx=(4, 8))

        self.language_combo = ttk.Combobox(
            footer,
            values=[label for _code, label in LANGUAGES],
            state="readonly",
            width=13,
        )
        language_index = next(
            (
                index
                for index, (code, _label) in enumerate(LANGUAGES)
                if code == I18N.code
            ),
            0,
        )
        self.language_combo.current(language_index)
        self.language_combo.pack(side="right", padx=(3, 4), pady=3)
        self.language_combo.bind(
            "<<ComboboxSelected>>",
            self.on_language_changed,
        )

        ttk.Label(
            footer,
            text="LANGUAGE",
            style="Footer.TLabel",
        ).pack(side="right")

    def on_language_changed(self, _event=None):
        index = self.language_combo.current()
        if index < 0 or index >= len(LANGUAGES):
            return
        code, label = LANGUAGES[index]
        if code == I18N.code:
            return
        try:
            I18N.set_language(code)
            I18N.retranslate(self.root)
            self._update_device_label()
            self.update_license_display()
            self.write_log(
                f"Мова інтерфейсу змінена: {label}",
                event="LANGUAGE_CHANGED",
            )
        except Exception as error:
            messagebox.showerror(
                APP_NAME,
                f"Не вдалося змінити мову: {error}",
                parent=self.root,
            )

    def update_license_display(self):
        status = self.license_status
        if not status:
            text = "LIC // НЕ АКТИВОВАНО"
        elif status.valid:
            remaining = format_remaining(status.remaining_seconds)
            text = f"LIC // {status.label} // {remaining}"
        else:
            text = "LIC // ПОТРІБНА АКТИВАЦІЯ"

        variable = getattr(self, "license_header_var", None)
        if variable is not None:
            variable.set(text)

    def open_license_window(self):
        if self.license_dialog_open or self.closed:
            return

        self.license_dialog_open = True
        try:
            result = show_license_dialog(
                self.root,
                self.license_manager,
                allow_cancel=bool(self.license_status and self.license_status.valid),
            )
            if result and result.valid:
                previous_plan = (
                    self.license_status.plan
                    if self.license_status
                    else ""
                )
                self.license_status = result
                self.update_license_display()
                if result.plan != previous_plan:
                    self.write_log(
                        f"Активовано ліцензію: {result.label}",
                        event="LICENSE_ACTIVATED",
                    )
        finally:
            self.license_dialog_open = False

    def check_license_periodically(self):
        if self.closed:
            return

        status = self.license_manager.check()
        self.license_status = status
        self.update_license_display()

        if not status.valid:
            if self.running:
                self.stop()
            messagebox.showwarning(
                f"{APP_NAME} — Ліцензія",
                status.message,
                parent=self.root,
            )
            result = show_license_dialog(
                self.root,
                self.license_manager,
                allow_cancel=False,
            )
            if not result or not result.valid:
                self.close(confirm=False)
                return
            self.license_status = result
            self.update_license_display()

        self.root.after(60000, self.check_license_periodically)

    def build_monitor_tab(self):
        top_tools = ttk.Frame(
            self.monitor_tab,
            style="Toolbar.TFrame",
            padding=(10, 8),
        )

        top_tools.pack(
            fill="x"
        )

        style = self.ui_style

        style.configure(
            "Monitor.Treeview",
            background=UI_SURFACE,
            fieldbackground=UI_SURFACE,
            foreground=UI_TEXT,
            font=("Cascadia Mono", 9),
            rowheight=31,
            bordercolor=UI_BORDER,
        )

        style.configure(
            "Monitor.Treeview.Heading",
            background=UI_PANEL,
            foreground=UI_CYAN,
            font=("Segoe UI Semibold", 9),
            padding=(7, 9),
        )
        style.map(
            "Monitor.Treeview",
            background=[("selected", UI_CYAN)],
            foreground=[("selected", UI_SELECTION_TEXT)],
        )

        ttk.Label(
            top_tools,
            text="SELECTED NODE",
            style="Section.TLabel",
        ).pack(side="left", padx=(0, 10))

        ttk.Button(
            top_tools,
            text="Додати IP",
            command=self.add_ip_dialog,
            style="Accent.TButton",
        ).pack(side="left", padx=(0, 5))

        ttk.Button(
            top_tools,
            text="Додати MAC",
            command=self.add_mac_dialog,
        ).pack(side="left", padx=(0, 5))

        ttk.Button(
            top_tools,
            text="Видалити IP",
            command=self.remove_selected_ip,
            style="Danger.TButton",
        ).pack(side="left", padx=(0, 5))

        ttk.Button(
            top_tools,
            text="Перейменувати",
            command=self.rename_selected,
        ).pack(side="left")

        ttk.Button(
            top_tools,
            text="Деталі / Історія",
            command=self.open_selected_detail,
        ).pack(
            side="left",
            padx=5,
        )

        ttk.Button(
            top_tools,
            text="Приховати",
            command=self.hide_selected_ip,
        ).pack(
            side="left",
            padx=5,
        )

        ttk.Button(
            top_tools,
            text="Приховані IP",
            command=self.show_hidden_ips_dialog,
        ).pack(
            side="left",
            padx=5,
        )

        ttk.Button(
            top_tools,
            text="Закріпити",
            command=self.toggle_pin_selected_ip,
        ).pack(
            side="left",
            padx=5,
        )

        ttk.Label(
            top_tools,
            text="DOUBLE CLICK  //  OPEN NODE DETAILS",
            style="Section.TLabel",
        ).pack(
            side="right"
        )

        columns = (
            "ip",
            "name",
            "status",
            "mt_port",
            "mt_mac",
            "mt_vendor",
            "mt_host",
            "response",
            "loss",
            "checks",
            "online",
            "offline",
            "last",
        )

        frame = ttk.Frame(
            self.monitor_tab
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=8,
            pady=8,
        )

        scroll = ttk.Scrollbar(
            frame,
            orient="vertical",
        )

        scroll.pack(
            side="right",
            fill="y",
        )

        self.tree = ttk.Treeview(
            frame,
            columns=columns,
            show="tree headings",
            yscrollcommand=scroll.set,
            selectmode="browse",
            style="Monitor.Treeview",
        )

        scroll.config(
            command=self.tree.yview
        )

        self.tree.heading(
            "#0",
            text="",
        )

        self.tree.column(
            "#0",
            width=30,
            stretch=False,
        )

        headings = {
            "ip": "IP-адреса",
            "name": "Назва",
            "status": "Статус",
            "mt_port": "Порт MikroTik",
            "mt_mac": "MAC (RouterOS)",
            "mt_vendor": "Виробник",
            "mt_host": "Hostname",
            "response": "Відповідь / Метод",
            "loss": "Loss",
            "checks": "Перевірки",
            "online": "ONLINE",
            "offline": "OFFLINE",
            "last": "Остання перевірка",
        }

        widths = {
            "ip": 130,
            "name": 140,
            "status": 95,
            "mt_port": 160,
            "mt_mac": 140,
            "mt_vendor": 120,
            "mt_host": 120,
            "response": 160,
            "loss": 75,
            "checks": 80,
            "online": 75,
            "offline": 75,
            "last": 140,
        }

        for col in columns:
            self.tree.heading(
                col,
                text=headings[col],
            )

            self.tree.column(
                col,
                width=widths[col],
                anchor="center",
            )

        self.tree.pack(
            fill="both",
            expand=True,
        )

        self.tree.bind(
            "<Button-1>",
            self.on_tree_click,
        )

        self.tree.bind(
            "<Double-1>",
            self.on_tree_double_click,
        )

        self.tree.bind(
            "<Escape>",
            lambda e: self.clear_tree_selection(),
        )

        self.tree.tag_configure(
            "good",
            foreground=UI_GREEN,
        )

        self.tree.tag_configure(
            "bad",
            foreground=UI_RED,
        )

        self.tree.tag_configure(
            "medium_ping",
            foreground=UI_AMBER,
        )

        self.tree.tag_configure(
            "high_ping",
            foreground=UI_MAGENTA,
        )

        self.tree.tag_configure(
            "unknown",
            foreground=UI_MUTED,
        )

    def build_events_tab(self):
        bar = ttk.Frame(
            self.events_tab,
            style="Toolbar.TFrame",
            padding=(10, 8),
        )

        bar.pack(fill="x")

        ttk.Label(
            bar,
            text="EVENT STREAM",
            style="Section.TLabel",
        ).pack(side="left", padx=(0, 10))

        ttk.Button(
            bar,
            text="Оновити потік",
            command=self.refresh_event_table,
        ).pack(side="left")

        ttk.Button(
            bar,
            text="Очистити екран",
            command=self.clear_event_table,
        ).pack(
            side="left",
            padx=5,
        )

        columns = (
            "time",
            "ip",
            "event",
            "details",
        )

        frame = ttk.Frame(
            self.events_tab
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=8,
            pady=8,
        )

        scroll = ttk.Scrollbar(
            frame,
            orient="vertical",
        )

        scroll.pack(
            side="right",
            fill="y",
        )

        self.events_tree = ttk.Treeview(
            frame,
            columns=columns,
            show="headings",
            yscrollcommand=scroll.set,
        )

        scroll.config(
            command=self.events_tree.yview
        )

        for col, title, width in [
            ("time", "Час", 180),
            ("ip", "IP", 170),
            ("event", "Подія", 200),
            ("details", "Деталі", 600),
        ]:
            self.events_tree.heading(
                col,
                text=title,
            )

            self.events_tree.column(
                col,
                width=width,
            )

        self.events_tree.pack(
            fill="both",
            expand=True,
        )

        self.events_tree.tag_configure(
            "event_info",
            foreground=UI_TEXT,
        )
        self.events_tree.tag_configure(
            "event_good",
            foreground=UI_GREEN,
        )
        self.events_tree.tag_configure(
            "event_warn",
            foreground=UI_AMBER,
        )
        self.events_tree.tag_configure(
            "event_bad",
            foreground=UI_RED,
        )
        self.events_tree.tag_configure(
            "event_security",
            foreground=UI_MAGENTA,
        )

        self.refresh_event_table()

    def run_on_gui(self, callback):
        if not self.closed:
            self.gui_queue.put(
                callback
            )

    def update_runtime_config(self):
        interval = clamp_int(
            self.interval.get(),
            DEFAULT_INTERVAL,
            1,
            3600,
        )

        timeout = clamp_int(
            self.timeout.get(),
            PING_TIMEOUT,
            1,
            60,
        )

        self.interval.set(interval)
        self.timeout.set(timeout)

        with self.config_lock:
            self.interval_seconds = interval
            self.timeout_seconds = timeout

    def get_runtime_config(self):
        with self.config_lock:
            return (
                self.interval_seconds,
                self.timeout_seconds,
            )

    def write_log(
        self,
        text,
        ip=None,
        event="INFO",
    ):
        LOGGER.info(
            "%s | ip=%s | %s",
            event,
            ip or "—",
            text,
        )
        self.db.add_event(
            ip,
            event,
            text,
        )

        def add():
            if (
                self.closed
                or not self.root.winfo_exists()
            ):
                return

            self.log_lines += 1

            if self.log_lines > MAX_LOG_LINES:
                self.log_lines = MAX_LOG_LINES

            if not self.event_refresh_pending:
                self.event_refresh_pending = True

                def refresh_later():
                    self.event_refresh_pending = False

                    if not self.closed:
                        self.refresh_event_table()

                self.root.after(200, refresh_later)

        self.run_on_gui(add)

    def refresh_event_table(self):
        if not hasattr(
            self,
            "events_tree",
        ):
            return

        for item in self.events_tree.get_children():
            self.events_tree.delete(item)

        for (
            ts,
            ip,
            event,
            details,
        ) in self.db.all_events(
            limit=1000
        ):
            event_name = str(event or "").upper()

            if event_name in (
                "ONLINE",
                "START",
                "MAC_RESTORED",
                "MIKROTIK_RESTORED",
            ):
                row_tag = "event_good"
            elif (
                "ERROR" in event_name
                or event_name in (
                    "OFFLINE",
                    "MAC_MISMATCH",
                    "TCP_CLOSED",
                )
            ):
                row_tag = "event_bad"
            elif (
                "SCAN" in event_name
                or "DFIR" in event_name
                or "SECURITY" in event_name
            ):
                row_tag = "event_security"
            elif (
                "WARN" in event_name
                or event_name in (
                    "HIGH_PING",
                    "CONFIG_ERROR",
                )
            ):
                row_tag = "event_warn"
            else:
                row_tag = "event_info"

            self.events_tree.insert(
                "",
                "end",
                values=(
                    datetime.fromtimestamp(
                        ts
                    ).strftime(
                        "%d.%m.%Y %H:%M:%S"
                    ),
                    ip or "—",
                    event,
                    details,
                ),
                tags=(row_tag,),
            )

    def clear_event_table(self):
        for item in self.events_tree.get_children():
            self.events_tree.delete(item)

    def process_gui_queue(self):
        if self.closed:
            return

        try:
            while True:
                action = (
                    self.gui_queue.get_nowait()
                )

                try:
                    action()

                except tk.TclError:
                    if self.closed:
                        return

                except Exception as e:
                    LOGGER.exception("GUI callback failed")
                    self.db.add_event(
                        None,
                        "GUI_ERROR",
                        str(e),
                    )

        except queue.Empty:
            pass

        if not self.closed:
            self.root.after(
                250,
                self.process_gui_queue,
            )

    def load_device_config(self):
        self.device_config = {}

        try:
            if os.path.exists(
                DEVICE_CONFIG_FILE
            ):
                with open(
                    DEVICE_CONFIG_FILE,
                    "r",
                    encoding="utf-8",
                ) as f:
                    data = json.load(f)

                if isinstance(data, dict):
                    self.device_config = data

        except Exception as e:
            self.device_config = {}

            self.write_log(
                "Помилка читання IP_devices.json: "
                + str(e)
            )

    def save_device_config(self):
        try:
            tmp = (
                DEVICE_CONFIG_FILE
                + ".tmp"
            )

            with open(
                tmp,
                "w",
                encoding="utf-8",
            ) as f:
                json.dump(
                    self.device_config,
                    f,
                    ensure_ascii=False,
                    indent=2,
                )

            os.replace(
                tmp,
                DEVICE_CONFIG_FILE,
            )

        except Exception as e:
            self.write_log(
                "Помилка збереження "
                "IP_devices.json: "
                + str(e)
            )

    def apply_device_config(self, host):
        cfg = self.device_config.get(
            host.ip,
            {},
        )

        if not isinstance(cfg, dict):
            cfg = {}

        ports = cfg.get(
            "ports",
            [],
        )

        host.ports = parse_ports(
            ",".join(
                str(x)
                for x in ports
            )
            if isinstance(ports, list)
            else ports
        )

        mac = str(
            cfg.get(
                "mac",
                "",
            )
            or ""
        ).strip().upper().replace(
            "-",
            ":",
        )

        host.expected_mac = (
            mac
            if valid_mac(mac)
            else ""
        )

    def edit_selected_device(self):
        ip = getattr(
            self,
            "selected_ip",
            None,
        )

        if not ip:
            selection = self.tree.selection()

            if selection:
                values = self.tree.item(
                    selection[0],
                    "values",
                )

                if values:
                    ip = values[0]

        if not ip:
            messagebox.showinfo(
                APP_NAME,
                "Виберіть IP.",
                parent=self.root,
            )
            return

        with self.hosts_lock:
            host = self.hosts.get(ip)

        if host is None:
            return

        ports = simpledialog.askstring(
            APP_NAME,
            f"TCP порти для {ip}:\n"
            "Приклад: 80,443,3389\n\n"
            "Порожньо = TCP-перевірка не використовується.",
            initialvalue=",".join(
                str(p)
                for p in host.ports
            ),
            parent=self.root,
        )

        if ports is None:
            return

        parsed_ports = parse_ports(
            ports
        )

        if (
            ports.strip()
            and not parsed_ports
        ):
            messagebox.showerror(
                APP_NAME,
                "Не знайдено коректних TCP-портів.",
                parent=self.root,
            )
            return

        mac = simpledialog.askstring(
            APP_NAME,
            f"Очікувана MAC-адреса для {ip}:\n"
            "Приклад: AA:BB:CC:DD:EE:FF\n\n"
            "Порожньо = MAC не фіксується.",
            initialvalue=host.expected_mac,
            parent=self.root,
        )

        if mac is None:
            return

        mac = (
            mac.strip()
            .upper()
            .replace("-", ":")
        )

        if mac and not valid_mac(mac):
            messagebox.showerror(
                APP_NAME,
                "Некоректна MAC-адреса.\n"
                "Формат: AA:BB:CC:DD:EE:FF",
                parent=self.root,
            )
            return

        host.ports = parsed_ports
        host.expected_mac = mac

        self.device_config[ip] = {
            "ports": parsed_ports,
            "mac": mac,
        }

        self.save_device_config()

        self.write_log(
            f"{ip}: TCP "
            f"[{','.join(map(str, parsed_ports)) or 'N/A'}], "
            f"MAC [{mac or 'N/A'}]",
            ip,
            "CONFIG",
        )

        self.refresh_host_row(host)

    def mikrotik_config_dialog(self):
        from michman_router_support import PLATFORMS, HOME_WEB_PLATFORMS, validate_router_profile

        win = tk.Toplevel(
            self.root
        )
        win.configure(background=UI_BG)

        win.title(
            f"{APP_NAME} — Роутери"
        )

        win.geometry(
            "980x560"
        )

        frame_top = ttk.Frame(
            win,
            padding=5,
        )

        frame_top.pack(
            fill="x"
        )

        tree_cols = (
            "name",
            "host",
            "platform",
            "user",
            "method",
            "port",
        )

        tree = ttk.Treeview(
            win,
            columns=tree_cols,
            show="headings",
        )

        tree.heading(
            "name",
            text="Назва",
        )

        tree.heading(
            "host",
            text="IP / Host",
        )

        tree.heading(
            "platform",
            text="Виробник / ОС",
        )

        tree.heading(
            "user",
            text="Користувач",
        )

        tree.heading(
            "method",
            text="Метод",
        )

        tree.heading(
            "port",
            text="Порт",
        )

        tree.column(
            "name",
            width=120,
        )

        tree.column(
            "host",
            width=150,
        )

        tree.column(
            "platform",
            width=210,
        )

        tree.column(
            "user",
            width=120,
        )

        tree.column(
            "method",
            width=80,
        )

        tree.column(
            "port",
            width=80,
        )

        tree.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5,
        )

        def populate():
            for item in tree.get_children():
                tree.delete(item)

            for item in self.mikrotik_list:
                tree.insert(
                    "",
                    "end",
                    values=(
                        item.get(
                            "name",
                            "",
                        ),
                        item.get(
                            "host",
                            "",
                        ),
                        PLATFORMS.get(
                            item.get("platform", "mikrotik"),
                            (item.get("platform", ""), (), ()),
                        )[0],
                        item.get(
                            "user",
                            "",
                        ),
                        item.get(
                            "method",
                            "REST",
                        ),
                        item.get(
                            "port",
                            443,
                        ),
                    ),
                )

        populate()

        def add_edit_dialog(
            existing=None,
            index=None,
        ):
            sub = tk.Toplevel(win)
            sub.configure(background=UI_BG)

            sub.title(
                "Параметри роутера"
            )

            sub.geometry(
                "620x650"
            )

            ttk.Label(
                sub,
                text="Назва (напр. Router-1):",
            ).pack(
                anchor="w",
                padx=15,
                pady=(10, 2),
            )

            e_name = ttk.Entry(sub)

            if existing:
                e_name.insert(
                    0,
                    existing.get(
                        "name",
                        "",
                    ),
                )

            e_name.pack(
                fill="x",
                padx=15,
            )

            ttk.Label(
                sub,
                text="IP / Hostname:",
            ).pack(
                anchor="w",
                padx=15,
                pady=(5, 2),
            )

            e_host = ttk.Entry(sub)

            if existing:
                e_host.insert(
                    0,
                    existing.get(
                        "host",
                        "",
                    ),
                )

            e_host.pack(
                fill="x",
                padx=15,
            )

            ttk.Label(
                sub,
                text="Виробник / операційна система:",
            ).pack(anchor="w", padx=15, pady=(5, 2))

            platform_keys = list(PLATFORMS)
            platform_labels = [PLATFORMS[key][0] for key in platform_keys]
            cb_platform = ttk.Combobox(
                sub,
                values=platform_labels,
                state="readonly",
            )
            platform_key = existing.get("platform", "mikrotik") if existing else "mikrotik"
            cb_platform.current(platform_keys.index(platform_key) if platform_key in platform_keys else 0)
            cb_platform.pack(fill="x", padx=15)

            ttk.Label(
                sub,
                text="Користувач (необов’язково):",
            ).pack(
                anchor="w",
                padx=15,
                pady=(5, 2),
            )

            e_user = ttk.Entry(sub)

            if existing:
                e_user.insert(
                    0,
                    existing.get(
                        "user",
                        "",
                    ),
                )

            e_user.pack(
                fill="x",
                padx=15,
            )

            ttk.Label(
                sub,
                text="Пароль:",
            ).pack(
                anchor="w",
                padx=15,
                pady=(5, 2),
            )

            e_pass = ttk.Entry(
                sub,
                show="*",
            )

            if existing:
                e_pass.insert(
                    0,
                    existing.get(
                        "password",
                        "",
                    ),
                )

            e_pass.pack(
                fill="x",
                padx=15,
            )

            f_m = ttk.Frame(sub)

            f_m.pack(
                fill="x",
                padx=15,
                pady=8,
            )

            ttk.Label(
                f_m,
                text="Метод:",
            ).pack(side="left")

            cb_m = ttk.Combobox(
                f_m,
                values=[
                    "REST",
                    "SSH",
                    "WEB",
                ],
                state="readonly",
                width=8,
            )

            cb_m.set(
                existing.get(
                    "method",
                    "REST",
                )
                if existing
                else "REST"
            )

            cb_m.pack(
                side="left",
                padx=5,
            )

            legacy_ssh_var = tk.BooleanVar(
                value=bool(existing.get("legacy_ssh", False)) if existing else False
            )
            ttk.Checkbutton(
                sub,
                text="Сумісність зі старим SSH (SHA-1; лише для старих роутерів)",
                variable=legacy_ssh_var,
            ).pack(anchor="w", padx=15, pady=(0, 4))

            ttk.Label(
                sub,
                text="Команда експорту (лише для «Користувацький SSH»):",
            ).pack(anchor="w", padx=15, pady=(4, 2))
            e_command = ttk.Entry(sub)
            if existing:
                e_command.insert(0, existing.get("command", ""))
            e_command.pack(fill="x", padx=15)

            ttk.Label(sub, text="Файл known_hosts (необов’язково):").pack(
                anchor="w", padx=15, pady=(5, 2)
            )
            known_row = ttk.Frame(sub)
            known_row.pack(fill="x", padx=15)
            e_known = ttk.Entry(known_row)
            if existing:
                e_known.insert(0, existing.get("known_hosts", ""))
            e_known.pack(side="left", fill="x", expand=True)
            ttk.Button(
                known_row,
                text="Обрати",
                command=lambda: (
                    (lambda path: (e_known.delete(0, "end"), e_known.insert(0, path)) if path else None)(
                        filedialog.askopenfilename(parent=sub, title="Файл known_hosts")
                    )
                ),
            ).pack(side="left", padx=(6, 0))

            ttk.Label(
                f_m,
                text="Порт:",
            ).pack(
                side="left",
                padx=(10, 0),
            )

            e_port = ttk.Entry(
                f_m,
                width=6,
            )

            e_port.insert(
                0,
                str(
                    existing.get(
                        "port",
                        443,
                    )
                    if existing
                    else 443
                ),
            )

            e_port.pack(
                side="left",
                padx=5,
            )

            verify_peer_var = tk.BooleanVar(
                value=(
                    bool(existing.get("verify_peer", True))
                    if existing
                    else True
                )
            )

            ttk.Checkbutton(
                sub,
                text=(
                    "Перевіряти TLS-сертифікат / SSH host key "
                    "(рекомендовано)"
                ),
                variable=verify_peer_var,
            ).pack(
                anchor="w",
                padx=15,
                pady=(0, 5),
            )

            ttk.Label(
                sub,
                text=(
                    "REST доступний для MikroTik RouterOS. Інші платформи "
                    "підключаються через SSH. Порожнє поле User означає "
                    "автентифікацію лише паролем; для MikroTik використовується admin."
                ),
                foreground=UI_MUTED,
                wraplength=580,
                justify="left",
            ).pack(
                anchor="w",
                padx=15,
            )

            def platform_changed(_event=None):
                key = platform_keys[cb_platform.current()] if cb_platform.current() >= 0 else "auto"
                if key in HOME_WEB_PLATFORMS:
                    cb_m.set("WEB")
                    e_port.delete(0, "end")
                    e_port.insert(0, "80")
                    legacy_ssh_var.set(key in ("mercusys", "tplink_home", "dlink_home", "tenda_home"))
                elif key != "mikrotik" and cb_m.get() in ("REST", "WEB"):
                    cb_m.set("SSH")
                    e_port.delete(0, "end");e_port.insert(0, "22")

            def method_changed(_event=None):
                default = "443" if cb_m.get() == "REST" else "80" if cb_m.get() == "WEB" else "22"
                current = e_port.get().strip()
                if current in ("22", "80", "443", ""):
                    e_port.delete(0, "end");e_port.insert(0, default)

            cb_platform.bind("<<ComboboxSelected>>", platform_changed)
            cb_m.bind("<<ComboboxSelected>>", method_changed)

            def save_entry():
                try:
                    p_val = int(
                        e_port.get().strip()
                    )

                except ValueError:
                    p_val = (
                        443 if cb_m.get() == "REST" else 80 if cb_m.get() == "WEB" else 22
                    )

                if not 1 <= p_val <= 65535:
                    messagebox.showerror(
                        APP_NAME,
                        "Порт має бути в діапазоні 1–65535.",
                        parent=sub,
                    )
                    return

                if not e_host.get().strip():
                    messagebox.showerror(
                        APP_NAME,
                        "Вкажіть IP/hostname роутера.",
                        parent=sub,
                    )
                    return

                if not e_user.get().strip() and not e_pass.get():
                    messagebox.showerror(
                        APP_NAME,
                        "Якщо User порожній, введіть пароль роутера.",
                        parent=sub,
                    )
                    return

                selected_platform = platform_keys[cb_platform.current()]
                if selected_platform != "mikrotik" and cb_m.get() == "REST":
                    messagebox.showerror(
                        APP_NAME,
                        "REST у цьому вікні підтримується лише для MikroTik RouterOS. Для вибраної платформи оберіть SSH.",
                        parent=sub,
                    )
                    return

                item_data = {
                    "name": (
                        e_name.get().strip()
                        or e_host.get().strip()
                    ),
                    "host": e_host.get().strip(),
                    "user": e_user.get().strip(),
                    "password": e_pass.get(),
                    "platform": selected_platform,
                    "auth_mode": "username" if e_user.get().strip() else "password_only",
                    "method": cb_m.get(),
                    "port": p_val,
                    "verify_peer": verify_peer_var.get(),
                    "legacy_ssh": legacy_ssh_var.get(),
                    "known_hosts": e_known.get().strip(),
                    "command": e_command.get().strip(),
                    "id": existing.get("id") if existing else uuid.uuid4().hex,
                }

                if selected_platform != "mikrotik" and cb_m.get() == "SSH":
                    try:
                        validate_router_profile(item_data)
                    except Exception as error:
                        messagebox.showerror(APP_NAME, str(error), parent=sub)
                        return

                if index is not None:
                    self.mikrotik_list[
                        index
                    ] = item_data
                else:
                    self.mikrotik_list.append(
                        item_data
                    )

                self.save_mikrotik_config()
                populate()
                sub.destroy()

            ttk.Button(
                sub,
                text="Зберегти",
                command=save_entry,
            ).pack(
                pady=10
            )

            sub.protocol("WM_DELETE_WINDOW", sub.destroy)
            _show_child_window(
                sub,
                620,
                650,
                min_width=520,
                min_height=560,
                modal=True,
            )

        def add():
            add_edit_dialog()

        def edit():
            sel = tree.selection()

            if not sel:
                return

            idx = tree.index(
                sel[0]
            )

            add_edit_dialog(
                self.mikrotik_list[idx],
                idx,
            )

        def delete():
            sel = tree.selection()

            if not sel:
                return

            idx = tree.index(
                sel[0]
            )

            del self.mikrotik_list[idx]

            self.save_mikrotik_config()
            populate()

        def test_connection():
            sel = tree.selection()
            if not sel:
                messagebox.showinfo(APP_NAME, "Оберіть роутер зі списку.", parent=win)
                return
            config = dict(self.mikrotik_list[tree.index(sel[0])])
            test_button.configure(state="disabled")

            def worker():
                try:
                    details = ""
                    platform = str(config.get("platform", "mikrotik"))
                    if platform == "mikrotik":
                        client = SingleMikroTikClient(
                            config.get("name"), config.get("host"), config.get("user"),
                            config.get("password"), config.get("method", "REST"),
                            config.get("port"), config.get("verify_peer", True), platform,
                            config.get("legacy_ssh", False),
                        )
                        client.get_security_snapshot()
                    elif str(config.get("method", "SSH")).upper() == "WEB":
                        from michman_router_support import HomeRouterWebSession
                        web_info = HomeRouterWebSession(config).probe()
                        details = "\n" + " • ".join(str(web_info.get(key)) for key in ("title", "modelName", "manufacturer", "server") if web_info.get(key))
                    else:
                        from michman_router_support import UniversalRouterSession
                        profile = validate_router_profile({
                            "id": config.get("id", uuid.uuid4().hex),
                            "name": config.get("name", ""), "host": config.get("host", ""),
                            "user": config.get("user", ""), "port": config.get("port", 22),
                            "platform": platform, "known_hosts": config.get("known_hosts", ""),
                            "command": config.get("command", ""),
                            "auth_mode": "username" if config.get("user") else "password_only",
                            "legacy_ssh": config.get("legacy_ssh", False),
                        })
                        with UniversalRouterSession(profile, config.get("password", "")):
                            pass
                    result = None
                except Exception as error:
                    result = str(error)

                def finish():
                    test_button.configure(state="normal")
                    if result:
                        messagebox.showerror(APP_NAME, "З’єднання не встановлено:\n" + result, parent=win)
                    else:
                        messagebox.showinfo(APP_NAME, "З’єднання з роутером успішно встановлено." + details, parent=win)
                if win.winfo_exists():
                    win.after(0, finish)

            threading.Thread(target=worker, daemon=True).start()

        def open_web_panel():
            sel = tree.selection()
            if not sel:
                messagebox.showinfo(APP_NAME, "Оберіть роутер зі списку.", parent=win)
                return
            config = self.mikrotik_list[tree.index(sel[0])]
            port = int(config.get("port") or 80)
            scheme = "https" if port in (443, 8443) else "http"
            default_port = (scheme == "http" and port == 80) or (scheme == "https" and port == 443)
            url = f"{scheme}://{config.get('host')}" + ("" if default_port else f":{port}")
            import webbrowser
            webbrowser.open(url)

        f_btns = ttk.Frame(
            win,
            padding=5,
        )

        f_btns.pack(
            fill="x"
        )

        ttk.Button(
            f_btns,
            text="Додати",
            command=add,
        ).pack(
            side="left",
            padx=5,
        )

        ttk.Button(
            f_btns,
            text="Редагувати",
            command=edit,
        ).pack(
            side="left",
            padx=5,
        )

        ttk.Button(
            f_btns,
            text="Видалити",
            command=delete,
        ).pack(
            side="left",
            padx=5,
        )

        ttk.Button(
            top_tools,
            text="Визначити",
            command=self.reidentify_selected_device,
        ).pack(side="left", padx=5)

        ttk.Button(
            top_tools,
            text="Копіювати",
            command=self.copy_selected_device_card,
        ).pack(side="left", padx=5)

        test_button = ttk.Button(
            f_btns,
            text="Перевірити з’єднання",
            command=test_connection,
        )
        test_button.pack(side="left", padx=5)

        ttk.Button(
            f_btns,
            text="Відкрити веб-панель",
            command=open_web_panel,
        ).pack(side="left", padx=5)

        ttk.Button(
            f_btns,
            text="Центр безпеки",
            command=lambda: (
                win.destroy(),
                self.open_mikrotik_security_center(),
            ),
            style="Accent.TButton",
        ).pack(
            side="right",
            padx=5,
        )

        win.protocol("WM_DELETE_WINDOW", win.destroy)
        _show_child_window(
            win,
            980,
            560,
            min_width=760,
            min_height=420,
        )

    def open_mikrotik_security_center(self):
        mikrotik_configs = [
            item for item in self.mikrotik_list
            if str(item.get("platform", "mikrotik")).lower() == "mikrotik"
        ]
        if not mikrotik_configs:
            messagebox.showinfo(
                APP_NAME,
                "Спочатку додайте MikroTik та вкажіть логін і пароль.",
                parent=self.root,
            )
            return

        win = tk.Toplevel(self.root)
        win.configure(background=UI_BG)
        win.title(f"{APP_NAME} — MikroTik Security Center")
        win.geometry("1260x790")
        win.minsize(980, 650)

        state = {
            "snapshot": None,
            "busy": False,
        }

        self.ui_style.configure(
            "SecurityScore.TLabel",
            background=UI_HEADER,
            foreground=UI_GREEN,
            font=("Cascadia Mono", 22, "bold"),
        )
        self.ui_style.configure(
            "SecurityTitle.TLabel",
            background=UI_HEADER,
            foreground=UI_CYAN,
            font=("Segoe UI Semibold", 17),
        )

        header = ttk.Frame(
            win,
            style="Header.TFrame",
            padding=(16, 12),
        )
        header.pack(fill="x")

        title_box = ttk.Frame(header, style="Header.TFrame")
        title_box.pack(side="left")
        ttk.Label(
            title_box,
            text="◈  MIKROTIK SECURITY CENTER",
            style="SecurityTitle.TLabel",
        ).pack(anchor="w")
        ttk.Label(
            title_box,
            text="AUDIT  •  SERVICES  •  FIREWALL  •  USERS",
            style="BrandSub.TLabel",
        ).pack(anchor="w")

        score_var = tk.StringVar(value="— / 100")
        ttk.Label(
            header,
            textvariable=score_var,
            style="SecurityScore.TLabel",
        ).pack(side="right", padx=(12, 2))
        ttk.Label(
            header,
            text="SECURITY SCORE",
            style="BrandSub.TLabel",
        ).pack(side="right")

        controls = ttk.Frame(
            win,
            style="Toolbar.TFrame",
            padding=(12, 9),
        )
        controls.pack(fill="x", pady=(1, 0))

        ttk.Label(
            controls,
            text="ROUTER",
            style="Section.TLabel",
        ).pack(side="left", padx=(0, 8))

        router_values = [
            f"{item.get('name') or item.get('host')}  //  {item.get('host')}"
            for item in mikrotik_configs
        ]
        router_combo = ttk.Combobox(
            controls,
            values=router_values,
            state="readonly",
            width=34,
        )
        router_combo.current(0)
        router_combo.pack(side="left", padx=(0, 8))

        status_var = tk.StringVar(value="Оберіть роутер та натисніть Оновити")

        notebook = ttk.Notebook(win)
        notebook.pack(fill="both", expand=True, padx=12, pady=(10, 7))

        audit_tab = ttk.Frame(notebook)
        services_tab = ttk.Frame(notebook)
        firewall_tab = ttk.Frame(notebook)
        users_tab = ttk.Frame(notebook)
        notebook.add(audit_tab, text="  АУДИТ  ")
        notebook.add(services_tab, text="  СЛУЖБИ  ")
        notebook.add(firewall_tab, text="  FIREWALL  ")
        notebook.add(users_tab, text="  КОРИСТУВАЧІ  ")

        identity_var = tk.StringVar(value="ROUTER // очікування даних")
        ttk.Label(
            audit_tab,
            textvariable=identity_var,
            foreground=UI_CYAN,
            font=("Cascadia Mono", 10, "bold"),
            padding=(8, 10),
        ).pack(fill="x")

        findings_frame = ttk.Frame(audit_tab)
        findings_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        findings_columns = ("severity", "title", "details")
        findings_tree = ttk.Treeview(
            findings_frame,
            columns=findings_columns,
            show="headings",
        )
        for column, label, width in (
            ("severity", "Ризик", 100),
            ("title", "Перевірка", 330),
            ("details", "Рекомендація", 650),
        ):
            findings_tree.heading(column, text=label)
            findings_tree.column(
                column,
                width=width,
                minwidth=80,
                stretch=(column == "details"),
            )
        findings_scroll = ttk.Scrollbar(
            findings_frame,
            orient="vertical",
            command=findings_tree.yview,
        )
        findings_tree.configure(yscrollcommand=findings_scroll.set)
        findings_tree.pack(side="left", fill="both", expand=True)
        findings_scroll.pack(side="right", fill="y")
        findings_tree.tag_configure("critical", foreground=UI_RED)
        findings_tree.tag_configure("high", foreground="#FF7A8F")
        findings_tree.tag_configure("medium", foreground=UI_AMBER)
        findings_tree.tag_configure("good", foreground=UI_GREEN)

        def table(parent, columns):
            frame = ttk.Frame(parent)
            frame.pack(fill="both", expand=True, padx=8, pady=8)
            widget = ttk.Treeview(frame, columns=tuple(columns), show="headings")
            vertical = ttk.Scrollbar(
                frame,
                orient="vertical",
                command=widget.yview,
            )
            horizontal = ttk.Scrollbar(
                frame,
                orient="horizontal",
                command=widget.xview,
            )
            widget.configure(
                yscrollcommand=vertical.set,
                xscrollcommand=horizontal.set,
            )
            widget.grid(row=0, column=0, sticky="nsew")
            vertical.grid(row=0, column=1, sticky="ns")
            horizontal.grid(row=1, column=0, sticky="ew")
            frame.rowconfigure(0, weight=1)
            frame.columnconfigure(0, weight=1)
            return widget

        service_columns = (
            "name", "port", "state", "address", "tls", "certificate",
        )
        services_tree = table(services_tab, service_columns)
        for column, label, width in (
            ("name", "Служба", 110),
            ("port", "Порт", 70),
            ("state", "Стан", 100),
            ("address", "Дозволені адреси", 360),
            ("tls", "TLS", 110),
            ("certificate", "Сертифікат", 230),
        ):
            services_tree.heading(column, text=label)
            services_tree.column(column, width=width, minwidth=60)
        services_tree.tag_configure("enabled", foreground=UI_GREEN)
        services_tree.tag_configure("disabled", foreground=UI_MUTED)
        services_tree.tag_configure("risky", foreground=UI_RED)

        firewall_columns = (
            "ref", "chain", "action", "protocol", "src", "dst",
            "port", "state", "comment",
        )
        firewall_tree = table(firewall_tab, firewall_columns)
        for column, label, width in (
            ("ref", "ID", 70),
            ("chain", "Chain", 85),
            ("action", "Action", 85),
            ("protocol", "Proto", 70),
            ("src", "Src address", 155),
            ("dst", "Dst address", 155),
            ("port", "Dst port", 100),
            ("state", "Стан", 95),
            ("comment", "Коментар", 300),
        ):
            firewall_tree.heading(column, text=label)
            firewall_tree.column(column, width=width, minwidth=55)
        firewall_tree.tag_configure("drop", foreground=UI_RED)
        firewall_tree.tag_configure("accept", foreground=UI_GREEN)
        firewall_tree.tag_configure("disabled", foreground=UI_MUTED)

        users_columns = ("name", "group", "state", "last")
        users_tree = table(users_tab, users_columns)
        for column, label, width in (
            ("name", "Користувач", 240),
            ("group", "Група", 180),
            ("state", "Стан", 130),
            ("last", "Останній вхід", 350),
        ):
            users_tree.heading(column, text=label)
            users_tree.column(column, width=width, minwidth=80)
        users_tree.tag_configure("enabled", foreground=UI_GREEN)
        users_tree.tag_configure("disabled", foreground=UI_MUTED)
        users_tree.tag_configure("admin", foreground=UI_AMBER)

        services_buttons = ttk.Frame(services_tab, style="Toolbar.TFrame")
        services_buttons.pack(fill="x", before=services_tree.master, padx=8)
        firewall_buttons = ttk.Frame(firewall_tab, style="Toolbar.TFrame")
        firewall_buttons.pack(fill="x", before=firewall_tree.master, padx=8)
        users_buttons = ttk.Frame(users_tab, style="Toolbar.TFrame")
        users_buttons.pack(fill="x", before=users_tree.master, padx=8)

        def current_client():
            index = router_combo.current()
            if index < 0 or index >= len(mikrotik_configs):
                raise RuntimeError("Оберіть MikroTik зі списку.")
            config = mikrotik_configs[index]
            client = SingleMikroTikClient(
                config.get("name", config.get("host", "MikroTik")),
                config.get("host", ""),
                config.get("user", ""),
                config.get("password", ""),
                config.get("method", "REST"),
                config.get("port"),
                config.get("verify_peer", True),
                "mikrotik",
            )
            if not client.is_configured():
                raise RuntimeError("Не заповнено IP/hostname або користувача.")
            return client

        def clear_tree(widget):
            for item in widget.get_children():
                widget.delete(item)

        def populate(snapshot):
            if not win.winfo_exists():
                return
            state["snapshot"] = snapshot
            assessment = snapshot.get("assessment", {})
            score = int(assessment.get("score", 0))
            score_var.set(f"{score} / 100")
            score_style = UI_GREEN if score >= 80 else UI_AMBER if score >= 50 else UI_RED
            self.ui_style.configure("SecurityScore.TLabel", foreground=score_style)

            identity = snapshot.get("identity", {})
            resource = snapshot.get("resource", {})
            router_name = identity.get("name") or snapshot.get("router") or "MikroTik"
            version = resource.get("version", "—")
            board = resource.get("board-name", resource.get("platform", "—"))
            identity_var.set(
                f"ROUTER // {router_name}    VERSION // {version}    BOARD // {board}"
            )

            clear_tree(findings_tree)
            findings = assessment.get("findings", [])
            if not findings:
                findings_tree.insert(
                    "",
                    "end",
                    values=("OK", "Критичних відхилень не знайдено", "Перевірте політики вручну."),
                    tags=("good",),
                )
            for finding in findings:
                severity = str(finding.get("severity", "medium"))
                findings_tree.insert(
                    "",
                    "end",
                    values=(
                        severity.upper(),
                        finding.get("title", ""),
                        finding.get("details", ""),
                    ),
                    tags=(severity,),
                )

            clear_tree(services_tree)
            risky_names = {"telnet", "ftp", "www", "api"}
            for item in snapshot.get("services", []):
                name = str(item.get("name", ""))
                disabled = SingleMikroTikClient._is_disabled(item)
                tag = "disabled" if disabled else (
                    "risky" if name.lower() in risky_names else "enabled"
                )
                services_tree.insert(
                    "",
                    "end",
                    values=(
                        name,
                        item.get("port", "—"),
                        "DISABLED" if disabled else "ENABLED",
                        item.get("address", "") or "ALL / FIREWALL",
                        item.get("tls-version", "—"),
                        item.get("certificate", "—"),
                    ),
                    tags=(tag,),
                )

            clear_tree(firewall_tree)
            for item in snapshot.get("firewall_rules", []):
                disabled = SingleMikroTikClient._is_disabled(item)
                reference = item.get(".id") or item.get(".number") or ""
                action = str(item.get("action", ""))
                tag = "disabled" if disabled else (
                    "drop" if action in ("drop", "reject") else "accept"
                )
                firewall_tree.insert(
                    "",
                    "end",
                    values=(
                        reference,
                        item.get("chain", ""),
                        action,
                        item.get("protocol", "any"),
                        item.get("src-address", "any"),
                        item.get("dst-address", "any"),
                        item.get("dst-port", "any"),
                        "DISABLED" if disabled else "ENABLED",
                        item.get("comment", ""),
                    ),
                    tags=(tag,),
                )

            clear_tree(users_tree)
            for item in snapshot.get("users", []):
                name = str(item.get("name", ""))
                disabled = SingleMikroTikClient._is_disabled(item)
                tag = "disabled" if disabled else (
                    "admin" if name.lower() == "admin" else "enabled"
                )
                users_tree.insert(
                    "",
                    "end",
                    values=(
                        name,
                        item.get("group", "—"),
                        "DISABLED" if disabled else "ENABLED",
                        item.get("last-logged-in", item.get("last-seen", "—")),
                    ),
                    tags=(tag,),
                )

            errors = snapshot.get("errors", [])
            status_var.set(
                "Аудит завершено"
                if not errors
                else "Частковий аудит: " + "; ".join(errors[:2])
            )
            state["busy"] = False

        def refresh_snapshot():
            if state["busy"]:
                return
            try:
                client = current_client()
            except Exception as error:
                messagebox.showerror(APP_NAME, str(error), parent=win)
                return
            state["busy"] = True
            status_var.set(f"Підключення до {client.name}…")

            def worker():
                try:
                    snapshot = client.get_security_snapshot()
                    self.run_on_gui(lambda s=snapshot: populate(s))
                except Exception as error:
                    def failed(message=str(error)):
                        state["busy"] = False
                        status_var.set("Помилка підключення")
                        messagebox.showerror(
                            f"{APP_NAME} — MikroTik",
                            message,
                            parent=win,
                        )
                    self.run_on_gui(failed)

            threading.Thread(
                target=worker,
                daemon=True,
                name="MikroTikSecurityAudit",
            ).start()

        def save_snapshot_local(notify=True):
            snapshot = state.get("snapshot")
            if not snapshot:
                if notify:
                    messagebox.showinfo(
                        APP_NAME,
                        "Спочатку виконайте аудит.",
                        parent=win,
                    )
                return None
            directory = os.path.join(BASE_DIR, "MikroTik_Audits")
            os.makedirs(directory, exist_ok=True)
            router_name = re.sub(
                r"[^A-Za-z0-9_.-]+",
                "_",
                str(snapshot.get("router") or snapshot.get("host") or "router"),
            ).strip("_") or "router"
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join(directory, f"{router_name}_{stamp}.json")
            temporary = path + ".tmp"
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(snapshot, handle, ensure_ascii=False, indent=2)
            os.replace(temporary, path)
            if notify:
                messagebox.showinfo(
                    APP_NAME,
                    f"Знімок аудиту збережено:\n{path}",
                    parent=win,
                )
            return path

        def perform_change(description, operation):
            if state["busy"]:
                return
            try:
                client = current_client()
                save_snapshot_local(notify=False)
            except Exception as error:
                messagebox.showerror(APP_NAME, str(error), parent=win)
                return

            state["busy"] = True
            status_var.set(description + "…")

            def worker():
                backup_name = ""
                backup_warning = ""
                try:
                    try:
                        backup_name = client.create_router_export()
                    except Exception as backup_error:
                        backup_warning = str(backup_error)
                    operation(client)
                    snapshot = client.get_security_snapshot()

                    def completed():
                        populate(snapshot)
                        self.write_log(
                            f"MikroTik {client.name}: {description}",
                            event="MIKROTIK_SECURITY_CHANGE",
                        )
                        details = "Зміни застосовано."
                        if backup_name:
                            details += f"\nПеред змінами створено {backup_name} на роутері."
                        elif backup_warning:
                            details += (
                                "\nУвага: export на роутері створити не вдалося: "
                                + backup_warning
                            )
                        messagebox.showinfo(
                            f"{APP_NAME} — MikroTik",
                            details,
                            parent=win,
                        )
                    self.run_on_gui(completed)
                except Exception as error:
                    def failed(message=str(error)):
                        state["busy"] = False
                        status_var.set("Зміни не застосовано")
                        messagebox.showerror(
                            f"{APP_NAME} — MikroTik",
                            message,
                            parent=win,
                        )
                    self.run_on_gui(failed)

            threading.Thread(
                target=worker,
                daemon=True,
                name="MikroTikSecurityChange",
            ).start()

        def selected_values(widget):
            selection = widget.selection()
            if not selection:
                return None
            return widget.item(selection[0], "values")

        def change_service(disabled):
            values = selected_values(services_tree)
            if not values:
                messagebox.showinfo(APP_NAME, "Виберіть службу.", parent=win)
                return
            name = str(values[0])
            try:
                client = current_client()
            except Exception as error:
                messagebox.showerror(APP_NAME, str(error), parent=win)
                return
            if disabled and (
                (client.method == "SSH" and name == "ssh")
                or (client.method == "REST" and name in ("www", "www-ssl"))
            ):
                messagebox.showwarning(
                    APP_NAME,
                    "Ця служба використовується поточним з’єднанням. "
                    "Її вимкнення з цього вікна заблоковано.",
                    parent=win,
                )
                return
            action = "вимкнути" if disabled else "увімкнути"
            if not messagebox.askyesno(
                f"{APP_NAME} — Підтвердження",
                f"{action.capitalize()} службу {name}?",
                parent=win,
            ):
                return
            perform_change(
                f"{action.capitalize()} службу {name}",
                lambda c: c.set_service_disabled(name, disabled),
            )

        def restrict_service():
            values = selected_values(services_tree)
            if not values:
                messagebox.showinfo(APP_NAME, "Виберіть службу.", parent=win)
                return
            name = str(values[0])
            current = "" if values[3] == "ALL / FIREWALL" else str(values[3])
            value = simpledialog.askstring(
                f"{APP_NAME} — Дозволені адреси",
                "Вкажіть IP/підмережі через кому.\n"
                "Приклад: 192.168.88.0/24,10.10.0.5/32\n\n"
                "Порожнє поле прибере обмеження служби.",
                initialvalue=current,
                parent=win,
            )
            if value is None:
                return
            warning = (
                "Прибрати обмеження адрес?"
                if not value.strip()
                else f"Дозволити доступ до {name} лише з:\n{value.strip()}?"
            )
            if not messagebox.askyesno(
                f"{APP_NAME} — Підтвердження",
                warning + "\n\nНеправильна підмережа може заблокувати ваш доступ.",
                parent=win,
            ):
                return
            perform_change(
                f"Змінити дозволені адреси служби {name}",
                lambda c: c.set_service_addresses(name, value),
            )

        def toggle_rule():
            values = selected_values(firewall_tree)
            if not values:
                messagebox.showinfo(APP_NAME, "Виберіть firewall-правило.", parent=win)
                return
            reference = str(values[0])
            currently_disabled = str(values[7]) == "DISABLED"
            new_disabled = not currently_disabled
            action = "вимкнути" if new_disabled else "увімкнути"
            if not messagebox.askyesno(
                f"{APP_NAME} — Підтвердження",
                f"{action.capitalize()} правило {reference}?\n\n"
                "Зміна firewall може вплинути на доступ до роутера.",
                parent=win,
            ):
                return
            perform_change(
                f"{action.capitalize()} firewall-правило {reference}",
                lambda c: c.set_firewall_rule_disabled(reference, new_disabled),
            )

        def add_rule_dialog():
            dialog = tk.Toplevel(win)
            dialog.configure(background=UI_BG)
            dialog.title(f"{APP_NAME} — Нове firewall-правило")
            dialog.geometry("570x590")
            dialog.transient(win)

            body = ttk.Frame(dialog, padding=18)
            body.pack(fill="both", expand=True)
            ttk.Label(
                body,
                text="NEW FIREWALL FILTER RULE",
                foreground=UI_CYAN,
                font=("Cascadia Mono", 13, "bold"),
            ).pack(anchor="w", pady=(0, 12))

            fields = {}

            def add_combo(label, values, default):
                ttk.Label(body, text=label).pack(anchor="w", pady=(5, 2))
                widget = ttk.Combobox(body, values=values, state="readonly")
                widget.set(default)
                widget.pack(fill="x")
                fields[label] = widget

            def add_entry(label, default=""):
                ttk.Label(body, text=label).pack(anchor="w", pady=(5, 2))
                widget = ttk.Entry(body)
                widget.insert(0, default)
                widget.pack(fill="x")
                fields[label] = widget

            add_combo("Chain", ["input", "forward", "output"], "input")
            add_combo("Action", ["accept", "drop", "reject"], "accept")
            add_combo("Protocol", ["", "tcp", "udp", "icmp"], "tcp")
            add_entry("Src address", "")
            add_entry("Dst address", "")
            add_entry("Dst port", "")
            add_entry("Comment", "MICHMAN KP security rule")

            ttk.Label(
                body,
                text=(
                    "Правило буде додано в кінець списку. Після додавання "
                    "перевірте його порядок у WinBox."
                ),
                foreground=UI_AMBER,
                wraplength=520,
                justify="left",
            ).pack(anchor="w", pady=(14, 8))

            def save_rule():
                parameters = {
                    "chain": fields["Chain"].get(),
                    "action": fields["Action"].get(),
                    "protocol": fields["Protocol"].get(),
                    "src_address": fields["Src address"].get(),
                    "dst_address": fields["Dst address"].get(),
                    "dst_port": fields["Dst port"].get(),
                    "comment": fields["Comment"].get(),
                }
                if not messagebox.askyesno(
                    f"{APP_NAME} — Підтвердження",
                    "Додати це правило до MikroTik?\n\n"
                    "Помилкове правило chain=input може заблокувати керування.",
                    parent=dialog,
                ):
                    return
                dialog.destroy()
                perform_change(
                    "Додати firewall-правило",
                    lambda c: c.add_firewall_rule(**parameters),
                )

            footer = ttk.Frame(body)
            footer.pack(fill="x", pady=(8, 0))
            ttk.Button(
                footer,
                text="Додати правило",
                command=save_rule,
                style="Accent.TButton",
            ).pack(side="left")
            ttk.Button(
                footer,
                text="Скасувати",
                command=dialog.destroy,
            ).pack(side="right")

            dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)
            _show_child_window(
                dialog,
                570,
                590,
                min_width=500,
                min_height=500,
                modal=True,
            )

        def change_user(disabled):
            values = selected_values(users_tree)
            if not values:
                messagebox.showinfo(APP_NAME, "Виберіть користувача.", parent=win)
                return
            name = str(values[0])
            try:
                client = current_client()
            except Exception as error:
                messagebox.showerror(APP_NAME, str(error), parent=win)
                return
            if disabled and name == client.user:
                messagebox.showwarning(
                    APP_NAME,
                    "Поточний обліковий запис з’єднання вимкнути не можна.",
                    parent=win,
                )
                return
            action = "вимкнути" if disabled else "увімкнути"
            if not messagebox.askyesno(
                f"{APP_NAME} — Підтвердження",
                f"{action.capitalize()} користувача {name}?",
                parent=win,
            ):
                return
            perform_change(
                f"{action.capitalize()} користувача {name}",
                lambda c: c.set_user_disabled(name, disabled),
            )

        def create_export():
            if state["busy"]:
                return
            try:
                client = current_client()
            except Exception as error:
                messagebox.showerror(APP_NAME, str(error), parent=win)
                return
            state["busy"] = True
            status_var.set("Створення export без паролів…")

            def worker():
                try:
                    name = client.create_router_export()

                    def completed():
                        state["busy"] = False
                        status_var.set("Export створено")
                        messagebox.showinfo(
                            f"{APP_NAME} — MikroTik",
                            f"На роутері створено файл {name}",
                            parent=win,
                        )
                    self.run_on_gui(completed)
                except Exception as error:
                    def failed(message=str(error)):
                        state["busy"] = False
                        status_var.set("Export не створено")
                        messagebox.showerror(APP_NAME, message, parent=win)
                    self.run_on_gui(failed)

            threading.Thread(
                target=worker,
                daemon=True,
                name="MikroTikExport",
            ).start()

        ttk.Button(
            controls,
            text="Оновити аудит",
            command=refresh_snapshot,
            style="Accent.TButton",
        ).pack(side="left", padx=3)
        ttk.Button(
            controls,
            text="Зберегти JSON",
            command=save_snapshot_local,
        ).pack(side="left", padx=3)
        ttk.Button(
            controls,
            text="Export на роутері",
            command=create_export,
        ).pack(side="left", padx=3)

        ttk.Button(
            services_buttons,
            text="Увімкнути",
            command=lambda: change_service(False),
        ).pack(side="left", padx=3, pady=7)
        ttk.Button(
            services_buttons,
            text="Вимкнути",
            command=lambda: change_service(True),
            style="Danger.TButton",
        ).pack(side="left", padx=3, pady=7)
        ttk.Button(
            services_buttons,
            text="Обмежити адреси",
            command=restrict_service,
        ).pack(side="left", padx=3, pady=7)

        ttk.Button(
            firewall_buttons,
            text="Увімкнути / вимкнути правило",
            command=toggle_rule,
        ).pack(side="left", padx=3, pady=7)
        ttk.Button(
            firewall_buttons,
            text="Додати правило",
            command=add_rule_dialog,
            style="Accent.TButton",
        ).pack(side="left", padx=3, pady=7)

        ttk.Button(
            users_buttons,
            text="Увімкнути користувача",
            command=lambda: change_user(False),
        ).pack(side="left", padx=3, pady=7)
        ttk.Button(
            users_buttons,
            text="Вимкнути користувача",
            command=lambda: change_user(True),
            style="Danger.TButton",
        ).pack(side="left", padx=3, pady=7)

        status_bar = ttk.Label(
            win,
            textvariable=status_var,
            style="StatusBar.TLabel",
        )
        status_bar.pack(fill="x")

        router_combo.bind("<<ComboboxSelected>>", lambda _event: refresh_snapshot())
        win.after(150, refresh_snapshot)
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        _show_child_window(
            win,
            1260,
            790,
            min_width=980,
            min_height=650,
        )

    def _update_device_label(self):
        labels = {
            "uk": "ПРИСТРОЇ",
            "en": "DEVICES",
            "pl": "URZĄDZENIA",
            "de": "GERÄTE",
            "es": "DISPOSITIVOS",
        }
        node_labels = {
            "uk": "вузлів",
            "en": "nodes",
            "pl": "węzłów",
            "de": "Knoten",
            "es": "nodos",
        }
        count = len(getattr(self, "hosts", {}))
        hidden = len(getattr(self, "hidden_ips", set()) & set(self.hosts))
        text = f"{labels.get(I18N.code, labels['en'])}  //  {count} {node_labels.get(I18N.code, 'nodes')}"
        if hidden:
            hidden_labels = {
                "uk": "приховано",
                "en": "hidden",
                "pl": "ukryte",
                "de": "ausgeblendet",
                "es": "ocultos",
            }
            text += f"  //  {hidden_labels.get(I18N.code, 'hidden')} {hidden}"
        try:
            self.file_label.config(text=text)
        except (AttributeError, tk.TclError):
            pass

    def _get_local_default_gateways(self):
        """Read the Windows route table only; no packet is sent to any host."""
        cached_at, cached = getattr(self, "_default_gateway_cache", (0.0, set()))
        if time.time() - float(cached_at or 0) < 60:
            return set(cached)
        gateways = set()
        if sys.platform.startswith("win"):
            try:
                completed = subprocess.run(
                    ["route.exe", "print", "-4"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=5,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
                )
                for line in (completed.stdout or "").splitlines():
                    match = re.match(r"^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+(\d{1,3}(?:\.\d{1,3}){3})\s+", line)
                    if match and valid_ipv4(match.group(1)) and match.group(1) != "0.0.0.0":
                        gateways.add(match.group(1))
            except (OSError, subprocess.SubprocessError):
                pass
        self._default_gateway_cache = (time.time(), gateways)
        return gateways

    def classify_host_passively(self, host):
        """Classify from local/configured evidence without contacting the endpoint."""
        ip = str(host.ip or "").strip()
        name = " ".join(
            value for value in (
                str(host.name or "").strip(),
                str(host.mt_hostname or "").strip().replace("—", ""),
                str(host.dns_name or "").strip().replace("—", ""),
            ) if value
        ).casefold()
        cached_mac = str(host.mt_mac or host.current_mac or "").strip().replace("—", "")
        if not cached_mac:
            # Reading the OS ARP cache is passive: this command does not send a
            # packet to the monitored endpoint.
            cached_mac = get_arp_mac(ip) or ""
        vendor = str(host.mt_vendor or "").strip().replace("—", "")
        if not vendor and cached_mac:
            vendor = get_mac_vendor(cached_mac) or ""
        vendor = vendor.casefold()

        if ip in self._get_local_default_gateways():
            result = ("Роутер", "HIGH", "IP є шлюзом за замовчуванням у локальній таблиці маршрутів Windows.")
        else:
            configured_router_ips = {
                str(item.get("host") or "").strip()
                for item in getattr(self, "mikrotik_list", [])
                if isinstance(item, dict) and valid_ipv4(str(item.get("host") or "").strip())
            }
            router_name_tokens = ("router", "gateway", "openwrt", "routeros", "mikrotik", "tplink", "tp-link", "archer", "deco", "unifi", "edge-router")
            computer_name_tokens = ("desktop-", "laptop-", "notebook", "workstation", "server-", "windows-pc", "win-pc", "computer")
            network_vendors = ("mikrotik", "ubiquiti", "cisco", "juniper", "tp-link", "mercusys", "netgear", "zyxel", "d-link", "aruba", "fortinet")
            computer_vendors = ("dell", "lenovo", "hewlett", "intel corporate", "acer", "micro-star", "gigabyte")

            if ip in configured_router_ips:
                result = ("Роутер", "HIGH", "IP збережений у налаштуваннях авторизованого роутера.")
            elif any(token in name for token in router_name_tokens):
                result = ("Роутер", "MEDIUM", "Збережене або отримане від роутера ім’я має ознаки мережевого шлюзу.")
            elif any(token in name for token in computer_name_tokens):
                result = ("Комп’ютер", "MEDIUM", "Збережене або DHCP-ім’я має типову ознаку комп’ютера.")
            elif any(token in vendor for token in network_vendors):
                result = ("Роутер", "MEDIUM", "MAC-виробник пов’язаний із мережевим обладнанням; модель пристрою не підтверджена.")
            elif name and any(token in vendor for token in computer_vendors):
                result = ("Комп’ютер", "MEDIUM", "Поєднання DHCP-імені та MAC-виробника відповідає типовому комп’ютеру.")
            else:
                result = ("Невідомий", "LOW", "Пасивних локальних даних недостатньо для надійного визначення.")

        host.device_kind, host.device_kind_confidence, host.device_kind_reason = result
        return {
            "kind": result[0],
            "confidence": result[1],
            "reason": result[2],
        }

    @staticmethod
    def _windows_identity(raw_os):
        raw_os = str(raw_os or "").strip()
        match = re.search(r"Windows[- ](\d+)[- ]([0-9.]+)", raw_os, re.I)
        if match:
            return f"Windows {match.group(1)} ({match.group(2)})"
        return raw_os.replace("-", " ") if raw_os else ""

    def _hostname_identity(self, host, snapshot=None):
        snapshot = snapshot or host.snapshot()
        identity = str(snapshot.get("device_identity") or "").strip()
        if not identity:
            kind = snapshot.get("device_kind")
            if kind == "Роутер":
                identity = "Роутер — модель невідома"
            elif kind == "Комп’ютер":
                identity = "Комп’ютер — ОС/версія невідомі"
            else:
                identity = "Невідомий пристрій"
        hostname = str(snapshot.get("mt_hostname") or "").strip()
        return f"{hostname} / {identity}" if hostname not in ("", "—") and hostname.casefold() not in identity.casefold() else identity

    def identify_host_active(self, host):
        """Use only bounded identity requests to the newly added address."""
        identity = ""
        reason = ""
        source = ""
        with host.lock:
            host.device_identification_last_attempt = time.time()

        # A managed agent provides the authoritative Windows version over mTLS.
        try:
            endpoints = self.platform_core.setting("endpoints", [])
            endpoint = next(
                (item for item in endpoints if str(item.get("host") or "").strip() == host.ip),
                None,
            )
            ssl_context = (self.identity_session or {}).get("ssl_context")
            if endpoint and ssl_context:
                from michman_agent import AgentClient
                telemetry = AgentClient(
                    host.ip,
                    int(endpoint.get("port") or 8743),
                    ssl_context,
                ).call("telemetry", timeout=10)
                os_identity = self._windows_identity(telemetry.get("os"))
                if os_identity:
                    identity = os_identity
                    source = "mTLS агент"
                    reason = "Точну версію ОС повідомив авторизований агент mTLS."
                    host.device_kind = "Комп’ютер"
                    host.device_kind_confidence = "HIGH"
                    self.platform_core.ingest(host.ip, telemetry, telemetry.get("name"))
        except Exception as error:
            self.write_log(f"{host.ip}: агент не надав дані ОС: {error}", host.ip, "IDENTITY_INFO")

        profile = next(
            (item for item in getattr(self, "mikrotik_list", [])
             if isinstance(item, dict) and str(item.get("host") or "").strip() == host.ip),
            None,
        )
        if not identity and profile:
            try:
                platform_key = str(profile.get("platform") or "auto").strip()
                if platform_key == "mikrotik":
                    client = SingleMikroTikClient(
                        profile.get("name"), host.ip, profile.get("user"), profile.get("password"),
                        profile.get("method", "REST"), profile.get("port"), profile.get("verify_peer", True),
                        platform_key, profile.get("legacy_ssh", False),
                    )
                    snapshot = client.get_security_snapshot()
                    resource = snapshot.get("resource") or {}
                    model = str(resource.get("board-name") or resource.get("platform") or "").strip()
                    version = str(resource.get("version") or "").strip()
                    details = " ".join(part for part in (model, f"RouterOS {version}" if version else "") if part)
                    identity = f"MikroTik {details}".strip() if details else "MikroTik RouterOS"
                    source = "RouterOS API/SSH"
                else:
                    from michman_router_support import HOME_WEB_PLATFORMS, PLATFORMS, HomeRouterWebSession
                    details = []
                    if platform_key in HOME_WEB_PLATFORMS:
                        found = HomeRouterWebSession(profile).probe()
                        details = [str(found.get(key) or "").strip() for key in ("manufacturer", "modelName", "modelNumber")]
                    details = [item for item in details if item]
                    identity = " ".join(details) or PLATFORMS.get(platform_key, (platform_key, (), ()))[0]
                    source = "Профіль роутера"
                if identity:
                    host.device_kind = "Роутер"
                    host.device_kind_confidence = "HIGH"
                    reason = "Модель/платформу отримано через налаштований профіль роутера."
            except Exception as error:
                self.write_log(f"{host.ip}: роутер не надав модель: {error}", host.ip, "IDENTITY_INFO")

        # For an address without a saved profile, request only the root web
        # page on the two standard management ports. No login is attempted.
        if not identity and not profile:
            for scheme, port in (("http", 80), ("https", 443)):
                try:
                    context = ssl._create_unverified_context() if scheme == "https" else None
                    request = urllib.request.Request(
                        f"{scheme}://{host.ip}:{port}/",
                        headers={"User-Agent": "MICHMAN-KP/2.4 DeviceIdentity", "Accept": "text/html"},
                    )
                    with urllib.request.urlopen(request, timeout=3, context=context) as response:
                        body = response.read(262145)
                        if len(body) > 262144:
                            continue
                        text = body.decode(response.headers.get_content_charset() or "utf-8", errors="replace")
                        title_match = re.search(r"(?is)<title[^>]*>\s*(.*?)\s*</title>", text)
                        title = re.sub(r"\s+", " ", title_match.group(1)).strip()[:120] if title_match else ""
                        server = str(response.headers.get("Server") or "").strip()[:120]
                    from michman_router_support import identify_router
                    detected = identify_router(" ".join((title, server, text[:4096])))
                    router_words = ("router", "gateway", "mercusys", "mikrotik", "tp-link", "tplink", "asuswrt", "netgear", "linksys", "keenetic", "zyxel", "d-link", "tenda", "miwifi")
                    if detected.get("platform") != "custom" or any(word in (title + " " + server).casefold() for word in router_words):
                        model = title if title and title.casefold() not in ("login", "home", "welcome") else ""
                        vendor = str(detected.get("vendor") or "").strip()
                        details = " · ".join(part for part in (vendor, model) if part and part != "Стандартний SNMP-пристрій")
                        identity = details or "Роутер — модель невідома"
                        source = "HTTP/HTTPS ідентифікатор"
                        host.device_kind = "Роутер"
                        host.device_kind_confidence = "HIGH" if model else "MEDIUM"
                        reason = "Виробника/модель визначено з веб-ідентифікатора пристрою."
                        break
                except (OSError, ValueError, urllib.error.URLError, ssl.SSLError):
                    continue

        # SMB or RDP indicates a computer-class endpoint, but does not expose
        # a trustworthy Windows release. Exact Windows data requires the agent.
        if not identity and (tcp_probe(host.ip, 445, 1.0) or tcp_probe(host.ip, 3389, 1.0)):
            identity = "Комп’ютер · Windows/ОС — версія невідома"
            source = "SMB/RDP"
            host.device_kind = "Комп’ютер"
            host.device_kind_confidence = "MEDIUM"
            reason = "Доступна стандартна служба SMB або RDP; точну версію ОС не розголошено."

        if identity:
            with host.lock:
                host.device_identity = identity
                host.device_kind_reason = reason
                host.device_identity_source = source
                host.device_identified_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self.save_devices()
            try:
                self.root.after(0, lambda: self.refresh_host_row(host))
            except (AttributeError, tk.TclError):
                pass
        else:
            self.save_devices()

    def schedule_host_identification(self, hosts):
        for host in hosts:
            self.tcp_executor.submit(self.identify_host_active, host)

    def load_devices(self, initial=False):
        """Load monitored nodes from JSON and migrate an old IP.txt once."""
        devices_exists = os.path.exists(DEVICES_FILE)
        records = _read_device_records(DEVICES_FILE) if devices_exists else []
        migrated = False

        if not devices_exists and os.path.exists(LEGACY_IP_FILE):
            records = _read_legacy_ip_records(LEGACY_IP_FILE, self.names)
            try:
                _write_device_records(DEVICES_FILE, records)
                migrated = True
            except OSError as error:
                self.write_log(f"Не вдалося перенести старий список IP: {error}")
        elif not devices_exists:
            try:
                _write_device_records(DEVICES_FILE, [])
            except OSError:
                pass

        new_hosts = {}
        with self.hosts_lock:
            old = set(self.hosts)

        for record in records:
            ip = record["ip"]
            name = record.get("name") or self.names.get(ip, "")
            with self.hosts_lock:
                host = self.hosts.get(ip)
            if host is None:
                host = Host(ip, name)
            if name:
                host.name = name
                self.names[ip] = name
            host.group = record.get("group", "Загальні") or "Загальні"
            host.priority = record.get("priority", "Звичайний") or "Звичайний"
            self.apply_device_config(host)
            passive_result = self.classify_host_passively(host)
            if passive_result["confidence"] == "LOW" and record.get("device_kind") not in (None, "", "Невідомий"):
                host.device_kind = str(record.get("device_kind"))
                host.device_kind_confidence = str(record.get("device_kind_confidence") or "LOW")
                host.device_kind_reason = str(record.get("device_kind_reason") or "Збережений результат попереднього пасивного визначення.")
            host.device_identity = str(record.get("device_identity") or host.device_identity)
            host.device_identity_source = str(record.get("device_identity_source") or "")
            host.device_identified_at = str(record.get("device_identified_at") or "")
            host.device_identification_last_attempt = float(record.get("device_identification_last_attempt") or 0)
            host.address_mode = str(record.get("address_mode") or "ip")
            host.tracking_mac = str(record.get("tracking_mac") or "")
            if host.address_mode == "mac" and valid_mac(host.tracking_mac):
                host.expected_mac = host.tracking_mac
            else:
                host.address_mode, host.tracking_mac = "ip", ""
            new_hosts[ip] = host

        with self.hosts_lock:
            self.hosts = new_hosts

        self._update_device_label()
        self.rebuild_tree()

        if migrated:
            self.write_log(
                f"Старий список IP перенесено у monitored_devices.json ({len(records)} вузлів).",
                event="DEVICES_MIGRATED",
            )

        if not initial:
            for ip in sorted(set(new_hosts) - old):
                self.write_log(f"Додано IP: {ip}", ip, "ADD")
            for ip in sorted(old - set(new_hosts)):
                self.write_log(f"Видалено IP: {ip}", ip, "REMOVE")
            self.schedule_host_identification(
                [new_hosts[ip] for ip in sorted(set(new_hosts) - old)]
            )

    def save_devices(self):
        with self.hosts_lock:
            records = [
                {
                    "ip": host.ip,
                    "name": host.name,
                    "group": host.group,
                    "priority": host.priority,
                    "device_kind": host.device_kind,
                    "device_kind_confidence": host.device_kind_confidence,
                    "device_kind_reason": host.device_kind_reason,
                    "device_identity": host.device_identity,
                    "device_identity_source": host.device_identity_source,
                    "device_identified_at": host.device_identified_at,
                    "device_identification_last_attempt": host.device_identification_last_attempt,
                    "address_mode": host.address_mode,
                    "tracking_mac": host.tracking_mac,
                }
                for host in self.hosts.values()
            ]
        try:
            _write_device_records(DEVICES_FILE, records)
            return True
        except OSError as error:
            self.write_log(f"Помилка збереження списку пристроїв: {error}", event="CONFIG_ERROR")
            return False

    def resolve_mac_address(self, mac):
        mac = str(mac or "").strip().upper().replace("-", ":")
        if not valid_mac(mac):
            return ""
        cached_ip = get_arp_table().get(mac, "")
        if cached_ip:
            return cached_ip
        with self.hosts_lock:
            for host in self.hosts.values():
                values = (host.current_mac, host.mt_mac, host.expected_mac, host.tracking_mac)
                if any(str(value or "").upper().replace("-", ":") == mac for value in values):
                    return host.ip
        return ""

    def refresh_mac_bindings(self, force=False):
        """Follow known MAC targets across DHCP changes without subnet scanning."""
        now = time.monotonic()
        if not force and now - getattr(self, "_last_mac_binding_refresh", 0.0) < 15:
            return []
        self._last_mac_binding_refresh = now
        table = get_arp_table()
        changes = []
        with self.hosts_lock:
            for old_ip, host in list(self.hosts.items()):
                if host.address_mode != "mac" or not valid_mac(host.tracking_mac):
                    continue
                new_ip = table.get(host.tracking_mac)
                if not new_ip or new_ip == old_ip or new_ip in self.hosts:
                    continue
                del self.hosts[old_ip]
                host.ip = new_ip
                self.hosts[new_ip] = host
                if old_ip in self.names:self.names[new_ip] = self.names.pop(old_ip)
                if old_ip in self.device_config:self.device_config[new_ip] = self.device_config.pop(old_ip)
                if old_ip in self.hidden_ips:self.hidden_ips.discard(old_ip);self.hidden_ips.add(new_ip)
                if old_ip in self.pinned_ips:self.pinned_ips.discard(old_ip);self.pinned_ips.add(new_ip)
                changes.append((old_ip, new_ip, host.tracking_mac))
        if changes:
            self.save_devices();self.save_names();self.save_device_config();self.save_visibility_config()
            try:self.root.after(0, self.rebuild_tree)
            except (AttributeError, tk.TclError):pass
            for old_ip, new_ip, mac in changes:
                self.write_log(f"{mac}: IP змінено DHCP {old_ip} → {new_ip}", new_ip, "MAC_IP_CHANGED")
        return changes

    def add_mac_dialog(self, parent=None):
        parent = parent or self.root
        mac = simpledialog.askstring(
            APP_NAME,
            "MAC-адреса пристрою:\nПриклад: AA:BB:CC:DD:EE:FF\n\nПоточний IP визначається з локальної таблиці сусідів без сканування підмережі.",
            parent=parent,
        )
        if mac is None:return
        mac = mac.strip().upper().replace("-", ":")
        if not valid_mac(mac):
            messagebox.showerror(APP_NAME, "Некоректна MAC-адреса.", parent=parent);return
        ip = self.resolve_mac_address(mac)
        if not ip:
            messagebox.showinfo(APP_NAME, "MAC поки не знайдено. Пристрій має бути у локальній таблиці сусідів або вже відомий застосунку.", parent=parent);return
        name = simpledialog.askstring(APP_NAME, f"Назва пристрою {ip}:", initialvalue=ip, parent=parent)
        if name is None:return
        with self.hosts_lock:
            host = self.hosts.get(ip)
            if host is None:
                host = Host(ip, name.strip() or ip);self.hosts[ip] = host
            elif name.strip():host.name = name.strip()
            host.address_mode, host.tracking_mac, host.expected_mac = "mac", mac, mac
            self.device_config[ip] = {"ports": list(host.ports), "mac": mac}
        self.names[ip] = host.name
        self.save_devices();self.save_names();self.save_device_config();self.rebuild_tree()
        self.schedule_host_identification([host])
        self.write_log(f"Додано моніторинг за MAC {mac}; поточний IP {ip}", ip, "ADD_MAC")

    def add_ip_dialog(self, parent=None):
        """Add one or more IPv4 addresses without editing an external file."""
        parent = parent or self.root
        win = tk.Toplevel(parent)
        win.configure(background=UI_BG)
        win.title(f"{APP_NAME} — Додати IP")

        body = ttk.Frame(win, padding=16)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="ДОДАТИ IP-ДЛЯ МОНІТОРИНГУ", style="Brand.TLabel").pack(anchor="w")
        ttk.Label(
            body,
            text="IPv4, підмережа або діапазон (до 4096 адрес). Формат: IP | Назва\n192.168.1.0/24 | Офіс; діапазон: 192.168.1.10-192.168.1.20",
            style="Section.TLabel",
            wraplength=600,
        ).pack(anchor="w", pady=(4, 9))

        ip_text = tk.Text(
            body,
            height=7,
            width=66,
            background=UI_SURFACE,
            foreground=UI_TEXT,
            insertbackground=UI_CYAN,
            selectbackground=UI_CYAN,
            selectforeground=UI_SELECTION_TEXT,
            relief="flat",
            borderwidth=1,
            highlightthickness=1,
            highlightbackground=UI_BORDER,
            highlightcolor=UI_CYAN,
            font=("Cascadia Mono", 10),
        )
        ip_text.pack(fill="both", expand=True)

        fields = ttk.Frame(body)
        fields.pack(fill="x", pady=(12, 0))
        ttk.Label(fields, text="Назва для рядків без назви:").grid(row=0, column=0, sticky="w")
        name_var = tk.StringVar()
        ttk.Entry(fields, textvariable=name_var, width=28).grid(row=0, column=1, padx=(8, 18), sticky="w")
        ttk.Label(fields, text="Група:").grid(row=0, column=2, sticky="w")
        group_var = tk.StringVar(value="Загальні")
        ttk.Entry(fields, textvariable=group_var, width=18).grid(row=0, column=3, padx=(8, 0), sticky="w")
        ttk.Label(fields, text="Пріоритет:").grid(row=1, column=0, pady=(9, 0), sticky="w")
        priority_var = tk.StringVar(value="Звичайний")
        ttk.Combobox(
            fields,
            textvariable=priority_var,
            values=("Низький", "Звичайний", "Високий", "Критичний"),
            state="readonly",
            width=25,
        ).grid(row=1, column=1, padx=(8, 18), pady=(9, 0), sticky="w")

        feedback = tk.StringVar(value="")
        ttk.Label(body, textvariable=feedback, style="Section.TLabel", wraplength=620).pack(anchor="w", pady=(10, 0))

        def save():
            with self.hosts_lock:
                existing = set(self.hosts)
            try:
                additions, duplicates = parse_device_input(
                    ip_text.get("1.0", "end"), existing,
                    name_var.get().strip(),
                    group_var.get().strip() or "Загальні",
                    priority_var.get().strip() or "Звичайний",
                )
            except ValueError as error:
                feedback.set(str(error))
                return

            if not additions:
                feedback.set("Введіть хоча б одну нову коректну IPv4-адресу.")
                return

            # Persist the complete candidate list before changing visible state.
            # A disk error leaves the current list and the input untouched.
            with self.hosts_lock:
                candidates = []
                for ip, name, item_group, item_priority in additions:
                    host = Host(ip, name)
                    host.group = item_group
                    host.priority = item_priority
                    self.apply_device_config(host)
                    self.classify_host_passively(host)
                    candidates.append(host)
                records = [
                    {"ip": h.ip, "name": h.name, "group": h.group, "priority": h.priority,
                     "device_kind": h.device_kind, "device_kind_confidence": h.device_kind_confidence,
                     "device_kind_reason": h.device_kind_reason, "device_identity": h.device_identity,
                     "device_identity_source": h.device_identity_source,
                     "device_identified_at": h.device_identified_at,
                     "device_identification_last_attempt": h.device_identification_last_attempt}
                    for h in list(self.hosts.values()) + candidates
                ]
                try:
                    _write_device_records(DEVICES_FILE, records)
                except OSError as error:
                    feedback.set(f"Не вдалося зберегти пристрої: {error}")
                    return
                for host in candidates:
                    self.hosts[host.ip] = host
                    if host.name:
                        self.names[host.ip] = host.name

            self.save_names()
            self._update_device_label()
            self.rebuild_tree()
            self.schedule_host_identification(candidates)
            for ip, name, _item_group, _item_priority in additions:
                self.write_log(
                    f"Додано IP у програмі: {ip}" + (f" ({name})" if name else ""),
                    ip,
                    "ADD",
                )

            notices = [f"Додано адрес: {len(additions)}"]
            if duplicates:
                notices.append(f"дублікати пропущено: {len(set(duplicates))}")
            feedback.set("; ".join(notices))
            ip_text.delete("1.0", "end")
            ip_text.focus_set()

        buttons = ttk.Frame(body)
        buttons.pack(fill="x", pady=(14, 0))
        ttk.Button(buttons, text="Додати", command=save, style="Accent.TButton").pack(side="left")
        ttk.Button(buttons, text="Закрити", command=win.destroy).pack(side="right")
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        _show_child_window(win, 760, 530, min_width=620, min_height=430, modal=True)
        ip_text.focus_set()
        try:
            parent.wait_window(win)
        except tk.TclError:
            pass

    def _remove_ips(self, ips, parent=None):
        ips = [str(ip).strip() for ip in ips if valid_ipv4(str(ip).strip())]
        if not ips:
            messagebox.showinfo(APP_NAME, "Виберіть IP для видалення.", parent=parent or self.root)
            return False
        if not messagebox.askyesno(
            APP_NAME,
            "Видалити вибрані IP зі списку моніторингу?\n\n" + "\n".join(ips),
            parent=parent or self.root,
        ):
            return False
        with self.hosts_lock:
            for ip in ips:
                self.hosts.pop(ip, None)
        for ip in ips:
            self.hidden_ips.discard(ip)
            self.pinned_ips.discard(ip)
            self.names.pop(ip, None)
            self.device_config.pop(ip, None)
            self.write_log(f"Видалено IP з програми: {ip}", ip, "REMOVE")
        self.save_devices()
        self.save_names()
        self.save_device_config()
        self.save_visibility_config()
        self.selected_ip = None
        self._update_device_label()
        self.rebuild_tree()
        return True

    def remove_selected_ip(self):
        ip = self.get_selected_main_ip()
        if ip:
            self._remove_ips([ip], parent=self.root)

    def open_devices_dialog(self):
        win = tk.Toplevel(self.root)
        win.configure(background=UI_BG)
        win.title(f"{APP_NAME} — Пристрої")
        ttk.Label(win, text="MONITORED DEVICES", style="Brand.TLabel", padding=(12, 12)).pack(anchor="w")
        frame = ttk.Frame(win, padding=(12, 0, 12, 8))
        frame.pack(fill="both", expand=True)
        columns = ("ip", "name", "group", "priority")
        tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="extended")
        headings = (("ip", "IP"), ("name", "Назва"), ("group", "Група"), ("priority", "Пріоритет"))
        for column, title in headings:
            tree.heading(column, text=title)
            tree.column(column, width=180 if column != "ip" else 150, anchor="w")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)

        def refresh():
            for item in tree.get_children():
                tree.delete(item)
            with self.hosts_lock:
                records = list(self.hosts.values())
            for host in records:
                tree.insert("", "end", values=(host.ip, host.name or "—", host.group, host.priority))

        def add():
            self.add_ip_dialog(parent=win)
            refresh()

        def remove():
            selected = tree.selection()
            ips = [tree.item(item, "values")[0] for item in selected if tree.item(item, "values")]
            if self._remove_ips(ips, parent=win):
                refresh()

        buttons = ttk.Frame(win, padding=12)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Додати IP", command=add, style="Accent.TButton").pack(side="left")
        ttk.Button(buttons, text="Видалити", command=remove, style="Danger.TButton").pack(side="left", padx=6)
        ttk.Button(buttons, text="Закрити", command=win.destroy).pack(side="right")
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        _show_child_window(win, 760, 520, min_width=600, min_height=380)
        refresh()

    def reset_statistics_cycle(self):
        with self.hosts_lock:
            hosts = list(
                self.hosts.values()
            )

        for host in hosts:
            with host.lock:
                host.history.clear()
                host.disconnects = 0
                host.high_ping_events = 0
                host.longest_outage = 0.0
                host.outage_started = (
                    current_time()
                    if host.online is False
                    else None
                )
                host.last_online = None
                host.last_offline = None

        self.write_log(
            "Статистика та історія перевірок "
            "обнулені після 60 хвилин активної роботи.",
            event="STATISTICS_RESET",
        )

    def rebuild_tree(self):
        self._update_device_label()
        for item in self.tree.get_children():
            self.tree.delete(item)

        self.rows.clear()

        with self.hosts_lock:
            hosts = list(
                self.hosts.values()
            )

        hosts = [
            host
            for host in hosts
            if host.ip not in self.hidden_ips
        ]

        hosts = self.sort_hosts_for_display(
            hosts
        )

        for host in hosts:
            iid = self.tree.insert(
                "",
                "end",
                text="●",
                values=(
                    host.ip,
                    host.name or "—",
                    "UNKNOWN",
                    "—",
                    "—",
                    "—",
                    "—",
                    "N/A / N/A",
                    "0.0%",
                    "0",
                    "0",
                    "0",
                    "—",
                ),
                tags=("unknown",),
            )

            self.rows[
                host.ip
            ] = iid

    def refresh_gui(self):
        if self.closed:
            return

        self.update_runtime_config()

        with self.hosts_lock:
            all_hosts = list(
                self.hosts.values()
            )

        hosts = [
            host
            for host in all_hosts
            if host.ip not in self.hidden_ips
        ]

        snapshots = [
            host.snapshot()
            for host in all_hosts
        ]
        online_count = sum(
            1
            for snapshot in snapshots
            if snapshot["online"] is True
        )
        offline_count = sum(
            1
            for snapshot in snapshots
            if snapshot["online"] is False
        )
        unknown_count = len(snapshots) - online_count - offline_count
        high_ping_count = sum(
            1
            for snapshot in snapshots
            if snapshot["online"] is True
            and snapshot["ping"] is not None
            and snapshot["ping"] > PING_LIMIT_MS
        )

        self.metric_total_var.set(str(len(all_hosts)))
        self.metric_online_var.set(str(online_count))
        self.metric_offline_var.set(str(offline_count))
        self.metric_high_ping_var.set(str(high_ping_count))
        self.metric_unknown_var.set(str(unknown_count))

        for host in hosts:
            self.refresh_host_row(
                host
            )

        if self.running:
            self.header_state_var.set("●  MONITORING ACTIVE")
            self.header_state_label.configure(style="StateActive.TLabel")
            self.start_button.configure(state="disabled")
            self.stop_button.configure(state="normal")
            self.status.config(
                text=(
                    f"SYSTEM ONLINE  //  NODES {len(all_hosts)}  //  "
                    f"VISIBLE {len(hosts)}  //  HIDDEN "
                    f"{len(all_hosts) - len(hosts)}  //  "
                    f"CYCLE {self.interval_seconds}s"
                )
            )

        else:
            self.header_state_var.set("●  STANDBY")
            self.header_state_label.configure(style="StateIdle.TLabel")
            self.start_button.configure(state="normal")
            self.stop_button.configure(state="disabled")
            self.status.config(
                text=(
                    f"SYSTEM STANDBY  //  NODES {len(all_hosts)}  //  "
                    f"READY FOR MONITORING"
                )
            )

        if not self.closed:
            self.root.after(
                1000,
                self.refresh_gui,
            )

    def refresh_host_row(self, host):
        iid = self.rows.get(
            host.ip
        )

        if (
            not iid
            or not self.tree.exists(iid)
        ):
            return

        s = host.snapshot()
        status = effective_status(s)

        if status == "ONLINE":
            if (
                s["ping"] is not None
                and s["ping"] > PING_LIMIT_MS
            ):
                tag = "high_ping"
            else:
                tag = "good"

            light = "●"

        elif status == "OFFLINE":
            tag = "bad"
            light = "●"

        else:
            tag = "unknown"
            light = "●"

        method = (
            s.get(
                "response_method"
            )
            or "N/A"
        )

        response = (
            f"{fmt_ping(s['ping'])} / {method}"
            if s["ping"] is not None
            else f"N/A / {method}"
        )

        row_light = (
            "★"
            if host.ip in self.pinned_ips
            else light
        )

        self.tree.item(
            iid,
            text=row_light,
            values=(
                host.ip,
                host.name or "—",
                status,
                s["mt_interface"],
                s["mt_mac"],
                s["mt_vendor"],
                self._hostname_identity(host, s),
                response,
                f"{s['loss']:.1f}%",
                s["checks"],
                s["online_count"],
                s["offline_count"],
                (
                    s["last_check"].strftime(
                        "%H:%M:%S"
                    )
                    if s["last_check"]
                    else "—"
                ),
            ),
            tags=(tag,),
        )

    def clear_tree_selection(self):
        selection = self.tree.selection()

        if selection:
            self.tree.selection_remove(
                selection
            )

        self.tree.focus("")

    def on_tree_click(self, event):
        row = self.tree.identify_row(
            event.y
        )

        if not row:
            self.clear_tree_selection()
            return "break"

        values = self.tree.item(
            row,
            "values",
        )

        if values:
            self.selected_ip = values[0]

        if row in self.tree.selection():
            self.root.after_idle(
                self.clear_tree_selection
            )

        return None

    def on_tree_double_click(self, event):
        row = self.tree.identify_row(
            event.y
        )

        if not row:
            self.clear_tree_selection()
            return "break"

        values = self.tree.item(
            row,
            "values",
        )

        if values:
            self.selected_ip = values[0]
            self.open_detail(
                values[0]
            )

        return "break"
    def start(self):
        if self.running:
            return

        self.update_runtime_config()

        with self.hosts_lock:
            if not self.hosts:
                messagebox.showwarning(
                    APP_NAME,
                    "Список моніторингу порожній. Додайте IP кнопкою «Додати IP».",
                    parent=self.root,
                )
                return

        self.stop_event.clear()
        self.running = True
        self.monitor_generation += 1
        generation = self.monitor_generation
        self.cycle_last_tick = time.monotonic()

        self.monitor_thread = threading.Thread(
            target=self.monitor_loop,
            args=(generation,),
            daemon=True,
            name="MichmanMonitor",
        )

        self.monitor_thread.start()

        self.write_log(
            "Моніторинг запущено.",
            event="START",
        )

    def stop(self):
        if not self.running:
            return

        self.running = False
        self.monitor_generation += 1
        self.stop_event.set()

        self.write_log(
            "Моніторинг зупинено.",
            event="STOP",
        )

    def monitor_loop(self, generation):
        while (
            self.running
            and generation == self.monitor_generation
            and not self.stop_event.is_set()
            and not self.closed
        ):
            cycle_started = time.monotonic()

            active_elapsed = cycle_started - self.cycle_last_tick
            self.cycle_last_tick = cycle_started
            self.cycle_elapsed += max(0.0, active_elapsed)

            if self.cycle_elapsed >= STATISTICS_PERIOD:
                self.cycle_elapsed %= STATISTICS_PERIOD
                self.reset_statistics_cycle()

            try:
                self.refresh_mac_bindings()
                with self.hosts_lock:
                    hosts = list(
                        self.hosts.values()
                    )

                if hosts:
                    self.check_hosts(hosts, generation)

            except Exception as e:
                self.write_log(
                    f"Помилка циклу моніторингу: {e}",
                    event="MONITOR_ERROR",
                )

            elapsed = (
                time.monotonic()
                - cycle_started
            )

            interval, _ = (
                self.get_runtime_config()
            )

            remaining = max(
                0.05,
                interval - elapsed,
            )

            self.stop_event.wait(
                remaining
            )

    def check_hosts(self, hosts, generation=None):
        """
        Перевіряє всі IP паралельно.

        ВАЖЛИВО:
        логіка ONLINE/OFFLINE не змінюється одним TCP-портом.
        Основою залишається ICMP, а TCP/MAC є додатковими
        доказами та інформацією про пристрій.
        """

        if not hosts:
            return

        _, timeout = (
            self.get_runtime_config()
        )

        workers = min(
            MAX_WORKERS,
            max(1, len(hosts)),
        )

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=workers
        ) as executor:

            future_map = {
                executor.submit(
                    self.check_single_host,
                    host,
                    timeout,
                ): host
                for host in hosts
            }

            for future in concurrent.futures.as_completed(
                future_map
            ):
                if (
                    self.closed
                    or self.stop_event.is_set()
                    or not self.running
                    or (
                        generation is not None
                        and generation != self.monitor_generation
                    )
                ):
                    for pending in future_map:
                        pending.cancel()
                    break

                host = future_map[future]

                try:
                    result = future.result()

                    self.apply_check_result(
                        host,
                        result,
                    )

                except Exception as e:
                    self.write_log(
                        f"{host.ip}: помилка перевірки: {e}",
                        host.ip,
                        "CHECK_ERROR",
                    )

    def check_single_host(
        self,
        host,
        timeout,
    ):
        """
        Багатоканальна перевірка:

        1. ICMP — головний метод визначення доступності.
        2. TCP — додаткова інформація, якщо задані порти.
        3. ARP/MAC — додаткова ідентифікація.
        4. MikroTik MAC — використовується як інформація
           про пристрій, але не ламає логіку ONLINE/OFFLINE.
        """

        ip = host.ip

        icmp_successes = 0
        icmp_pings = []

        # ---------------------------------------------------------
        # ICMP
        # ---------------------------------------------------------

        for _ in range(ICMP_ATTEMPTS):
            if self.stop_event.is_set():
                break

            ok, ping, _ = ping_host(
                ip,
                timeout,
            )

            if ok and ping is not None:
                icmp_successes += 1
                icmp_pings.append(
                    ping
                )

                # Один успішний ICMP вже є доказом ONLINE.
                # Не чекаємо всі 3 спроби.
                break

        icmp_online = (
            icmp_successes > 0
        )

        avg_ping = (
            sum(icmp_pings)
            / len(icmp_pings)
            if icmp_pings
            else None
        )

        # ---------------------------------------------------------
        # TCP
        # ---------------------------------------------------------

        tcp_success_ports = []

        ports = list(
            host.ports
        )

        if ports:
            future_ports = {
                self.tcp_executor.submit(
                    tcp_probe,
                    ip,
                    port,
                    TCP_TIMEOUT,
                ): port
                for port in ports
            }

            for future in concurrent.futures.as_completed(
                future_ports
            ):
                port = future_ports[
                    future
                ]

                try:
                    if future.result():
                        tcp_success_ports.append(
                            port
                        )
                except Exception:
                    pass

        tcp_success_ports.sort()

        tcp_online = bool(
            tcp_success_ports
        )

        # ---------------------------------------------------------
        # MAC
        # ---------------------------------------------------------

        current_mac = get_arp_mac(
            ip
        )

        if (
            not current_mac
            and host.mt_mac
            and host.mt_mac != "—"
        ):
            current_mac = host.mt_mac

        expected_mac = (
            host.expected_mac
        )

        mac_match = None

        if expected_mac:
            if current_mac:
                mac_match = (
                    current_mac.upper()
                    == expected_mac.upper()
                )
            else:
                mac_match = False

        # ---------------------------------------------------------
        # ФІНАЛЬНИЙ СТАТУС
        # ---------------------------------------------------------
        #
        # Головний принцип:
        #
        # ICMP ONLINE -> ONLINE
        #
        # ICMP OFFLINE -> OFFLINE
        #
        # TCP не переводить ONLINE в OFFLINE.
        # TCP лише показує додаткову доступність портів.
        #
        # Це зберігає попередню логіку підтвердження.
        # ---------------------------------------------------------

        online = icmp_online

        if icmp_online:
            if icmp_successes:
                response_method = "ICMP"

            else:
                response_method = "N/A"

        else:
            response_method = "N/A"

        # Якщо ICMP не відповів, але TCP порт відкритий,
        # це сильний сигнал, що пристрій реально доступний.
        #
        # Але ми не використовуємо TCP як автоматичну заміну
        # ICMP у стандартній логіці.
        #
        # Це дозволяє уникнути помилкових ONLINE через
        # випадковий відкритий сервіс.
        if tcp_online and icmp_online:
            response_method = (
                "ICMP + TCP"
            )

        elif tcp_online:
            response_method = (
                "TCP evidence"
            )

        return {
            "online": online,
            "ping": avg_ping,
            "current_mac": current_mac,
            "mac_match": mac_match,
            "icmp_successes": icmp_successes,
            "tcp_success_ports": (
                tcp_success_ports
            ),
            "response_method": response_method,
        }

    def apply_check_result(
        self,
        host,
        result,
    ):
        online = bool(
            result.get(
                "online",
                False,
            )
        )

        ping = result.get(
            "ping"
        )

        previous = host.snapshot()

        previous_status = effective_status(
            previous
        )

        host.set_evidence(
            result.get(
                "response_method",
                "N/A",
            ),
            result.get(
                "current_mac",
                "",
            ),
            result.get(
                "mac_match"
            ),
            result.get(
                "icmp_successes",
                0,
            ),
            result.get(
                "tcp_success_ports",
                [],
            ),
        )

        with host.lock:
            if online:
                host.consecutive_successes += 1
                host.consecutive_failures = 0
            else:
                host.consecutive_failures += 1
                host.consecutive_successes = 0

        host.add_result(
            online,
            ping,
        )

        self.db.add_check(
            host.ip,
            online,
            ping,
        )

        current_status = (
            "ONLINE"
            if online
            else "OFFLINE"
        )

        if (
            online
            and previous_status != "ONLINE"
            and not host.device_identity
            and time.time() - host.device_identification_last_attempt >= 1800
        ):
            self.schedule_host_identification([host])

        # ---------------------------------------------------------
        # ПОДІЇ ЗМІНИ СТАТУСУ
        # ---------------------------------------------------------

        if (
            previous_status != current_status
        ):
            if current_status == "ONLINE":
                self.write_log(
                    f"{host.ip}: ONLINE"
                    + (
                        f", ping={fmt_ping(ping)}"
                        if ping is not None
                        else ""
                    ),
                    host.ip,
                    "ONLINE",
                )

            else:
                self.write_log(
                    f"{host.ip}: OFFLINE",
                    host.ip,
                    "OFFLINE",
                )

        # ---------------------------------------------------------
        # ВИСОКИЙ PING
        # ---------------------------------------------------------

        if (
            online
            and ping is not None
            and ping > WARN_PING_MS
        ):
            with host.lock:
                host.high_ping_events += 1

                high_ping_count = (
                    host.high_ping_events
                )

            # Не створюємо подію на кожній перевірці.
            # Повідомляємо при першому випадку та кожні
            # HIGH_PING_LOG_EVERY циклів/подій.
            if (
                high_ping_count == 1
                or high_ping_count
                % HIGH_PING_LOG_EVERY
                == 0
            ):
                self.write_log(
                    f"{host.ip}: високий ping "
                    f"{fmt_ping(ping)}",
                    host.ip,
                    "HIGH_PING",
                )

        # ---------------------------------------------------------
        # MAC
        # ---------------------------------------------------------

        expected_mac = (
            host.expected_mac
        )

        current_mac = (
            result.get(
                "current_mac",
                "",
            )
        )

        mac_match = (
            result.get(
                "mac_match"
            )
        )

        if (
            expected_mac
            and current_mac
            and mac_match is False
            and (
                previous.get("mac_match") is not False
                or previous.get("current_mac") != current_mac
            )
        ):
            self.write_log(
                f"{host.ip}: невідповідність MAC. "
                f"Очікується {expected_mac}, "
                f"отримано {current_mac}",
                host.ip,
                "MAC_MISMATCH",
            )

        elif (
            expected_mac
            and current_mac
            and mac_match is True
            and previous.get("mac_match") is False
        ):
            self.write_log(
                f"{host.ip}: відповідність MAC відновлено "
                f"({current_mac})",
                host.ip,
                "MAC_RESTORED",
            )

        # ---------------------------------------------------------
        # TCP
        # ---------------------------------------------------------

        tcp_ports = result.get(
            "tcp_success_ports",
            [],
        )

        # Подію створюємо тільки якщо змінився набір
        # доступних портів, включно із закриттям останнього порту.
        previous_ports = set(
            previous.get(
                "tcp_success_ports",
                [],
            )
        )

        current_ports = set(
            tcp_ports
        )

        if previous_ports != current_ports:
            if tcp_ports:
                self.write_log(
                    f"{host.ip}: доступні TCP-порти: "
                    + ", ".join(
                        str(p)
                        for p in tcp_ports
                    ),
                    host.ip,
                    "TCP",
                )
            elif previous_ports:
                self.write_log(
                    f"{host.ip}: раніше доступні TCP-порти "
                    "більше не відповідають: "
                    + ", ".join(
                        str(p)
                        for p in sorted(previous_ports)
                    ),
                    host.ip,
                    "TCP_CLOSED",
                )

        # ---------------------------------------------------------
        # Оновлення GUI
        # ---------------------------------------------------------

        self.run_on_gui(
            lambda h=host: self.refresh_host_row(
                h
            )
        )

    def rename_selected(self):
        ip = self.selected_ip

        if not ip:
            selection = self.tree.selection()

            if selection:
                values = self.tree.item(
                    selection[0],
                    "values",
                )

                if values:
                    ip = values[0]

        if not ip:
            messagebox.showinfo(
                APP_NAME,
                "Виберіть IP.",
                parent=self.root,
            )
            return

        with self.hosts_lock:
            host = self.hosts.get(ip)

        if host is None:
            return

        name = simpledialog.askstring(
            APP_NAME,
            f"Назва для {ip}:",
            initialvalue=host.name,
            parent=self.root,
        )

        if name is None:
            return

        name = name.strip()

        host.name = name

        self.classify_host_passively(host)

        if name:
            self.names[ip] = name
        else:
            self.names.pop(
                ip,
                None,
            )

        self.save_names()
        self.save_devices()

        self.write_log(
            f"{ip}: назву змінено на "
            f"'{name or '—'}'",
            ip,
            "RENAME",
        )

        self.refresh_host_row(
            host
        )

    def open_selected_detail(self):
        ip = self.selected_ip

        if not ip:
            selection = self.tree.selection()

            if selection:
                values = self.tree.item(
                    selection[0],
                    "values",
                )

                if values:
                    ip = values[0]

        if not ip:
            messagebox.showinfo(
                APP_NAME,
                "Виберіть IP.",
                parent=self.root,
            )
            return

        self.open_detail(
            ip
        )

    def open_detail(self, ip):
        with self.hosts_lock:
            host = self.hosts.get(ip)

        if host is None:
            return

        existing = self.detail_windows.get(
            ip
        )

        if existing:
            try:
                if existing.winfo_exists():
                    _bring_window_to_front(existing)
                    return
            except Exception:
                pass

        win = tk.Toplevel(
            self.root
        )
        win.configure(background=UI_BG)

        win.title(
            f"{APP_NAME} — {ip}"
        )

        win.geometry(
            "950x650"
        )

        self.detail_windows[ip] = win

        def close_detail():
            self.detail_windows.pop(
                ip,
                None,
            )

            try:
                win.destroy()
            except Exception:
                pass

        win.protocol(
            "WM_DELETE_WINDOW",
            close_detail,
        )

        header = ttk.Frame(
            win,
            padding=10,
            style="Header.TFrame",
        )

        header.pack(
            fill="x"
        )

        ttk.Label(
            header,
            text=f"{ip}",
            style="Brand.TLabel",
        ).pack(
            side="left"
        )

        info = ttk.Label(
            header,
            text="",
            style="Header.TLabel",
        )

        info.pack(
            side="right"
        )

        columns = (
            "time",
            "status",
            "ping",
            "method",
            "mac",
            "ports",
        )

        frame = ttk.Frame(
            win
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5,
        )

        scroll = ttk.Scrollbar(
            frame,
            orient="vertical",
        )

        scroll.pack(
            side="right",
            fill="y",
        )

        tree = ttk.Treeview(
            frame,
            columns=columns,
            show="headings",
            yscrollcommand=scroll.set,
        )

        scroll.config(
            command=tree.yview
        )

        headings = {
            "time": "Час",
            "status": "Статус",
            "ping": "Ping",
            "method": "Метод",
            "mac": "MAC",
            "ports": "TCP",
        }

        widths = {
            "time": 160,
            "status": 100,
            "ping": 110,
            "method": 130,
            "mac": 170,
            "ports": 180,
        }

        for col in columns:
            tree.heading(
                col,
                text=headings[col],
            )

            tree.column(
                col,
                width=widths[col],
                anchor="center",
            )

        tree.pack(
            fill="both",
            expand=True,
        )

        bottom = ttk.Frame(
            win,
            padding=10,
        )

        bottom.pack(
            fill="x"
        )

        stats_label = ttk.Label(
            bottom,
            text="",
            justify="left",
        )

        stats_label.pack(
            anchor="w"
        )

        def refresh_detail():
            if self.closed:
                return

            try:
                if not win.winfo_exists():
                    return
            except Exception:
                return

            s = host.snapshot()

            info.config(
                text=(
                    f"Статус: "
                    f"{effective_status(s)}   |   "
                    f"Ping: "
                    f"{fmt_ping(s['ping'])}"
                )
            )

            for item in tree.get_children():
                tree.delete(item)

            history = s["history"]

            for timestamp, online, ping in reversed(
                history
            ):
                status = (
                    "ONLINE"
                    if online
                    else "OFFLINE"
                )

                method = (
                    s.get(
                        "response_method",
                        "N/A",
                    )
                    if online
                    else "N/A"
                )

                mac = (
                    s.get(
                        "current_mac",
                        "",
                    )
                    or "—"
                )

                ports = ", ".join(
                    str(p)
                    for p in s.get(
                        "tcp_success_ports",
                        [],
                    )
                ) or "—"

                tree.insert(
                    "",
                    "end",
                    values=(
                        timestamp.strftime(
                            "%d.%m.%Y %H:%M:%S"
                        ),
                        status,
                        fmt_ping(ping),
                        method,
                        mac,
                        ports,
                    ),
                )

            stats_label.config(
                text=(
                    f"Перевірок: {s['checks']}    "
                    f"ONLINE: {s['online_count']}    "
                    f"OFFLINE: {s['offline_count']}    "
                    f"Loss: {s['loss']:.1f}%    "
                    f"Середній ping: "
                    f"{fmt_ping(s['avg'])}\n"
                    f"Min: {fmt_ping(s['min'])}    "
                    f"Max: {fmt_ping(s['max'])}    "
                    f"Відключень: {s['disconnects']}    "
                    f"Найдовше відключення: "
                    f"{s['longest_outage']:.1f} с\n"
                    f"MAC: "
                    f"{s['current_mac'] or '—'}    "
                    f"Очікувана MAC: "
                    f"{s['expected_mac'] or '—'}    "
                    f"MAC match: "
                    f"{'YES' if s['mac_match'] is True else 'NO' if s['mac_match'] is False else 'N/A'}"
                )
            )

            if win.winfo_exists():
                win.after(
                    1000,
                    refresh_detail,
                )

        refresh_detail()
        _show_child_window(
            win,
            950,
            650,
            min_width=760,
            min_height=500,
        )

    def export_csv(self):
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Зберегти CSV",
            defaultextension=".csv",
            filetypes=[
                (
                    "CSV files",
                    "*.csv",
                ),
                (
                    "All files",
                    "*.*",
                ),
            ],
        )

        if not path:
            return

        try:
            with open(
                path,
                "w",
                newline="",
                encoding="utf-8-sig",
            ) as f:

                writer = SafeCSVWriter(
                    f,
                    delimiter=";",
                )

                writer.writerow([
                    "IP",
                    "Назва",
                    "Статус",
                    "Ping",
                    "Loss %",
                    "Перевірки",
                    "ONLINE",
                    "OFFLINE",
                    "MAC",
                    "Очікувана MAC",
                    "MAC Match",
                    "TCP порти",
                    "Метод",
                    "MikroTik MAC",
                    "Виробник",
                    "Hostname",
                    "Джерело ідентифікації",
                    "Час ідентифікації UTC",
                    "Порт/Interface",
                    "Lease",
                    "Остання перевірка",
                ])

                with self.hosts_lock:
                    hosts = list(
                        self.hosts.values()
                    )

                for host in hosts:
                    s = host.snapshot()

                    writer.writerow([
                        host.ip,
                        host.name,
                        effective_status(s),
                        (
                            s["ping"]
                            if s["ping"] is not None
                            else ""
                        ),
                        f"{s['loss']:.2f}",
                        s["checks"],
                        s["online_count"],
                        s["offline_count"],
                        s["current_mac"],
                        s["expected_mac"],
                        (
                            "YES"
                            if s["mac_match"] is True
                            else "NO"
                            if s["mac_match"] is False
                            else ""
                        ),
                        ",".join(
                            str(p)
                            for p in s[
                                "tcp_success_ports"
                            ]
                        ),
                        s["response_method"],
                        s["mt_mac"],
                        s["mt_vendor"],
                        self._hostname_identity(host, s),
                        s["device_identity_source"],
                        s["device_identified_at"],
                        s["mt_interface"],
                        s["mt_lease_status"],
                        (
                            s["last_check"].strftime(
                                "%d.%m.%Y %H:%M:%S"
                            )
                            if s["last_check"]
                            else ""
                        ),
                    ])

            messagebox.showinfo(
                APP_NAME,
                f"CSV збережено:\n{path}",
                parent=self.root,
            )

            self.write_log(
                f"CSV звіт збережено: {path}",
                event="EXPORT",
            )

        except Exception as e:
            messagebox.showerror(
                APP_NAME,
                f"Помилка експорту CSV:\n{e}",
                parent=self.root,
            )

    def network_scan_dialog(self):
        win = tk.Toplevel(
            self.root
        )
        win.configure(background=UI_BG)
        scan_cancel_event = threading.Event()

        win.title(
            f"{APP_NAME} — Сканування мережі"
        )

        win.geometry(
            "820x650"
        )
        win.minsize(
            700,
            500,
        )

        top = ttk.Frame(
            win,
            padding=10,
        )

        top.pack(
            fill="x"
        )

        ttk.Label(
            top,
            text="Мережа CIDR:",
        ).pack(
            side="left"
        )

        entry = ttk.Entry(
            top,
            width=25,
        )

        entry.insert(
            0,
            self.detect_local_network()
            or "192.168.1.0/24",
        )

        entry.pack(
            side="left",
            padx=5,
        )

        result_frame = ttk.Frame(
            win
        )

        result_frame.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5,
        )

        scroll = ttk.Scrollbar(
            result_frame,
            orient="vertical",
        )

        scroll.pack(
            side="right",
            fill="y",
        )

        tree = ttk.Treeview(
            result_frame,
            columns=(
                "ip",
                "ping",
                "mac",
                "hostname",
            ),
            show="headings",
            yscrollcommand=scroll.set,
        )

        scroll.config(
            command=tree.yview
        )

        for col, title, width in [
            (
                "ip",
                "IP",
                170,
            ),
            (
                "ping",
                "Ping",
                130,
            ),
            (
                "mac",
                "MAC",
                210,
            ),
            (
                "hostname",
                "Hostname",
                260,
            ),
        ]:
            tree.heading(
                col,
                text=title,
            )

            tree.column(
                col,
                width=width,
                anchor="center",
            )

        tree.pack(
            fill="both",
            expand=True,
        )

        status = ttk.Label(
            win,
            text="Готовий",
            padding=8,
        )

        status.pack(
            fill="x"
        )

        results_cache = []
        last_network = ""

        def export_scan_excel():
            if not results_cache:
                messagebox.showinfo(
                    APP_NAME,
                    "Немає отриманих даних для експорту.",
                    parent=win,
                )
                return

            try:
                from openpyxl import Workbook
                from openpyxl.styles import Font, Alignment
                from openpyxl.utils import get_column_letter
            except ImportError:
                messagebox.showerror(
                    APP_NAME,
                    "Для експорту Excel потрібен пакет openpyxl.\n\n"
                    "Встановіть його командою:\n"
                    "pip install openpyxl",
                    parent=win,
                )
                return

            path = filedialog.asksaveasfilename(
                parent=win,
                title="Експортувати результати сканування в Excel",
                defaultextension=".xlsx",
                filetypes=[
                    (
                        "Excel files",
                        "*.xlsx",
                    ),
                    (
                        "All files",
                        "*.*",
                    ),
                ],
                initialfile=(
                    "network_scan_"
                    + datetime.now().strftime(
                        "%Y%m%d_%H%M%S"
                    )
                    + ".xlsx"
                ),
            )

            if not path:
                return

            try:
                workbook = Workbook()
                sheet = workbook.active
                sheet.title = "Сканування мережі"

                headers = [
                    "IP",
                    "Ping",
                    "MAC",
                    "Hostname",
                ]

                sheet.append(headers)

                for cell in sheet[1]:
                    cell.font = Font(
                        bold=True
                    )
                    cell.alignment = Alignment(
                        horizontal="center",
                        vertical="center",
                    )

                for (
                    ip,
                    ping,
                    mac,
                    hostname,
                ) in results_cache:
                    sheet.append([
                        ip,
                        (
                            ping
                            if ping is not None
                            else ""
                        ),
                        mac or "",
                        hostname or "",
                    ])

                sheet.freeze_panes = "A2"
                sheet.auto_filter.ref = (
                    f"A1:D{sheet.max_row}"
                )

                widths = {
                    1: 20,
                    2: 15,
                    3: 24,
                    4: 36,
                }

                for index, width in widths.items():
                    sheet.column_dimensions[
                        get_column_letter(index)
                    ].width = width

                workbook.save(path)

                self.write_log(
                    f"Excel звіт сканування збережено: {path}",
                    event="EXPORT",
                )

                messagebox.showinfo(
                    APP_NAME,
                    f"Excel збережено:\n{path}",
                    parent=win,
                )

            except Exception as e:
                messagebox.showerror(
                    APP_NAME,
                    f"Помилка експорту Excel:\n{e}",
                    parent=win,
                )

        export_button = ttk.Button(
            top,
            text="Експорт Excel",
            command=export_scan_excel,
            state="disabled",
        )

        export_button.pack(
            side="left",
            padx=5,
        )

        def scan():
            nonlocal last_network

            cidr = entry.get().strip()

            try:
                network = ipaddress.IPv4Network(
                    cidr,
                    strict=False,
                )

            except ValueError:
                messagebox.showerror(
                    APP_NAME,
                    "Некоректна CIDR-мережа.",
                    parent=win,
                )
                return

            # Захист від випадкового сканування
            # надто великої мережі.
            if network.num_addresses > 4096:
                messagebox.showerror(
                    APP_NAME,
                    "Мережа занадто велика.\n"
                    "Максимум: 4096 адрес.",
                    parent=win,
                )
                return

            button.config(
                state="disabled"
            )
            scan_cancel_event.clear()
            export_button.config(
                state="disabled"
            )

            results_cache.clear()
            last_network = str(network)

            for item in tree.get_children():
                tree.delete(item)

            status.config(
                text=(
                    f"Сканування {network}..."
                )
            )

            def worker():
                addresses = [
                    str(ip)
                    for ip in network.hosts()
                ]

                results = []

                def check(ip):
                    if scan_cancel_event.is_set() or self.closed:
                        return None

                    ok, ping, _ = ping_host(
                        ip,
                        1,
                    )

                    mac = get_arp_mac(
                        ip
                    )

                    # A device on the local segment can block ICMP but still
                    # be proven present by its ARP entry.
                    if not ok and not mac:
                        return None

                    hostname = reverse_dns(
                        ip
                    )

                    return (
                        ip,
                        ping,
                        mac,
                        hostname,
                    )

                with concurrent.futures.ThreadPoolExecutor(
                    max_workers=min(
                        64,
                        max(
                            1,
                            len(addresses),
                        ),
                    )
                ) as executor:

                    futures = [
                        executor.submit(
                            check,
                            ip,
                        )
                        for ip in addresses
                    ]

                    completed = 0

                    for future in concurrent.futures.as_completed(
                        futures
                    ):
                        if scan_cancel_event.is_set() or self.closed:
                            for pending in futures:
                                pending.cancel()
                            break

                        completed += 1

                        try:
                            result = future.result()

                            if result:
                                results.append(
                                    result
                                )

                        except Exception:
                            pass

                        progress = (
                            completed
                            / max(
                                1,
                                len(addresses),
                            )
                            * 100
                        )

                        def update_progress(value=progress):
                            try:
                                if win.winfo_exists():
                                    status.config(
                                        text=f"Сканування: {value:.0f}%"
                                    )
                            except tk.TclError:
                                pass

                        self.run_on_gui(update_progress)

                if scan_cancel_event.is_set() or self.closed:
                    return

                results.sort(
                    key=lambda x: tuple(
                        int(v)
                        for v in x[0].split(".")
                    )
                )

                def show_results():
                    try:
                        if not win.winfo_exists():
                            return
                    except tk.TclError:
                        return

                    results_cache.clear()
                    results_cache.extend(
                        results
                    )

                    for item in tree.get_children():
                        tree.delete(item)

                    for (
                        ip,
                        ping,
                        mac,
                        hostname,
                    ) in results:

                        tree.insert(
                            "",
                            "end",
                            values=(
                                ip,
                                fmt_ping(ping),
                                mac or "—",
                                hostname or "—",
                            ),
                        )

                    status.config(
                        text=(
                            f"Знайдено: "
                            f"{len(results)} "
                            f"активних пристроїв"
                            f" | Мережа: {last_network}"
                        )
                    )

                    button.config(
                        state="normal"
                    )

                    export_button.config(
                        state=(
                            "normal"
                            if results
                            else "disabled"
                        )
                    )

                self.run_on_gui(
                    show_results
                )

            threading.Thread(
                target=worker,
                daemon=True,
            ).start()

        button = ttk.Button(
            top,
            text="Сканувати",
            command=scan,
        )

        button.pack(
            side="left",
            padx=5,
        )

        def close_scan_window():
            scan_cancel_event.set()

            try:
                win.destroy()
            except tk.TclError:
                pass

        win.protocol("WM_DELETE_WINDOW", close_scan_window)
        _show_child_window(
            win,
            820,
            650,
            min_width=700,
            min_height=500,
        )

    def detect_local_network(self):
        """
        Визначення локальної IPv4-мережі через маршрут
        до зовнішньої адреси.
        """

        try:
            sock = socket.socket(
                socket.AF_INET,
                socket.SOCK_DGRAM,
            )

            sock.settimeout(
                1
            )

            sock.connect(
                (
                    "8.8.8.8",
                    80,
                )
            )

            local_ip = sock.getsockname()[0]
            sock.close()

            # Отримуємо маску через ipconfig на Windows.
            if sys.platform.startswith("win"):
                result = subprocess.run(
                    [
                        "ipconfig"
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding="cp866",
                    errors="ignore",
                    creationflags=getattr(
                        subprocess,
                        "CREATE_NO_WINDOW",
                        0x08000000,
                    ),
                    timeout=3,
                )

                output = result.stdout

                # Шукаємо блок із локальною адресою.
                lines = output.splitlines()

                for index, line in enumerate(
                    lines
                ):
                    if local_ip in line:
                        for next_line in lines[
                            index:index + 5
                        ]:
                            m = re.search(
                                r"(?:Subnet Mask|Маска підмережі)"
                                r"\s*[.:]\s*"
                                r"(\d+\.\d+\.\d+\.\d+)",
                                next_line,
                                re.IGNORECASE,
                            )

                            if m:
                                mask = m.group(1)

                                network = ipaddress.IPv4Network(
                                    f"{local_ip}/{mask}",
                                    strict=False,
                                )

                                return str(
                                    network
                                )

            return str(
                ipaddress.IPv4Network(
                    f"{local_ip}/24",
                    strict=False,
                )
            )

        except Exception:
            return ""

    def update_mikrotik_data(self):
        if not self.mikrotik_list or self.mikrotik_refresh_busy:
            return

        manager = MultiMikroTikManager(
            self.mikrotik_list
        )

        if not manager.is_configured():
            return

        self.mikrotik_refresh_busy = True

        def worker():
            try:
                data = manager.fetch_data()
                errors = manager.get_last_errors()

                if errors != self.last_mikrotik_errors:
                    for router_name, error in errors.items():
                        if self.last_mikrotik_errors.get(router_name) != error:
                            self.write_log(
                                f"MikroTik {router_name}: {error}",
                                event="MIKROTIK_ERROR",
                            )

                    for router_name in (
                        set(self.last_mikrotik_errors) - set(errors)
                    ):
                        self.write_log(
                            f"MikroTik {router_name}: підключення відновлено.",
                            event="MIKROTIK_RESTORED",
                        )

                    self.last_mikrotik_errors = dict(errors)

                added = (
                    manager.get_last_added_ips()
                )

                self.run_on_gui(
                    lambda d=data, a=added:
                    self.apply_mikrotik_data(
                        d,
                        a,
                    )
                )

            except Exception as e:
                self.write_log(
                    f"Помилка опитування MikroTik: {e}",
                    event="MIKROTIK_ERROR",
                )
            finally:
                self.mikrotik_refresh_busy = False

        threading.Thread(
            target=worker,
            daemon=True,
        ).start()

    def apply_mikrotik_data(
        self,
        data,
        added_ips=None,
    ):
        if not isinstance(
            data,
            dict,
        ):
            return

        added_ips = (
            added_ips
            if isinstance(
                added_ips,
                dict,
            )
            else {}
        )

        with self.hosts_lock:
            hosts = dict(
                self.hosts
            )

        # ---------------------------------------------------------
        # Дані MikroTik
        # ---------------------------------------------------------

        classification_changed = False
        for ip, info in data.items():
            host = hosts.get(ip)

            if host:
                previous_kind = (host.device_kind, host.device_kind_confidence, host.device_kind_reason)
                host.update_mikrotik_data(
                    info
                )
                self.classify_host_passively(host)
                classification_changed = classification_changed or previous_kind != (host.device_kind, host.device_kind_confidence, host.device_kind_reason)

        # ---------------------------------------------------------
        # Якщо MikroTik знайшов нові адреси, перечитуємо app-owned JSON.
        # ---------------------------------------------------------

        if added_ips:
            self.load_devices()

            with self.hosts_lock:
                hosts = dict(
                    self.hosts
                )

            for ip, info in data.items():
                host = hosts.get(ip)

                if host:
                    previous_kind = (host.device_kind, host.device_kind_confidence, host.device_kind_reason)
                    host.update_mikrotik_data(
                        info
                    )
                    self.classify_host_passively(host)
                    classification_changed = classification_changed or previous_kind != (host.device_kind, host.device_kind_confidence, host.device_kind_reason)

            for ip, hostname in added_ips.items():
                self.write_log(
                    f"MikroTik: автоматично "
                    f"додано {ip}"
                    + (
                        f" ({hostname})"
                        if hostname
                        else ""
                    ),
                    ip,
                    "MIKROTIK_ADD",
                )

        if classification_changed:
            self.save_devices()

        for host in hosts.values():
            self.refresh_host_row(
                host
            )

    def refresh_mikrotik_periodically(self):
        if self.closed:
            return

        self.update_mikrotik_data()

        if not self.closed:
            self.root.after(
                15000,
                self.refresh_mikrotik_periodically,
            )

    # =====================================================================
    # DFIR / INCIDENT RESPONSE
    # =====================================================================

    def _dfir_run_powershell(self, script, computer=None):
        """Run local Windows PowerShell and force UTF-8 output for Event Log text."""
        target = computer or "localhost"
        prefix = (
            '$ErrorActionPreference="Stop"; '
            '$ProgressPreference="SilentlyContinue"; '
            '$OutputEncoding = New-Object System.Text.UTF8Encoding($false); '
            '[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); '
            f'$ComputerName="{target}"; '
        )
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        result = subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", prefix + script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=180,
            creationflags=flags,
        )

        def decode_ps(data):
            if not data:
                return ""
            for enc in ("utf-8-sig", "utf-8", "utf-16-le", "cp866", "cp1251"):
                try:
                    return data.decode(enc)
                except UnicodeDecodeError:
                    pass
            return data.decode("utf-8", errors="replace")

        stdout = decode_ps(result.stdout)
        stderr = decode_ps(result.stderr)
        if result.returncode != 0:
            raise RuntimeError(stderr.strip() or f"PowerShell exit code {result.returncode}")
        return stdout

    def _dfir_collect_host(self, ip):
        if not valid_ipv4(ip):
            raise ValueError("Некоректна IPv4-адреса")
        ps = r'''
function Convert-EventToObject($evt) {
    $map=@{}
    try {
        [xml]$xml=$evt.ToXml()
        foreach($d in $xml.Event.EventData.Data) {
            if($d.Name) { $map[[string]$d.Name]=[string]$d.'#text' }
        }
        if($xml.Event.UserData) {
            $nodes=$xml.Event.UserData.SelectNodes('.//*')
            foreach($n in $nodes) {
                if($n.LocalName -and -not [string]::IsNullOrWhiteSpace([string]$n.InnerText)) {
                    if(-not $map.ContainsKey([string]$n.LocalName)) { $map[[string]$n.LocalName]=[string]$n.InnerText }
                }
            }
        }
    } catch {}
    $src=$map['IpAddress']; if([string]::IsNullOrWhiteSpace($src)){$src=$map['SourceAddress']}; if([string]::IsNullOrWhiteSpace($src)){$src=$map['Address']}; if([string]::IsNullOrWhiteSpace($src)){$src=$map['ClientAddress']}; if([string]::IsNullOrWhiteSpace($src)){$src=$map['Param3']}
    if($src -match '^::ffff:(\d+\.\d+\.\d+\.\d+)$'){$src=$Matches[1]}
    if($src -in @('-','::1','127.0.0.1','0.0.0.0','::')){$src=''}
    $user=$map['TargetUserName']; if([string]::IsNullOrWhiteSpace($user)){$user=$map['User']}; if([string]::IsNullOrWhiteSpace($user)){$user=$map['UserName']}; if([string]::IsNullOrWhiteSpace($user)){$user=$map['Param1']}
    $domain=$map['TargetDomainName']; if([string]::IsNullOrWhiteSpace($domain)){$domain=$map['DomainName']}; if([string]::IsNullOrWhiteSpace($domain)){$domain=$map['Param2']}
    [PSCustomObject]@{TimeCreated=if($evt.TimeCreated){$evt.TimeCreated.ToString('o')}else{''};Id=$evt.Id;ProviderName=$evt.ProviderName;LogName=$evt.LogName;MachineName=$evt.MachineName;Message=$evt.Message;SourceIP=$src;SourcePort=if($map['IpPort']){$map['IpPort']}else{$map['SourcePort']};TargetUser=$user;TargetDomain=$domain;SubjectUser=$map['SubjectUserName'];LogonType=$map['LogonType'];TargetLogonId=$map['TargetLogonId'];SubjectLogonId=$map['SubjectLogonId'];LogonId=if($map['LogonId']){$map['LogonId']}else{$map['SessionID']};SessionId=if($map['SessionID']){$map['SessionID']}else{$map['SessionId']};WorkstationName=$map['WorkstationName'];ProcessName=if($map['ProcessName']){$map['ProcessName']}else{$map['NewProcessName']};NewProcessId=$map['NewProcessId'];ParentProcessName=$map['ParentProcessName'];Status=$map['Status'];SubStatus=$map['SubStatus'];AuthenticationPackage=$map['AuthenticationPackageName'];ServiceName=$map['ServiceName'];ServiceFileName=if($map['ServiceFileName']){$map['ServiceFileName']}else{$map['ImagePath']};TaskName=$map['TaskName'];CommandLine=$map['CommandLine']}
}
$events=@();$collectionIssues=@();$start=(Get-Date).AddDays(-30)
try {$ids=@(4624,4625,4634,4647,4648,4672,4688,4697,4698,4700,4702,1102);$events += @(Get-WinEvent -ComputerName $ComputerName -FilterHashtable @{LogName='Security';Id=$ids;StartTime=$start} -MaxEvents 4000 -ErrorAction Stop | ForEach-Object { Convert-EventToObject $_ })} catch {$collectionIssues += "Security log: $($_.Exception.Message)"}
try {$events += @(Get-WinEvent -ComputerName $ComputerName -FilterHashtable @{LogName='System';Id=7045;StartTime=$start} -MaxEvents 1000 -ErrorAction Stop | ForEach-Object { Convert-EventToObject $_ })} catch {$collectionIssues += "System log: $($_.Exception.Message)"}
try {$events += @(Get-WinEvent -ComputerName $ComputerName -FilterHashtable @{LogName='Microsoft-Windows-PowerShell/Operational';Id=@(4103,4104);StartTime=$start} -MaxEvents 2500 -ErrorAction Stop | ForEach-Object { Convert-EventToObject $_ })} catch {$collectionIssues += "PowerShell log: $($_.Exception.Message)"}
try {$events += @(Get-WinEvent -ComputerName $ComputerName -FilterHashtable @{LogName='Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational';Id=1149;StartTime=$start} -MaxEvents 1500 -ErrorAction Stop | ForEach-Object { Convert-EventToObject $_ })} catch {$collectionIssues += "RDP authentication log: $($_.Exception.Message)"}
try {$events += @(Get-WinEvent -ComputerName $ComputerName -FilterHashtable @{LogName='Microsoft-Windows-TerminalServices-LocalSessionManager/Operational';Id=@(21,24,25);StartTime=$start} -MaxEvents 1500 -ErrorAction Stop | ForEach-Object { Convert-EventToObject $_ })} catch {$collectionIssues += "RDP session log: $($_.Exception.Message)"}
$processes=@();try{$processes=Get-CimInstance Win32_Process -ComputerName $ComputerName -ErrorAction Stop|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate}catch{$collectionIssues += "Processes: $($_.Exception.Message)"}
$services=@();try{$services=Get-CimInstance Win32_Service -ComputerName $ComputerName -ErrorAction Stop|Select-Object Name,DisplayName,State,StartMode,StartName,PathName}catch{$collectionIssues += "Services: $($_.Exception.Message)"}
$users=@();try{$users=Get-CimInstance Win32_UserAccount -ComputerName $ComputerName -ErrorAction Stop|Select-Object Name,Domain,Disabled,Lockout,Local}catch{$collectionIssues += "Users: $($_.Exception.Message)"}
$connections=@();try{$cs=New-CimSession -ComputerName $ComputerName -ErrorAction Stop;$connections=Get-NetTCPConnection -CimSession $cs -ErrorAction Stop|Select-Object LocalAddress,LocalPort,RemoteAddress,RemotePort,State,OwningProcess;Remove-CimSession $cs}catch{$collectionIssues += "Connections: $($_.Exception.Message)"}
$tasks=@();try{$cs=New-CimSession -ComputerName $ComputerName -ErrorAction Stop;$tasks=Get-ScheduledTask -CimSession $cs -ErrorAction Stop|Select-Object TaskName,TaskPath,State;Remove-CimSession $cs}catch{$collectionIssues += "Scheduled tasks: $($_.Exception.Message)"}
$os=@{};try{$os=Get-CimInstance Win32_OperatingSystem -ComputerName $ComputerName -ErrorAction Stop|Select-Object Caption,Version,BuildNumber,LastBootUpTime,CSName}catch{$collectionIssues += "Operating system: $($_.Exception.Message)"}
[PSCustomObject]@{Computer=$ComputerName;CollectedAt=(Get-Date).ToString('o');CollectionIssues=@($collectionIssues);OS=$os;Events=@($events|Sort-Object TimeCreated -Descending);Processes=$processes;Services=$services;Users=$users;Connections=$connections;ScheduledTasks=$tasks}|ConvertTo-Json -Depth 10 -Compress
'''
        data = json.loads(self._dfir_run_powershell(ps, computer=ip))
        self._dfir_correlate_sources(data)
        return data

    def _dfir_parse_time(self, value):
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except Exception:
            return None

    def _dfir_normalize_logon_id(self, value):
        value = str(value or "").strip().lower()
        return "" if not value or value in ("-", "0x0", "0") else value

    def _dfir_direct_source(self, event):
        src = str(event.get("SourceIP") or "").strip()
        if src.startswith("::ffff:"):
            src = src[7:]
        return "" if src in ("-", "::1", "127.0.0.1", "0.0.0.0", "::") else src

    def _dfir_effective_source(self, event):
        return self._dfir_direct_source(event) or str(event.get("CorrelatedSourceIP") or "").strip() or ""

    def _dfir_correlate_sources(self, data):
        events = list(data.get("Events") or [])
        sessions=[];by_logon={}
        for e in events:
            eid=int(e.get("Id") or 0);src=self._dfir_direct_source(e);when=self._dfir_parse_time(e.get("TimeCreated"));user=str(e.get("TargetUser") or e.get("SubjectUser") or "").strip();lid=self._dfir_normalize_logon_id(e.get("TargetLogonId") or e.get("LogonId") or e.get("SessionId"))
            if eid in (4624,1149,21,24,25) and src:
                a={"source":src,"time":when,"user":user,"logon_id":lid,"event_id":eid};sessions.append(a)
                if lid:by_logon[lid]=a
        for e in events:
            if self._dfir_direct_source(e):e["SourceConfidence"]="DIRECT";e["CorrelationReason"]="IP записаний у самій події Windows";continue
            eid=int(e.get("Id") or 0);when=self._dfir_parse_time(e.get("TimeCreated"));user=str(e.get("TargetUser") or e.get("SubjectUser") or "").strip();cand=None;reason="";conf=""
            for key in ("SubjectLogonId","TargetLogonId","LogonId","SessionId"):
                lid=self._dfir_normalize_logon_id(e.get(key))
                if lid and lid in by_logon:cand=by_logon[lid];reason=f"кореляція за {key}={lid}";conf="HIGH";break
            if cand is None and when is not None and eid in (4103,4104,4688,4697,7045,4698,4700,4702,4672):
                candidates=[]
                for a in sessions:
                    if a["time"] is None:continue
                    try:delta=(when-a["time"]).total_seconds()
                    except TypeError:continue
                    if 0<=delta<=1800:
                        score=delta-(600 if user and a["user"] and user.lower()==a["user"].lower() else 0);candidates.append((score,delta,a))
                if candidates:
                    candidates.sort(key=lambda x:x[0]);_,delta,cand=candidates[0];reason=f"найближчий попередній віддалений вхід, {int(delta)} с до події";conf="MEDIUM" if user and cand.get("user") and user.lower()==cand.get("user","").lower() else "LOW"
            if cand:e["CorrelatedSourceIP"]=cand["source"];e["SourceConfidence"]=conf;e["CorrelationReason"]=reason
            else:e["CorrelatedSourceIP"]="";e["SourceConfidence"]="UNKNOWN";e["CorrelationReason"]="недостатньо даних у Windows Event Logs"
        data["Events"]=events

    def _dfir_score_event(self,event):
        eid=int(event.get("Id") or 0);msg=(event.get("Message") or "").lower();score=0;reasons=[]
        weights={4625:(20,"невдала автентифікація"),4624:(5,"успішна автентифікація"),1149:(15,"RDP автентифікація"),21:(15,"RDP session logon"),24:(20,"RDP disconnect"),25:(20,"RDP reconnect"),4648:(25,"явне використання облікових даних"),4672:(20,"привілейований доступ"),4688:(10,"створення процесу"),4697:(50,"встановлення служби"),7045:(50,"створення служби"),4698:(45,"створення Scheduled Task"),4700:(45,"активація Scheduled Task"),4702:(45,"зміна Scheduled Task"),1102:(80,"очищення Security Log"),4103:(35,"PowerShell activity"),4104:(35,"PowerShell activity")}
        if eid in weights:w,r=weights[eid];score+=w;reasons.append(r)
        if any(x in msg for x in ("encodedcommand","-enc ","frombase64string","downloadstring","invoke-webrequest","iex ")):score+=35;reasons.append("підозрілий PowerShell pattern")
        if any(x in msg for x in ("\\temp\\","\\appdata\\","\\downloads\\")):score+=20;reasons.append("нетиповий каталог")
        score=min(score,100);severity="CRITICAL" if score>=80 else "HIGH" if score>=55 else "MEDIUM" if score>=30 else "LOW";return score,severity,reasons

    def _dfir_event_result(self,event):
        eid=int(event.get("Id") or 0);return "FAILED" if eid==4625 else "SUCCESS" if eid in (4624,1149,21,25) else "EVENT"

    def _dfir_event_action(self,event):
        eid=int(event.get("Id") or 0);lt=str(event.get("LogonType") or "")
        if eid in (4624,4625):
            names={2:"Interactive",3:"Network/SMB",4:"Batch",5:"Service",7:"Unlock",8:"NetworkCleartext",9:"NewCredentials",10:"RDP/RemoteInteractive",11:"CachedInteractive"}
            try:suffix=names.get(int(lt),f"LogonType {lt}")
            except Exception:suffix=f"LogonType {lt}" if lt else "Logon"
            return ("Успішний вхід — " if eid==4624 else "Невдалий вхід — ")+suffix
        return {1149:"RDP автентифікація",21:"RDP вхід у сесію",24:"RDP відключення",25:"RDP повторне підключення",4648:"Явні облікові дані",4672:"Привілейований доступ",4688:"Створення процесу",4697:"Встановлення служби",7045:"Створення служби",4698:"Scheduled Task створено",4700:"Scheduled Task активовано",4702:"Scheduled Task змінено",1102:"Очищення Security Log",4103:"PowerShell",4104:"PowerShell ScriptBlock"}.get(eid,f"Windows Event {eid}")

    def _dfir_analyze(self, data, ip):
        events = list(data.get("Events") or [])
        incidents = []
        failed_by_source = {}
        successful_events = []

        for event in events:
            try:
                event_id = int(event.get("Id") or 0)
            except (TypeError, ValueError):
                continue

            source = self._dfir_effective_source(event)
            event_time = self._dfir_parse_time(event.get("TimeCreated"))
            event_timestamp = (
                event_time.timestamp()
                if event_time is not None
                else None
            )

            if event_id == 4625 and source and event_timestamp is not None:
                failed_by_source.setdefault(source, []).append(
                    (event_timestamp, event)
                )
            elif (
                event_id in (4624, 1149, 21, 25)
                and source
                and event_timestamp is not None
            ):
                successful_events.append((event_timestamp, source, event))

        # Five or more failures must occur inside one ten-minute window.
        # This avoids classifying a few unrelated failures across 30 days as
        # a brute-force incident.
        for source, timed_events in failed_by_source.items():
            timed_events.sort(key=lambda item: item[0])
            left = 0
            strongest_window = []

            for right in range(len(timed_events)):
                while (
                    left < right
                    and timed_events[right][0] - timed_events[left][0] > 600
                ):
                    left += 1

                window = timed_events[left:right + 1]

                if len(window) > len(strongest_window):
                    strongest_window = window

            if len(strongest_window) < 5:
                continue

            failed_events = [item[1] for item in strongest_window]
            users = sorted({
                str(event.get("TargetUser") or "").strip()
                for event in failed_events
                if str(event.get("TargetUser") or "").strip()
            })
            confidence = (
                failed_events[-1].get("SourceConfidence") or "UNKNOWN"
            )
            first_time = strongest_window[0][0]
            last_time = strongest_window[-1][0]

            incidents.append({
                "severity": "HIGH",
                "score": 70,
                "source": source,
                "source_confidence": confidence,
                "target": ip,
                "user": ", ".join(users[:5]) or "—",
                "result": "FAILED",
                "title": "Масові невдалі спроби автентифікації",
                "details": (
                    f"{len(strongest_window)} невдалих входів з {source} "
                    f"на {ip} протягом "
                    f"{int(last_time - first_time)} с."
                ),
                "time": strongest_window[-1][1].get("TimeCreated"),
            })

            matching_successes = []

            for success_time, success_source, success_event in successful_events:
                if success_source != source:
                    continue

                delta = success_time - last_time

                if 0 <= delta <= 1800:
                    matching_successes.append(
                        (success_time, success_event, delta)
                    )

            if matching_successes:
                matching_successes.sort(key=lambda item: item[0])
                _, success_event, delta = matching_successes[0]
                incidents.append({
                    "severity": "CRITICAL",
                    "score": 95,
                    "source": source,
                    "source_confidence": (
                        success_event.get("SourceConfidence") or "UNKNOWN"
                    ),
                    "target": ip,
                    "user": success_event.get("TargetUser") or "—",
                    "result": "SUCCESS",
                    "title": "Успішний вхід після серії невдалих",
                    "details": (
                        f"Після {len(strongest_window)} невдалих входів "
                        f"зафіксовано успішний вхід з {source} через "
                        f"{int(delta)} с."
                    ),
                    "time": success_event.get("TimeCreated"),
                })

        for event in events:
            score, severity, reasons = self._dfir_score_event(event)

            if score < 45:
                continue

            source = self._dfir_effective_source(event) or "—"
            confidence = event.get("SourceConfidence") or "UNKNOWN"
            correlation = event.get("CorrelationReason") or ""
            details = (
                "; ".join(reasons)
                or str(event.get("Message") or "")[:500]
            )

            if source != "—" and confidence != "DIRECT":
                details += (
                    f" | Source IP {source} "
                    f"({confidence}: {correlation})"
                )

            incidents.append({
                "severity": severity,
                "score": score,
                "source": source,
                "source_confidence": confidence,
                "target": ip,
                "user": (
                    event.get("TargetUser")
                    or event.get("SubjectUser")
                    or "—"
                ),
                "result": self._dfir_event_result(event),
                "title": self._dfir_event_action(event),
                "details": details,
                "time": event.get("TimeCreated"),
            })

        return sorted(
            incidents,
            key=lambda item: item.get("score", 0),
            reverse=True,
        )

    def load_scan_defense_settings(self):
        defaults = {
            "realtime_alerts": True,
            "auto_block": True,
            "trusted_ips": [],
        }
        try:
            with open(SCAN_DEFENSE_SETTINGS_FILE, "r", encoding="utf-8") as handle:
                stored = json.load(handle)
            if isinstance(stored, dict):
                defaults["realtime_alerts"] = bool(stored.get("realtime_alerts", True))
                defaults["auto_block"] = bool(stored.get("auto_block", True))
                trusted = []
                for value in stored.get("trusted_ips", []):
                    value = str(value or "").strip()
                    if valid_ipv4(value) and value not in trusted:
                        trusted.append(value)
                defaults["trusted_ips"] = trusted
        except (OSError, ValueError, TypeError):
            pass
        return defaults

    def save_scan_defense_settings(self):
        try:
            atomic_write_json(SCAN_DEFENSE_SETTINGS_FILE, self.scan_defense_settings)
        except Exception as exc:
            self.scan_watch_last_error = str(exc)

    def _set_scan_defense_option(self, name, value):
        if name not in ("realtime_alerts", "auto_block"):
            return
        self.scan_defense_settings[name] = bool(value)
        self.save_scan_defense_settings()

    def _update_scan_defense_record(self, source_ip, status, detail=""):
        changed = False
        with self.scan_watch_lock:
            for row in reversed(self.scan_watch_records):
                if row.get("source_ip") != source_ip:
                    continue
                row["defense_status"] = str(status or "")
                row["defense_detail"] = str(detail or "")[:500]
                row["defense_ts"] = time.time()
                changed = True
                break
        if changed:
            self.save_scan_watch_records()
        return changed

    def _scan_detection_is_active(self, detection, now=None):
        try:
            age = float(now if now is not None else time.time()) - float(detection.get("last_ts", 0))
            return -5 <= age <= SCAN_WATCH_ACTIVE_SECONDS
        except (TypeError, ValueError):
            return False

    def _scan_alert_due(self, detection, now=None):
        if not self._scan_detection_is_active(detection, now=now):
            return False
        source = str(detection.get("source_ip") or "")
        if not source:
            return False
        current = float(now if now is not None else time.time())
        previous = self.scan_watch_last_alert.get(source, {})
        signature = (
            int(detection.get("attempts", 0) or 0),
            int(detection.get("unique_ports", 0) or 0),
            str(detection.get("level") or ""),
        )
        if (
            previous.get("signature") == signature
            and current - float(previous.get("time", 0) or 0) < SCAN_WATCH_ALERT_COOLDOWN_SECONDS
        ):
            return False
        self.scan_watch_last_alert[source] = {"time": current, "signature": signature}
        return True

    def _log_scan_defense(self, source_ip, event_type, message):
        try:
            self.db.add_event(source_ip, event_type, message)
        except Exception:
            pass
        try:
            LOGGER.info("%s | source=%s | %s", event_type, source_ip, message)
        except Exception:
            pass

    def _apply_scan_firewall_action(self, source_ip, blocked, *, alert_data=None):
        action = "SCAN_IP_BLOCK" if blocked else "SCAN_IP_UNBLOCK"
        status = "BLOCKING" if blocked else "UNBLOCKING"
        self._update_scan_defense_record(source_ip, status)
        if alert_data:
            self.run_on_gui(
                lambda d=dict(alert_data): self.show_scan_defense_alert(
                    d,
                    "Створюю локальне правило Windows Firewall...",
                )
            )
        ok, message = set_windows_firewall_block(source_ip, blocked=blocked, allow_elevation=True)
        final_status = "BLOCKED" if ok and blocked else "TRUSTED" if ok else "FAILED"
        self._update_scan_defense_record(source_ip, final_status, message)
        self._log_scan_defense(source_ip, action if ok else action + "_FAILED", message)
        if alert_data:
            self.run_on_gui(
                lambda d=dict(alert_data), m=message: self.show_scan_defense_alert(d, m)
            )
        self.run_on_gui(self.refresh_scan_watch_window)
        return ok, message

    def process_active_scan_detections(self, detections):
        """Notify and locally block fresh detections; never contact the source host."""
        now = time.time()
        trusted = set(self.scan_defense_settings.get("trusted_ips", []))
        alerts_enabled = bool(self.scan_defense_settings.get("realtime_alerts", True))
        auto_block = bool(self.scan_defense_settings.get("auto_block", True))
        for detection in detections:
            if not self._scan_detection_is_active(detection, now=now):
                continue
            source_ip = str(detection.get("source_ip") or "")
            if not valid_ipv4(source_ip):
                continue
            if source_ip in trusted:
                self._update_scan_defense_record(source_ip, "TRUSTED", "IP є у списку довірених.")
                continue

            alert_due = alerts_enabled and self._scan_alert_due(detection, now=now)
            if alert_due:
                self.run_on_gui(
                    lambda d=dict(detection): self.show_scan_defense_alert(
                        d,
                        "Виявлено активне сканування. Захисна реакція готується.",
                    )
                )

            previous_attempt = float(self.scan_watch_block_attempts.get(source_ip, 0) or 0)
            if auto_block and now - previous_attempt >= SCAN_WATCH_BLOCK_RETRY_SECONDS:
                self.scan_watch_block_attempts[source_ip] = now
                self._apply_scan_firewall_action(
                    source_ip,
                    True,
                    alert_data=detection if alerts_enabled else None,
                )

    def block_scan_source(self, source_ip, detection=None):
        source_ip = str(source_ip or "").strip()
        if not valid_ipv4(source_ip):
            return
        self.scan_watch_block_attempts[source_ip] = time.time()
        data = dict(detection or {"source_ip": source_ip})
        threading.Thread(
            target=self._apply_scan_firewall_action,
            args=(source_ip, True),
            kwargs={"alert_data": data},
            daemon=True,
            name="ScanDefenseBlock",
        ).start()

    def trust_scan_source(self, source_ip, detection=None):
        source_ip = str(source_ip or "").strip()
        if not valid_ipv4(source_ip):
            return
        trusted = self.scan_defense_settings.setdefault("trusted_ips", [])
        if source_ip not in trusted:
            trusted.append(source_ip)
            self.save_scan_defense_settings()
        self._update_scan_defense_record(source_ip, "TRUSTED", "IP додано до списку довірених.")
        data = dict(detection or {"source_ip": source_ip})
        threading.Thread(
            target=self._apply_scan_firewall_action,
            args=(source_ip, False),
            kwargs={"alert_data": data},
            daemon=True,
            name="ScanDefenseTrust",
        ).start()

    def show_scan_defense_alert(self, detection, status_text=""):
        source_ip = str(detection.get("source_ip") or "—")
        current = self.scan_watch_alert_windows.get(source_ip)
        if current:
            try:
                if current["window"].winfo_exists():
                    current["summary"].set(self._scan_alert_summary(detection))
                    current["details"].set(self._scan_alert_details(detection))
                    current["status"].set(status_text)
                    current["detection"] = dict(detection)
                    current["window"].attributes("-topmost", True)
                    current["window"].lift()
                    return
            except tk.TclError:
                pass
            self.scan_watch_alert_windows.pop(source_ip, None)

        win = tk.Toplevel(self.root)
        win.title(f"{APP_NAME} — ALERT — {source_ip}")
        win.configure(background="#210811")
        win.attributes("-topmost", True)
        win.resizable(True, True)
        win.minsize(560, 360)

        tk.Label(
            win,
            text="☠  ВАС СКАНУЮТЬ",
            bg="#210811",
            fg="#FF4D6D",
            font=("Segoe UI Symbol", 30, "bold"),
            pady=16,
        ).pack(fill="x")
        summary_var = tk.StringVar(value=self._scan_alert_summary(detection))
        tk.Label(
            win,
            textvariable=summary_var,
            justify="center",
            bg="#5A1022",
            fg="#FFFFFF",
            font=("Segoe UI", 16, "bold"),
            padx=18,
            pady=12,
        ).pack(fill="x", padx=18)
        details_var = tk.StringVar(value=self._scan_alert_details(detection))
        status_var = tk.StringVar(value=status_text)
        tk.Label(
            win,
            textvariable=details_var,
            justify="left",
            anchor="w",
            bg="#210811",
            fg="#F5DDE4",
            font=("Consolas", 12),
            padx=24,
            pady=16,
        ).pack(fill="both", expand=True)
        tk.Label(
            win,
            textvariable=status_var,
            justify="left",
            anchor="w",
            wraplength=600,
            bg="#32101A",
            fg="#FFC857",
            font=("Segoe UI", 11, "bold"),
            padx=18,
            pady=10,
        ).pack(fill="x", padx=18, pady=(0, 10))

        buttons = tk.Frame(win, bg="#210811", padx=18, pady=10)
        buttons.pack(fill="x")
        tk.Button(
            buttons,
            text="ЗАБЛОКУВАТИ IP",
            command=lambda: self.block_scan_source(
                source_ip,
                self.scan_watch_alert_windows.get(source_ip, {}).get("detection", detection),
            ),
            bg="#FF4D6D",
            fg="#120107",
            activebackground="#FF758E",
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=14,
            pady=8,
        ).pack(side="left")
        tk.Button(
            buttons,
            text="ДОВІРЯТИ IP",
            command=lambda: self.trust_scan_source(
                source_ip,
                self.scan_watch_alert_windows.get(source_ip, {}).get("detection", detection),
            ),
            bg="#194257",
            fg="#E8FAFF",
            activebackground="#235A70",
            font=("Segoe UI", 10),
            relief="flat",
            padx=14,
            pady=8,
        ).pack(side="left", padx=8)
        tk.Button(
            buttons,
            text="ВІДКРИТИ ЖУРНАЛ",
            command=self.open_scan_watch_window,
            bg="#194257",
            fg="#E8FAFF",
            activebackground="#235A70",
            font=("Segoe UI", 10),
            relief="flat",
            padx=14,
            pady=8,
        ).pack(side="left")

        def close_alert():
            self.scan_watch_alert_windows.pop(source_ip, None)
            try:
                win.destroy()
            except tk.TclError:
                pass

        tk.Button(
            buttons,
            text="ЗАКРИТИ",
            command=close_alert,
            bg="#194257",
            fg="#E8FAFF",
            activebackground="#235A70",
            font=("Segoe UI", 10),
            relief="flat",
            padx=14,
            pady=8,
        ).pack(side="right")
        win.protocol("WM_DELETE_WINDOW", close_alert)
        self.scan_watch_alert_windows[source_ip] = {
            "window": win,
            "summary": summary_var,
            "details": details_var,
            "status": status_var,
            "detection": dict(detection),
        }

        def alarm_tick():
            try:
                current_alert = self.scan_watch_alert_windows.get(source_ip)
                if not current_alert or current_alert.get("window") is not win or not win.winfo_exists():
                    return
                if winsound is not None:
                    winsound.MessageBeep(winsound.MB_ICONHAND)
                else:
                    win.bell()
                win.attributes("-topmost", True)
                win.lift()
                win.after(1100, alarm_tick)
            except (tk.TclError, RuntimeError):
                return

        _center_window(win, 680, 430, min_width=560, min_height=360)
        try:
            win.lift()
            win.focus_force()
        except tk.TclError:
            pass
        alarm_tick()

    def _scan_alert_summary(self, detection):
        return (
            f"ХТО СКАНУЄ:  {detection.get('source_ip', '—')}\n"
            f"КІЛЬКІСТЬ СПРОБ:  {detection.get('attempts', 0)}\n"
            f"ТИП:  {detection.get('scan_type', 'НЕ ВИЗНАЧЕНО')}"
        )

    def _scan_alert_details(self, detection):
        ports = ", ".join(str(value) for value in detection.get("ports", [])[:24]) or "—"
        targets = ", ".join(str(value) for value in detection.get("targets", [])[:5]) or "локальний ПК"
        users = ", ".join(str(value) for value in detection.get("target_users", [])[:5]) or "—"
        return (
            f"РІВЕНЬ:      {detection.get('level', '—')}\n"
            f"ДОСТОВІРНІСТЬ: {detection.get('scan_confidence', '—')}\n"
            f"ПОРТИ:       {ports}\n"
            f"ЦІЛЬ:        {targets}\n"
            f"КОРИСТУВАЧІ: {users}\n"
            f"ОСТАННЯ:     {detection.get('last_seen', '—')}\n"
            f"ПОЯСНЕННЯ:   {detection.get('scan_reason', '—')}"
        )

    def load_scan_watch_records(self):
        """Завантажує локальний список виявлених ознак мережевого сканування."""
        with self.scan_watch_lock:
            self.scan_watch_records = []
            try:
                if not os.path.exists(NETWORK_SCAN_WATCH_FILE):
                    return
                with open(NETWORK_SCAN_WATCH_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    cutoff = (
                        time.time()
                        - NETWORK_SCAN_RETENTION_DAYS * 86400
                    )
                    cleaned = []

                    for item in data:
                        if not isinstance(item, dict):
                            continue

                        try:
                            if float(item.get("last_ts", 0) or 0) >= cutoff:
                                cleaned.append(item)
                        except (TypeError, ValueError):
                            continue

                    self.scan_watch_records = cleaned[-2000:]
            except Exception as e:
                self.scan_watch_last_error = str(e)
                self.scan_watch_records = []

    def save_scan_watch_records(self):
        with self.scan_watch_lock:
            cutoff = time.time() - NETWORK_SCAN_RETENTION_DAYS * 86400
            cleaned = []
            for item in self.scan_watch_records:
                try:
                    if float(item.get("last_ts", 0) or 0) >= cutoff:
                        cleaned.append(item)
                except Exception:
                    continue
            self.scan_watch_records = cleaned[-2000:]
            tmp = NETWORK_SCAN_WATCH_FILE + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.scan_watch_records, f, ensure_ascii=False, indent=2)
                os.replace(tmp, NETWORK_SCAN_WATCH_FILE)
            except Exception as e:
                self.scan_watch_last_error = str(e)

    def load_scan_watch_probe_records(self):
        """Load individual inbound TCP/UDP observations for every destination port."""
        with self.scan_watch_lock:
            self.scan_watch_probe_records = []
            try:
                if not os.path.exists(NETWORK_PORT_ATTEMPTS_FILE):
                    return
                with open(NETWORK_PORT_ATTEMPTS_FILE, "r", encoding="utf-8") as stream:
                    data = json.load(stream)
                cutoff = time.time() - NETWORK_SCAN_RETENTION_DAYS * 86400
                if isinstance(data, list):
                    self.scan_watch_probe_records = [
                        row for row in data
                        if isinstance(row, dict) and float(row.get("ts", 0) or 0) >= cutoff
                    ][-10000:]
            except Exception as exc:
                self.scan_watch_last_error = str(exc)
                self.scan_watch_probe_records = []

    def save_scan_watch_probe_records(self):
        with self.scan_watch_lock:
            cutoff = time.time() - NETWORK_SCAN_RETENTION_DAYS * 86400
            self.scan_watch_probe_records = [
                row for row in self.scan_watch_probe_records
                if isinstance(row, dict) and float(row.get("ts", 0) or 0) >= cutoff
            ][-10000:]
            tmp = NETWORK_PORT_ATTEMPTS_FILE + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as stream:
                    json.dump(self.scan_watch_probe_records, stream, ensure_ascii=False, indent=2)
                os.replace(tmp, NETWORK_PORT_ATTEMPTS_FILE)
            except Exception as exc:
                self.scan_watch_last_error = str(exc)

    def get_local_ipv4_addresses(self):
        result = {"127.0.0.1"}
        try:
            for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
                if valid_ipv4(ip):
                    result.add(ip)
        except Exception:
            pass
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            result.add(s.getsockname()[0])
            s.close()
        except Exception:
            pass
        return result

    def _scan_sensor_log_status(self):
        if not sys.platform.startswith("win"):
            return False, "Сенсор підтримується лише у Windows."
        path = os.path.join(
            os.environ.get("SystemRoot", r"C:\Windows"),
            "System32",
            "LogFiles",
            "Firewall",
            "pfirewall.log",
        )
        if not os.path.exists(path):
            return False, "Журнал Windows Firewall ще не створений. Увімкніть сенсор і повторіть тестове сканування."
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as stream:
                stream.read(256)
        except OSError as exc:
            return False, f"Журнал Firewall недоступний для читання: {exc}"
        return True, "Сенсор активний: журнал Windows Firewall доступний."

    def _initialize_scan_sensor(self):
        if self.scan_sensor_setup_busy or not sys.platform.startswith("win"):
            return
        self.scan_sensor_setup_busy = True

        def worker():
            try:
                ok, message = enable_windows_scan_sensor(allow_elevation=False)
                self.scan_sensor_status = message
                if not ok:
                    LOGGER.warning("Scan sensor initialization: %s", message)
            finally:
                self.scan_sensor_setup_busy = False
                self.run_on_gui(self.refresh_scan_watch_window)

        threading.Thread(target=worker, daemon=True, name="ScanSensorInit").start()

    def enable_scan_sensor_interactive(self):
        """Enable only local Windows audit sources after the user's UI action."""
        if self.scan_sensor_setup_busy:
            return
        self.scan_sensor_setup_busy = True
        self.scan_sensor_status = "Очікується підтвердження Windows UAC..."
        sensor_var = getattr(self, "scan_sensor_status_var", None)
        if sensor_var is not None:
            sensor_var.set(self.scan_sensor_status)

        def worker():
            try:
                ok, message = enable_windows_scan_sensor(allow_elevation=True)
                self.scan_sensor_status = message
                self._log_scan_defense(
                    None,
                    "SCAN_SENSOR_ENABLED" if ok else "SCAN_SENSOR_ENABLE_FAILED",
                    message,
                )
            finally:
                self.scan_sensor_setup_busy = False
                self.run_on_gui(self.refresh_scan_watch_window)

        threading.Thread(target=worker, daemon=True, name="ScanSensorSetup").start()

    def _powershell_scan_watch_events(self, minutes=10):
        """Читає локальний Security Event Log без активного сканування мережі."""
        if not sys.platform.startswith("win"):
            return []
        ps = """
$ErrorActionPreference='Continue'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$ids = 5152,5156,5157,4625
$start = (Get-Date).AddMinutes(-MINUTES_TOKEN)
$out = @()
try {
$out += @(Get-WinEvent -FilterHashtable @{LogName='Security'; Id=$ids; StartTime=$start} -ErrorAction Stop | ForEach-Object {
    $xml = [xml]$_.ToXml()
    $d = @{}
    foreach($x in $xml.Event.EventData.Data){ if($x.Name){ $d[$x.Name] = [string]$x.'#text' } }
    [PSCustomObject]@{
        Time = $_.TimeCreated.ToString('o')
        EventId = $_.Id
        RecordId = $_.RecordId
        SourceAddress = if($d['SourceAddress']) {$d['SourceAddress']} else {$d['IpAddress']}
        SourcePort = if($d['SourcePort']) {$d['SourcePort']} else {$d['IpPort']}
        DestAddress = $d['DestAddress']
        DestPort = $d['DestPort']
        Protocol = $d['Protocol']
        Application = $d['Application']
        Direction = if($d['Direction'] -eq '%%14592') {'INBOUND'} elseif($d['Direction'] -eq '%%14593') {'OUTBOUND'} else {$d['Direction']}
        EventCategory = if($_.Id -eq 4625) {'AUTH_FAILURE'} else {'NETWORK'}
        Action = if($_.Id -in 5152,5157) {'BLOCKED'} elseif($_.Id -eq 5156) {'ALLOWED'} else {'OBSERVED'}
        TargetUser = $d['TargetUserName']
        EvidenceSource = 'Windows Security / Filtering Platform'
    }
})
} catch {
    if ($_.FullyQualifiedErrorId -notlike 'NoMatchingEventsFound*') { $null = $_.Exception.Message }
}
try {
    if (Get-WinEvent -ListLog 'Microsoft-Windows-Sysmon/Operational' -ErrorAction SilentlyContinue) {
        $out += @(Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=3; StartTime=$start} -ErrorAction Stop | ForEach-Object {
            $xml = [xml]$_.ToXml()
            $d = @{}
            foreach($x in $xml.Event.EventData.Data){ if($x.Name){ $d[$x.Name] = [string]$x.'#text' } }
            [PSCustomObject]@{
                Time = $_.TimeCreated.ToString('o')
                EventId = 'SYSMON-3'
                RecordId = $_.RecordId
                SourceAddress = $d['SourceIp']
                SourcePort = $d['SourcePort']
                DestAddress = $d['DestinationIp']
                DestPort = $d['DestinationPort']
                Protocol = $d['Protocol']
                Application = $d['Image']
                Direction = if(([string]$d['Initiated']).ToLowerInvariant() -eq 'false') {'INBOUND'} else {'OUTBOUND'}
                EventCategory = 'NETWORK'
                Action = 'OBSERVED'
                TargetUser = $d['User']
                EvidenceSource = 'Sysmon Event 3'
            }
        })
    }
} catch {}
try {
    $tcp = @(Get-NetTCPConnection -ErrorAction Stop)
    $listenPorts = @{}
    foreach($connection in $tcp){ if([string]$connection.State -eq 'Listen'){ $listenPorts[[string]$connection.LocalPort] = $true } }
    foreach($connection in $tcp){
        $state = [string]$connection.State
        $remote = [string]$connection.RemoteAddress
        if(($state -eq 'Established' -or $state -eq 'SynReceived') -and $listenPorts.ContainsKey([string]$connection.LocalPort) -and $remote -and $remote -notin @('0.0.0.0','127.0.0.1','::','::1')){
            $created = if($connection.CreationTime){$connection.CreationTime.ToString('o')}else{(Get-Date).ToString('o')}
            [string]$snapshotId = 'TCP|' + $connection.LocalAddress + '|' + $connection.LocalPort + '|' + $remote + '|' + $connection.RemotePort + '|' + $created
            $out += [PSCustomObject]@{
                Time = $created
                EventId = 'TCP-SNAPSHOT'
                RecordId = $snapshotId
                SourceAddress = $remote
                SourcePort = $connection.RemotePort
                DestAddress = $connection.LocalAddress
                DestPort = $connection.LocalPort
                Protocol = 'TCP'
                Application = 'Windows TCP/IP stack'
                Direction = 'INBOUND'
                EventCategory = 'NETWORK'
                Action = 'ALLOWED'
                TargetUser = ''
                EvidenceSource = 'Active TCP connection snapshot'
            }
        }
    }
} catch {}
@($out) | ConvertTo-Json -Depth 4 -Compress
""".replace("MINUTES_TOKEN", str(int(minutes)))
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        try:
            cp = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=20,
                creationflags=flags,
            )
            if cp.returncode != 0:
                detail=(cp.stderr or cp.stdout or "Security Event Log недоступний").strip()
                first=next((line.strip() for line in detail.splitlines() if line.strip() and not line.lstrip().startswith(('+','At line:','CategoryInfo','FullyQualifiedErrorId'))),detail)
                raise RuntimeError(first[:300])
            raw = (cp.stdout or "").strip()
            if not raw:
                return []
            data = json.loads(raw)
            if isinstance(data, dict):
                data = [data]
            return data if isinstance(data, list) else []
        except Exception as e:
            self.scan_watch_last_error = str(e)
            return []

    def _firewall_log_scan_watch_events(self, minutes=10):
        """Fallback: читає Windows Firewall pfirewall.log, якщо журнал увімкнений."""
        if not sys.platform.startswith("win"):
            return []
        path = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "LogFiles", "Firewall", "pfirewall.log")
        if not os.path.exists(path):
            return []
        cutoff = datetime.now() - timedelta(minutes=max(1, int(minutes)))
        fields = []
        out = []
        try:
            recent_lines = deque(maxlen=20000)
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                for raw_line in f:
                    stripped = raw_line.strip()
                    if stripped.startswith("#Fields:"):
                        fields = stripped.split(":", 1)[1].strip().split()
                    recent_lines.append(raw_line)
            for line in recent_lines:
                line = line.strip()
                if not line:
                    continue
                if line.startswith("#Fields:"):
                    fields = line.split(":", 1)[1].strip().split()
                    continue
                if line.startswith("#") or not fields:
                    continue
                parts = line.split()
                if len(parts) < len(fields):
                    continue
                row = dict(zip(fields, parts))
                try:
                    dt = datetime.strptime(row.get("date", "") + " " + row.get("time", ""), "%Y-%m-%d %H:%M:%S")
                except Exception:
                    continue
                if dt < cutoff:
                    continue
                direction = str(row.get("direction", "") or "").upper()
                if direction in ("SEND", "OUTBOUND"):
                    continue
                out.append({
                    "Time": dt.isoformat(),
                    "EventId": "FW-" + row.get("action", ""),
                    "RecordId": "",
                    "SourceAddress": row.get("src-ip", ""),
                    "SourcePort": row.get("src-port", ""),
                    "DestAddress": row.get("dst-ip", ""),
                    "DestPort": row.get("dst-port", ""),
                    "Protocol": row.get("protocol", ""),
                    "Application": "Windows Firewall log",
                    "Direction": "INBOUND" if direction in ("", "RECEIVE", "INBOUND") else direction,
                    "Action": row.get("action", ""),
                    "EvidenceSource": "Windows Firewall log",
                    "TcpFlags": row.get("tcpflags", ""),
                })
        except Exception as e:
            self.scan_watch_last_error = str(e)
        return out

    def _normalize_scan_watch_event(self, item, local_addresses=None):
        try:
            source = str(item.get("SourceAddress") or "").strip()
            target = str(item.get("DestAddress") or "").strip()
            direction = str(item.get("Direction") or "").strip().upper()
            if direction in ("OUTBOUND", "SEND", "%%14593"):
                return None
            if not valid_ipv4(source):
                return None
            ip_obj = ipaddress.ip_address(source)
            if ip_obj.is_loopback or ip_obj.is_multicast or ip_obj.is_unspecified:
                return None
            local_addresses = (
                local_addresses
                if local_addresses is not None
                else self.get_local_ipv4_addresses()
            )
            if source in local_addresses:
                return None
            try:
                dport = int(str(item.get("DestPort") or "").strip())
            except Exception:
                dport = 0
            protocol = str(item.get("Protocol") or "—").strip().upper()
            if protocol == "6":
                protocol = "TCP"
            elif protocol == "17":
                protocol = "UDP"
            when = str(item.get("Time") or "").strip()
            try:
                dt = datetime.fromisoformat(when.replace("Z", "+00:00"))
                ts = dt.timestamp()
            except Exception:
                ts = time.time()
            return {
                "ts": ts,
                "time": when or datetime.fromtimestamp(ts).isoformat(),
                "source": source,
                "source_port": str(item.get("SourcePort") or ""),
                "target": target or "—",
                "dest_port": dport,
                "protocol": protocol,
                "event_id": str(item.get("EventId") or "—"),
                "record_id": str(item.get("RecordId") or ""),
                "application": str(item.get("Application") or ""),
                "direction": direction,
                "event_category": str(item.get("EventCategory") or "NETWORK").upper(),
                "target_user": str(item.get("TargetUser") or "").strip(),
                "action": str(item.get("Action") or "OBSERVED").upper(),
                "evidence_source": str(item.get("EvidenceSource") or "Windows event source").strip(),
                "tcp_flags": str(item.get("TcpFlags") or "").strip().upper(),
            }
        except Exception:
            return None

    def record_scan_watch_probe_events(self, events):
        """Persist every observed inbound TCP/UDP port attempt without probing peers."""
        local_addresses = self.get_local_ipv4_addresses()
        incoming = []
        for item in events:
            row = self._normalize_scan_watch_event(item, local_addresses=local_addresses)
            if not row or row.get("event_category") != "NETWORK" or int(row.get("dest_port", 0) or 0) <= 0:
                continue
            action = str(row.get("action") or "OBSERVED").upper()
            event_id = str(row.get("event_id") or "")
            if action in ("DROP", "BLOCK", "BLOCKED") or event_id in ("5152", "5157") or "DROP" in event_id.upper():
                row["result"] = "ЗАБЛОКОВАНО"
            elif action in ("ALLOW", "ALLOWED") or event_id == "5156" or "ALLOW" in event_id.upper():
                row["result"] = "ДОЗВОЛЕНО"
            else:
                row["result"] = "СПОСТЕРЕЖЕНО"
            incoming.append(row)

        if not incoming:
            return 0
        def observation_key(row):
            return (
                int(float(row.get("ts", 0) or 0)), row.get("source"),
                row.get("source_port"), row.get("target"),
                int(row.get("dest_port", 0) or 0), str(row.get("protocol") or "").upper(),
                row.get("event_category"),
            )
        with self.scan_watch_lock:
            existing = {observation_key(row): row for row in self.scan_watch_probe_records}
            added = 0
            changed = False
            for row in incoming:
                key = observation_key(row)
                if key in existing:
                    current = existing[key]
                    sources = {x.strip() for x in str(current.get("evidence_source") or "").split(" / ") if x.strip()}
                    sources.update(x.strip() for x in str(row.get("evidence_source") or "").split(" / ") if x.strip())
                    event_ids = {x.strip() for x in str(current.get("event_id") or "").split(" / ") if x.strip()}
                    event_ids.update(x.strip() for x in str(row.get("event_id") or "").split(" / ") if x.strip())
                    merged_source = " / ".join(sorted(sources))
                    merged_event = " / ".join(sorted(event_ids))
                    result_rank = {"СПОСТЕРЕЖЕНО": 1, "ДОЗВОЛЕНО": 2, "ЗАБЛОКОВАНО": 3}
                    merged_result = max((current.get("result", "СПОСТЕРЕЖЕНО"), row.get("result", "СПОСТЕРЕЖЕНО")), key=lambda value: result_rank.get(value, 0))
                    if (current.get("evidence_source"), current.get("event_id"), current.get("result")) != (merged_source, merged_event, merged_result):
                        current["evidence_source"] = merged_source
                        current["event_id"] = merged_event
                        current["result"] = merged_result
                        changed = True
                    continue
                existing[key] = row
                self.scan_watch_probe_records.append(row)
                added += 1
        if added or changed:
            self.save_scan_watch_probe_records()
        return added

    def _classify_scan_activity(self, window, ports, attempts):
        auth_failures = sum(1 for row in window if row.get("event_category") == "AUTH_FAILURE")
        users = sorted({row.get("target_user") for row in window if row.get("target_user")})
        protocols = {str(row.get("protocol") or "").upper() for row in window}
        access_ports = {21, 22, 23, 139, 445, 3389, 5900, 5985, 5986}
        access_services = {
            21: "FTP", 22: "SSH", 23: "Telnet", 139: "NetBIOS",
            445: "SMB", 3389: "RDP", 5900: "VNC", 5985: "WinRM", 5986: "WinRM TLS",
        }
        web_ports = {80, 443, 8000, 8080, 8081, 8443, 8888}
        access_hits = sorted(set(ports) & access_ports)
        web_hits = sorted(set(ports) & web_ports)
        syn_observations = sum(
            1 for row in window
            if "S" in str(row.get("tcp_flags") or "").upper()
            and "A" not in str(row.get("tcp_flags") or "").upper()
        )

        if auth_failures >= 10:
            return {
                "scan_type": "ПОВТОРНІ НЕВДАЛІ СПРОБИ ВХОДУ",
                "scan_confidence": "HIGH",
                "scan_reason": f"Windows зафіксував {auth_failures} невдалих входів із цього джерела.",
                "auth_failures": auth_failures,
                "target_users": users[:10],
            }
        if auth_failures >= 5:
            return {
                "scan_type": "СПРОБИ ОТРИМАННЯ ДОСТУПУ",
                "scan_confidence": "HIGH",
                "scan_reason": f"Windows зафіксував {auth_failures} невдалих входів.",
                "auth_failures": auth_failures,
                "target_users": users[:10],
            }
        if len(ports) >= NETWORK_SCAN_UNIQUE_PORTS and syn_observations >= max(5, attempts // 2):
            return {
                "scan_type": "SYN-ПЕРЕВІРКА TCP-ПОРТІВ",
                "scan_confidence": "MEDIUM",
                "scan_reason": f"Локальний журнал містить {syn_observations} TCP SYN-звернень без ознаки ACK до різних портів.",
                "auth_failures": auth_failures,
                "target_users": users[:10],
            }
        if access_hits and attempts >= 10 and len(ports) <= 4:
            service_names = ", ".join(access_services.get(port, str(port)) for port in access_hits)
            return {
                "scan_type": "ЙМОВІРНА ПЕРЕВІРКА СЛУЖБ ДОСТУПУ",
                "scan_confidence": "MEDIUM",
                "scan_reason": f"Повторні звернення до локальних служб {service_names}; це ознака, а не доказ успішного доступу.",
                "auth_failures": auth_failures,
                "target_users": users[:10],
            }
        if len(ports) >= 20:
            scan_type = "ШИРОКЕ СКАНУВАННЯ ПОРТІВ"
            reason = f"Перевірено щонайменше {len(ports)} різних портів."
        elif len(ports) >= 8:
            adjacent = sum(1 for left, right in zip(ports, ports[1:]) if right - left == 1)
            if len(ports) > 1 and adjacent / (len(ports) - 1) >= 0.6:
                scan_type = "ПОСЛІДОВНЕ СКАНУВАННЯ ПОРТІВ"
                reason = "Порти перевіряються переважно послідовно."
            else:
                scan_type = "ЗВИЧАЙНЕ СКАНУВАННЯ ПОРТІВ"
                reason = "Перевіряється набір різних мережевих портів."
        elif web_hits and attempts >= 10:
            scan_type = "ПЕРЕВІРКА ВЕБСЛУЖБ"
            reason = "Повторні звернення до вебпортів: " + ", ".join(map(str, web_hits))
        elif "17" in protocols or "UDP" in protocols:
            scan_type = "UDP-ПРОБИ"
            reason = "Зафіксовано інтенсивні UDP-звернення."
        else:
            scan_type = "ІНТЕНСИВНІ МЕРЕЖЕВІ ПРОБИ"
            reason = "Багато мережевих спроб за короткий проміжок часу."
        return {
            "scan_type": scan_type,
            "scan_confidence": "MEDIUM",
            "scan_reason": reason,
            "auth_failures": auth_failures,
            "target_users": users[:10],
        }

    def analyze_scan_watch_events(self, events):
        """Шукає багато спроб або багато портів з одного Source IP у короткому вікні."""
        normalized = []
        seen = {}
        local_addresses = self.get_local_ipv4_addresses()
        for item in events:
            ev = self._normalize_scan_watch_event(
                item,
                local_addresses=local_addresses,
            )
            if not ev:
                continue
            key = (
                int(ev["ts"]), ev["source"], ev["source_port"], ev["target"],
                ev["dest_port"], str(ev["protocol"]).upper(), ev.get("event_category"),
            )
            if key in seen:
                current = seen[key]
                sources = {x.strip() for x in str(current.get("evidence_source") or "").split(" / ") if x.strip()}
                sources.update(x.strip() for x in str(ev.get("evidence_source") or "").split(" / ") if x.strip())
                current["evidence_source"] = " / ".join(sorted(sources))
                actions = {"OBSERVED": 1, "ALLOWED": 2, "BLOCKED": 3, "DROP": 3}
                if actions.get(ev.get("action"), 0) > actions.get(current.get("action"), 0):
                    current["action"] = ev.get("action")
                ids = {x.strip() for x in str(current.get("event_id") or "").split(" / ") if x.strip()}
                ids.update(x.strip() for x in str(ev.get("event_id") or "").split(" / ") if x.strip())
                current["event_id"] = " / ".join(sorted(ids))
                continue
            seen[key] = ev
            normalized.append(ev)
        normalized.sort(key=lambda x: x["ts"])
        by_source = {}
        for ev in normalized:
            by_source.setdefault(ev["source"], []).append(ev)
        detections = []
        for source, rows in by_source.items():
            left = 0
            for right in range(len(rows)):
                while left < right and rows[right]["ts"] - rows[left]["ts"] > NETWORK_SCAN_WINDOW_SECONDS:
                    left += 1
                window = rows[left:right + 1]
                ports = sorted({x["dest_port"] for x in window if x["dest_port"] > 0})
                targets = sorted({x["target"] for x in window if x["target"] not in ("", "—")})
                blocked = sum(1 for x in window if str(x.get("action") or "").upper() in ("BLOCKED", "DROP") or str(x["event_id"]) in ("5152", "5157") or "DROP" in str(x["event_id"]).upper())
                attempts = len(window)
                auth_failures = sum(1 for x in window if x.get("event_category") == "AUTH_FAILURE")
                if len(ports) < NETWORK_SCAN_UNIQUE_PORTS and attempts < NETWORK_SCAN_ATTEMPTS and auth_failures < 5:
                    continue
                if len(ports) >= 20 or attempts >= 50:
                    level = "HIGH"
                elif len(ports) >= NETWORK_SCAN_UNIQUE_PORTS:
                    level = "MEDIUM"
                else:
                    level = "LOW"
                classification = self._classify_scan_activity(window, ports, attempts)
                detections.append({
                    "source_ip": source,
                    "first_ts": window[0]["ts"],
                    "last_ts": window[-1]["ts"],
                    "first_seen": datetime.fromtimestamp(window[0]["ts"]).strftime("%d.%m.%Y %H:%M:%S"),
                    "last_seen": datetime.fromtimestamp(window[-1]["ts"]).strftime("%d.%m.%Y %H:%M:%S"),
                    "attempts": attempts,
                    "unique_ports": len(ports),
                    "ports": ports[:40],
                    "targets": targets[:10],
                    "blocked": blocked,
                    "level": level,
                    "evidence": " / ".join(sorted({str(x.get('evidence_source') or '') for x in window if x.get('evidence_source')})),
                    **classification,
                })
        strongest = {}
        for d in detections:
            old = strongest.get(d["source_ip"])
            if old is None or (d["unique_ports"], d["attempts"]) > (old["unique_ports"], old["attempts"]):
                strongest[d["source_ip"]] = d
        return list(strongest.values())

    def merge_scan_watch_detections(self, detections):
        changed = False
        notifications = []
        rank = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
        milestones = (20, 50, 100, 250, 500, 1000)

        with self.scan_watch_lock:
            for new in detections:
                merged = False

                for old in reversed(self.scan_watch_records):
                    if old.get("source_ip") != new.get("source_ip"):
                        continue

                    try:
                        if abs(float(new["last_ts"]) - float(old.get("last_ts", 0))) <= 600:
                            before = json.dumps(
                                old,
                                ensure_ascii=False,
                                sort_keys=True,
                                default=str,
                            )
                            old_attempts = int(old.get("attempts", 0))
                            old_level = old.get("level")
                            old["last_ts"] = max(float(old.get("last_ts", 0)), float(new["last_ts"]))
                            old["last_seen"] = datetime.fromtimestamp(old["last_ts"]).strftime("%d.%m.%Y %H:%M:%S")
                            old["attempts"] = max(int(old.get("attempts", 0)), int(new.get("attempts", 0)))
                            old_ports = set(old.get("ports", [])); old_ports.update(new.get("ports", []))
                            old["ports"] = sorted(old_ports)[:80]
                            old["unique_ports"] = max(int(old.get("unique_ports", 0)), len(old_ports), int(new.get("unique_ports", 0)))
                            old_targets = set(old.get("targets", [])); old_targets.update(new.get("targets", [])); old["targets"] = sorted(old_targets)[:20]
                            old["blocked"] = max(int(old.get("blocked", 0)), int(new.get("blocked", 0)))
                            if rank.get(new.get("level"), 0) > rank.get(old.get("level"), 0):
                                old["level"] = new.get("level")
                            confidence_rank = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
                            if confidence_rank.get(new.get("scan_confidence"), 0) >= confidence_rank.get(old.get("scan_confidence"), 0):
                                old["scan_type"] = new.get("scan_type", old.get("scan_type", ""))
                                old["scan_confidence"] = new.get("scan_confidence", old.get("scan_confidence", ""))
                                old["scan_reason"] = new.get("scan_reason", old.get("scan_reason", ""))
                            old["auth_failures"] = max(int(old.get("auth_failures", 0) or 0), int(new.get("auth_failures", 0) or 0))
                            old_users = set(old.get("target_users", [])); old_users.update(new.get("target_users", [])); old["target_users"] = sorted(old_users)[:10]

                            after = json.dumps(
                                old,
                                ensure_ascii=False,
                                sort_keys=True,
                                default=str,
                            )

                            if before != after:
                                changed = True

                                crossed_milestone = any(
                                    old_attempts < value <= int(old["attempts"])
                                    for value in milestones
                                )
                                level_raised = (
                                    rank.get(old.get("level"), 0)
                                    > rank.get(old_level, 0)
                                )

                                if crossed_milestone or level_raised:
                                    notifications.append(dict(old))

                            merged = True
                            break
                    except Exception:
                        continue

                if not merged:
                    self.scan_watch_records.append(dict(new))
                    changed = True

                    notifications.append(dict(new))

        if changed:
            self.save_scan_watch_records()

            for d in notifications:
                try:
                    self.db.add_event(d.get("source_ip"), "SCAN_DETECTED", f"Пасивно виявлено ознаки сканування: {d.get('attempts')} спроб, {d.get('unique_ports')} портів, рівень {d.get('level')}")
                except Exception:
                    pass

        return changed

    def collect_scan_watch_once(self):
        self.scan_watch_last_error = ""
        events = self._powershell_scan_watch_events(10)
        fw = self._firewall_log_scan_watch_events(10)
        if fw:
            events.extend(fw)
        source_counts = {}
        for item in events:
            source_name = str(item.get("EvidenceSource") or "Windows event source")
            source_counts[source_name] = source_counts.get(source_name, 0) + 1
        self.scan_sensor_sources = source_counts
        self.record_scan_watch_probe_events(events)
        detections = self.analyze_scan_watch_events(events)
        changed = self.merge_scan_watch_detections(detections)
        if detections:
            self.process_active_scan_detections(detections)
        return detections, changed, len(events)

    def scan_watch_periodic(self):
        if self.closed:
            return
        if not self.scan_watch_busy:
            self.scan_watch_busy = True
            def worker():
                try:
                    self.collect_scan_watch_once()
                finally:
                    self.scan_watch_busy = False
                    self.run_on_gui(self.refresh_scan_watch_window)
            threading.Thread(target=worker, daemon=True, name="ScanWatch").start()
        if not self.closed:
            self.root.after(SCAN_WATCH_POLL_MS, self.scan_watch_periodic)

    def refresh_scan_watch_window(self):
        win = getattr(self, "scan_watch_window", None)
        if not win:
            return
        try:
            if not win.winfo_exists():
                self.scan_watch_window = None
                return
        except Exception:
            self.scan_watch_window = None
            return
        tree = getattr(self, "scan_watch_tree", None)
        probe_tree = getattr(self, "scan_watch_probe_tree", None)
        status = getattr(self, "scan_watch_status_var", None)
        if tree is None:
            return
        for item in tree.get_children():
            tree.delete(item)
        if probe_tree is not None:
            for item in probe_tree.get_children():
                probe_tree.delete(item)
        with self.scan_watch_lock:
            rows = sorted(self.scan_watch_records, key=lambda x: float(x.get("last_ts", 0) or 0), reverse=True)
            probe_rows = sorted(self.scan_watch_probe_records, key=lambda x: float(x.get("ts", 0) or 0), reverse=True)
        for row in rows:
            ports = ",".join(str(x) for x in row.get("ports", [])[:18]) or "—"
            targets = ", ".join(row.get("targets", [])[:4]) or "локальний ПК"
            tree.insert("", "end", values=(
                row.get("last_seen", "—"), row.get("first_seen", "—"), row.get("source_ip", "—"), row.get("level", "—"),
                row.get("attempts", 0), row.get("unique_ports", 0), ports, row.get("blocked", 0),
                row.get("scan_type", "—"), row.get("defense_status", "OBSERVED"), targets, row.get("evidence", "—")
            ), tags=(row.get("level", ""),))
        if probe_tree is not None:
            for row in probe_rows:
                probe_tree.insert("", "end", values=(
                    datetime.fromtimestamp(float(row.get("ts", 0) or 0)).strftime("%d.%m.%Y %H:%M:%S"),
                    row.get("source", "—"), row.get("source_port", "—"),
                    row.get("target", "локальний ПК"), row.get("dest_port", "—"),
                    row.get("protocol", "—"), row.get("result", "СПОСТЕРЕЖЕНО"),
                    row.get("evidence_source", "—"), row.get("event_id", "—"),
                ), tags=(row.get("result", ""),))
        if status is not None:
            extra = f" | Остання помилка: {self.scan_watch_last_error}" if self.scan_watch_last_error else ""
            status.set(f"Сканувань: {len(rows)}; усіх вхідних спроб портів: {len(probe_rows)}. Пасивний аналіз локальних журналів; активне сканування не виконується.{extra}")
        sensor_status = getattr(self, "scan_sensor_status_var", None)
        if sensor_status is not None:
            sources = ", ".join(f"{name}: {count}" for name, count in sorted(self.scan_sensor_sources.items()))
            suffix = f" | Джерела: {sources}" if sources else " | Джерела ще не повернули подій."
            if self.scan_sensor_setup_busy:
                sensor_status.set((self.scan_sensor_status or "Налаштування локального сенсора...") + suffix)
            elif self.scan_sensor_status:
                sensor_status.set(self.scan_sensor_status + suffix)
            else:
                _ready, message = self._scan_sensor_log_status()
                sensor_status.set(message + suffix)

    def open_scan_watch_window(self):
        win = getattr(self, "scan_watch_window", None)
        try:
            if win and win.winfo_exists():
                _bring_window_to_front(win)
                self.refresh_scan_watch_window()
                return
        except Exception:
            pass
        win = tk.Toplevel(self.root)
        win.configure(background=UI_BG)
        self.scan_watch_window = win
        win.title(f"{APP_NAME} — Хто сканував")
        win.geometry("1450x650")
        win.minsize(900, 450)
        top = ttk.Frame(win, padding=8, style="Header.TFrame"); top.pack(fill="x")
        ttk.Label(top, text="ОЗНАКИ СКАНУВАННЯ / ПРОБ ПОРТІВ", style="Brand.TLabel").pack(side="left")
        self.scan_watch_status_var = tk.StringVar(value="Оновлення...")
        ttk.Label(win, textvariable=self.scan_watch_status_var, padding=(8, 0)).pack(fill="x")
        _sensor_ready, sensor_message = self._scan_sensor_log_status()
        self.scan_sensor_status_var = tk.StringVar(value=self.scan_sensor_status or sensor_message)
        sensor_bar = ttk.Frame(win, padding=(8, 4)); sensor_bar.pack(fill="x")
        ttk.Label(sensor_bar, textvariable=self.scan_sensor_status_var, foreground=UI_AMBER).pack(side="left", fill="x", expand=True)
        ttk.Button(
            sensor_bar,
            text="УВІМКНУТИ / ВІДНОВИТИ СЕНСОР",
            command=self.enable_scan_sensor_interactive,
            style="Accent.TButton",
        ).pack(side="right")
        ttk.Label(win, text="Показуються лише спроби, які цей ПК реально бачить у Windows Security/Firewall logs. Це не означає, що програма бачить весь трафік усієї підмережі.", padding=(8, 4), foreground=UI_MUTED).pack(fill="x")
        controls = ttk.Frame(win, padding=(8, 4)); controls.pack(fill="x")
        alerts_var = tk.BooleanVar(value=bool(self.scan_defense_settings.get("realtime_alerts", True)))
        auto_block_var = tk.BooleanVar(value=bool(self.scan_defense_settings.get("auto_block", True)))
        def refresh_now():
            if self.scan_watch_busy:
                self.scan_watch_status_var.set("Аналіз уже виконується..."); return
            self.scan_watch_busy = True
            self.scan_watch_status_var.set("Читаю локальні Security/Firewall журнали...")
            def worker():
                try:
                    detections, changed, count = self.collect_scan_watch_once()
                    msg = f"Перевірено подій: {count}; виявлень у поточному вікні: {len(detections)}"
                    self.run_on_gui(lambda m=msg: self.scan_watch_status_var.set(m))
                finally:
                    self.scan_watch_busy = False
                    self.run_on_gui(self.refresh_scan_watch_window)
            threading.Thread(target=worker, daemon=True).start()
        def clear_all():
            if not messagebox.askyesno(APP_NAME, "Очистити весь список виявлених сканувань?", parent=win):
                return
            with self.scan_watch_lock:
                self.scan_watch_records = []
                self.scan_watch_probe_records = []
            self.save_scan_watch_records(); self.save_scan_watch_probe_records(); self.scan_watch_last_error = ""; self.refresh_scan_watch_window()
            try:
                self.db.add_event(None, "SCAN_LIST_CLEAR", "Список виявлених сканувань очищено користувачем.")
            except Exception:
                pass
        ttk.Button(controls, text="Оновити зараз", command=refresh_now).pack(side="left")
        ttk.Button(controls, text="Очистити список", command=clear_all).pack(side="left", padx=6)
        ttk.Checkbutton(
            controls,
            text="Alert поверх усіх вікон",
            variable=alerts_var,
            command=lambda: self._set_scan_defense_option("realtime_alerts", alerts_var.get()),
        ).pack(side="left", padx=(14, 4))
        ttk.Checkbutton(
            controls,
            text="Автоматично блокувати IP",
            variable=auto_block_var,
            command=lambda: self._set_scan_defense_option("auto_block", auto_block_var.get()),
        ).pack(side="left", padx=4)
        ttk.Button(controls, text="Закрити", command=win.destroy).pack(side="right")
        actions = ttk.Frame(win, padding=(8, 2)); actions.pack(fill="x")
        columns = ("last", "first", "source", "level", "attempts", "ports_count", "ports", "blocked", "scan_type", "defense", "targets", "evidence")
        scan_tabs = ttk.Notebook(win); scan_tabs.pack(fill="both", expand=True, padx=8, pady=8)
        detected_tab = ttk.Frame(scan_tabs); probe_tab = ttk.Frame(scan_tabs)
        scan_tabs.add(detected_tab, text="ВИЯВЛЕНІ СКАНУВАННЯ")
        scan_tabs.add(probe_tab, text="УСІ СПРОБИ ДО ПОРТІВ")
        frame = ttk.Frame(detected_tab, padding=4); frame.pack(fill="both", expand=True)
        sy = ttk.Scrollbar(frame, orient="vertical"); sy.pack(side="right", fill="y")
        sx = ttk.Scrollbar(frame, orient="horizontal"); sx.pack(side="bottom", fill="x")
        tree = ttk.Treeview(frame, columns=columns, show="headings", yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.scan_watch_tree = tree
        sy.config(command=tree.yview); sx.config(command=tree.xview)
        specs = [
            ("last", "Остання спроба", 155), ("first", "Перша спроба", 155), ("source", "Source IP", 140),
            ("level", "Рівень", 90), ("attempts", "Спроб", 85), ("ports_count", "Унік. портів", 115),
            ("ports", "Порти", 250), ("blocked", "Відхилено подій", 120), ("scan_type", "Тип активності", 260), ("defense", "Захист", 120),
            ("targets", "Target", 200), ("evidence", "Джерело даних", 240),
        ]
        for c, title, width in specs:
            tree.heading(c, text=title); tree.column(c, width=width, minwidth=75, anchor="center" if c in ("level","attempts","ports_count","blocked") else "w")
        tree.pack(fill="both", expand=True)
        tree.tag_configure("HIGH", foreground=UI_RED); tree.tag_configure("MEDIUM", foreground=UI_AMBER)
        probe_columns = ("time", "source", "source_port", "target", "port", "protocol", "result", "sensor", "event")
        probe_sy = ttk.Scrollbar(probe_tab, orient="vertical"); probe_sy.pack(side="right", fill="y")
        probe_sx = ttk.Scrollbar(probe_tab, orient="horizontal"); probe_sx.pack(side="bottom", fill="x")
        probe_tree = ttk.Treeview(probe_tab, columns=probe_columns, show="headings", yscrollcommand=probe_sy.set, xscrollcommand=probe_sx.set)
        self.scan_watch_probe_tree = probe_tree
        probe_sy.config(command=probe_tree.yview); probe_sx.config(command=probe_tree.xview)
        for column, title, width in [
            ("time", "Час", 165), ("source", "Source IP", 145), ("source_port", "Порт джерела", 110),
            ("target", "Target IP", 145), ("port", "Цільовий порт", 110), ("protocol", "Протокол", 90),
            ("result", "Результат", 130), ("sensor", "Джерело сенсора", 240), ("event", "Event ID", 120),
        ]:
            probe_tree.heading(column, text=title); probe_tree.column(column, width=width, minwidth=75, anchor="center")
        probe_tree.tag_configure("ЗАБЛОКОВАНО", foreground=UI_RED)
        probe_tree.tag_configure("ДОЗВОЛЕНО", foreground=UI_GREEN)
        probe_tree.pack(fill="both", expand=True)
        def selected_detection():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo(APP_NAME, "Виберіть запис із Source IP.", parent=win)
                return None
            values = tree.item(selected[0], "values")
            if len(values) < 3 or not valid_ipv4(str(values[2])):
                return None
            source_ip = str(values[2])
            with self.scan_watch_lock:
                for row in reversed(self.scan_watch_records):
                    if row.get("source_ip") == source_ip:
                        return dict(row)
            return {"source_ip": source_ip}
        def block_selected():
            detection = selected_detection()
            if detection:
                self.block_scan_source(detection["source_ip"], detection)
        def trust_selected():
            detection = selected_detection()
            if detection:
                self.trust_scan_source(detection["source_ip"], detection)
        ttk.Button(actions, text="Заблокувати вибраний IP", command=block_selected, style="Danger.TButton").pack(side="left")
        ttk.Button(actions, text="Довіряти вибраному IP", command=trust_selected).pack(side="left", padx=6)
        ttk.Label(
            actions,
            text="Захисна відповідь діє лише на цьому ПК через Windows Firewall.",
            foreground=UI_MUTED,
        ).pack(side="left", padx=12)
        def close_win():
            self.scan_watch_window = None
            try: win.destroy()
            except Exception: pass
        win.protocol("WM_DELETE_WINDOW", close_win)
        _show_child_window(
            win,
            1450,
            650,
            min_width=900,
            min_height=450,
        )
        self.refresh_scan_watch_window()
        refresh_now()

    def open_dfir_window(self):
        win=tk.Toplevel(self.root);win.configure(background=UI_BG);win.title(f"{APP_NAME} — DFIR / Incident Response");win.geometry("1580x840");win.minsize(1100,650)
        top=ttk.Frame(win,padding=8,style="Header.TFrame");top.pack(fill="x");ttk.Label(top,text="DFIR / INCIDENT RESPONSE",style="Brand.TLabel").pack(side="left");ttk.Label(top,text="Авторизований збір • без network discovery",style="BrandSub.TLabel").pack(side="left",padx=15)
        tabs=ttk.Notebook(win);tabs.pack(fill="both",expand=True,padx=8,pady=(0,8));inc_tab=ttk.Frame(tabs);collect_tab=ttk.Frame(tabs);time_tab=ttk.Frame(tabs);ev_tab=ttk.Frame(tabs);tabs.add(inc_tab,text="Інциденти");tabs.add(collect_tab,text="Віддалений збір");tabs.add(time_tab,text="Timeline");tabs.add(ev_tab,text="Evidence")
        state={"data":{},"incidents":[],"evidence":[]};ip_var=tk.StringVar();status_var=tk.StringVar(value="Готовий");bar=ttk.Frame(collect_tab,padding=8);bar.pack(fill="x");ttk.Label(bar,text="IP авторизованого ПК:").pack(side="left");ip_entry=ttk.Entry(bar,textvariable=ip_var,width=22);ip_entry.pack(side="left",padx=6);ttk.Label(bar,textvariable=status_var).pack(side="left",padx=10)
        ttk.Label(collect_tab,text="Вкажіть конкретний IP. Підмережі та перебір адрес DFIR-модулем не виконуються. Source IP: DIRECT = з самої події; HIGH/MEDIUM/LOW = корельований; UNKNOWN = доказів недостатньо.",padding=(8,0)).pack(fill="x")
        cols=("time","source","confidence","target","user","action","result","id","message");frame=ttk.Frame(collect_tab);frame.pack(fill="both",expand=True,padx=8,pady=8);scroll=ttk.Scrollbar(frame,orient="vertical");scroll.pack(side="right",fill="y");event_tree=ttk.Treeview(frame,columns=cols,show="headings",yscrollcommand=scroll.set);scroll.config(command=event_tree.yview)
        for c,t,w in [("time","Час",190),("source","Source IP",135),("confidence","Джерело",95),("target","Target IP",135),("user","Користувач",150),("action","Дія / доступ",230),("result","Результат",90),("id","Event ID",75),("message","Деталі",500)]:event_tree.heading(c,text=t);event_tree.column(c,width=w,anchor="w")
        event_tree.pack(fill="both",expand=True)
        inc_frame=ttk.Frame(inc_tab,padding=8);inc_frame.pack(fill="both",expand=True);inc_cols=("severity","score","source","confidence","target","user","result","title","details");inc_tree=ttk.Treeview(inc_frame,columns=inc_cols,show="headings")
        for c,t,w in [("severity","Рівень",90),("score","Score",60),("source","Source IP",135),("confidence","Джерело",95),("target","Target IP",135),("user","Користувач",145),("result","Результат",90),("title","Інцидент",280),("details","Доказ / причина",500)]:inc_tree.heading(c,text=t);inc_tree.column(c,width=w,anchor="w")
        inc_tree.pack(fill="both",expand=True)
        time_frame=ttk.Frame(time_tab,padding=8);time_frame.pack(fill="both",expand=True);time_cols=("time","source","confidence","target","user","type","id","result","details");time_tree=ttk.Treeview(time_frame,columns=time_cols,show="headings")
        for c,t,w in [("time","Час",190),("source","Source IP",135),("confidence","Джерело",95),("target","Target IP",135),("user","Користувач",145),("type","Тип",200),("id","ID / Процес",120),("result","Результат",90),("details","Деталі",500)]:time_tree.heading(c,text=t);time_tree.column(c,width=w,anchor="w")
        time_tree.pack(fill="both",expand=True)
        ev_frame=ttk.Frame(ev_tab,padding=8);ev_frame.pack(fill="both",expand=True);evidence_cols=("time","file","path","sha256");evidence_tree=ttk.Treeview(ev_frame,columns=evidence_cols,show="headings")
        for c,t,w in [("time","Час",180),("file","Evidence",150),("path","Шлях",600),("sha256","SHA-256",330)]:evidence_tree.heading(c,text=t);evidence_tree.column(c,width=w,anchor="w")
        evidence_tree.pack(fill="both",expand=True)
        def render_all():
            for t in (event_tree,inc_tree,time_tree,evidence_tree):
                for item in t.get_children():t.delete(item)
            data=state["data"];target=data.get("Computer") or ip_var.get().strip()
            for e in data.get("Events") or []:
                src=self._dfir_effective_source(e) or "—";conf=e.get("SourceConfidence") or "UNKNOWN";msg=(e.get("Message","") or "").replace("\r"," " ).replace("\n"," " )[:1000]
                if src!="—" and conf!="DIRECT":msg=(f"[{conf}: {e.get('CorrelationReason','')}] "+msg)[:1000]
                event_tree.insert("","end",values=(e.get("TimeCreated",""),src,conf,target,e.get("TargetUser") or e.get("SubjectUser") or "—",self._dfir_event_action(e),self._dfir_event_result(e),e.get("Id",""),msg))
            for x in state["incidents"]:inc_tree.insert("","end",values=(x.get("severity"),x.get("score"),x.get("source","—"),x.get("source_confidence","UNKNOWN"),x.get("target",target),x.get("user","—"),x.get("result","EVENT"),x.get("title"),x.get("details","")))
            timeline=[]
            for e in data.get("Events") or []:timeline.append((e.get("TimeCreated",""),self._dfir_effective_source(e) or "—",e.get("SourceConfidence") or "UNKNOWN",target,e.get("TargetUser") or e.get("SubjectUser") or "—",self._dfir_event_action(e),e.get("Id",""),self._dfir_event_result(e),(e.get("Message","") or "").replace("\r"," " ).replace("\n"," " )[:700]))
            timeline += [(p.get("CreationDate","") or "","—","UNKNOWN",target,"—","PROCESS",p.get("Name","") or "","EVENT",p.get("CommandLine","") or "") for p in data.get("Processes") or []]
            for row in sorted(timeline,key=lambda x:str(x[0])):time_tree.insert("","end",values=row)
            for row in state["evidence"]:evidence_tree.insert("","end",values=row)
        def fail(err):status_var.set("Помилка збору");collect_btn.config(state="normal");messagebox.showerror(APP_NAME,f"DFIR-збір не виконано:\n{err}\n\nПеревірте WinRM/PowerShell Remoting та права доступу.",parent=win)
        def finish(data, incidents, evidence_rows, ip):
            state.update(
                data=data,
                incidents=incidents,
                evidence=evidence_rows,
            )
            raw_issues = data.get("CollectionIssues") or []
            issues = (
                list(raw_issues)
                if isinstance(raw_issues, list)
                else [str(raw_issues)]
            )
            suffix = f" • попереджень {len(issues)}" if issues else ""
            status_var.set(
                f"Завершено: {ip} • подій "
                f"{len(data.get('Events') or [])} • інцидентів "
                f"{len(incidents)}{suffix}"
            )
            collect_btn.config(state="normal")
            render_all()
            tabs.select(inc_tab)

            if issues:
                messagebox.showwarning(
                    APP_NAME,
                    "DFIR-збір завершено частково. Деякі джерела "
                    "були недоступні:\n\n"
                    + "\n".join(f"• {item}" for item in issues[:12]),
                    parent=win,
                )
        def collect():
            ip=ip_var.get().strip()
            if not valid_ipv4(ip):messagebox.showerror(APP_NAME,"Введіть коректну IPv4-адресу.",parent=win);return
            collect_btn.config(state="disabled");status_var.set(f"Збір з {ip}...")
            def worker():
                try:
                    data = self._dfir_collect_host(ip)
                    incidents = self._dfir_analyze(data, ip)
                    collected_utc = datetime.now(timezone.utc)
                    stamp = collected_utc.strftime("%Y%m%d_%H%M%S_%fZ")
                    evidence_dir = os.path.join(
                        BASE_DIR,
                        "DFIR_Evidence",
                        ip,
                        stamp,
                    )
                    os.makedirs(evidence_dir, exist_ok=False)

                    raw = json.dumps(
                        data,
                        ensure_ascii=False,
                        indent=2,
                        default=str,
                    )
                    raw_bytes = raw.encode("utf-8")
                    collection_path = os.path.join(
                        evidence_dir,
                        "collection.json",
                    )

                    with open(collection_path, "xb") as evidence_file:
                        evidence_file.write(raw_bytes)
                        evidence_file.flush()
                        os.fsync(evidence_file.fileno())

                    with open(collection_path, "rb") as evidence_file:
                        digest = hashlib.sha256(evidence_file.read()).hexdigest()

                    manifest = {
                        "schema_version": 1,
                        "target_ip": ip,
                        "collected_at_utc": collected_utc.isoformat(),
                        "collected_at_local": datetime.now().astimezone().isoformat(),
                        "collector": "МІЧМАН КП DFIR",
                        "collector_version": APP_VERSION,
                        "collector_host": socket.gethostname(),
                        "collector_user": os.environ.get("USERNAME", ""),
                        "mode": "authorized read-only collection",
                        "evidence_file": "collection.json",
                        "evidence_size_bytes": len(raw_bytes),
                        "evidence_sha256": digest,
                        "source_ip_semantics": (
                            "DIRECT from event; HIGH/MEDIUM/LOW correlated; "
                            "UNKNOWN insufficient evidence"
                        ),
                    }
                    manifest_path = os.path.join(
                        evidence_dir,
                        "manifest.json",
                    )
                    manifest_bytes = json.dumps(
                        manifest,
                        ensure_ascii=False,
                        indent=2,
                    ).encode("utf-8")

                    with open(manifest_path, "xb") as manifest_file:
                        manifest_file.write(manifest_bytes)
                        manifest_file.flush()
                        os.fsync(manifest_file.fileno())

                    manifest_digest = hashlib.sha256(
                        manifest_bytes
                    ).hexdigest()
                    checksum_path = os.path.join(
                        evidence_dir,
                        "manifest.sha256",
                    )

                    with open(
                        checksum_path,
                        "x",
                        encoding="ascii",
                        newline="\n",
                    ) as checksum_file:
                        checksum_file.write(
                            f"{manifest_digest}  manifest.json\n"
                            f"{digest}  collection.json\n"
                        )

                    evidence_rows = [
                        (
                            datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
                            "collection.json",
                            collection_path,
                            digest,
                        ),
                        (
                            datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
                            "manifest.json",
                            manifest_path,
                            manifest_digest,
                        ),
                    ]
                    self.run_on_gui(
                        lambda: finish(
                            data,
                            incidents,
                            evidence_rows,
                            ip,
                        )
                    )
                except Exception as e:self.run_on_gui(lambda err=str(e):fail(err))
            threading.Thread(target=worker,daemon=True).start()
        collect_btn=ttk.Button(bar,text="Зібрати DFIR",command=collect);collect_btn.pack(side="left",padx=5);ttk.Button(bar,text="Закрити",command=win.destroy).pack(side="right");ip_entry.focus_set()
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        _show_child_window(
            win,
            1580,
            840,
            min_width=1100,
            min_height=650,
        )

    def close(self, confirm=True):
        platform_window = getattr(self, "platform_window", None)
        if platform_window and platform_window.alive and any(k.startswith("action:") for k in platform_window.busy):
            messagebox.showinfo(APP_NAME, "Дочекайтеся завершення віддалених дій.", parent=self.root)
            return
        center = getattr(self, "network_center", None)
        if center and center.alive and "backup" in center.busy:
            messagebox.showinfo(APP_NAME, "Дочекайтеся завершення резервного копіювання або відновлення.", parent=self.root)
            return
        if self.closed:
            return

        answer = True
        if confirm:
            answer = messagebox.askyesno(
                APP_NAME,
                "Закрити програму?",
                parent=self.root,
            )

        if not answer:
            return

        platform_window = getattr(self, "platform_window", None)
        if platform_window and platform_window.alive:
            platform_window.close()
        self.closed = True
        self.running = False
        self.monitor_generation += 1
        self.stop_event.set()

        try:
            self.tcp_executor.shutdown(
                wait=False,
                cancel_futures=True,
            )
        except Exception:
            pass

        for win in list(
            self.detail_windows.values()
        ):
            try:
                win.destroy()
            except Exception:
                pass

        self.detail_windows.clear()

        try:
            self.db.add_event(
                None,
                "EXIT",
                "Програму завершено.",
            )
        except Exception:
            pass

        try:
            self.platform_core.close()
            self.db.close()
        except Exception:
            pass

        try:
            self.root.destroy()
        except Exception:
            pass


def _configure_license_theme(root):
    root.configure(background=UI_BG)
    root.option_add("*TFrame.background", UI_BG)
    root.option_add("*TLabel.background", UI_BG)
    root.option_add("*TLabel.foreground", UI_TEXT)
    root.option_add("*TButton.background", UI_PANEL)
    root.option_add("*TButton.foreground", UI_TEXT)
    root.option_add("*TEntry.background", UI_PANEL)
    root.option_add("*TEntry.foreground", UI_TEXT)
    root.option_add("*Toplevel.background", UI_BG)
    style = ttk.Style(root)
    _select_ttk_theme(style)
    style.configure("TFrame", background=UI_BG)
    style.configure(
        "TLabel",
        background=UI_BG,
        foreground=UI_TEXT,
        font=("Segoe UI", 10),
    )
    style.configure(
        "LicenseHeader.TFrame",
        background=UI_HEADER,
    )
    style.configure(
        "LicenseBrand.TLabel",
        background=UI_HEADER,
        foreground=UI_CYAN,
        font=("Segoe UI Semibold", 20),
    )
    style.configure(
        "LicenseSub.TLabel",
        background=UI_HEADER,
        foreground=UI_MUTED,
        font=("Cascadia Mono", 9),
    )
    style.configure(
        "LicensePanel.TFrame",
        background=UI_PANEL,
        borderwidth=1,
        relief="solid",
    )
    style.configure(
        "LicensePanel.TLabel",
        background=UI_PANEL,
        foreground=UI_TEXT,
    )
    style.configure(
        "LicenseCode.TLabel",
        background=UI_PANEL,
        foreground=UI_CYAN,
        font=("Cascadia Mono", 12, "bold"),
    )
    style.configure(
        "TEntry",
        fieldbackground=UI_SURFACE,
        foreground=UI_TEXT,
        insertcolor=UI_CYAN,
        bordercolor=UI_BORDER,
        padding=9,
    )
    style.configure(
        "TButton",
        background=UI_PANEL,
        foreground=UI_TEXT,
        bordercolor=UI_BORDER,
        padding=(12, 8),
        font=("Segoe UI Semibold", 9),
    )
    style.map(
        "TButton",
        background=[("active", UI_PANEL_HOVER), ("pressed", UI_CYAN_SOFT)],
        foreground=[("active", UI_CYAN)],
    )
    style.configure(
        "Accent.TButton",
        background=UI_CYAN,
        foreground=UI_SELECTION_TEXT,
        bordercolor=UI_CYAN,
        padding=(15, 9),
        font=("Segoe UI Semibold", 10),
    )
    style.map(
        "Accent.TButton",
        background=[("active", "#57F2FF"), ("pressed", "#00AFC4")],
    )


def show_license_dialog(parent, manager, allow_cancel=False):
    """Show the fully offline activation gate and return a valid status."""
    _configure_license_theme(parent)
    current = manager.check(update_last_seen=False)
    result = {"status": current if current.valid else None}

    dialog = tk.Toplevel(parent)
    dialog.configure(background=UI_BG)
    dialog.title(f"{APP_NAME} — Активація")
    dialog.geometry("700x570")
    dialog.resizable(False, False)
    try:
        dialog.transient(parent)
    except tk.TclError:
        pass

    header = ttk.Frame(
        dialog,
        style="LicenseHeader.TFrame",
        padding=(22, 18),
    )
    header.pack(fill="x")

    brand_box = ttk.Frame(header, style="LicenseHeader.TFrame")
    brand_box.pack(side="left")
    ttk.Label(
        brand_box,
        text="◈  МІЧМАН КП",
        style="LicenseBrand.TLabel",
    ).pack(anchor="w")
    ttk.Label(
        brand_box,
        text="OFFLINE LICENSE CORE  //  DEVICE-BOUND ACTIVATION",
        style="LicenseSub.TLabel",
    ).pack(anchor="w", pady=(2, 0))

    language_box = ttk.Frame(header, style="LicenseHeader.TFrame")
    language_box.pack(side="right")
    ttk.Label(
        language_box,
        text="LANGUAGE",
        style="LicenseSub.TLabel",
    ).pack(anchor="e")
    activation_language_combo = ttk.Combobox(
        language_box,
        values=[label for _code, label in LANGUAGES],
        state="readonly",
        width=13,
    )
    activation_language_combo.current(
        next(
            (
                index
                for index, (code, _label) in enumerate(LANGUAGES)
                if code == I18N.code
            ),
            0,
        )
    )
    activation_language_combo.pack(anchor="e", pady=(3, 0))

    def activation_language_changed(_event=None):
        index = activation_language_combo.current()
        if 0 <= index < len(LANGUAGES):
            I18N.set_language(LANGUAGES[index][0])
            I18N.retranslate(dialog)

    activation_language_combo.bind(
        "<<ComboboxSelected>>",
        activation_language_changed,
    )

    body = ttk.Frame(dialog, padding=22)
    body.pack(fill="both", expand=True)

    status_panel = ttk.Frame(
        body,
        style="LicensePanel.TFrame",
        padding=(16, 13),
    )
    status_panel.pack(fill="x")

    ttk.Label(
        status_panel,
        text="СТАН ЛІЦЕНЗІЇ",
        style="LicensePanel.TLabel",
        font=("Segoe UI Semibold", 9),
        foreground=UI_MUTED,
    ).pack(anchor="w")
    current_text = (
        f"{current.label}  //  {format_remaining(current.remaining_seconds)}"
        if current.valid
        else current.message
    )
    current_var = tk.StringVar(value=current_text)
    current_label = ttk.Label(
        status_panel,
        textvariable=current_var,
        style="LicenseCode.TLabel",
        wraplength=610,
        justify="left",
    )
    current_label.pack(anchor="w", pady=(4, 0))

    device_panel = ttk.Frame(
        body,
        style="LicensePanel.TFrame",
        padding=(16, 13),
    )
    device_panel.pack(fill="x", pady=(12, 0))
    ttk.Label(
        device_panel,
        text="КОД ЦЬОГО КОМП’ЮТЕРА",
        style="LicensePanel.TLabel",
        font=("Segoe UI Semibold", 9),
        foreground=UI_MUTED,
    ).pack(anchor="w")
    code_row = ttk.Frame(device_panel, style="LicensePanel.TFrame")
    code_row.pack(fill="x", pady=(4, 0))
    ttk.Label(
        code_row,
        text=manager.device_code,
        style="LicenseCode.TLabel",
    ).pack(side="left")

    def copy_device_code():
        dialog.clipboard_clear()
        dialog.clipboard_append(manager.device_code)
        feedback_var.set("Код ПК скопійовано.")

    ttk.Button(
        code_row,
        text="Копіювати",
        command=copy_device_code,
    ).pack(side="right")

    ttk.Label(
        body,
        text="КЛЮЧ АКТИВАЦІЇ",
        foreground=UI_MUTED,
        font=("Segoe UI Semibold", 9),
    ).pack(anchor="w", pady=(18, 4))
    key_entry = ttk.Entry(body, font=("Cascadia Mono", 12), justify="center")
    key_entry.pack(fill="x")

    feedback_var = tk.StringVar(
        value="Перевірка виконується локально. Інтернет не використовується."
    )
    feedback_label = ttk.Label(
        body,
        textvariable=feedback_var,
        foreground=UI_MUTED,
        wraplength=640,
        justify="left",
    )
    feedback_label.pack(anchor="w", pady=(10, 0))

    def activate():
        status = manager.activate(key_entry.get())
        if status.valid:
            result["status"] = status
            current_var.set(
                f"{status.label}  //  {format_remaining(status.remaining_seconds)}"
            )
            current_label.configure(foreground=UI_GREEN)
            feedback_var.set("АКТИВАЦІЮ ЗАВЕРШЕНО. Усі функції доступні.")
            feedback_label.configure(foreground=UI_GREEN)
            key_entry.delete(0, "end")
            dialog.after(650, dialog.destroy)
        else:
            feedback_var.set(status.message)
            feedback_label.configure(foreground=UI_RED)
            key_entry.selection_range(0, "end")
            key_entry.focus_set()

    footer = ttk.Frame(body)
    footer.pack(fill="x", side="bottom", pady=(18, 0))
    ttk.Button(
        footer,
        text="АКТИВУВАТИ",
        command=activate,
        style="Accent.TButton",
    ).pack(side="left")

    def close_dialog():
        if allow_cancel and current.valid:
            result["status"] = current
        else:
            result["status"] = None
        dialog.destroy()

    ttk.Button(
        footer,
        text="Закрити" if allow_cancel else "Вийти",
        command=close_dialog,
    ).pack(side="right")

    ttk.Label(
        body,
        text=(
            "Пробна ліцензія запускається один раз на цьому ПК. "
            "Переведення системного часу назад не продовжує пробний період."
        ),
        foreground=UI_AMBER,
        wraplength=640,
        justify="left",
    ).pack(anchor="w", side="bottom", pady=(12, 0))

    dialog.protocol("WM_DELETE_WINDOW", close_dialog)
    key_entry.bind("<Return>", lambda _event: activate())
    dialog.update_idletasks()
    width = dialog.winfo_width()
    height = dialog.winfo_height()
    _show_child_window(
        dialog,
        width,
        height,
        min_width=420,
        min_height=360,
        modal=True,
    )
    key_entry.focus_force()
    parent.wait_window(dialog)
    return result["status"]


def _install_platform_hooks():
    from functools import wraps
    from michman_identity import require
    permissions = {
        "start": "monitor", "stop": "monitor", "network_scan_dialog": "monitor",
        "add_ip_dialog": "configure", "_remove_ips": "configure", "rename_selected": "configure",
        "edit_selected_device": "configure", "mikrotik_config_dialog": "configure",
        "register_platform_host": "enroll", "open_mikrotik_security_center": "security",
        "open_scan_watch_window": "security", "open_dfir_window": "security",
    }
    for name, capability in permissions.items():
        original = getattr(MichmanKP, name)
        def guarded(self, *args, _original=original, _capability=capability, **kwargs):
            try:
                require(self.identity_session["role"], _capability)
            except PermissionError as error:
                messagebox.showerror(APP_NAME, str(error), parent=self.root)
                return
            return _original(self, *args, **kwargs)
        setattr(MichmanKP, name, wraps(original)(guarded))
    original_check = MichmanKP.apply_check_result
    @wraps(original_check)
    def check(self, host, result):
        value = original_check(self, host, result)
        if not self.closed:
            try:
                self.platform_core.ingest(host.ip, host.snapshot(), host.name)
            except Exception:
                LOGGER.exception("Platform telemetry ingest failed")
        return value
    MichmanKP.apply_check_result = check
    original_log = MichmanKP.write_log
    @wraps(original_log)
    def log(self, message, ip=None, event="INFO", *args, **kwargs):
        value = original_log(self, message, ip, event, *args, **kwargs)
        if hasattr(self, "platform_core") and any(word in str(event).upper() for word in ("SCAN", "DFIR", "MAC_CHANGE", "SECURITY")):
            try:
                self.platform_core.event(ip or "console", str(event), "WARNING", message)
            except Exception:
                LOGGER.exception("Platform event ingest failed")
        return value
    MichmanKP.write_log = log


_install_platform_hooks()


def _run_application():
    enable_windows_dpi_awareness()

    if not acquire_single_instance():
        root = tk.Tk()
        try:
            root.geometry("1x1+0+0")
            _bring_window_to_front(root)
        except tk.TclError:
            pass
        messagebox.showwarning(
            APP_NAME,
            "Програма вже запущена. Закрийте попереднє вікно "
            "або скористайтеся ним.",
            parent=root,
        )
        root.destroy()
        return

    root = tk.Tk()
    root.withdraw()
    LOGGER.info("Startup root created; checking offline license")

    try:
        license_manager = LicenseManager(BASE_DIR)
        license_status = license_manager.check()

        if not license_status.valid:
            # A withdrawn owner can hide a modal Toplevel on some Windows
            # configurations. Keep a tiny visible owner while activation is
            # open; hide it again immediately afterwards.
            try:
                root.geometry("1x1+0+0")
                root.deiconify()
                root.update_idletasks()
            except tk.TclError:
                pass
            license_status = show_license_dialog(
                root,
                license_manager,
                allow_cancel=False,
            )
            try:
                root.withdraw()
            except tk.TclError:
                pass
            if not license_status or not license_status.valid:
                root.destroy()
                return

        from michman_identity import IdentityStore, login_dialog
        identity_store = IdentityStore(BASE_DIR)
        identity_session = login_dialog(root, identity_store)
        if not identity_session:
            root.destroy()
            return
        LOGGER.info("Offline license accepted; building main window")
        app = MichmanKP(
            root,
            license_manager=license_manager,
            license_status=license_status,
            identity_session=identity_session,
            identity_store=identity_store,
        )
        root.after(500, app.open_platform)
        _center_window(root, 1640, 900, min_width=1180, min_height=700)
        _bring_window_to_front(root)
        LOGGER.info("Main window shown")

        # -------------------------------------------------------------
        # Періодичне опитування MikroTik.
        #
        # Воно НЕ змінює логіку ONLINE/OFFLINE.
        # MikroTik використовується для:
        #   - MAC
        #   - виробника
        #   - hostname
        #   - interface
        #   - DHCP lease
        #   - автоматичного додавання знайдених пристроїв у JSON-список
        # -------------------------------------------------------------

        root.after(
            3000,
            app.refresh_mikrotik_periodically,
        )

        root.mainloop()
    finally:
        release_single_instance()


def main():
    try:
        if "--enable-scan-sensor" in sys.argv:
            ok, message = enable_windows_scan_sensor(allow_elevation=False)
            print(message)
            raise SystemExit(0 if ok else 1)
        if "--diagnostics" in sys.argv:
            from michman_diagnostics import run
            run(BASE_DIR)
            return
        _run_application()
    except Exception as error:
        record_startup_failure(error)


if __name__ == "__main__":
    main()

