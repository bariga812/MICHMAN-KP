import inspect
import unittest
from unittest.mock import patch

from MichmanKP_Protected import MultiMikroTikManager, SingleMikroTikClient
from michman_network_ui import NetworkCenter
from michman_router_support import HOME_WEB_PLATFORMS, HomeRouterWebSession, PLATFORMS


class _Headers(dict):
    def get_content_charset(self):
        return 'utf-8'


class _WebResponse:
    status = 200
    headers = _Headers({'Server': 'Mercusys HTTPD'})
    def __enter__(self):return self
    def __exit__(self,*_args):return False
    def read(self,_limit):return b'<html><title>Mercusys AC12G</title></html>'
    def geturl(self):return 'http://192.0.2.1/'


class UnifiedRouterTests(unittest.TestCase):
    def test_non_mikrotik_blank_user_stays_blank(self):
        client = SingleMikroTikClient(
            'Router', '192.0.2.1', '', 'secret', 'SSH', 22, True, 'openwrt'
        )
        self.assertEqual(client.auth_user, '')
        self.assertTrue(client.is_configured())

    def test_routeros_manager_does_not_send_routeros_commands_to_other_platforms(self):
        manager = MultiMikroTikManager([
            {'name': 'MT', 'host': '192.0.2.1', 'password': 'x', 'platform': 'mikrotik'},
            {'name': 'Cisco', 'host': '192.0.2.2', 'password': 'x', 'platform': 'cisco_ios'},
        ])
        self.assertEqual([client.name for client in manager.clients], ['MT'])

    def test_network_center_no_longer_creates_separate_universal_tab(self):
        source = inspect.getsource(NetworkCenter.__init__)
        self.assertNotIn('self.make_universal_routers()', source)
        self.assertIn('self.make_backup()', source)

    def test_major_home_router_profiles_are_available(self):
        for platform in ('mercusys','tplink_home','asuswrt','keenetic','dlink_home','tenda_home','netgear_home','linksys_home','xiaomi_home','zyxel_home'):
            self.assertIn(platform, PLATFORMS)
            self.assertIn(platform, HOME_WEB_PLATFORMS)

    @patch('urllib.request.OpenerDirector.open', return_value=_WebResponse())
    def test_home_web_probe_reads_identity_without_subnet_scan(self, _open):
        result = HomeRouterWebSession({'host':'192.0.2.1','port':80,'platform':'mercusys','password':'secret'}).probe()
        self.assertEqual(result['title'], 'Mercusys AC12G')
        self.assertEqual(result['status'], 200)


if __name__ == '__main__':
    unittest.main()
