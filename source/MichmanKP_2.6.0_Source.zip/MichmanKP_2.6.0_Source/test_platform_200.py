import json
import os
import ssl
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from michman_platform_core import PlatformCore
from michman_identity import IdentityStore,require
from michman_agent import AgentRuntime,AgentClient,start_server


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.now=1000000
        self.core=PlatformCore(Path(self.temp.name)/'test.db',lambda:self.now)
    def tearDown(self):self.core.close();self.temp.cleanup()
    def ingest(self,ip,**data):self.core.ingest(ip,data,ip);self.now+=5
    def test_link_metrics_and_jitter(self):
        for ping in (10,20,15):self.ingest('a',online=True,ping=ping)
        self.ingest('a',online=False,ping=None)
        metrics=self.core.link_metrics('a',3600)
        self.assertEqual(metrics['jitter_ms'],7.5)
        self.assertEqual(metrics['loss_percent'],25)
        self.assertEqual(metrics['uptime_percent'],75)
        self.assertEqual(metrics['outages'],1)
    def test_dependencies_reject_cycles(self):
        self.core.set_dependency('a','b');self.core.set_dependency('b','c')
        with self.assertRaises(ValueError):self.core.set_dependency('c','a')
    def test_correlation_uses_failed_parent(self):
        self.core.set_dependency('router','server')
        first=self.core.event('router','OFFLINE','CRITICAL','down')
        second=self.core.event('server','OFFLINE','CRITICAL','down')
        self.assertEqual(first,second)
        self.assertEqual(len(self.core.rows('SELECT * FROM p_affected WHERE incident=?',(first,))),2)
    def test_unrelated_failures_not_merged(self):
        a=self.core.event('a','OFFLINE','CRITICAL','down');b=self.core.event('b','OFFLINE','CRITICAL','down')
        self.assertNotEqual(a,b)
    def test_recovered_parent_not_used_as_origin(self):
        self.core.set_dependency('router','server')
        first=self.core.event('router','OFFLINE','CRITICAL','down')
        self.now+=10;self.core.event('router','RECOVERED','INFO','up',False)
        second=self.core.event('server','OFFLINE','CRITICAL','down')
        self.assertNotEqual(first,second)
    def test_mac_and_ip_baseline(self):
        self.ingest('a',online=True,current_mac='AA:BB:CC:DD:EE:FF')
        self.core.accept_baseline('a','admin')
        self.ingest('a',online=True,current_mac='AA:BB:CC:DD:EE:00')
        self.ingest('b',online=True,current_mac='AA:BB:CC:DD:EE:FF')
        kinds={r['kind'] for r in self.core.rows('SELECT kind FROM p_events')}
        self.assertIn('MAC_CHANGE',kinds);self.assertIn('IP_CHANGE',kinds)
    def test_agent_enriches_network_asset(self):
        self.ingest('a',online=True,ping=12)
        self.ingest('a',cpu_percent=37,ram_percent=55)
        latest=json.loads(self.core.rows('SELECT latest FROM p_assets')[0]['latest'])
        self.assertTrue(latest['online']);self.assertEqual(latest['cpu_percent'],37)
    def test_recorder_pre_post_and_export(self):
        self.ingest('a',online=True,ping=1)
        self.now+=650
        self.ingest('a',online=True,ping=2)
        incident=self.core.event('a','OFFLINE','CRITICAL','down')
        self.ingest('a',online=False)
        captured=self.core.rows("SELECT * FROM p_capture WHERE incident=? AND kind='telemetry'",(incident,))
        self.assertEqual(len(captured),2)
        self.now+=400;self.ingest('a',online=True)
        self.assertEqual(len(self.core.rows("SELECT * FROM p_capture WHERE incident=? AND kind='telemetry'",(incident,))),2)
        destination=Path(self.temp.name)/'incident.zip';self.core.export_incident(incident,destination)
        self.assertTrue(destination.exists())
    def test_retention(self):
        self.ingest('a',online=True,ping=1);self.now+=31*86400;self.core.maintenance()
        self.assertEqual(self.core.rows('SELECT * FROM p_samples'),[])
    def test_report_escapes_formula(self):
        self.core.ingest('a',{'online':True,'ping':1},'=SUM(A1)')
        path=Path(self.temp.name)/'report.csv';self.core.report(path)
        self.assertIn("'=SUM(A1)",path.read_text(encoding='utf-8-sig'))


class IdentityAndAgentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.base=Path(cls.temp.name)
        cls.store=IdentityStore(cls.base)
        cls.store.bootstrap('admin','Admin-password-123')
        cls.store.create_user('viewer','Viewer-password-123','Viewer','Admin-password-123')
        cls.store.create_user('helpdesk','Helpdesk-password-123','Helpdesk','Admin-password-123')
        cls.folder=cls.store.provision_agent('127.0.0.1',cls.base/'agent','Admin-password-123',port=0)
        config=json.loads((cls.folder/'agent.json').read_text());config['bind']='127.0.0.1'
        (cls.folder/'agent.json').write_text(json.dumps(config))
        cls.runtime=AgentRuntime(cls.folder,consent=lambda user:False)
        cls.server=start_server(cls.runtime);cls.port=cls.server.server_address[1]
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close()
        import logging
        logger=logging.getLogger('michman-agent-'+str(cls.folder))
        for handler in list(logger.handlers):handler.close();logger.removeHandler(handler)
        cls.temp.cleanup()
    def client(self,user,password):return AgentClient('127.0.0.1',self.port,self.store.login(user,password)['ssl_context'])
    def test_login_and_roles(self):
        self.assertEqual(self.store.login('viewer','Viewer-password-123')['role'],'Viewer')
        with self.assertRaises(PermissionError):self.store.login('viewer','bad')
        with self.assertRaises(PermissionError):require('Viewer','power')
    def test_private_keys_are_encrypted(self):
        self.assertIn(b'ENCRYPTED PRIVATE KEY',(self.store.directory/'admin-key.pem').read_bytes())
        self.assertIn(b'ENCRYPTED PRIVATE KEY',(self.store.directory/'ca-key.pem').read_bytes())
    def test_real_mtls_telemetry(self):
        result=self.client('viewer','Viewer-password-123').call('telemetry')
        self.assertIn('cpu_percent',result);self.assertEqual(result['agent_id'],self.runtime.config['agent_id'])
    def test_certificate_required(self):
        context=ssl.create_default_context(cafile=str(self.store.directory/'ca.pem'))
        with self.assertRaises(Exception):AgentClient('127.0.0.1',self.port,context).call('telemetry')
    def test_role_enforced_on_agent(self):
        with self.assertRaisesRegex(RuntimeError,'дозволу'):
            self.client('viewer','Viewer-password-123').call('power',{'verb':'reboot'})
    def test_local_policy_denies_even_admin(self):
        with self.assertRaisesRegex(RuntimeError,'локально'):
            self.client('admin','Admin-password-123').call('power',{'verb':'reboot'})
    def test_arbitrary_commands_denied(self):
        with self.assertRaisesRegex(RuntimeError,'не дозволена'):
            self.client('admin','Admin-password-123').call('command',{'id':'rm -rf /'})
    def test_path_traversal_denied(self):
        with self.assertRaisesRegex(RuntimeError,'shared'):
            self.client('helpdesk','Helpdesk-password-123').call('files_list',{'path':'../'})
    def test_assistance_without_consent_denied(self):
        with self.assertRaisesRegex(RuntimeError,'відмовив'):
            self.client('helpdesk','Helpdesk-password-123').call('assist_request')
        with self.assertRaisesRegex(RuntimeError,'згоди'):
            self.client('helpdesk','Helpdesk-password-123').call('assist_frame',{'token':'made-up'})
    def test_file_roundtrip(self):
        client=self.client('helpdesk','Helpdesk-password-123')
        source=self.base/'payload.bin';source.write_bytes(os.urandom(1200000))
        client.upload(source,'example.bin');target=self.base/'download.bin';client.download('example.bin',target)
        self.assertEqual(source.read_bytes(),target.read_bytes())
    def test_client_cannot_invent_role(self):
        with self.assertRaises(RuntimeError):
            self.client('viewer','Viewer-password-123').call('command',{'role':'Administrator','id':'test'})
    def test_revocation_enforced(self):
        self.store.create_user('revokee','Revokee-password-123','Viewer','Admin-password-123')
        serial=self.store.users()['revokee']['serial']
        self.client('admin','Admin-password-123').call('revoke_user',{'serial':serial})
        with self.assertRaisesRegex(RuntimeError,'відкликано'):
            self.client('revokee','Revokee-password-123').call('telemetry')
    def test_screen_token_bound_to_user_and_expiry(self):
        import time
        self.runtime.sessions['fixture']={'user':'alice','expires':time.monotonic()+10}
        with self.assertRaises(PermissionError):self.runtime.session('bob','fixture')
        self.runtime.sessions['fixture']['expires']=0
        with self.assertRaises(PermissionError):self.runtime.session('alice','fixture')

    def test_approved_assistance_has_no_time_limit(self):
        original=self.runtime.consent
        try:
            self.runtime.consent=lambda _user:True
            result=self.runtime.rpc('helpdesk','Helpdesk','assist_request',{})
            self.assertTrue(result['unlimited']);self.assertIsNone(result['expires_seconds'])
            self.assertIsNone(self.runtime.session('helpdesk',result['token'])['expires'])
            self.runtime.rpc('helpdesk','Helpdesk','assist_stop',{'token':result['token']})
            with self.assertRaises(PermissionError):self.runtime.session('helpdesk',result['token'])
        finally:self.runtime.consent=original

    def test_stream_mtls_frames_and_consent_revocation(self):
        import threading,time,io,sys
        from types import SimpleNamespace
        from PIL import Image
        client=self.client('helpdesk','Helpdesk-password-123')
        self.runtime.sessions['video-test']={'user':'helpdesk','expires':time.monotonic()+10}
        stop=threading.Event()
        fake=SimpleNamespace(screenshot=lambda:Image.new('RGB',(1920,1080),'navy'))
        with patch.dict(sys.modules,{'pyautogui':fake}):
            frames=client.frames('video-test',stop)
            try:
                for _ in range(3):
                    data=next(frames)
                    self.assertEqual(Image.open(io.BytesIO(data)).size,(1280,720))
                self.runtime.revoke_assistance()
                with self.assertRaises(EOFError):
                    for _ in range(40):next(frames)
            finally:stop.set();frames.close()

    def test_stream_rejects_missing_consent(self):
        import threading
        from urllib.error import HTTPError
        frames=self.client('helpdesk','Helpdesk-password-123').frames('invalid',threading.Event())
        with self.assertRaises(HTTPError):next(frames)

    def test_upload_progress_cancel_preserves_target(self):
        import threading
        client=self.client('helpdesk','Helpdesk-password-123')
        source=self.base/'cancel.bin';source.write_bytes(os.urandom(2200000))
        target=self.runtime.root/'cancel-target.bin';target.write_bytes(b'original')
        cancel=threading.Event();updates=[]
        def progress(done,total):updates.append((done,total));cancel.set()
        with self.assertRaises(InterruptedError):client.upload(source,target.name,True,progress,cancel)
        self.assertTrue(updates);self.assertEqual(target.read_bytes(),b'original')
        self.assertFalse(self.runtime.uploads)
        self.assertFalse(list(self.runtime.root.glob('.michman-upload-*')))

    def test_download_cancel_preserves_local_file(self):
        import threading
        source=self.runtime.root/'download-cancel.bin';source.write_bytes(os.urandom(2200000))
        target=self.base/'keep-local.bin';target.write_bytes(b'original')
        cancel=threading.Event()
        with self.assertRaises(InterruptedError):
            self.client('helpdesk','Helpdesk-password-123').download(source.name,target,lambda *_:cancel.set(),cancel)
        self.assertEqual(target.read_bytes(),b'original')
        self.assertFalse(target.with_name(target.name+'.michman-part').exists())

    def test_existing_partial_download_not_deleted(self):
        target=self.base/'occupied.bin';partial=target.with_name(target.name+'.michman-part');partial.write_bytes(b'keep')
        with self.assertRaises(FileExistsError):self.client('helpdesk','Helpdesk-password-123').download('anything',target)
        self.assertEqual(partial.read_bytes(),b'keep')


if __name__=='__main__':unittest.main()
