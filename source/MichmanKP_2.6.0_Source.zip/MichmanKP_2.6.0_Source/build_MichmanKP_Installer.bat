@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo   MICHMAN KP 2.0.0 - WINDOWS INSTALLER BUILD
echo ============================================================
echo.

where py >nul 2>&1
if errorlevel 1 (
  echo Python Launcher ^(py.exe^) was not found.
  echo Install Python 3.12 for Windows and run this file again.
  goto :error
)

py -3.12 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.12 was not found through the Python Launcher.
  echo Install Python 3.12 for Windows and run this file again.
  goto :error
)

if not exist "MichmanKP_Protected.py" (
  echo MichmanKP_Protected.py was not found beside this script.
  goto :error
)
if not exist "michman_i18n.py" (
  echo michman_i18n.py was not found beside this script.
  goto :error
)
if not exist "michman_license.py" (
  echo michman_license.py was not found beside this script.
  goto :error
)
if not exist "LICENSE_MICHMAN_UA.txt" (
  echo LICENSE_MICHMAN_UA.txt was not found beside this script.
  goto :error
)
if not exist "MichmanKP_Icon.ico" (
  echo MichmanKP_Icon.ico was not found beside this script.
  goto :error
)

echo Installing Python build dependencies...
py -3.12 -m pip install --upgrade pip
if errorlevel 1 goto :error
py -3.12 -m pip install -r MichmanKP_Protected_requirements.txt
if errorlevel 1 goto :error

echo Building the Windows application with Nuitka...
py -3.12 -m nuitka ^
  --mode=standalone ^
  --assume-yes-for-downloads ^
  --enable-plugin=tk-inter ^
  --windows-console-mode=disable ^
  --windows-icon-from-ico=MichmanKP_Icon.ico ^
  --output-dir=dist ^
  --output-filename=MichmanKP_Protected.exe ^
  --company-name="MICHMAN" ^
  --product-name="MICHMAN KP" ^
  --file-description="Network Observability and MikroTik Security Center" ^
  --file-version=2.0.0.0 ^
  --product-version=2.0.0.0 ^
  --copyright="Property of Ihor Stepanenko" ^
  --include-module=michman_license ^
  --include-module=michman_i18n ^
  --include-package=openpyxl ^
  --include-package=paramiko ^
  --include-package=pysnmp ^
  --include-package=pyasn1 ^
  --include-package=Cryptodome ^
  --include-package=psutil ^
  --include-package=PIL ^
  --include-package=pyautogui ^
  MichmanKP_Protected.py
if errorlevel 1 goto :error

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"

if not defined ISCC (
  echo.
  echo Inno Setup 6 was not found.
  echo Install it from https://jrsoftware.org/isinfo.php and run this file again.
  goto :error
)

if not exist "dist\MichmanKP_Protected.dist\MichmanKP_Protected.exe" (
  echo Nuitka output was not found.
  goto :error
)

echo Creating the installer with Inno Setup...
"%ISCC%" "%~dp0MichmanKP_Installer.iss"
if errorlevel 1 goto :error

echo.
echo ============================================================
echo BUILD COMPLETED
echo Installer:
echo %~dp0installer_output\MichmanKP_Setup_2.0.0.exe
echo ============================================================
pause
exit /b 0

:error
echo.
echo ============================================================
echo BUILD FAILED. Review the messages above.
echo ============================================================
pause
exit /b 1
