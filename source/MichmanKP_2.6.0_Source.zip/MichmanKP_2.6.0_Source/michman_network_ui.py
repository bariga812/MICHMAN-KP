from michman_windows import install_window_policy, WrapToolbar, restore
install_window_policy()
"""Tk network center. Workers never read or mutate Tk widgets."""
import copy
import json
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

from michman_utils import atomic_write_json
from michman_snmp import SNMPClient, validate_profile, add_rates
from michman_topology import collect_router_tables, build_graph
from michman_backup import RouterSession, create_backup, compare_backups, restore_backup, verify_backup
from michman_router_support import (PLATFORMS,UniversalRouterSession,validate_router_profile,
    create_universal_backup,read_universal_backup,compare_universal_backups)
from michman_router_analysis import analyze_router_snapshot,router_inventory_summary,detect_router_changes


def display(value, suffix=''):
    return '—' if value is None else f'{value:,.1f}{suffix}' if isinstance(value, float) else str(value) + suffix


class NetworkCenter:
    def __init__(self, app, base_dir, protect, unprotect, client_factory):
        self.app, self.base = app, Path(base_dir)
        self.protect, self.unprotect, self.client_factory = protect, unprotect, client_factory
        self.profile_path = self.base / 'snmp_profiles.json'
        self.router_profile_path = self.base / 'router_profiles.json'
        self.router_profiles = self.load_router_profiles()
        self.profiles, self.snapshots, self.failures, self.next_poll = [], {}, {}, {}
        self.busy, self.alive, self.graph = set(), True, None
        self.window = tk.Toplevel(app.root)
        self.window.title('МІЧМАН КП — Мережевий центр')
        self.window.geometry('1150x780')
        self.window.minsize(900, 640)
        self.window.protocol('WM_DELETE_WINDOW', self.close)
        self.status = tk.StringVar(value='Готово')
        ttk.Label(self.window, text='МЕРЕЖЕВИЙ ЦЕНТР  /  SNMP • КАРТА • РЕЗЕРВНІ КОПІЇ', padding=12).pack(fill='x')
        self.tabs = ttk.Notebook(self.window)
        self.tabs.pack(fill='both', expand=True, padx=12)
        ttk.Label(self.window, textvariable=self.status, wraplength=1050, padding=10).pack(fill='x')
        self.make_snmp()
        self.make_map()
        self.make_backup()
        try:
            if self.profile_path.exists():
                saved = json.loads(self.profile_path.read_text(encoding='utf-8'))
                if not isinstance(saved, list):
                    raise ValueError('Некоректний формат snmp_profiles.json')
                for profile in saved:
                    p = dict(profile)
                    p.setdefault('id', uuid.uuid4().hex)
                    if any(old['id'] == p['id'] for old in self.profiles):
                        raise ValueError('Дубль ідентифікатора SNMP-профілю.')
                    for key in ('community', 'auth_key', 'priv_key'):
                        p[key] = unprotect(p.get(key, ''))
                    self.profiles.append(validate_profile(p))
        except Exception as error:
            self.status.set('Помилка читання SNMP-профілів: ' + str(error))
            # Prevent overwriting unreadable credentials with an empty list.
            self.profile_load_error = True
        else:
            self.profile_load_error = False
        self.refresh_profiles()
        self.refresh_backups()
        self.map_due = time.monotonic()
        self.timer = self.window.after(1000, self.tick)

    def close(self):
        if 'backup' in self.busy:
            messagebox.showinfo('Операція триває', 'Дочекайтеся завершення операції резервного копіювання або відновлення.', parent=self.window)
            return
        self.alive = False
        self.window.after_cancel(self.timer)
        self.window.destroy()

    def job(self, key, work, done):
        if key in self.busy:
            return
        self.busy.add(key)
        self.status.set('Виконується: ' + key)
        def worker():
            try:
                result, error = work(), None
            except Exception as exc:
                result, error = None, str(exc) or type(exc).__name__
            def finish():
                self.busy.discard(key)
                if not self.alive or not self.window.winfo_exists():
                    return
                if error:
                    self.status.set('Помилка: ' + error)
                    if key == 'backup':
                        messagebox.showerror('Мережевий центр', error, parent=self.window)
                else:
                    self.status.set('Завершено: ' + key)
                    done(result)
            self.app.run_on_gui(finish)
        threading.Thread(target=worker, name='NetworkCenter-' + key, daemon=True).start()

    def table(self, parent, columns, height=10, selectmode='browse'):
        frame = ttk.Frame(parent)
        frame.pack(fill='both', expand=True, pady=5)
        tree = ttk.Treeview(frame, columns=[c[0] for c in columns], show='headings', height=height, selectmode=selectmode)
        for key, title, width in columns:
            tree.heading(key, text=title)
            tree.column(key, width=width, minwidth=60)
        y = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        x = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
        tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        tree.grid(row=0, column=0, sticky='nsew')
        y.grid(row=0, column=1, sticky='ns')
        x.grid(row=1, column=0, sticky='ew')
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def make_snmp(self):
        tab = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(tab, text='SNMP v2 / v3')
        bar = WrapToolbar(tab)
        bar.pack(fill='x')
        for label, command in [('Додати', self.edit_profile), ('Редагувати', lambda: self.edit_profile(True)),
                               ('Видалити', self.delete_profile), ('Оновити зараз', lambda: self.poll_snmp(True)),
                               ('Повний знімок',self.show_router_inventory),('Аналіз проблем',self.show_router_issues),
                               ('Експорт знімка',self.export_router_snapshot)]:
            ttk.Button(bar, text=label, command=command).pack(side='left', padx=3)
        self.snmp_auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text='Автоопитування, поки центр відкритий', variable=self.snmp_auto).pack(side='left', padx=12)
        self.host_table = self.table(tab, [('host', 'Пристрій', 145), ('vendor', 'Виробник / ОС', 180), ('state', 'Стан / час UTC', 210),
            ('cpu', 'CPU %', 75), ('ram', 'RAM використано / всього MiB', 190), ('temp', '°C', 65)], height=7)
        self.host_table.bind('<<TreeviewSelect>>', lambda _: self.show_interfaces())
        self.snmp_detail = tk.StringVar(value='RX/TX з’являються після двох успішних вимірювань. — = дані недоступні.')
        ttk.Label(tab, textvariable=self.snmp_detail, wraplength=1040).pack(fill='x')
        self.if_table = self.table(tab, [('name', 'Інтерфейс', 130), ('state', 'Стан', 80),
            ('rx', 'RX Mbit/s', 100), ('tx', 'TX Mbit/s', 100), ('rx_total', 'RX bytes', 130), ('tx_total', 'TX bytes', 130),
            ('in_err', 'RX errors', 90), ('out_err', 'TX errors', 90), ('drop', 'Drops RX/TX', 110)])

    def save_profiles(self, profiles):
        from michman_identity import require
        require(getattr(self.app, 'identity_session', {}).get('role', 'Viewer'), 'configure')
        if self.profile_load_error:
            raise ValueError('Виправте або перемістіть пошкоджений snmp_profiles.json та відкрийте центр повторно.')
        saved = copy.deepcopy(profiles)
        for profile in saved:
            for key in ('community', 'auth_key', 'priv_key'):
                profile[key] = self.protect(profile.get(key, ''))
                if profile[key] and not profile[key].startswith('dpapi:'):
                    raise ValueError('Збереження секретів потребує Windows DPAPI.')
        atomic_write_json(self.profile_path, saved)
        self.profiles = profiles
        self.refresh_profiles()

    def edit_profile(self, editing=False):
        selected = self.host_table.selection()
        original = next((p for p in self.profiles if selected and p['id'] == selected[0]), None) if editing else None
        if editing and not original:
            return
        defaults = {'id': uuid.uuid4().hex, 'host': '', 'port': 161, 'version': '3', 'community': '',
            'user': '', 'level': 'authPriv', 'auth_protocol': 'SHA', 'auth_key': '',
            'priv_protocol': 'AES', 'priv_key': '', 'context': '', 'interval': 30, 'extra_oids': []}
        defaults.update(original or {})
        win = tk.Toplevel(self.window)
        win.title('SNMP-профіль')
        win.transient(self.window)
        body = ttk.Frame(win, padding=16)
        body.pack(fill='both', expand=True)
        fields = [('host', 'IP / DNS'), ('port', 'UDP-порт'), ('version', 'Версія'), ('community', 'Community (v2c)'),
            ('user', 'Користувач (v3)'), ('level', 'Рівень v3'), ('auth_protocol', 'Автентифікація'),
            ('auth_key', 'Пароль автентифікації'), ('priv_protocol', 'Шифрування'), ('priv_key', 'Пароль шифрування'),
            ('context', 'Context name'), ('interval', 'Інтервал, с'), ('extra_oids','Додаткові OID, через кому')]
        options = {'version': ('2c', '3'), 'level': ('noAuthNoPriv', 'authNoPriv', 'authPriv'),
                   'auth_protocol': ('SHA', 'MD5', 'SHA256'), 'priv_protocol': ('AES', 'DES')}
        variables = {}
        for row, (key, title) in enumerate(fields):
            ttk.Label(body, text=title).grid(row=row, column=0, sticky='w', pady=4)
            initial=','.join(defaults[key]) if key=='extra_oids' and isinstance(defaults[key],list) else defaults[key]
            variable = variables[key] = tk.StringVar(value=initial)
            if key in options:
                entry = ttk.Combobox(body, textvariable=variable, values=options[key], state='readonly', width=32)
            else:
                entry = ttk.Entry(body, textvariable=variable, width=35, show='*' if key in ('community', 'auth_key', 'priv_key') else '')
            entry.grid(row=row, column=1, padx=12, pady=4)
        feedback = tk.StringVar()
        ttk.Label(body, textvariable=feedback, wraplength=500).grid(row=13, column=0, columnspan=2)
        def save():
            try:
                profile = validate_profile({'id': defaults['id'], **{k: v.get() for k, v in variables.items()}})
                updated = [p for p in self.profiles if p['id'] != profile['id']] + [profile]
                self.save_profiles(updated)
                self.snapshots.pop(profile['id'], None)
                self.next_poll.pop(profile['id'], None)
                win.destroy()
            except Exception as error:
                feedback.set(str(error))
        ttk.Button(body, text='Зберегти', command=save).grid(row=14, column=1, sticky='e', pady=10)
        win.grab_set()

    def delete_profile(self):
        selection = self.host_table.selection()
        if selection and messagebox.askyesno('SNMP', 'Видалити вибраний профіль?', parent=self.window):
            try:
                self.save_profiles([p for p in self.profiles if p['id'] != selection[0]])
                self.snapshots.pop(selection[0], None)
            except Exception as error:
                self.status.set(str(error))

    def refresh_profiles(self):
        selected = self.host_table.selection()
        self.host_table.delete(*self.host_table.get_children())
        for profile in self.profiles:
            snap = self.snapshots.get(profile['id'], {})
            error = self.failures.get(profile['id'])
            ram = '—' if snap.get('ram_total') is None else f"{snap['ram_used']/1048576:.1f} / {snap['ram_total']/1048576:.1f}"
            self.host_table.insert('', 'end', iid=profile['id'], values=(profile['host'],
                snap.get('vendor','—'),
                'Помилка / дані застаріли' if error else snap.get('collected_at', 'Очікує'),
                display(snap.get('cpu_percent')), ram, display(snap.get('temperature_c'))))
        if selected and self.host_table.exists(selected[0]):
            self.host_table.selection_set(selected[0])
        self.show_interfaces()

    def show_interfaces(self):
        self.if_table.delete(*self.if_table.get_children())
        selection = self.host_table.selection()
        if not selection:
            return
        snap = self.snapshots.get(selection[0], {})
        self.snmp_detail.set(self.failures.get(selection[0]) or '; '.join(snap.get('warnings', [])) or
            'RX/TX: швидкість відносно пристрою. Errors/Drops: накопичувальні лічильники. — = немає надійних даних.')
        if snap.get('ups'):
            self.snmp_detail.set(self.snmp_detail.get() + '\nUPS: ' + json.dumps(snap['ups'], ensure_ascii=False))
        if snap:
            counts=router_inventory_summary(snap)['counts']
            self.snmp_detail.set(self.snmp_detail.get()+f"\nIP: {counts['ip_addresses']} · Маршрути: {counts['routes']} · VLAN: {counts['vlans']} · LLDP: {counts['lldp_neighbors']} · FDB: {counts['fdb_entries']} · Hardware: {counts['hardware_components']} · OID: {counts['raw_oids']}")
        for interface in snap.get('interfaces', []):
            mbps = lambda key: display(interface[key] / 1000000 if interface.get(key) is not None else None)
            self.if_table.insert('', 'end', values=(interface['name'], {1: 'UP', 2: 'DOWN'}.get(interface['status'], display(interface['status'])),
                mbps('rx_bps'), mbps('tx_bps'), display(interface['rx']), display(interface['tx']),
                display(interface['rx_errors']), display(interface['tx_errors']),
                display(interface['rx_discards']) + '/' + display(interface['tx_discards'])))

    def selected_snmp_snapshot(self):
        selection=self.host_table.selection()
        if len(selection)!=1:raise ValueError('Виберіть один SNMP-пристрій.')
        snapshot=self.snapshots.get(selection[0])
        if not snapshot:raise ValueError('Спочатку виконайте успішне SNMP-опитування.')
        return snapshot

    def show_json_window(self,title,payload):
        win=tk.Toplevel(self.window);win.title(title);win.geometry('1050x700');win.minsize(700,450)
        frame=ttk.Frame(win);frame.pack(fill='both',expand=True)
        view=tk.Text(frame,wrap='none');y=ttk.Scrollbar(frame,command=view.yview);x=ttk.Scrollbar(frame,orient='horizontal',command=view.xview)
        y.pack(side='right',fill='y');x.pack(side='bottom',fill='x');view.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        view.pack(fill='both',expand=True);view.insert('1.0',json.dumps(payload,ensure_ascii=False,indent=2,default=str));view.configure(state='disabled')

    def show_router_inventory(self):
        try:snapshot=self.selected_snmp_snapshot()
        except Exception as error:self.status.set(str(error));return
        sections={key:snapshot.get(key) for key in ('host','name','vendor','platform','sys_descr','sys_object_id','sys_contact','sys_location','uptime',
            'cpu_percent','ram_used','ram_total','temperature_c','capabilities','interfaces','ip_addresses','routes','arp','neighbors','bridge_fdb','vlans','hardware','sensors','ups','warnings')}
        sections['summary']=router_inventory_summary(snapshot)
        self.show_json_window('Повний знімок роутера',sections)

    def show_router_issues(self):
        try:snapshot=self.selected_snmp_snapshot()
        except Exception as error:self.status.set(str(error));return
        issues=analyze_router_snapshot(snapshot)
        win=tk.Toplevel(self.window);win.title('Аналіз проблем роутера');win.geometry('900x520')
        tree=self.table(win,[('severity','Рівень',100),('category','Категорія',150),('message','Опис',610)],height=18)
        for issue in issues:tree.insert('','end',values=(issue['severity'],issue['category'],issue['message']))
        ttk.Label(win,text='Проблем не виявлено за доступними SNMP-даними.' if not issues else f'Знайдено подій: {len(issues)}').pack(fill='x',padx=10,pady=8)

    def export_router_snapshot(self):
        try:snapshot=self.selected_snmp_snapshot()
        except Exception as error:self.status.set(str(error));return
        path=filedialog.asksaveasfilename(parent=self.window,title='Експорт повного SNMP-знімка',defaultextension='.json',
            initialfile='router_'+str(snapshot.get('host','device')).replace(':','_')+'.json',filetypes=[('JSON','*.json')])
        if path:
            try:atomic_write_json(path,snapshot);self.status.set('Збережено: '+path)
            except Exception as error:self.status.set(str(error))

    def poll_snmp(self, force=False):
        if 'snmp' in self.busy:
            return
        profiles = copy.deepcopy([p for p in self.profiles if force or self.next_poll.get(p['id'], 0) <= time.monotonic()])
        if not profiles:
            return
        def work():
            def poll(profile):
                try:
                    return profile, SNMPClient(profile).poll(topology=True), None
                except Exception as error:
                    return profile, None, str(error) or type(error).__name__
            with ThreadPoolExecutor(max_workers=4) as executor:
                return list(executor.map(poll, profiles))
        def done(results):
            for profile, snapshot, error in results:
                # Ignore results for a profile edited while its old request was running.
                if profile not in self.profiles:
                    continue
                key = profile['id']
                self.next_poll[key] = time.monotonic() + profile['interval']
                if error:
                    self.failures[key] = error
                else:
                    previous=self.snapshots.get(key) if key not in self.failures else None
                    self.snapshots[key] = snapshot = add_rates(snapshot,previous)
                    snapshot['changes']=detect_router_changes(previous,snapshot)
                    if hasattr(self.app, 'platform_core'):
                        inventory=router_inventory_summary(snapshot);issues=inventory['issues']
                        telemetry = {'cpu_percent': snapshot.get('cpu_percent'),
                            'ram_percent': 100 * snapshot['ram_used'] / snapshot['ram_total'] if snapshot.get('ram_total') else None,
                            'interfaces': snapshot.get('interfaces', []), 'temperature_c': snapshot.get('temperature_c'), 'ups': snapshot.get('ups', {}),
                            'router_vendor':snapshot.get('vendor'),'router_platform':snapshot.get('platform'),
                            'router_inventory':inventory['counts'],'router_capabilities':snapshot.get('capabilities',{}),
                            'router_issues':{'critical':sum(i['severity']=='CRITICAL' for i in issues),'warning':sum(i['severity']=='WARNING' for i in issues)}}
                        self.app.platform_core.ingest(profile['host'], telemetry, snapshot.get('name'))
                        for change in snapshot['changes']:
                            self.app.platform_core.throttled_event(profile['host'],change['category'],change['severity'],change['message'],60)
                    self.failures.pop(key, None)
            self.refresh_profiles()
            self.refresh_router_profiles()
        self.job('snmp', work, done)

    def make_map(self):
        tab = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(tab, text='Автоматична карта')
        bar = WrapToolbar(tab)
        bar.pack(fill='x')
        ttk.Button(bar, text='Оновити карту', command=self.poll_map).pack(side='left')
        ttk.Button(bar, text='Експорт JSON', command=self.export_map).pack(side='left', padx=8)
        self.map_auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text='Автооновлення 60 с', variable=self.map_auto).pack(side='left')
        ttk.Label(tab, text='Лише налаштовані MikroTik/SNMP-пристрої. ARP/DHCP — спостереження; Neighbors/LLDP — сусідство.\n'
            'Це не гарантія фізичного кабельного з’єднання чи поточного ONLINE. Нові IP автоматично не опитуються.', wraplength=1050).pack(fill='x', pady=8)
        frame = ttk.Frame(tab)
        frame.pack(fill='both', expand=True)
        self.canvas = tk.Canvas(frame, background='#0b1722', highlightthickness=0)
        x = ttk.Scrollbar(frame, orient='horizontal', command=self.canvas.xview)
        y = ttk.Scrollbar(frame, orient='vertical', command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=x.set, yscrollcommand=y.set)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        x.grid(row=1, column=0, sticky='ew')
        y.grid(row=0, column=1, sticky='ns')
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.map_summary = tk.StringVar(value='Очікує даних')
        ttk.Label(tab, textvariable=self.map_summary, wraplength=1050).pack(fill='x', pady=5)

    def poll_map(self):
        configs = copy.deepcopy(self.app.mikrotik_list)
        intervals = {p['id']: p['interval'] for p in self.profiles}
        snapshots = copy.deepcopy([s for key, s in self.snapshots.items()
            if key not in self.failures and key in intervals
            and time.monotonic() - s['monotonic'] <= intervals[key] * 2 + 55])
        def work():
            def collect(config):
                client = self.client_factory(config.get('name'), config.get('host'), config.get('user'),
                    config.get('password'), config.get('method', 'REST'), config.get('port'), config.get('verify_peer', True))
                return collect_router_tables(client)
            with ThreadPoolExecutor(max_workers=4) as executor:
                routers = list(executor.map(collect, configs))
            return build_graph(routers, snapshots)
        def done(graph):
            self.graph = graph
            if hasattr(self.app, 'platform_core'):
                for node in graph['nodes']:
                    address = node.get('address')
                    if address and node['kind'] == 'device':
                        observed = {'discovery_sources': [edge['evidence'] + ':' + edge['interface']
                            for edge in graph['edges'] if edge['target'] == node['id']]}
                        if node.get('mac'):
                            observed['current_mac'] = node['mac']
                        self.app.platform_core.ingest(address, observed, node['label'])
            self.draw_map()
            self.map_due = time.monotonic() + 60
        self.job('map', work, done)

    def draw_map(self):
        self.canvas.delete('all')
        graph = self.graph
        nodes = {n['id']: n for n in graph['nodes']}
        roots = [n for n in graph['nodes'] if n['kind'] == 'router']
        count, row = 0, 0
        for root in roots:
            edges = [e for e in graph['edges'] if e['source'] == root['id']]
            y = 50 + row * 76
            self.canvas.create_rectangle(20, y-25, 230, y+25, fill='#194257', outline='#00e5ff')
            self.canvas.create_text(125, y, text=root['label'][:25] + '\n' + root.get('address', ''), fill='white')
            for edge in edges:
                if count >= 400:
                    break
                ey = 50 + row * 76
                target = nodes[edge['target']]
                self.canvas.create_line(230, y, 600, ey, fill='#20f6a7' if edge['relation'] == 'neighbor' else '#9ec2ce',
                                        dash=() if edge['relation'] == 'neighbor' else (4, 4))
                self.canvas.create_text(410, ey-10, text=(edge['interface'] + ' · ' + edge['evidence'])[:55], fill='#9ec2ce')
                self.canvas.create_rectangle(600, ey-26, 940, ey+26, fill='#132d3d', outline='#2c7186')
                self.canvas.create_text(770, ey, text=str(target['label'])[:42] + '\n' + target.get('address', target.get('mac', '')), fill='white')
                row += 1
                count += 1
            row += 1
            if count >= 400:
                break
        self.canvas.configure(scrollregion=self.canvas.bbox('all') or (0, 0, 1000, 500))
        warnings = '; '.join(graph['warnings'])
        self.map_summary.set(f"Вузлів: {len(nodes)}; зв’язків: {len(graph['edges'])}; показано: {count}. {graph['created_at']}\n" +
            ('Перші 400 зв’язків; повні дані в JSON. ' if len(graph['edges']) > 400 else '') + warnings)

    def export_map(self):
        if self.graph:
            path = filedialog.asksaveasfilename(parent=self.window, defaultextension='.json', filetypes=[('JSON', '*.json')])
            if path:
                try:
                    atomic_write_json(path, self.graph)
                except Exception as error:
                    self.status.set(str(error))

    def load_router_profiles(self):
        self.router_profile_error=''
        try:
            if not self.router_profile_path.exists():return []
            data=json.loads(self.router_profile_path.read_text(encoding='utf-8'))
            if not isinstance(data,list):raise ValueError('router_profiles.json повинен містити список.')
            profiles=[validate_router_profile(item) for item in data]
            if len({item['id'] for item in profiles})!=len(profiles):raise ValueError('Дубль ID профілю роутера.')
            return profiles
        except Exception as error:
            self.router_profile_error=str(error);return []

    def save_router_profiles(self,profiles):
        from michman_identity import require
        require(getattr(self.app,'identity_session',{}).get('role','Viewer'),'configure')
        if self.router_profile_error:raise ValueError('Виправте пошкоджений router_profiles.json перед збереженням.')
        cleaned=[validate_router_profile(profile) for profile in profiles]
        atomic_write_json(self.router_profile_path,cleaned);self.router_profiles=cleaned;self.refresh_router_profiles()

    def make_universal_routers(self):
        tab=ttk.Frame(self.tabs,padding=10);self.tabs.add(tab,text='Універсальні роутери')
        bar=WrapToolbar(tab);bar.pack(fill='x')
        for label,command in [('Додати',self.edit_router_profile),('Редагувати',lambda:self.edit_router_profile(True)),
            ('Видалити',self.delete_router_profile),('Перевірити SSH',self.test_router_profile),
            ('Зашифрована копія',self.backup_universal_router),('Порівняти копії',self.compare_universal_router_backups)]:
            ttk.Button(bar,text=label,command=command).pack(side='left',padx=3)
        ttk.Label(tab,text='SNMP-моніторинг працює через стандартні MIB. SSH-профілі створюють зашифровані текстові копії; автоматичне відновлення для невідомих платформ заблоковане.',wraplength=1050).pack(fill='x',pady=7)
        self.universal_table=self.table(tab,[('name','Назва',160),('host','IP / DNS',140),('platform','Платформа',190),
            ('auth','Автентифікація',155),('user','SSH користувач',130),('port','Порт',65),('snmp','SNMP визначення',220)],height=13)
        self.universal_backup_dir=tk.StringVar(value=str(self.base/'universal_router_backups'))
        bottom=WrapToolbar(tab);bottom.pack(fill='x')
        ttk.Label(bottom,text='Папка зашифрованих копій:').pack(side='left')
        ttk.Entry(bottom,textvariable=self.universal_backup_dir,width=55).pack(side='left',padx=5)
        ttk.Button(bottom,text='Обрати',command=self.choose_universal_backup_dir).pack(side='left')
        self.refresh_router_profiles()

    def refresh_router_profiles(self):
        if not hasattr(self,'universal_table'):return
        selected=self.universal_table.selection();self.universal_table.delete(*self.universal_table.get_children())
        by_host={profile['host']:self.snapshots.get(profile['id'],{}) for profile in self.profiles}
        for profile in self.router_profiles:
            snap=by_host.get(profile['host'],{});detected=snap.get('vendor','—')
            self.universal_table.insert('','end',iid=profile['id'],values=(profile['name'] or profile['host'],profile['host'],
                PLATFORMS[profile['platform']][0],'Лише пароль' if profile['auth_mode']=='password_only' else 'Логін + пароль/ключ',
                profile['user'] or '—',profile['port'],detected))
        for item in selected:
            if self.universal_table.exists(item):self.universal_table.selection_add(item)
        if self.router_profile_error:self.status.set('Помилка профілів роутерів: '+self.router_profile_error)

    def edit_router_profile(self,editing=False):
        selected=self.universal_table.selection();original=next((p for p in self.router_profiles if selected and p['id']==selected[0]),None) if editing else None
        if editing and not original:return
        defaults={'id':uuid.uuid4().hex,'name':'','host':'','port':22,'platform':'auto','user':'','known_hosts':'','command':'','auth_mode':'username'};defaults.update(original or {})
        win=tk.Toplevel(self.window);win.title('Профіль універсального роутера');body=ttk.Frame(win,padding=16);body.pack(fill='both',expand=True)
        fields=[('name','Назва'),('host','IP / DNS'),('port','SSH-порт'),('platform','Платформа'),('user','SSH користувач'),
            ('known_hosts','Файл known_hosts'),('command','Команда експорту (лише custom)')]
        variables={}
        platform_keys=list(PLATFORMS)
        platform_labels=[PLATFORMS[key][0] for key in platform_keys]
        platform_entry=None
        for row,(key,title) in enumerate(fields):
            initial=PLATFORMS[defaults[key]][0] if key=='platform' else defaults[key]
            ttk.Label(body,text=title).grid(row=row,column=0,sticky='w',pady=5);variable=variables[key]=tk.StringVar(value=initial)
            if key=='platform':
                entry=ttk.Combobox(body,textvariable=variable,values=platform_labels,state='readonly',width=42)
                platform_entry=entry
            else:entry=ttk.Entry(body,textvariable=variable,width=45)
            entry.grid(row=row,column=1,padx=10,pady=5,sticky='ew')
        password_only=tk.BooleanVar(value=defaults.get('auth_mode')=='password_only')
        ttk.Checkbutton(body,text='Лише пароль (без логіна)',variable=password_only).grid(row=7,column=1,sticky='w',padx=10,pady=5)
        feedback=tk.StringVar();ttk.Label(body,textvariable=feedback,wraplength=550).grid(row=8,column=0,columnspan=2,sticky='w')
        def save():
            try:
                values={key:value.get() for key,value in variables.items()}
                index=platform_entry.current()
                if index<0:raise ValueError('Виберіть платформу роутера.')
                values['platform']=platform_keys[index]
                values['auth_mode']='password_only' if password_only.get() else 'username'
                profile=validate_router_profile({'id':defaults['id'],**values})
                self.save_router_profiles([p for p in self.router_profiles if p['id']!=profile['id']]+[profile]);win.destroy()
            except Exception as error:feedback.set(str(error))
        ttk.Button(body,text='Зберегти',command=save).grid(row=9,column=1,sticky='e',pady=10);win.grab_set()

    def selected_router_profile(self):
        selection=self.universal_table.selection()
        if len(selection)!=1:raise ValueError('Виберіть один профіль роутера.')
        return next(profile for profile in self.router_profiles if profile['id']==selection[0])

    def delete_router_profile(self):
        try:profile=self.selected_router_profile()
        except Exception as error:self.status.set(str(error));return
        if messagebox.askyesno('Роутер','Видалити профіль '+(profile['name'] or profile['host'])+'?',parent=self.window):
            try:self.save_router_profiles([item for item in self.router_profiles if item['id']!=profile['id']])
            except Exception as error:self.status.set(str(error))

    def router_session_data(self):
        profile=self.selected_router_profile()
        if profile['platform']=='auto':
            snap=next((self.snapshots.get(item['id']) for item in self.profiles if item['host']==profile['host'] and self.snapshots.get(item['id'])),None)
            if not snap:raise ValueError('Спочатку опитайте цей роутер через SNMP або виберіть платформу вручну.')
            detected=snap.get('platform','custom')
            if detected=='custom':raise ValueError('SNMP не визначив платформу. Виберіть її вручну або використайте custom.')
            profile={**profile,'platform':detected}
        prompt='Пароль роутера (логін не використовується):' if profile['auth_mode']=='password_only' else 'Пароль SSH (залиште порожнім для ключа/ssh-agent):'
        password=simpledialog.askstring('SSH',prompt,show='*',parent=self.window)
        if password is None:return None,None
        if profile['auth_mode']=='password_only' and not password:raise ValueError('Введіть пароль роутера.')
        return profile,password

    def test_router_profile(self):
        try:profile,password=self.router_session_data()
        except Exception as error:self.status.set(str(error));return
        if profile is None:return
        def work():
            with UniversalRouterSession(profile,password) as session:text=session.export()
            return {'bytes':len(text.encode('utf-8')),'lines':len(text.splitlines())}
        self.job('router-test',work,lambda result:messagebox.showinfo('Роутер',f"SSH і команда читання працюють. Рядків: {result['lines']}; bytes: {result['bytes']}",parent=self.window))

    def choose_universal_backup_dir(self):
        path=filedialog.askdirectory(parent=self.window)
        if path:self.universal_backup_dir.set(path)

    def backup_universal_router(self):
        from michman_identity import require
        try:
            require(getattr(self.app,'identity_session',{}).get('role','Viewer'),'backup');profile,ssh_password=self.router_session_data()
        except Exception as error:self.status.set(str(error));return
        if profile is None:return
        archive_password=simpledialog.askstring('Шифрування копії','Пароль архіву, щонайменше 12 символів:',show='*',parent=self.window)
        if not archive_password:return
        directory=self.universal_backup_dir.get()
        def work():
            with UniversalRouterSession(profile,ssh_password) as session:return create_universal_backup(session,directory,archive_password)
        self.job('universal-backup',work,lambda result:messagebox.showinfo('Зашифрована копія','Збережено: '+result['path'],parent=self.window))

    def compare_universal_router_backups(self):
        first=filedialog.askopenfilename(parent=self.window,title='Перша копія',filetypes=[('MICHMAN Router','*.mrouter')])
        if not first:return
        second=filedialog.askopenfilename(parent=self.window,title='Друга копія',filetypes=[('MICHMAN Router','*.mrouter')])
        if not second:return
        first_password=simpledialog.askstring('Перша копія','Пароль першої копії:',show='*',parent=self.window)
        second_password=simpledialog.askstring('Друга копія','Пароль другої копії:',show='*',parent=self.window)
        if first_password is None or second_password is None:return
        def done(diff):
            win=tk.Toplevel(self.window);win.title('Порівняння конфігурацій роутера');win.geometry('1000x650')
            text=tk.Text(win,wrap='none');y=ttk.Scrollbar(win,command=text.yview);x=ttk.Scrollbar(win,orient='horizontal',command=text.xview)
            y.pack(side='right',fill='y');x.pack(side='bottom',fill='x');text.configure(yscrollcommand=y.set,xscrollcommand=x.set);text.pack(fill='both',expand=True)
            text.insert('1.0',diff);text.configure(state='disabled')
        self.job('universal-diff',lambda:compare_universal_backups(first,first_password,second,second_password),done)

    def make_backup(self):
        tab = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(tab, text='Резервні копії роутерів')
        fields = ttk.Frame(tab)
        fields.pack(fill='x')
        ttk.Label(fields, text='Роутер:').grid(row=0, column=0, sticky='w')
        self.router = ttk.Combobox(fields, state='readonly', width=36)
        self.router.grid(row=0, column=1, padx=8, pady=5)
        ttk.Button(fields, text='Оновити список', command=self.refresh_routers).grid(row=0, column=2)
        ttk.Label(fields, text='SSH-порт:').grid(row=1, column=0, sticky='w')
        self.ssh_port = tk.StringVar(value='22')
        ttk.Entry(fields, textvariable=self.ssh_port, width=10).grid(row=1, column=1, sticky='w', padx=8)
        ttk.Label(fields, text='known_hosts (необов’язково):').grid(row=2, column=0, sticky='w', pady=5)
        self.known_hosts = tk.StringVar()
        ttk.Entry(fields, textvariable=self.known_hosts, width=60).grid(row=2, column=1, columnspan=2, padx=8, sticky='ew')
        ttk.Button(fields, text='Обрати', command=self.choose_known_hosts).grid(row=2, column=3)
        self.backup_directory = tk.StringVar(value=str(self.base / 'backups'))
        ttk.Label(fields, text='Папка копій:').grid(row=3, column=0, sticky='w')
        ttk.Entry(fields, textvariable=self.backup_directory, width=60).grid(row=3, column=1, columnspan=2, padx=8)
        ttk.Button(fields, text='Обрати', command=self.choose_backup_directory).grid(row=3, column=3)
        self.router.bind('<<ComboboxSelected>>', lambda _: self.set_router_port())
        self.refresh_routers()
        ttk.Label(tab, text='MikroTik: зашифрований .backup та читабельний .rsc. Інші платформи: зашифрований AES-256-GCM файл .mrouter із безпечною командою експорту.\n'
            'Автоматичне відновлення доступне лише для RouterOS; SSH host key має бути відомим системі або в known_hosts.', wraplength=1030).pack(fill='x', pady=10)
        bar = WrapToolbar(tab)
        bar.pack(fill='x')
        for label, command in [('Створити копію', self.backup_now), ('Оновити список копій', self.refresh_backups),
                               ('Порівняти дві', self.diff_selected), ('Відновити вибрану', self.restore_selected)]:
            ttk.Button(bar, text=label, command=command).pack(side='left', padx=3)
        self.backup_table = self.table(tab, [('date', 'Дата UTC', 210), ('name', 'Пристрій', 160),
            ('version', 'Платформа / версія', 190), ('device', 'Device ID / host', 170), ('state', 'Перевірка', 200)], selectmode='extended')

    def refresh_routers(self):
        self.router_configs = copy.deepcopy(self.app.mikrotik_list)
        self.router['values'] = [f"{c.get('name', '')} ({c.get('host', '')}) — {PLATFORMS.get(c.get('platform', 'mikrotik'), ('SSH', (), ()))[0]}" for c in self.router_configs]
        if self.router_configs:
            self.router.current(0)
            self.set_router_port()

    def set_router_port(self):
        index = self.router.current()
        if index >= 0:
            config = self.router_configs[index]
            self.ssh_port.set(str(config.get('port') or 22))
            self.known_hosts.set(str(config.get('known_hosts') or ''))

    def choose_known_hosts(self):
        path = filedialog.askopenfilename(parent=self.window, title='Файл відомих SSH-ключів known_hosts')
        if path:
            self.known_hosts.set(path)

    def choose_backup_directory(self):
        path = filedialog.askdirectory(parent=self.window)
        if path:
            self.backup_directory.set(path)
            self.refresh_backups()

    def backup_config(self):
        index = self.router.current()
        if index < 0:
            raise ValueError('Спочатку додайте роутер у налаштуваннях головного вікна.')
        config = dict(self.router_configs[index])
        if str(config.get('method', 'SSH')).upper() == 'WEB':
            raise ValueError('Цей роутер керується через веб-панель. Автоматичний експорт залежить від моделі; створіть резервну копію у веб-панелі виробника.')
        config['ssh_port'] = int(self.ssh_port.get())
        if not 1 <= config['ssh_port'] <= 65535:
            raise ValueError('Некоректний SSH-порт.')
        config['known_hosts'] = self.known_hosts.get().strip()
        config.setdefault('platform', 'mikrotik')
        config['auth_mode'] = 'username' if str(config.get('user', '')).strip() else 'password_only'
        if config['platform'] == 'mikrotik' and not config.get('user'):
            config['user'] = 'admin'
            config['auth_mode'] = 'username'
        if config['platform'] == 'auto':
            snap = next((self.snapshots.get(item['id']) for item in self.profiles
                         if item.get('host') == config.get('host') and self.snapshots.get(item['id'])), None)
            if not snap or snap.get('platform') in (None, 'custom'):
                raise ValueError('Для автоматичного профілю спочатку виконайте SNMP-опитування або виберіть платформу вручну.')
            config['platform'] = snap['platform']
        return config

    def backup_now(self):
        from michman_identity import require
        try:
            require(getattr(self.app, 'identity_session', {}).get('role', 'Viewer'), 'backup')
        except PermissionError as error:
            self.status.set(str(error))
            return
        if 'backup' in self.busy:
            return
        try:
            config = self.backup_config()
        except Exception as error:
            self.status.set(str(error))
            return
        generic = config.get('platform') != 'mikrotik'
        minimum = 12 if generic else 8
        extension = '.mrouter' if generic else '.backup'
        password = simpledialog.askstring('Пароль копії', f'Новий пароль шифрування {extension} (мінімум {minimum} символів).\nЗбережіть його: застосунок його не запам’ятовує.', show='*', parent=self.window)
        if not password:
            return
        directory = self.backup_directory.get()
        def work():
            if generic:
                profile = validate_router_profile({
                    'id': config.get('id', uuid.uuid4().hex), 'name': config.get('name', ''),
                    'host': config.get('host', ''), 'port': config['ssh_port'],
                    'platform': config.get('platform', 'custom'), 'user': config.get('user', ''),
                    'auth_mode': config.get('auth_mode', 'username'),
                    'legacy_ssh': config.get('legacy_ssh', False),
                    'known_hosts': config.get('known_hosts', ''), 'command': config.get('command', ''),
                })
                with UniversalRouterSession(profile, config.get('password', '')) as session:
                    return create_universal_backup(session, directory, password)
            with RouterSession(config) as session:
                return create_backup(session, directory, password)
        def done(result):
            self.refresh_backups()
            location = result.get('folder') or result.get('path')
            messagebox.showinfo('Резервна копія', 'Збережено: ' + location + result.get('warning', ''), parent=self.window)
        self.job('backup', work, done)

    def refresh_backups(self):
        if not hasattr(self, 'backup_table'):
            return
        directory = self.backup_directory.get()
        def work():
            result = []
            for path in sorted(Path(directory).glob('*/manifest.json'), reverse=True):
                try:
                    result.append(('mikrotik', str(path.parent), verify_backup(path.parent), None))
                except Exception as error:
                    result.append(('mikrotik', str(path.parent), {}, str(error)))
            for path in sorted(Path(directory).glob('*.mrouter'), reverse=True):
                try:
                    packet = json.loads(path.read_text(encoding='utf-8'))
                    metadata = {key: packet.get(key, '') for key in ('created_at', 'name', 'host', 'platform', 'vendor')}
                    state = 'AES-256-GCM' if packet.get('encrypted') == 'AES-256-GCM' and packet.get('payload') else 'Пошкоджено'
                    result.append(('universal', str(path), metadata, None if state == 'AES-256-GCM' else state))
                except Exception as error:
                    result.append(('universal', str(path), {}, str(error)))
            result.sort(key=lambda row: str(row[2].get('created_at', '')), reverse=True)
            return result
        def done(rows):
            self.backup_table.delete(*self.backup_table.get_children())
            self.backup_paths = {}
            for index, (kind, path, manifest, error) in enumerate(rows):
                key = str(index)
                self.backup_paths[key] = {'kind': kind, 'path': path}
                if kind == 'mikrotik':
                    device = manifest.get('device', {})
                    values = (manifest.get('created_at', Path(path).name), device.get('identity', ''),
                              'RouterOS ' + str(device.get('version', '')), device.get('device_id', ''), error or 'SHA-256 OK')
                else:
                    values = (manifest.get('created_at', Path(path).name), manifest.get('name', ''),
                              manifest.get('vendor') or manifest.get('platform', ''), manifest.get('host', ''), error or 'AES-256-GCM')
                self.backup_table.insert('', 'end', iid=key, values=values)
        self.job('backup-list', work, done)

    def diff_selected(self):
        selected = self.backup_table.selection()
        if len(selected) != 2:
            self.status.set('Виберіть рівно дві копії (Ctrl + клацання).')
            return
        records = [self.backup_paths[key] for key in selected]
        if records[0]['kind'] != records[1]['kind']:
            self.status.set('Порівнювати можна лише копії одного формату.')
            return
        paths = sorted(record['path'] for record in records)
        def done(diff):
            win = tk.Toplevel(self.window)
            win.title('Зміни конфігурації — текстовий експорт')
            win.geometry('1000x650')
            text = tk.Text(win, wrap='none', background='#0b1722', foreground='#e8faff')
            y = ttk.Scrollbar(win, command=text.yview)
            y.pack(side='right', fill='y')
            x = ttk.Scrollbar(win, orient='horizontal', command=text.xview)
            x.pack(side='bottom', fill='x')
            text.configure(yscrollcommand=y.set, xscrollcommand=x.set)
            text.pack(fill='both', expand=True)
            text.insert('1.0', diff)
            text.configure(state='disabled')
        if records[0]['kind'] == 'universal':
            first_password = simpledialog.askstring('Перша копія', 'Пароль першої копії:', show='*', parent=self.window)
            if first_password is None:return
            second_password = simpledialog.askstring('Друга копія', 'Пароль другої копії:', show='*', parent=self.window)
            if second_password is None:return
            work = lambda: compare_universal_backups(paths[0], first_password, paths[1], second_password)
        else:
            work = lambda: compare_backups(*paths)
        self.job('diff', work, done)

    def restore_selected(self):
        from michman_identity import require
        try:
            require(getattr(self.app, 'identity_session', {}).get('role', 'Viewer'), 'backup')
        except PermissionError as error:
            self.status.set(str(error))
            return
        if 'backup' in self.busy:
            return
        selected = self.backup_table.selection()
        if len(selected) != 1:
            self.status.set('Виберіть одну резервну копію.')
            return
        try:
            config = self.backup_config()
        except Exception as error:
            self.status.set(str(error))
            return
        record = self.backup_paths[selected[0]]
        if record['kind'] != 'mikrotik':
            self.status.set('Автоматичне відновлення доступне лише для резервних копій MikroTik RouterOS.')
            return
        if config.get('platform') != 'mikrotik':
            self.status.set('Для відновлення копії RouterOS виберіть MikroTik у списку роутерів.')
            return
        folder = record['path']
        confirmation = simpledialog.askstring('Відновлення та перезавантаження',
            f"Копія: {Path(folder).name}\nЦіль: {config['host']}\nБуде замінено конфігурацію й перезавантажено пристрій.\n"
            f"Для підтвердження введіть: ВІДНОВИТИ {config['host']}", parent=self.window)
        if confirmation != 'ВІДНОВИТИ ' + config['host']:
            return
        password = simpledialog.askstring('Пароль копії', 'Пароль вибраної резервної копії:', show='*', parent=self.window)
        if not password:
            return
        safety_password = simpledialog.askstring('Копія поточного стану', 'Пароль НОВОЇ копії перед відновленням (мінімум 8 символів).\nЗбережіть пароль для можливого повернення.', show='*', parent=self.window)
        if not safety_password:
            return
        directory = self.backup_directory.get()
        def work():
            with RouterSession(config) as session:
                return restore_backup(session, folder, password, directory, safety_password)
        def done(result):
            self.refresh_backups()
            messagebox.showinfo('Стан відновлення', result, parent=self.window)
        self.job('backup', work, done)

    def tick(self):
        if not self.alive:
            return
        if self.snmp_auto.get():
            self.poll_snmp()
        if self.map_auto.get() and time.monotonic() >= self.map_due:
            self.poll_map()
        self.timer = self.window.after(1000, self.tick)


def open_network_center(app, base_dir, protect, unprotect, client_factory):
    existing = getattr(app, 'network_center', None)
    if existing and existing.alive and existing.window.winfo_exists():
        restore(existing.window)
        return
    app.network_center = NetworkCenter(app, base_dir, protect, unprotect, client_factory)
