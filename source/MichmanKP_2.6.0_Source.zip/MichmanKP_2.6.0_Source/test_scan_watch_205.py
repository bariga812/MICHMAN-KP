import subprocess
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import MichmanKP_Protected as main


class ScanWatchCollectionTests(unittest.TestCase):
    def app(self):
        app=object.__new__(main.MichmanKP)
        app.scan_watch_last_error='old error'
        return app

    def test_empty_json_is_normal_result(self):
        completed=SimpleNamespace(returncode=0,stdout='[]',stderr='')
        app=self.app()
        with patch.object(subprocess,'run',return_value=completed) as run:
            self.assertEqual(app._powershell_scan_watch_events(),[])
        script=run.call_args.args[0][-1]
        self.assertIn("NoMatchingEventsFound*",script)

    def test_real_error_is_shortened_for_status(self):
        completed=SimpleNamespace(returncode=1,stdout='',stderr='Get-WinEvent : Access is denied\nAt line:6 char:8\n+ trace\n    + CategoryInfo: PermissionDenied')
        app=self.app()
        with patch.object(subprocess,'run',return_value=completed):
            self.assertEqual(app._powershell_scan_watch_events(),[])
        self.assertEqual(app.scan_watch_last_error,'Get-WinEvent : Access is denied')
        self.assertNotIn('CategoryInfo',app.scan_watch_last_error)

    def test_collection_clears_previous_error(self):
        app=self.app()
        app._powershell_scan_watch_events=lambda _minutes:[]
        app._firewall_log_scan_watch_events=lambda _minutes:[]
        app.analyze_scan_watch_events=lambda events:[]
        app.merge_scan_watch_detections=lambda detections:False
        self.assertEqual(app.collect_scan_watch_once(),([],False,0))
        self.assertEqual(app.scan_watch_last_error,'')

    def test_outbound_wfp_event_is_not_treated_as_scan(self):
        app=self.app()
        event={
            'SourceAddress':'192.168.1.10',
            'DestAddress':'203.0.113.10',
            'DestPort':'443',
            'Direction':'OUTBOUND',
        }
        self.assertIsNone(app._normalize_scan_watch_event(event, {'192.168.1.10'}))


if __name__=='__main__':unittest.main()
