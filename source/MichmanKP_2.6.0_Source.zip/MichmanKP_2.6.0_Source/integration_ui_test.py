import sys
import queue
import tempfile
import time
import tkinter as tk
from pathlib import Path
from types import SimpleNamespace
from michman_network_ui import NetworkCenter
from michman_topology import build_graph
from michman_snmp import validate_profile
from MichmanKP_Protected import protect_secret, unprotect_secret, SingleMikroTikClient

root = tk.Tk()
root.withdraw()
callbacks = queue.Queue()
errors = []
root.report_callback_exception = lambda *args: errors.append(str(args[1]))
app = SimpleNamespace(root=root, mikrotik_list=[], run_on_gui=callbacks.put, identity_session={'role':'Administrator'})
with tempfile.TemporaryDirectory() as directory:
    center = NetworkCenter(app, directory, protect_secret, unprotect_secret, SingleMikroTikClient)
    center.window.withdraw()
    center.snmp_auto.set(False)
    center.map_auto.set(False)
    root.update()
    assert len(center.tabs.tabs()) == 3
    profile = validate_profile({'id': 'test', 'host': '192.0.2.1', 'version': '3', 'user': 'test', 'level': 'noAuthNoPriv'})
    center.save_profiles([profile])
    saved = (Path(directory) / 'snmp_profiles.json').read_text(encoding='utf-8')
    assert '192.0.2.1' in saved
    center.graph = build_graph([{'host': '192.0.2.1', 'name': 'Router', 'tables': {
        'arp': [{'address': '192.0.2.2', 'interface': 'ether1'}]}}])
    center.draw_map()
    assert len(center.canvas.find_all()) >= 5
    center.edit_profile()
    root.update()
    for widget in center.window.winfo_children():
        if isinstance(widget, tk.Toplevel):
            widget.destroy()
    for _ in range(20):
        root.update()
        while not callbacks.empty():
            callbacks.get_nowait()()
        if not center.busy:
            break
        time.sleep(.02)
    center.close()
    root.destroy()
assert not errors, errors
print('Tk: 3 unified tabs, profile dialog, non-secret profile persistence, map drawing, background callback and close OK')
