@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo   MICHMAN KP 2.0.0 DEVICES - NUITKA BUILD
echo ============================================================
echo.

if not exist "MichmanKP_Icon.ico" (
  echo MichmanKP_Icon.ico was not found beside this script.
  goto :error
)

py -m pip install --upgrade pip
if errorlevel 1 goto :error

py -m pip install -r MichmanKP_Protected_requirements.txt
if errorlevel 1 goto :error

py -m nuitka ^
  --mode=standalone ^
  --assume-yes-for-downloads ^
  --enable-plugin=tk-inter ^
  --windows-console-mode=disable ^
  --windows-icon-from-ico=MichmanKP_Icon.ico ^
  --output-dir=dist ^
  --output-filename=MichmanKP_Protected.exe ^
  --company-name="MICHMAN" ^
  --product-name="MICHMAN KP" ^
  --file-description="Network Observability and MikroTik Security Center" ^
  --file-version=2.0.0.0 ^
  --product-version=2.0.0.0 ^
  --copyright="Property of Ihor Stepanenko" ^
  --include-module=michman_license ^
  --include-module=michman_i18n ^
  --include-package=openpyxl ^
  --include-package=paramiko ^
  --include-package=pysnmp ^
  --include-package=pyasn1 ^
  --include-package=Cryptodome ^
  --include-package=psutil ^
  --include-package=PIL ^
  --include-package=pyautogui ^
  MichmanKP_Protected.py
if errorlevel 1 goto :error

echo.
echo ============================================================
echo BUILD COMPLETED
echo Program:
echo dist\MichmanKP_Protected.dist\MichmanKP_Protected.exe
echo.
echo Distribute the whole MichmanKP_Protected.dist folder.
echo Never put OWNER_LICENSE_KEYS.txt into the customer folder.
echo ============================================================
pause
exit /b 0

:error
echo.
echo ============================================================
echo BUILD FAILED. Review the messages above.
echo ============================================================
pause
exit /b 1
