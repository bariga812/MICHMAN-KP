#define AppName "MICHMAN KP"
#define AppVersion "2.6.0"
#ifndef SourceDir
  #define SourceDir "dist\MichmanKP_Protected"
#endif
#ifndef OutputDirPath
  #define OutputDirPath "installer_output"
#endif
[Setup]
AppId={{F5A3A2D4-0E55-4D1A-9D8C-1D4A5C1B1300}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Ihor Stepanenko
DefaultDirName={autopf}\MichmanKP
DefaultGroupName=MICHMAN KP
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir={#OutputDirPath}
OutputBaseFilename=MichmanKP_Setup_2.6.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
LicenseFile=LICENSE_MICHMAN_UA.txt
SetupIconFile=MichmanKP_Icon.ico
UninstallDisplayIcon={app}\MichmanKP_Protected.exe
[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked
[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "START_HERE_2.6.0_UA.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "AGENT_2.2_UA.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "ACCEPTANCE_2.0_UA.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "START_HERE_1.4.0_UA.md"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{group}\MICHMAN KP"; Filename: "{app}\MichmanKP_Protected.exe"
Name: "{autodesktop}\MICHMAN KP"; Filename: "{app}\MichmanKP_Protected.exe"; Tasks: desktopicon
[Run]
Filename: "{app}\MichmanKP_Protected.exe"; Parameters: "--enable-scan-sensor"; StatusMsg: "Configuring the local ScanWatch sensor..."; Flags: runhidden waituntilterminated
Filename: "{app}\MichmanKP_Protected.exe"; Description: "Start MICHMAN KP"; Flags: nowait postinstall skipifsilent

