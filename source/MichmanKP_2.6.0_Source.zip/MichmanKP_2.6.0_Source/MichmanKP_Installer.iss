; MICHMAN KP 2.0.0 — Inno Setup installer
; Build the application folder first with build_MichmanKP_Installer.bat.

#define AppName "MICHMAN KP"
#define AppVersion "2.0.0"
#define AppPublisher "Ihor Stepanenko"
#define AppExeName "MichmanKP_Protected.exe"
#define AppDistDir "dist\MichmanKP_Protected.dist"
#define AppLicenseFile "LICENSE_MICHMAN_UA.txt"
#define AppIconFile "MichmanKP_Icon.ico"

[Setup]
AppId={{F5A3A2D4-0E55-4D1A-9D8C-1D4A5C1B1300}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\Programs\MichmanKP
DefaultGroupName={#AppName}
; Explicit wizard pages: Welcome -> License -> Folder -> Start Menu -> Tasks
; -> Ready -> Install -> Finish.
DisableWelcomePage=no
DisableDirPage=no
DisableProgramGroupPage=no
DisableReadyPage=no
DisableFinishedPage=no
LicenseFile="{#AppLicenseFile}"
SetupIconFile="{#AppIconFile}"
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
OutputDir=installer_output
OutputBaseFilename=MichmanKP_Setup_2.0.0
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#AppName} {#AppVersion}
UninstallDisplayIcon={app}\{#AppIconFile}
SetupLogging=yes
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked

[Files]
; Nuitka standalone output contains the executable and all runtime modules.
Source: "{#AppDistDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#AppIconFile}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\{#AppIconFile}"; IconIndex: 0
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\{#AppIconFile}"; IconIndex: 0; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName}"; WorkingDir: "{app}"; Flags: nowait postinstall skipifsilent

; Deliberately no UninstallDelete entry for %LOCALAPPDATA%\\MichmanKP:
; user monitoring history, configuration and offline license state are kept.
