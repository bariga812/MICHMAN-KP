import asyncio
import sys
from pysnmp.entity import engine, config
from pysnmp.carrier.asyncio.dgram import udp
from pysnmp.entity.rfc3413 import cmdrsp, context
from michman_snmp import SNMPClient


async def main():
    agent = engine.SnmpEngine()
    transport = udp.UdpTransport().open_server_mode(('127.0.0.1', 0))
    config.add_transport(agent, udp.DOMAIN_NAME, transport)
    config.add_v1_system(agent, 'local-test', 'michman-test')
    config.add_vacm_user(agent, 2, 'local-test', 'noAuthNoPriv', (1,))
    config.add_v3_user(agent, 'test-user', config.USM_AUTH_HMAC96_SHA, 'test-auth-123',
                       config.USM_PRIV_CFB128_AES, 'test-priv-123')
    config.add_vacm_user(agent, 3, 'test-user', 'authPriv', (1,))
    ctx = context.SnmpContext(agent)
    cmdrsp.GetCommandResponder(agent, ctx)
    cmdrsp.NextCommandResponder(agent, ctx)
    cmdrsp.BulkCommandResponder(agent, ctx)
    try:
        await asyncio.sleep(0.1)
        port = transport.transport.get_extra_info('sockname')[1]
        for values in [{'version': '2c', 'community': 'michman-test'},
                       {'version': '3', 'user': 'test-user', 'auth_key': 'test-auth-123', 'priv_key': 'test-priv-123'}]:
            profile = {'host': '127.0.0.1', 'port': port, **values}
            result = await SNMPClient(profile).collect(topology=True)
            assert result['name']
            assert result['uptime'] is not None
            print('REAL UDP SNMP', values['version'], 'OK', result['name'])
    finally:
        agent.close_dispatcher()


asyncio.run(main())
