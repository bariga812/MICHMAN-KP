"""Shared on-premise telemetry, dependencies, baseline and incident recorder."""
import csv
import io
import json
import math
import socket
import sqlite3
import threading
import time
import uuid
import zipfile
from pathlib import Path

from michman_utils import safe_csv_cell


class PlatformCore:
    def __init__(self, database, clock=time.time, connection=None, lock=None):
        self.clock, self.lock = clock, lock or threading.RLock()
        self.owns_connection = connection is None
        self.db = connection if connection is not None else sqlite3.connect(str(database), check_same_thread=False, timeout=10)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA busy_timeout=10000')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS p_assets(ip TEXT PRIMARY KEY,name TEXT,first_seen REAL,last_seen REAL,baseline TEXT,latest TEXT);
        CREATE TABLE IF NOT EXISTS p_samples(id INTEGER PRIMARY KEY,ts REAL,ip TEXT,data TEXT);
        CREATE INDEX IF NOT EXISTS p_samples_ip_ts ON p_samples(ip,ts);
        CREATE INDEX IF NOT EXISTS p_samples_ts ON p_samples(ts);
        CREATE TABLE IF NOT EXISTS p_events(id INTEGER PRIMARY KEY,ts REAL,ip TEXT,kind TEXT,severity TEXT,details TEXT,incident TEXT);
        CREATE INDEX IF NOT EXISTS p_events_ts ON p_events(ts);
        CREATE TABLE IF NOT EXISTS p_dependencies(parent TEXT,child TEXT UNIQUE,PRIMARY KEY(parent,child));
        CREATE TABLE IF NOT EXISTS p_incidents(id TEXT PRIMARY KEY,started REAL,updated REAL,root TEXT,severity TEXT,status TEXT,summary TEXT,freeze_until REAL);
        CREATE TABLE IF NOT EXISTS p_affected(incident TEXT,ip TEXT,PRIMARY KEY(incident,ip));
        CREATE TABLE IF NOT EXISTS p_capture(incident TEXT,kind TEXT,item_id INTEGER,ts REAL,ip TEXT,data TEXT,PRIMARY KEY(incident,kind,item_id));
        CREATE TABLE IF NOT EXISTS p_settings(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS p_audit(id INTEGER PRIMARY KEY,ts REAL,actor TEXT,target TEXT,action TEXT,result TEXT);
        ''')
        self.db.commit()
        if 'category' not in {row[1] for row in self.db.execute('PRAGMA table_info(p_incidents)')}:
            self.db.execute("ALTER TABLE p_incidents ADD COLUMN category TEXT DEFAULT 'NETWORK'")
            self.db.commit()
        self.last_maintenance = 0
        self.cooldown = {}
        self.closed = False

    def rows(self, sql, args=()):
        with self.lock:
            return [dict(row) for row in self.db.execute(sql, args)]

    def setting(self, key, default=None):
        rows = self.rows('SELECT value FROM p_settings WHERE key=?', (key,))
        return json.loads(rows[0]['value']) if rows else default

    def set_setting(self, key, value):
        with self.lock, self.db:
            self.db.execute('INSERT OR REPLACE INTO p_settings VALUES(?,?)', (key, json.dumps(value)))

    def audit(self, actor, target, action, result):
        with self.lock, self.db:
            self.db.execute('INSERT INTO p_audit(ts,actor,target,action,result) VALUES(?,?,?,?,?)',
                            (self.clock(), actor, target, action, str(result)[:3000]))
        self.event(target, 'ADMIN_ACTION', 'INFO', f'{actor}: {action}: {str(result)[:500]}', correlate=False)

    def set_dependency(self, parent, child):
        if not parent or not child or parent == child:
            raise ValueError('Вкажіть різні батьківський та підлеглий пристрої.')
        with self.lock, self.db:
            links = {r['child']: r['parent'] for r in self.rows('SELECT * FROM p_dependencies')}
            links[child] = parent
            current, visited = child, set()
            while current in links:
                if current in visited:
                    raise ValueError('Залежність створює цикл.')
                visited.add(current)
                current = links[current]
            self.db.execute('INSERT OR REPLACE INTO p_dependencies VALUES(?,?)', (parent, child))

    def remove_dependency(self, child):
        with self.lock, self.db:
            self.db.execute('DELETE FROM p_dependencies WHERE child=?', (child,))

    def _root(self, ip, now):
        links = {r['child']: r['parent'] for r in self.db.execute('SELECT * FROM p_dependencies')}
        current, result, visited = ip, ip, set()
        while current in links and current not in visited:
            visited.add(current)
            current = links[current]
            recent = self.db.execute("SELECT kind FROM p_events WHERE ip=? AND ts>=? AND kind IN ('OFFLINE','LOSS','LATENCY','FLAPPING','RECOVERED') ORDER BY ts DESC,id DESC LIMIT 1", (current, now-120)).fetchone()
            if recent and recent['kind']!='RECOVERED':
                result = current
        return result

    def _correlate(self, ip, severity, kind, now):
        category = 'NETWORK' if kind in ('OFFLINE','LOSS','LATENCY','FLAPPING') else 'SECURITY' if kind in ('NEW_DEVICE','MAC_CHANGE','IP_CHANGE','SERVICE_CHANGE') else kind
        root = self._root(ip, now) if category=='NETWORK' else ip
        row = self.db.execute("SELECT id FROM p_incidents WHERE root=? AND category=? AND status!='CLOSED' ORDER BY started DESC LIMIT 1", (root,category)).fetchone()
        incident = row['id'] if row else uuid.uuid4().hex[:12]
        if not row:
            self.db.execute('INSERT INTO p_incidents(id,started,updated,root,severity,status,summary,freeze_until,category) VALUES(?,?,?,?,?,?,?,?,?)',
                (incident, now, now, root, severity, 'OPEN', f'{kind}: ймовірне джерело {root}', now+300,category))
            self.db.execute("INSERT OR IGNORE INTO p_capture SELECT ?, 'telemetry',id,ts,ip,data FROM p_samples WHERE ts>=?", (incident, now-600))
            self.db.execute("INSERT OR IGNORE INTO p_capture SELECT ?, 'event',id,ts,ip,details FROM p_events WHERE ts>=?", (incident, now-600))
        self.db.execute('INSERT OR IGNORE INTO p_affected VALUES(?,?)', (incident, ip))
        if root != ip:
            self.db.execute('INSERT OR IGNORE INTO p_affected VALUES(?,?)', (incident, root))
        self.db.execute("UPDATE p_incidents SET updated=?,severity=CASE WHEN severity='CRITICAL' THEN severity ELSE ? END WHERE id=?", (now,severity,incident))
        return incident

    def event(self, ip, kind, severity, details, correlate=True):
        now = self.clock()
        with self.lock, self.db:
            if self.closed:
                return
            incident = self._correlate(ip, severity, kind, now) if correlate and severity in ('WARNING','CRITICAL') else None
            if not incident:
                match = self.db.execute("SELECT a.incident FROM p_affected a JOIN p_incidents i ON i.id=a.incident WHERE a.ip=? AND i.status!='CLOSED' LIMIT 1", (ip,)).fetchone()
                incident = match['incident'] if match else None
            cursor = self.db.execute('INSERT INTO p_events(ts,ip,kind,severity,details,incident) VALUES(?,?,?,?,?,?)',
                (now, ip, kind, severity, str(details)[:8000], incident))
            self.db.execute("INSERT OR IGNORE INTO p_capture SELECT id,'event',?,?,?,? FROM p_incidents WHERE freeze_until>=? AND status!='CLOSED'",
                            (cursor.lastrowid, now, ip, str(details)[:8000], now))
            return incident

    def throttled_event(self, ip, kind, severity, details, seconds=300):
        now = self.clock()
        if now - self.cooldown.get((ip, kind), -math.inf) >= seconds:
            self.cooldown[ip, kind] = now
            return self.event(ip, kind, severity, details)

    def ingest(self, ip, snapshot, name=''):
        now = self.clock()
        allowed = ('online','ping','loss','current_mac','mt_mac','mt_vendor','mt_hostname','tcp_success_ports','primary_mac','mac_addresses',
                   'response_method','cpu_percent','ram_percent','disks','services','os','uptime','agent_id','interfaces','temperature_c','ups','discovery_sources',
                   'router_vendor','router_platform','router_inventory','router_capabilities','router_issues')
        data = {key: snapshot[key] for key in allowed if key in snapshot}
        data['name'] = name or snapshot.get('name') or ip
        encoded = json.dumps(data, ensure_ascii=False, default=str)
        with self.lock, self.db:
            if self.closed:
                return
            old = self.db.execute('SELECT * FROM p_assets WHERE ip=?', (ip,)).fetchone()
            previous = json.loads(old['latest']) if old else {}
            # Agent measurements enrich the same asset rather than erasing ICMP evidence.
            merged = {**previous, **data}
            self.db.execute('INSERT INTO p_assets VALUES(?,?,?,?,?,?) ON CONFLICT(ip) DO UPDATE SET name=excluded.name,last_seen=excluded.last_seen,latest=excluded.latest',
                            (ip,data['name'],now,now,None,json.dumps(merged,ensure_ascii=False)))
            cursor = self.db.execute('INSERT INTO p_samples(ts,ip,data) VALUES(?,?,?)', (now,ip,encoded))
            self.db.execute("INSERT OR IGNORE INTO p_capture SELECT id,'telemetry',?,?,?,? FROM p_incidents WHERE freeze_until>=? AND status!='CLOSED'", (cursor.lastrowid,now,ip,encoded,now))
            if not old:
                self.event(ip,'NEW_DEVICE','WARNING','Новий пристрій у спільному обліку')
                mac=data.get('current_mac') or data.get('mt_mac')
                if mac and mac not in ('—','N/A'):
                    for asset in self.db.execute('SELECT ip,baseline FROM p_assets WHERE ip!=? AND baseline IS NOT NULL',(ip,)):
                        baseline=json.loads(asset['baseline'])
                        expected=baseline.get('current_mac') or baseline.get('mt_mac')
                        if expected and expected.lower()==mac.lower():
                            self.event(ip,'IP_CHANGE','WARNING',f"Відома MAC {mac}: IP {asset['ip']} → {ip}")
            if 'online' in data:
                if data['online'] is False and previous.get('online') is not False:
                    self.event(ip,'OFFLINE','CRITICAL','Втрачено мережеву доступність')
                elif data['online'] is True and previous.get('online') is False:
                    self.event(ip,'RECOVERED','INFO','Мережеву доступність відновлено',False)
                if data.get('ping') is not None and data['ping'] > 200:
                    self.throttled_event(ip,'LATENCY','WARNING',f"Latency {data['ping']:.1f} ms")
                if data.get('loss',0) >= 10:
                    self.throttled_event(ip,'LOSS','WARNING',f"Packet loss {data['loss']:.1f}%")
                transitions = self.db.execute("SELECT COUNT(*) FROM p_events WHERE ip=? AND kind IN ('OFFLINE','RECOVERED') AND ts>=?", (ip,now-300)).fetchone()[0]
                if transitions >= 4:
                    self.throttled_event(ip,'FLAPPING','WARNING',f'{transitions} переходів за 5 хвилин')
            if old and old['baseline']:
                baseline = json.loads(old['baseline'])
                oldmac = baseline.get('current_mac') or baseline.get('mt_mac')
                mac = data.get('current_mac') or data.get('mt_mac')
                if mac and oldmac and mac not in ('—','N/A') and mac.lower() != oldmac.lower():
                    self.throttled_event(ip,'MAC_CHANGE','CRITICAL',f'MAC: {oldmac} → {mac}')
                expected = set(baseline.get('tcp_success_ports', []))
                if 'tcp_success_ports' in data and expected - set(data['tcp_success_ports']):
                    self.throttled_event(ip,'SERVICE_CHANGE','WARNING','Недоступні очікувані TCP: '+str(sorted(expected-set(data['tcp_success_ports']))))
                for service,state in data.get('services',{}).items():
                    expected_state=baseline.get('services',{}).get(service)
                    if expected_state in ('running','active') and state not in ('running','active'):
                        self.throttled_event(ip,'SERVICE_STOPPED:'+service,'WARNING',f'Служба {service}: {state}')
            for key in ('cpu_percent','ram_percent'):
                if data.get(key,0) is not None and data.get(key,0) >= 90:
                    self.throttled_event(ip,key.upper(),'WARNING',f'{key}: {data[key]}%')
            for disk in data.get('disks',[]):
                if disk.get('percent',0) >= 95:
                    self.throttled_event(ip,'DISK_FULL','CRITICAL',f"{disk.get('mountpoint')}: {disk['percent']}%")

    def accept_baseline(self, ip, actor):
        with self.lock, self.db:
            self.db.execute('UPDATE p_assets SET baseline=latest WHERE ip=?', (ip,))
        self.audit(actor,ip,'ACCEPT_BASELINE','OK')

    def link_history(self, ip, seconds):
        values = self.rows('SELECT ts,data FROM p_samples WHERE ip=? AND ts>=? ORDER BY ts', (ip,self.clock()-seconds))
        return [(r['ts'],json.loads(r['data'])) for r in values if 'online' in json.loads(r['data'])]

    def link_metrics(self, ip, seconds):
        history = self.link_history(ip, seconds)
        available = [d for _,d in history if d.get('online') is not None]
        pings = [d['ping'] for d in available if d.get('online') and d.get('ping') is not None]
        jitter = [abs(b['ping']-a['ping']) for (_,a),(_,b) in zip(history,history[1:])
                  if a.get('online') and b.get('online') and a.get('ping') is not None and b.get('ping') is not None]
        outages = sum(a.get('online') is True and b.get('online') is False for (_,a),(_,b) in zip(history,history[1:]))
        return {'samples':len(available),'loss_percent':100*sum(not d['online'] for d in available)/len(available) if available else None,
                'mean_ms':sum(pings)/len(pings) if pings else None,'jitter_ms':sum(jitter)/len(jitter) if jitter else None,
                'uptime_percent':100*sum(bool(d['online']) for d in available)/len(available) if available else None,
                'outages':outages,'history':history}

    def incident_status(self, incident, status, actor):
        if status not in ('OPEN','ACKNOWLEDGED','CLOSED'):
            raise ValueError('Невідомий стан')
        with self.lock,self.db:
            self.db.execute('UPDATE p_incidents SET status=?,updated=? WHERE id=?',(status,self.clock(),incident))
        self.audit(actor,incident,'INCIDENT_'+status,'OK')

    def freeze(self, ip, actor):
        result = self.event(ip,'MANUAL_FREEZE','WARNING',f'Flight Recorder: {actor}')
        return result

    def export_incident(self, incident, path):
        incident_rows = self.rows('SELECT * FROM p_incidents WHERE id=?',(incident,))
        if not incident_rows:
            raise ValueError('Інцидент не знайдено')
        captured = self.rows('SELECT * FROM p_capture WHERE incident=? ORDER BY ts,kind,item_id',(incident,))
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('incident.json',json.dumps(incident_rows[0],ensure_ascii=False,indent=2))
            archive.writestr('timeline.jsonl','\n'.join(json.dumps(r,ensure_ascii=False) for r in captured))
            archive.writestr('affected.json',json.dumps(self.rows('SELECT ip FROM p_affected WHERE incident=?',(incident,))))

    def report(self, path, seconds=86400):
        with open(path,'w',encoding='utf-8-sig',newline='') as handle:
            writer=csv.writer(handle,delimiter=';')
            writer.writerow(['IP','Name','Samples','Loss %','Uptime %','Mean ms','Jitter ms','Outages'])
            for asset in self.rows('SELECT ip,name FROM p_assets ORDER BY ip'):
                m=self.link_metrics(asset['ip'],seconds)
                writer.writerow([safe_csv_cell(v) for v in [asset['ip'],asset['name'],m['samples'],m['loss_percent'],m['uptime_percent'],m['mean_ms'],m['jitter_ms'],m['outages']]])

    def maintenance(self):
        now=self.clock()
        with self.lock,self.db:
            if now-self.last_maintenance < 3600 or self.closed:
                return
            self.db.execute('DELETE FROM p_samples WHERE ts<?',(now-30*86400,))
            self.db.execute('DELETE FROM p_events WHERE ts<?',(now-180*86400,))
            self.last_maintenance=now

    def close(self):
        with self.lock:
            self.closed=True
            if self.owns_connection:self.db.close()


class SyslogReceiver:
    def __init__(self, core, bind='127.0.0.1', port=5514, allowed=()):
        import ipaddress
        self.core,self.bind,self.port=core,bind,int(port)
        self.allowed=[ipaddress.ip_network(item.strip(),strict=False) for item in allowed if item.strip()]
        if bind not in ('127.0.0.1','::1') and not self.allowed:
            raise ValueError('Для мережевого Syslog вкажіть дозволені IP/підмережі.')
        self.stop_event=threading.Event()
        self.socket=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.socket.bind((bind,self.port))
        self.socket.settimeout(.5)
        self.thread=threading.Thread(target=self.loop,daemon=True)
        self.thread.start()

    def loop(self):
        import ipaddress,re
        counts={}
        while not self.stop_event.is_set():
            try:
                packet,address=self.socket.recvfrom(8192)
                ip=address[0]
                if self.allowed and not any(ipaddress.ip_address(ip) in net for net in self.allowed):
                    continue
                bucket=int(time.time())
                if counts.get('bucket') != bucket:
                    counts={'bucket':bucket,'total':0}
                counts['total']+=1
                if counts['total']>100:
                    continue
                text=packet.decode('utf-8',errors='replace')
                match=re.match(r'^<(\d{1,3})>',text)
                priority=int(match.group(1))%8 if match else 6
                severity='CRITICAL' if priority<=2 else 'WARNING' if priority<=4 else 'INFO'
                self.core.event(ip,'SYSLOG',severity,text,correlate=severity!='INFO')
            except socket.timeout:
                continue
            except OSError:
                break

    def close(self):
        self.stop_event.set()
        self.socket.close()
        self.thread.join(timeout=2)
