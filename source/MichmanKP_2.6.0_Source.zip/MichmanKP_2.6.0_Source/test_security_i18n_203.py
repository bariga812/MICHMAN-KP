import ssl
import ast
import tempfile
import unittest
from pathlib import Path

from michman_agent import AgentClient,secure_tls_context
from michman_i18n import LANGUAGE_CODES,Localizer


class SecurityAndLanguageTests(unittest.TestCase):
    def test_agent_client_rejects_unverified_context(self):
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname=False
        context.verify_mode=ssl.CERT_NONE
        with self.assertRaisesRegex(ValueError,'сертифіката'):
            AgentClient('example.invalid',8743,context)

    def test_secure_context_requires_modern_tls_without_compression(self):
        context=secure_tls_context(ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT))
        self.assertGreaterEqual(context.minimum_version,ssl.TLSVersion.TLSv1_2)
        self.assertTrue(context.options & getattr(ssl,'OP_NO_COMPRESSION',0))

    def test_new_windows_translate_in_every_language(self):
        with tempfile.TemporaryDirectory() as directory:
            localizer=Localizer(directory)
            sources=('Керовані ПК','Повний екран (F11)','Передати файли',
                     'Резервні копії MikroTik','ЗУПИНИТИ ВІДДАЛЕНУ ДОПОМОГУ')
            for code in LANGUAGE_CODES:
                localizer.set_language(code)
                for source in sources:
                    translated=localizer.translate(source)
                    if code!='uk':self.assertNotEqual(translated,source,(code,source))

    def test_dynamic_stream_status_translates(self):
        with tempfile.TemporaryDirectory() as directory:
            localizer=Localizer(directory);localizer.set_language('en')
            translated=localizer.translate('18.4 кадрів/с · 55 KiB/кадр · ціль до 20 кадрів/с')
            self.assertIn('fps',translated);self.assertIn('target',translated)

    def test_static_visible_text_in_new_modules_has_english_translation(self):
        localizer=Localizer(tempfile.gettempdir());localizer.code='en'
        untranslated=[]
        directory=Path(__file__).parent
        for name in ('michman_platform_ui.py','michman_network_ui.py','michman_identity.py','michman_agent.py'):
            tree=ast.parse((directory/name).read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if not isinstance(node,ast.Call):continue
                values=[]
                for keyword in node.keywords:
                    if keyword.arg in ('text','title','message') and isinstance(keyword.value,ast.Constant):
                        values.append(keyword.value.value)
                if isinstance(node.func,ast.Attribute) and node.func.attr in ('showinfo','showwarning','showerror','askyesno','askstring','askinteger'):
                    values.extend(arg.value for arg in node.args[:2] if isinstance(arg,ast.Constant))
                for value in values:
                    if isinstance(value,str) and any(ord(char)>127 for char in value):
                        if all(char.isdigit() or char in '× ' for char in value):continue
                        if localizer.translate(value)==value:untranslated.append((name,node.lineno,value))
        self.assertFalse(untranslated,untranslated)


if __name__=='__main__':unittest.main()
