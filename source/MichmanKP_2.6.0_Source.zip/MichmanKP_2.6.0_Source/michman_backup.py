"""Encrypted RouterOS binary backup, readable diff and guarded SSH/SFTP restore."""
import difflib
import hashlib
import json
import os
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from michman_utils import atomic_write_json

MAX_BACKUP_BYTES = 256 * 1024 * 1024


def quote(value):
    value = str(value)
    if any(ord(c) < 32 for c in value):
        raise ValueError('Керівні символи в параметрах RouterOS заборонені.')
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"').replace('$', '\\$') + '"'


def sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def parse_properties(text):
    result = {}
    for line in text.splitlines():
        if ':' in line:
            key, value = line.strip().split(':', 1)
            result[key.strip()] = value.strip()
    return result


class RouterSession:
    def __init__(self, config):
        self.config = dict(config)
        self.client = None

    def __enter__(self):
        import paramiko
        self.client = paramiko.SSHClient()
        self.client.load_system_host_keys()
        known_hosts = self.config.get('known_hosts')
        if known_hosts:
            self.client.load_host_keys(known_hosts)
        self.client.set_missing_host_key_policy(paramiko.RejectPolicy())
        try:
            self.client.connect(hostname=self.config['host'], port=int(self.config.get('ssh_port', 22)),
                username=self.config['user'], password=self.config.get('password') or None,
                timeout=8, auth_timeout=10, banner_timeout=10,
                look_for_keys=not bool(self.config.get('password')), allow_agent=not bool(self.config.get('password')))
        except Exception:
            self.client.close()
            raise
        return self

    def __exit__(self, *args):
        if self.client:
            self.client.close()

    def command(self, command, timeout=60):
        channel = self.client.get_transport().open_session(timeout=10)
        channel.settimeout(2)
        channel.exec_command(command)
        output, errors = bytearray(), bytearray()
        deadline = time.monotonic() + timeout
        try:
            while True:
                if channel.recv_ready():
                    output.extend(channel.recv(65536))
                if channel.recv_stderr_ready():
                    errors.extend(channel.recv_stderr(65536))
                if len(output) + len(errors) > 32 * 1024 * 1024:
                    raise RuntimeError('Відповідь RouterOS перевищила 32 МБ.')
                if channel.exit_status_ready() and not channel.recv_ready() and not channel.recv_stderr_ready():
                    break
                if time.monotonic() > deadline:
                    raise TimeoutError('RouterOS не завершив команду вчасно.')
                time.sleep(0.02)
            text = output.decode('utf-8', errors='replace')
            if channel.recv_exit_status() != 0 or errors or re.search(r'(?im)^\s*(failure:|syntax error|bad command|expected end of command|not enough permissions)', text):
                # Do not include command or device output: it may echo backup passwords.
                raise RuntimeError('RouterOS відхилив команду. Перевірте версію, права та доступність служби.')
            return text
        finally:
            channel.close()

    def metadata(self):
        resource = parse_properties(self.command('/system resource print'))
        identity = parse_properties(self.command('/system identity print'))
        try:
            board = parse_properties(self.command('/system routerboard print'))
        except RuntimeError:
            board = {}
        try:
            license_info = parse_properties(self.command('/system license print'))
        except RuntimeError:
            license_info = {}
        device_id = board.get('serial-number') or license_info.get('system-id') or license_info.get('software-id')
        if not device_id or not resource.get('version'):
            raise RuntimeError('Не вдалося отримати серійний/system/software ID та версію RouterOS.')
        return {'host': self.config['host'], 'identity': identity.get('name', ''),
                'device_id': device_id, 'version': resource['version'],
                'board': resource.get('board-name', board.get('model', ''))}

    def download(self, remote, local):
        with self.client.open_sftp() as sftp:
            sftp.get_channel().settimeout(15)
            deadline = time.monotonic() + 30
            while True:
                try:
                    size = sftp.stat(remote).st_size
                    if size:
                        break
                except OSError:
                    pass
                if time.monotonic() > deadline:
                    raise TimeoutError('Файл резервної копії не з’явився на роутері.')
                time.sleep(0.5)
            if size > MAX_BACKUP_BYTES:
                raise ValueError('Резервна копія перевищує 256 МБ.')
            def progress(transferred, total):
                if transferred > MAX_BACKUP_BYTES or time.monotonic() > deadline + 120:
                    raise TimeoutError('Перевищено ліміт завантаження резервної копії.')
            sftp.get(remote, str(local), callback=progress)
            if Path(local).stat().st_size != size:
                raise IOError('Розмір отриманої резервної копії не збігається.')

    def remove(self, remote):
        with self.client.open_sftp() as sftp:
            sftp.get_channel().settimeout(10)
            sftp.remove(remote)

    def upload(self, local, remote):
        with self.client.open_sftp() as sftp:
            sftp.get_channel().settimeout(15)
            sftp.put(str(local), remote, confirm=True)
            # Verify the bytes stored by the router before invoking restore.
            digest = hashlib.sha256()
            with sftp.open(remote, 'rb') as handle:
                for block in iter(lambda: handle.read(1024 * 1024), b''):
                    digest.update(block)
            if digest.hexdigest() != sha256(local):
                raise IOError('Контрольна сума завантаженого на роутер файлу не збігається.')

    def restore(self, remote, password):
        channel = self.client.get_transport().open_session(timeout=10)
        channel.get_pty(width=200)
        channel.exec_command('/system backup load name=' + quote(remote) + ' password=' + quote(password))
        deadline, output, confirmed = time.monotonic() + 90, '', False
        try:
            while time.monotonic() < deadline:
                if channel.recv_ready():
                    output = (output + channel.recv(65536).decode('utf-8', errors='replace'))[-100000:]
                    if re.search(r'(?i)(failure:|password.*incorrect|invalid.*password|could not restore)', output):
                        raise RuntimeError('RouterOS відхилив відновлення; перевірте пароль копії та сумісність.')
                    if not confirmed and re.search(r'(?i)Restore and reboot\?.*\[y/N\]', output):
                        channel.sendall('y\r\n')
                        confirmed = True
                    if 'rebooting' in output.lower():
                        return 'RouterOS повідомив про перезавантаження. Перевірте доступність і конфігурацію після запуску.'
                if channel.exit_status_ready() or channel.closed:
                    break
                time.sleep(0.05)
            if confirmed:
                return 'Підтвердження відновлення надіслано; остаточний результат не підтверджено. Перевірте роутер після перезавантаження.'
            raise RuntimeError('RouterOS не підтвердив початок відновлення. Результат невідомий; перевірте роутер.')
        finally:
            channel.close()


def create_backup(session, directory, password):
    if len(password) < 8:
        raise ValueError('Пароль резервної копії: щонайменше 8 символів.')
    quote(password)
    metadata = session.metadata()
    base = 'michman_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:8]
    folder = Path(directory) / base
    folder.mkdir(parents=True, exist_ok=False)
    remote = base + '.backup'
    cleanup_warning = ''
    try:
        session.command('/system backup save name=' + quote(base) + ' password=' + quote(password) + ' encryption=aes-sha256 dont-encrypt=no')
        session.download(remote, folder / 'config.backup')
        # Never silently accept an export with missing read permissions.
        major = int(metadata['version'].split('.')[0])
        export = session.command('/export compact ' + ('show-sensitive=no' if major >= 7 else 'hide-sensitive'))
        if not export.strip() or re.search(r'(?im)^\s*#.*(error|failed)', export):
            raise RuntimeError('Текстовий експорт порожній або містить помилки.')
        (folder / 'config.rsc').write_text(export, encoding='utf-8')
        manifest = {'schema': 1, 'created_at': datetime.now(timezone.utc).isoformat(),
            'device': metadata, 'encrypted': True, 'export_sensitive': False,
            'files': {name: sha256(folder / name) for name in ('config.backup', 'config.rsc')},
            'exclusions': ['The Dude database', 'User Manager database', 'external files/containers']}
        atomic_write_json(folder / 'manifest.json', manifest)
    finally:
        try:
            session.remove(remote)
        except Exception:
            cleanup_warning = ' Тимчасовий зашифрований файл міг залишитися на роутері: ' + remote
    return {'folder': str(folder), 'manifest': manifest, 'warning': cleanup_warning}


def verify_backup(folder):
    folder = Path(folder).resolve()
    manifest_path = folder / 'manifest.json'
    if manifest_path.stat().st_size > 65536:
        raise ValueError('Маніфест занадто великий.')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('schema') != 1 or manifest.get('encrypted') is not True:
        raise ValueError('Непідтримуваний формат резервної копії.')
    if set(manifest.get('files', {})) != {'config.backup', 'config.rsc'}:
        raise ValueError('Неповний комплект резервної копії.')
    for name, digest in manifest['files'].items():
        path = folder / name
        if path.resolve().parent != folder or not 0 < path.stat().st_size <= MAX_BACKUP_BYTES:
            raise ValueError('Некоректний файл резервної копії.')
        if sha256(path) != digest:
            raise ValueError('Резервна копія пошкоджена: ' + name)
    if not all(manifest.get('device', {}).get(k) for k in ('device_id', 'version', 'host')):
        raise ValueError('Відсутня ідентифікація пристрою.')
    return manifest


def compare_backups(first, second):
    left, right = verify_backup(first), verify_backup(second)
    if left['device']['device_id'] != right['device']['device_id']:
        raise ValueError('Оберіть дві копії одного пристрою.')
    def lines(folder):
        # Ignore only volatile header comments; command order is meaningful.
        return [line for line in (Path(folder) / 'config.rsc').read_text(encoding='utf-8').splitlines(keepends=True)
                if not line.startswith('#')]
    return ''.join(difflib.unified_diff(lines(first), lines(second),
                   fromfile=left['created_at'], tofile=right['created_at'])) or 'Змін у текстовому експорті немає.\n'


def validate_restore(manifest, device):
    for key in ('device_id', 'version', 'board'):
        if manifest['device'].get(key) != device.get(key):
            raise ValueError('Відновлення заблоковано: не збігається ' + key)


def restore_backup(session, folder, password, safety_directory, safety_password):
    manifest = verify_backup(folder)
    validate_restore(manifest, session.metadata())
    # A verified safety copy must exist before the first restore operation.
    safety = create_backup(session, safety_directory, safety_password)
    verify_backup(safety['folder'])
    remote = 'michman_restore_' + uuid.uuid4().hex + '.backup'
    session.upload(Path(folder) / 'config.backup', remote)
    try:
        outcome = session.restore(remote, password)
    except Exception as error:
        raise RuntimeError(f'{error}\nКопія перед відновленням: {safety["folder"]}') from error
    return outcome + '\nКопія перед відновленням: ' + safety['folder'] + '\nФайл на роутері: ' + remote
