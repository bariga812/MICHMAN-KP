"""Bounded read-only SNMP v2c/v3 collection (PySNMP 7.1)."""
import asyncio
import time
from datetime import datetime, timezone

SYSTEM = '1.3.6.1.2.1.1'
CPU = '1.3.6.1.2.1.25.3.3.1.2'
STORAGE = '1.3.6.1.2.1.25.2.3.1'
IFTABLE = '1.3.6.1.2.1.2.2.1'
IFX = '1.3.6.1.2.1.31.1.1.1'
ARP = '1.3.6.1.2.1.4.22.1'
LLDP = '1.0.8802.1.1.2.1.4.1.1'
TEMPERATURE = '1.3.6.1.4.1.14988.1.1.3.10.0'
SENSORS = '1.3.6.1.2.1.99.1.1.1'
UPS = '1.3.6.1.2.1.33.1'
IPADDR = '1.3.6.1.2.1.4.20.1'
ROUTES = '1.3.6.1.2.1.4.24.4.1'
BRIDGE_PORT = '1.3.6.1.2.1.17.1.4.1'
BRIDGE_FDB = '1.3.6.1.2.1.17.4.3.1'
VLANS = '1.3.6.1.2.1.17.7.1.4.3.1'
ENTITY = '1.3.6.1.2.1.47.1.1.1.1'


def validate_profile(profile):
    p = dict(profile)
    p['host'] = str(p.get('host', '')).strip()
    if not p['host'] or any(c.isspace() for c in p['host']):
        raise ValueError('Вкажіть IP або DNS-ім’я SNMP-пристрою.')
    p['port'] = int(p.get('port', 161))
    p['interval'] = int(p.get('interval', 30))
    if not 1 <= p['port'] <= 65535 or not 10 <= p['interval'] <= 3600:
        raise ValueError('Порт: 1–65535; інтервал: 10–3600 с.')
    if p.get('version') not in ('2c', '3'):
        raise ValueError('Підтримуються SNMP 2c та 3.')
    if p['version'] == '2c':
        if not p.get('community'):
            raise ValueError('Вкажіть community.')
    else:
        if not p.get('user'):
            raise ValueError('Вкажіть користувача SNMP v3.')
        level = p.get('level', 'authPriv')
        if level not in ('noAuthNoPriv', 'authNoPriv', 'authPriv'):
            raise ValueError('Невідомий рівень SNMP v3.')
        if p.get('auth_protocol', 'SHA') not in ('SHA', 'MD5', 'SHA256'):
            raise ValueError('Невідомий протокол автентифікації.')
        if p.get('priv_protocol', 'AES') not in ('AES', 'DES'):
            raise ValueError('Невідомий протокол шифрування.')
        for key in (['auth_key'] if level == 'authNoPriv' else ['auth_key', 'priv_key'] if level == 'authPriv' else []):
            if len(p.get(key, '')) < 8:
                raise ValueError('Паролі SNMP v3 повинні містити щонайменше 8 символів.')
    raw=p.get('extra_oids',[])
    if isinstance(raw,str):raw=[item.strip().lstrip('.') for item in raw.replace(';',',').split(',') if item.strip()]
    if not isinstance(raw,list) or len(raw)>16:raise ValueError('Дозволено до 16 додаткових OID.')
    p['extra_oids']=[]
    for oid in raw:
        oid=str(oid).strip().lstrip('.')
        if not oid or len(oid)>200 or not all(part.isdigit() and 0<=int(part)<=4294967295 for part in oid.split('.')):
            raise ValueError('Додаткові OID повинні бути числовими, через кому.')
        if oid not in p['extra_oids']:p['extra_oids'].append(oid)
    return p


def _value(value):
    from pysnmp.proto.rfc1905 import NoSuchObject, NoSuchInstance, EndOfMibView
    from pyasn1.type.univ import Integer
    if isinstance(value, (NoSuchObject, NoSuchInstance, EndOfMibView)):
        return None
    if isinstance(value, Integer):
        return int(value)
    return value.prettyPrint()


class SNMPClient:
    def __init__(self, profile):
        self.profile = validate_profile(profile)

    async def collect(self, topology=False):
        from pysnmp.hlapi.v3arch import asyncio as snmp
        p = self.profile
        engine = snmp.SnmpEngine()
        try:
            if p['version'] == '2c':
                auth = snmp.CommunityData(p['community'], mpModel=1)
            else:
                level = p.get('level', 'authPriv')
                auths = {'SHA': snmp.usmHMACSHAAuthProtocol, 'MD5': snmp.usmHMACMD5AuthProtocol,
                         'SHA256': snmp.usmHMAC192SHA256AuthProtocol}
                privs = {'AES': snmp.usmAesCfb128Protocol, 'DES': snmp.usmDESPrivProtocol}
                auth = snmp.UsmUserData(p['user'],
                    authKey=p.get('auth_key') if level != 'noAuthNoPriv' else None,
                    privKey=p.get('priv_key') if level == 'authPriv' else None,
                    authProtocol=auths[p.get('auth_protocol', 'SHA')] if level != 'noAuthNoPriv' else snmp.usmNoAuthProtocol,
                    privProtocol=privs[p.get('priv_protocol', 'AES')] if level == 'authPriv' else snmp.usmNoPrivProtocol)
            target_class = snmp.Udp6TransportTarget if ':' in p['host'] else snmp.UdpTransportTarget
            target = await target_class.create((p['host'], p['port']), timeout=2, retries=1)
            context = snmp.ContextData(contextName=p.get('context', ''))
            warnings = []

            async def walk(base, cap=8192):
                data = {}
                async for error, status, _, bindings in snmp.bulk_walk_cmd(
                    engine, auth, target, context, 0, 25,
                    snmp.ObjectType(snmp.ObjectIdentity(base)), lookupMib=False,
                    lexicographicMode=False, maxRows=cap, maxCalls=400):
                    if error or status:
                        raise RuntimeError(str(error or status))
                    for oid, value in bindings:
                        key = str(oid)
                        if not key.startswith(base + '.'):
                            continue
                        data[key] = _value(value)
                        if len(data) >= cap:
                            warnings.append(f'{base}: досягнуто ліміт {cap} OID')
                            return data
                return data

            async def optional(base, cap=8192, timeout=25):
                try:
                    return await asyncio.wait_for(walk(base,cap), timeout=timeout)
                except Exception as error:
                    warnings.append(f'{base}: {error or type(error).__name__}')
                    return {}

            system = await asyncio.wait_for(walk(SYSTEM, 64), timeout=15)
            if not system:
                raise RuntimeError('SNMP не повернув системні дані.')
            bases = [(CPU,2048), (STORAGE,4096), (IFTABLE,8192), (IFX,8192), (SENSORS,4096), (UPS,2048),
                (IPADDR,4096), (ROUTES,8192), (BRIDGE_PORT,4096), (BRIDGE_FDB,8192), (VLANS,4096), (ENTITY,4096)]
            if topology:
                bases += [(ARP,8192), (LLDP,8192)]
            bases += [(oid,1024) for oid in p.get('extra_oids',[])]
            tables = await asyncio.gather(*(optional(base,cap) for base,cap in bases))
            data = dict(system)
            for table in tables:
                data.update(table)
            try:
                error, status, _, bindings = await snmp.get_cmd(engine, auth, target, context,
                    snmp.ObjectType(snmp.ObjectIdentity(TEMPERATURE)), lookupMib=False)
                if not error and not status:
                    for oid, value in bindings:
                        data[str(oid)] = _value(value)
            except Exception:
                pass
            return decode_snapshot(p['host'], data, warnings)
        finally:
            engine.close_dispatcher()

    def poll(self, topology=False):
        async def bounded():
            return await asyncio.wait_for(self.collect(topology), timeout=55)
        return asyncio.run(bounded())


def column(data, base, col):
    prefix = f'{base}.{col}.'
    return {oid[len(prefix):]: value for oid, value in data.items() if oid.startswith(prefix)}


def table_rows(data,base,columns):
    values={name:column(data,base,number) for name,number in columns.items()}
    indices=sorted({index for items in values.values() for index in items})
    return [{**{'index':index},**{name:items.get(index) for name,items in values.items() if items.get(index) is not None}} for index in indices]


def normalized_mac(value,index=''):
    text=str(value or '')
    if text.lower().startswith('0x') and len(text)==14:text=text[2:]
    elif not text and index:
        parts=index.split('.')[-6:]
        if len(parts)==6 and all(part.isdigit() and 0<=int(part)<=255 for part in parts):text=''.join(f'{int(part):02x}' for part in parts)
    compact=''.join(char for char in text if char.lower() in '0123456789abcdef')
    return ':'.join(compact[i:i+2] for i in range(0,12,2)).upper() if len(compact)==12 else str(value or '')


def decode_snapshot(host, data, warnings=()):
    from michman_router_support import identify_router
    identity=identify_router(data.get(SYSTEM+'.1.0',''),data.get(SYSTEM+'.2.0',''))
    cpu = [v for k, v in data.items() if k.startswith(CPU + '.') and isinstance(v, int) and 0 <= v <= 100]
    sizes, used, units = (column(data, STORAGE, c) for c in (5, 6, 4))
    ram_indices = [i for i, value in column(data, STORAGE, 2).items()
                   if str(value).lstrip('.') == '1.3.6.1.2.1.25.2.1.2']
    ram_total = sum(sizes.get(i, 0) * units.get(i, 0) for i in ram_indices)
    ram_used = sum(used.get(i, 0) * units.get(i, 0) for i in ram_indices)
    interfaces = []
    for index, description in column(data, IFTABLE, 2).items():
        get = lambda base, col: data.get(f'{base}.{col}.{index}')
        hc = get(IFX, 6) is not None and get(IFX, 10) is not None
        interfaces.append({'index': index, 'name': get(IFX, 1) or description, 'description':description,
            'alias':get(IFX,18) or '', 'type':get(IFTABLE,3), 'mtu':get(IFTABLE,4),
            'mac':normalized_mac(get(IFTABLE,6)), 'admin_status':get(IFTABLE,7),
            'status': get(IFTABLE, 8), 'last_change':get(IFTABLE,9),
            'speed_bps': (get(IFX, 15) or 0) * 1000000 or get(IFTABLE, 5),
            'rx': get(IFX, 6) if hc else get(IFTABLE, 10),
            'tx': get(IFX, 10) if hc else get(IFTABLE, 16), 'bits': 64 if hc else 32,
            'rx_unicast':get(IFX,7) if hc else get(IFTABLE,11),
            'tx_unicast':get(IFX,11) if hc else get(IFTABLE,17),
            'rx_multicast':get(IFX,8), 'tx_multicast':get(IFX,12),
            'rx_broadcast':get(IFX,9), 'tx_broadcast':get(IFX,13),
            'rx_errors': get(IFTABLE, 14), 'tx_errors': get(IFTABLE, 20),
            'rx_discards': get(IFTABLE, 13), 'tx_discards': get(IFTABLE, 19),
            'unknown_protocols':get(IFTABLE,15), 'out_queue':get(IFTABLE,21),
            'promiscuous':get(IFX,16), 'connector_present':get(IFX,17),
            'discontinuity': get(IFX, 19)})
    arp = [{'address': address, 'mac-address': column(data, ARP, 2).get(index, ''),
            'interface': index.split('.')[0]} for index, address in column(data, ARP, 3).items()]
    neighbors = [{'identity': name, 'interface': index.split('.')[1] if '.' in index else index,
                  'remote-port': column(data, LLDP, 7).get(index, ''),
                  'chassis-id': column(data, LLDP, 5).get(index, '')}
                 for index, name in column(data, LLDP, 9).items()]
    ip_addresses=table_rows(data,IPADDR,{'address':1,'interface_index':2,'netmask':3,'broadcast':4})
    routes=table_rows(data,ROUTES,{'destination':1,'netmask':2,'next_hop':4,'interface_index':5,'type':6,'protocol':7,'age':8,'metric':11})
    bridge_ports={index:value for index,value in column(data,BRIDGE_PORT,2).items()}
    fdb=[]
    for row in table_rows(data,BRIDGE_FDB,{'mac':1,'bridge_port':2,'status':3}):
        row['mac']=normalized_mac(row.get('mac'),row['index']);row['interface_index']=bridge_ports.get(str(row.get('bridge_port')))
        fdb.append(row)
    vlans=table_rows(data,VLANS,{'name':1,'egress_ports':2,'forbidden_ports':3,'untagged_ports':4,'status':5})
    hardware=table_rows(data,ENTITY,{'description':2,'contained_in':4,'class':5,'name':7,'hardware_revision':8,
        'firmware_revision':9,'software_revision':10,'serial_number':11,'manufacturer':12,'model':13,'alias':14,'asset_id':15,'is_fru':16})
    temp = data.get(TEMPERATURE)
    temperatures,sensor_values = [],[]
    sensor_units={1:'other',2:'unknown',3:'VAC',4:'VDC',5:'A',6:'W',7:'Hz',8:'°C',9:'%RH',10:'RPM',11:'m³/min',12:'boolean'}
    for index, kind in column(data, SENSORS, 1).items():
        status=data.get(f'{SENSORS}.5.{index}')
        value, scale, precision = (data.get(f'{SENSORS}.{col}.{index}') for col in (4, 2, 3))
        if all(isinstance(item, int) for item in (value, scale, precision)) and 1 <= scale <= 17 and -8 <= precision <= 9:
            measured=value * 10 ** ((scale - 9) * 3 - precision)
            sensor={'index':index,'type':kind,'unit':sensor_units.get(kind,'unknown'),'value':measured,'status':status}
            sensor_values.append(sensor)
            if kind==8 and status==1:temperatures.append({'index': index, 'celsius': measured})
    ups = {'battery_status': data.get(UPS+'.2.1.0'), 'runtime_minutes': data.get(UPS+'.2.3.0'),
           'charge_percent': data.get(UPS+'.2.4.0'), 'battery_temperature_c': data.get(UPS+'.2.7.0'),
           'output_source': data.get(UPS+'.4.1.0'), 'load_percent': list(column(data, UPS+'.4.4.1', 5).values())}
    ups = {key: value for key, value in ups.items() if value is not None and value != []}
    capabilities={'cpu':bool(cpu),'memory':bool(ram_total),'interfaces':bool(interfaces),'sensors':bool(sensor_values or temp is not None),
        'ip_addresses':bool(ip_addresses),'routes':bool(routes),'arp':bool(arp),'lldp':bool(neighbors),'bridge_fdb':bool(fdb),
        'vlans':bool(vlans),'hardware_inventory':bool(hardware),'ups':bool(ups)}
    return {'host': host, 'name': data.get(SYSTEM + '.5.0') or host,
            'sys_descr': data.get(SYSTEM+'.1.0',''), 'sys_object_id': data.get(SYSTEM+'.2.0',''),
            'sys_contact': data.get(SYSTEM+'.4.0',''), 'sys_location': data.get(SYSTEM+'.6.0',''), **identity,
            'uptime': data.get(SYSTEM + '.3.0'), 'monotonic': time.monotonic(),
            'collected_at': datetime.now(timezone.utc).isoformat(),
            'cpu_percent': sum(cpu) / len(cpu) if cpu else None,
            'ram_total': ram_total or None, 'ram_used': ram_used if ram_total else None,
            'temperature_c': temp / 10 if isinstance(temp, (int, float)) else temperatures[0]['celsius'] if temperatures else ups.get('battery_temperature_c'),
            'temperatures': temperatures, 'sensors':sensor_values, 'ups': ups,
            'interfaces': interfaces, 'ip_addresses':ip_addresses, 'routes':routes, 'arp': arp, 'neighbors': neighbors,
            'bridge_fdb':fdb,'vlans':vlans,'hardware':hardware,'capabilities':capabilities,
            'raw_oids':dict(sorted(data.items())), 'warnings': list(warnings)}


def add_rates(current, previous):
    old = {i['index']: i for i in (previous or {}).get('interfaces', [])}
    elapsed = current['monotonic'] - (previous or {}).get('monotonic', current['monotonic'])
    uptime, prior_uptime = current.get('uptime'), (previous or {}).get('uptime')
    reset = uptime is None or prior_uptime is None or uptime < prior_uptime
    for interface in current['interfaces']:
        before = old.get(interface['index'])
        for direction in ('rx', 'tx'):
            interface[direction + '_bps'] = None
            if not before or elapsed <= 0 or reset:
                continue
            if any(interface.get(k) != before.get(k) for k in ('name', 'bits', 'discontinuity')):
                continue
            value, old_value = interface.get(direction), before.get(direction)
            if value is None or old_value is None:
                continue
            # Unknown counter resets and multiple Counter32 wraps cannot be distinguished safely.
            if value < old_value:
                continue
            speed = interface.get('speed_bps')
            if interface['bits'] == 32 and (not speed or elapsed * speed / 8 >= 2 ** 32):
                continue
            bps = (value - old_value) * 8 / elapsed
            if speed and bps > speed * 1.1:
                continue
            interface[direction + '_bps'] = bps
    return current
