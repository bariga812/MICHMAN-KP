$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
Set-Location -LiteralPath $taskRoot
py -3.12 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'venv failed' }
$taskPython = Join-Path $taskRoot '.venv\Scripts\python.exe'
& $taskPython -m pip install -r requirements-build-tested.txt
if ($LASTEXITCODE -ne 0) { throw 'dependency install failed' }
$taskIcon = Join-Path $taskRoot 'MichmanKP_Icon.ico'
& $taskPython -m PyInstaller --noconfirm --windowed --onedir --name MichmanKP_Protected --specpath build --workpath build\console --distpath dist --icon $taskIcon --paths $taskRoot --collect-all pysnmp --collect-all pyasn1 --collect-all Cryptodome --collect-all paramiko --collect-all openpyxl --collect-all psutil --collect-all PIL --collect-all pyautogui --add-data "$taskIcon;." MichmanKP_Protected.py
if ($LASTEXITCODE -ne 0) { throw 'Console build failed' }
& $taskPython -m PyInstaller --noconfirm --windowed --onedir --name MICHMAN_Agent --specpath build --workpath build\agent --distpath dist --icon $taskIcon --paths $taskRoot --collect-all psutil --collect-all PIL --collect-all pyautogui michman_agent.py
if ($LASTEXITCODE -ne 0) { throw 'Agent build failed' }
$taskCompiler = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'
if (Test-Path -LiteralPath $taskCompiler) {
    & $taskCompiler MichmanKP_Platform.iss
    if ($LASTEXITCODE -ne 0) { throw 'Console installer failed' }
    & $taskCompiler MICHMAN_Agent.iss
    if ($LASTEXITCODE -ne 0) { throw 'Agent installer failed' }
}
Write-Output 'Build complete. See dist and installer_output.'
