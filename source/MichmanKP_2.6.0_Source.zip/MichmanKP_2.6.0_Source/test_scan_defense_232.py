import base64
import os
from pathlib import Path
import tempfile
import time
import unittest
from datetime import datetime
from unittest.mock import Mock, patch

import MichmanKP_Protected as main
import michman_scan_defense as defense


class FirewallCommandTests(unittest.TestCase):
    def test_accepts_canonical_unicast_ipv4(self):
        self.assertEqual(defense.blockable_ipv4(" 192.168.1.25 "), "192.168.1.25")
        self.assertEqual(
            defense.rule_name("192.168.1.25"),
            "MICHMAN KP Scan Defense 192.168.1.25",
        )

    def test_rejects_addresses_that_must_never_be_blocked(self):
        for value in ("127.0.0.1", "0.0.0.0", "224.0.0.1", "255.255.255.255", "not-an-ip", "::1"):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    defense.blockable_ipv4(value)

    def test_encoded_script_only_changes_local_firewall(self):
        encoded = defense._encoded_firewall_script("203.0.113.8", True)
        script = base64.b64decode(encoded).decode("utf-16le")
        self.assertIn("netsh.exe advfirewall firewall", script)
        self.assertIn("remoteip=$ip", script)
        self.assertNotIn("Invoke-WebRequest", script)
        self.assertNotIn("Test-NetConnection", script)

    def test_scan_sensor_enables_only_local_windows_logging(self):
        encoded = defense._encoded_scan_sensor_script()
        script = base64.b64decode(encoded).decode("utf-16le")
        self.assertIn("auditpol.exe", script)
        self.assertIn("Set-NetFirewallProfile", script)
        self.assertIn("-LogBlocked True", script)
        self.assertIn("-LogAllowed True", script)
        self.assertNotIn("Invoke-WebRequest", script)
        self.assertNotIn("Test-NetConnection", script)
        self.assertNotIn("New-NetFirewallRule", script)


class ActivityClassificationTests(unittest.TestCase):
    def setUp(self):
        self.app = object.__new__(main.MichmanKP)

    def test_confirmed_failed_logons_are_access_attempts(self):
        rows = [{"event_category": "AUTH_FAILURE", "target_user": "admin", "protocol": "6"} for _ in range(5)]
        result = self.app._classify_scan_activity(rows, [], 5)
        self.assertEqual(result["scan_type"], "СПРОБИ ОТРИМАННЯ ДОСТУПУ")
        self.assertEqual(result["scan_confidence"], "HIGH")
        self.assertEqual(result["target_users"], ["admin"])

    def test_repeated_remote_management_port_is_possible_access(self):
        rows = [{"event_category": "NETWORK", "protocol": "6"} for _ in range(12)]
        result = self.app._classify_scan_activity(rows, [3389], 12)
        self.assertEqual(result["scan_type"], "ЙМОВІРНА ПЕРЕВІРКА СЛУЖБ ДОСТУПУ")
        self.assertEqual(result["scan_confidence"], "MEDIUM")

    def test_repeated_failed_logons_receive_distinct_alert_type(self):
        rows = [{"event_category": "AUTH_FAILURE", "target_user": "operator", "protocol": "TCP"} for _ in range(10)]
        result = self.app._classify_scan_activity(rows, [], 10)
        self.assertEqual(result["scan_type"], "ПОВТОРНІ НЕВДАЛІ СПРОБИ ВХОДУ")
        self.assertEqual(result["scan_confidence"], "HIGH")

    def test_syn_pattern_is_classified_from_local_firewall_flags(self):
        rows = [{"event_category": "NETWORK", "protocol": "TCP", "tcp_flags": "S"} for _ in range(8)]
        result = self.app._classify_scan_activity(rows, list(range(2000, 2008)), 8)
        self.assertEqual(result["scan_type"], "SYN-ПЕРЕВІРКА TCP-ПОРТІВ")
        self.assertEqual(result["scan_confidence"], "MEDIUM")

    def test_wide_and_sequential_scans_are_distinguished(self):
        rows = [{"event_category": "NETWORK", "protocol": "6"} for _ in range(30)]
        wide = self.app._classify_scan_activity(rows, list(range(1, 31)), 30)
        sequential = self.app._classify_scan_activity(rows[:10], list(range(1000, 1010)), 10)
        self.assertEqual(wide["scan_type"], "ШИРОКЕ СКАНУВАННЯ ПОРТІВ")
        self.assertEqual(sequential["scan_type"], "ПОСЛІДОВНЕ СКАНУВАННЯ ПОРТІВ")

    def test_large_firewall_log_keeps_fields_header(self):
        self.app.scan_watch_last_error = ""
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with tempfile.TemporaryDirectory() as folder:
            log_path = Path(folder) / "System32" / "LogFiles" / "Firewall" / "pfirewall.log"
            log_path.parent.mkdir(parents=True)
            with log_path.open("w", encoding="utf-8") as stream:
                stream.write("#Fields: date time action protocol src-ip dst-ip src-port dst-port size direction\n")
                for _ in range(20005):
                    stream.write("# old line\n")
                stream.write(f"{now} DROP TCP 192.168.1.77 192.168.1.10 50000 445 0 RECEIVE\n")
            with patch.dict(os.environ, {"SystemRoot": folder}):
                rows = self.app._firewall_log_scan_watch_events(10)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["SourceAddress"], "192.168.1.77")
        self.assertEqual(rows[0]["DestPort"], "445")

    def test_records_open_and_closed_port_observations_once(self):
        self.app.scan_watch_lock = main.threading.RLock()
        self.app.scan_watch_probe_records = []
        self.app.get_local_ipv4_addresses = Mock(return_value={"192.168.1.10", "127.0.0.1"})
        self.app.save_scan_watch_probe_records = Mock()
        now = datetime.now().isoformat()
        events = [
            {"Time": now, "EventId": 5156, "RecordId": 10, "SourceAddress": "192.168.1.77", "SourcePort": 50001, "DestAddress": "192.168.1.10", "DestPort": 80, "Protocol": 6, "Direction": "INBOUND", "Action": "ALLOWED"},
            {"Time": now, "EventId": 5157, "RecordId": 11, "SourceAddress": "192.168.1.77", "SourcePort": 50002, "DestAddress": "192.168.1.10", "DestPort": 445, "Protocol": 6, "Direction": "INBOUND", "Action": "BLOCKED"},
        ]
        self.assertEqual(self.app.record_scan_watch_probe_events(events), 2)
        self.assertEqual(self.app.record_scan_watch_probe_events(events), 0)
        self.assertEqual({row["result"] for row in self.app.scan_watch_probe_records}, {"ДОЗВОЛЕНО", "ЗАБЛОКОВАНО"})

    def test_same_observation_merges_multiple_sensor_sources(self):
        self.app.scan_watch_lock = main.threading.RLock()
        self.app.scan_watch_probe_records = []
        self.app.get_local_ipv4_addresses = Mock(return_value={"192.168.1.10", "127.0.0.1"})
        self.app.save_scan_watch_probe_records = Mock()
        now = datetime.now().isoformat()
        common = {"Time": now, "SourceAddress": "192.168.1.77", "SourcePort": 51000, "DestAddress": "192.168.1.10", "DestPort": 443, "Protocol": 6, "Direction": "INBOUND"}
        events = [
            {**common, "EventId": 5156, "Action": "ALLOWED", "EvidenceSource": "Windows Security / Filtering Platform"},
            {**common, "EventId": "SYSMON-3", "Action": "OBSERVED", "EvidenceSource": "Sysmon Event 3"},
        ]
        self.assertEqual(self.app.record_scan_watch_probe_events(events), 1)
        row = self.app.scan_watch_probe_records[0]
        self.assertIn("Sysmon Event 3", row["evidence_source"])
        self.assertIn("Windows Security", row["evidence_source"])
        self.assertEqual(row["result"], "ДОЗВОЛЕНО")

    def test_powershell_collector_contains_three_read_only_sources(self):
        self.app.scan_watch_last_error = ""
        completed = Mock(returncode=0, stdout="[]", stderr="")
        with patch.object(main.subprocess, "run", return_value=completed) as run:
            self.assertEqual(self.app._powershell_scan_watch_events(1), [])
        script = run.call_args.args[0][-1]
        self.assertIn("Microsoft-Windows-Sysmon/Operational", script)
        self.assertIn("Get-NetTCPConnection", script)
        self.assertIn("LogName='Security'", script)
        self.assertNotIn("New-NetFirewallRule", script)
        self.assertNotIn("Test-NetConnection", script)

    def test_scan_correlation_does_not_double_count_sensor_duplicates(self):
        self.app.get_local_ipv4_addresses = Mock(return_value={"192.168.1.10", "127.0.0.1"})
        now = datetime.now().isoformat()
        events = []
        for index, port in enumerate(range(1000, 1008)):
            common = {"Time": now, "SourceAddress": "192.168.1.77", "SourcePort": 52000 + index, "DestAddress": "192.168.1.10", "DestPort": port, "Protocol": "TCP", "Direction": "INBOUND"}
            events.append({**common, "EventId": 5156, "Action": "ALLOWED", "EvidenceSource": "Windows Security / Filtering Platform"})
            events.append({**common, "EventId": "SYSMON-3", "Action": "OBSERVED", "EvidenceSource": "Sysmon Event 3"})
        detections = self.app.analyze_scan_watch_events(events)
        self.assertEqual(len(detections), 1)
        self.assertEqual(detections[0]["attempts"], 8)
        self.assertIn("Sysmon Event 3", detections[0]["evidence"])
        self.assertIn("Windows Security", detections[0]["evidence"])


class ActiveDetectionTests(unittest.TestCase):
    def app(self):
        app = object.__new__(main.MichmanKP)
        app.scan_watch_last_alert = {}
        app.scan_watch_block_attempts = {}
        app.scan_defense_settings = {
            "realtime_alerts": True,
            "auto_block": True,
            "trusted_ips": [],
        }
        app.run_on_gui = Mock()
        app._apply_scan_firewall_action = Mock(return_value=(True, "ok"))
        app._update_scan_defense_record = Mock()
        return app

    def detection(self, age=0):
        return {
            "source_ip": "203.0.113.8",
            "last_ts": time.time() - age,
            "attempts": 30,
            "unique_ports": 12,
            "level": "MEDIUM",
            "ports": [22, 80, 443],
        }

    def test_fresh_detection_alerts_and_blocks(self):
        app = self.app()
        detection = self.detection()
        app.process_active_scan_detections([detection])
        self.assertEqual(app.run_on_gui.call_count, 1)
        app._apply_scan_firewall_action.assert_called_once()
        self.assertEqual(app._apply_scan_firewall_action.call_args.args[:2], ("203.0.113.8", True))

    def test_stale_detection_is_not_presented_as_live(self):
        app = self.app()
        app.process_active_scan_detections([self.detection(age=main.SCAN_WATCH_ACTIVE_SECONDS + 5)])
        app.run_on_gui.assert_not_called()
        app._apply_scan_firewall_action.assert_not_called()

    def test_trusted_source_is_never_blocked(self):
        app = self.app()
        app.scan_defense_settings["trusted_ips"] = ["203.0.113.8"]
        app.process_active_scan_detections([self.detection()])
        app._apply_scan_firewall_action.assert_not_called()
        app._update_scan_defense_record.assert_called_once_with(
            "203.0.113.8", "TRUSTED", "IP є у списку довірених."
        )

    def test_identical_alert_is_rate_limited(self):
        app = self.app()
        detection = self.detection()
        now = time.time()
        self.assertTrue(app._scan_alert_due(detection, now=now))
        self.assertFalse(app._scan_alert_due(detection, now=now + 1))


if __name__ == "__main__":
    unittest.main()
